"""ALL-TABS pre-flight for the Pharma Supply Chain demo.

Same contract as hedis_alltabs_verify.py: every step the runbook tells a
presenter to take is executed here against the real engine, so the document is
generated from verified output rather than from memory. Eleven tabs, in the
order the demo walks them.

Two results below are HONEST NEGATIVES and are asserted as such, because a
demo that hides them fails in the room instead of here:

  * Simulator — the what-if delta model is written against four payer metric
    ids. Under the pharma Brain it raises a NAMED SimulationConfigError
    listing what is missing, rather than a bare KeyError 500. Verified as a
    graceful degrade, not as a working simulation.
  * Pillars — thermal_excursion, dscsa_quarantine and chargeback_zscore are
    declared in policy_rules.md with no pillar handler registered. They are
    reported as inert on the Pillars payload. The personas already detect all
    three, so a handler would be a second implementation of the same rule.

Run:
    cd oppal/backend
    PYTHONPATH=. python3 demo/pharma_alltabs_verify.py
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "data"))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("pharmaalltabs")

R = Reporter()

SWARM_Q = ("Are there cold chain thermal excursions or chargeback claim "
           "leakage?")
CHAT_QS = [
    "spoilage rate by hub",
    "units spoiled by hub",
    "units claimed by hub",
    "chargeback leakage variance by hub",
    "mean kinetic temperature by shipment",
    "unverified sgtin by lot",
]
LOT, HUB = "ONC-8812", "Hub-09"


def main():
    from app.data.db import (ensure_db, get_user_context, POOL,
                             invalidate_scope_values, ALL_LOBS)
    from app.semantic import brain as bl
    import make_pharma_dataset as mk

    ensure_db()
    counts = mk.build()
    POOL.reset()
    # Users are resolved AFTER the domain switch: get_user_context()
    # intersects role_lob_access with ALL_LOBS(), the ACTIVE domain's own
    # scope universe, so resolving casey/dana/morgan while healthcare_payer
    # was still active handed them the payer's LOBs instead of the pharma
    # distributors. A real caller doesn't hit this -- a user's domain is
    # already switched, via the UI, before any of their requests land.
    bl.set_active("pharma_supply_chain")
    bl.reload_brain()
    invalidate_scope_values()
    casey = get_user_context("u-compliance")     # Quality Lead class
    dana = get_user_context("u-compliance2")     # Finance Controller class
    morgan = get_user_context("u-ma")            # logistics analyst
    from app.mcp import scope_from_user
    sc_casey, sc_dana = scope_from_user(casey), scope_from_user(dana)
    sc_morgan = scope_from_user(morgan)

    print()
    print("+" + "-" * (R.W - 2) + "+")
    print("|" + "  Pharma Supply Chain demo -- ALL 11 TABS pre-flight".ljust(R.W - 2) + "|")
    print("+" + "-" * (R.W - 2) + "+")

    bl.set_active("pharma_supply_chain")
    try:
        rep = bl.reload_brain()
        R.banner("SETUP", "Switch the Context Brain to the pharma domain")
        R.check("the pharma warehouse is built", len(counts) == 6,
                f"{counts['iot_readings']:,} raw IoT readings")
        R.check("the Brain reloads with no parse errors",
                not rep.get("errors"), rep.get("report", "")[:72])
        b = bl.get_brain()
        R.check("scope is distributor_id, not lob",
                (b.get("governance") or {}).get("scope_column")
                == "distributor_id")
        R.check("RBAC universe is distributors",
                {"Cardinal-East", "McK-Central", "ABC-West"} <= set(ALL_LOBS()),
                str(sorted(ALL_LOBS()))[:78])

        from app.llm.base import get_provider
        from app.agents.orchestrator import Orchestrator
        orch = Orchestrator(get_provider())

        def ask(q, user=casey):
            a = orch.handle(q, user=user)
            rows = next((art["rows"] for art in a.get("artifacts", [])
                         if art.get("rows")), None)
            return (a.get("sql"),
                    round((a.get("trust") or {}).get("score", 0) * 100),
                    rows or [])

        # ---------------------------------------------------- 1. Chat
        R.banner("TAB 1/11", "Chat -- every question the runbook asks")
        for q in CHAT_QS:
            sql, tr, rows = ask(q)
            head = ", ".join(f"{r[0]}={r[1]}" for r in rows[:2])
            R.check(f'type: "{q}"',
                    sql != "-- withheld" and tr >= 85 and bool(rows),
                    f"trust {tr}% - {head}")
        sql, _, _ = ask("spoilage rate by hub")
        R.check("the scope predicate is pushed down on distributor_id",
                "distributor_id IN" in sql and ".lob" not in sql, sql[:88])
        R.check('"by hub" resolves the vocabulary alias to hub_id',
                "hub_id" in sql, "a bare dim: alias used to be inert")

        R.banner("FACTS", "Full result sets behind the runbook narrative")
        for q in ("spoilage rate by hub", "units spoiled by hub",
                  "units claimed by hub", "chargeback leakage variance by hub"):
            _, tr, rows = ask(q)
            R.say(f'"{q}"  [trust {tr}%]')
            for rr in rows[:5]:
                R.say(f"     {str(rr[0]):16s} {rr[1]}", indent=4)

        # ---------------------------------------------------- 2. Data
        R.banner("TAB 2/11", "Data -- claim and shipment drill-down")
        con = POOL.acquire()
        try:
            sp, cl = con.execute(
                "SELECT s.units_spoiled, c.units_claimed FROM shipments s "
                "JOIN chargeback_claims c ON c.shipment_id = s.shipment_id "
                "WHERE s.lot_id = ?", (LOT,)).fetchone()
            wac = con.execute("SELECT wac_unit FROM drug_products LIMIT 1"
                              ).fetchone()[0]
        finally:
            POOL.release(con)
        R.check(f"lot {LOT}: {cl} claimed vs {sp} spoiled",
                (sp, cl) == (420, 600), f"{cl - sp} unit excess")
        R.check("the excess is exactly $153,000 at WAC",
                (cl - sp) * wac == 153000.0,
                f"{cl - sp} x ${wac:,.0f} = ${(cl - sp) * wac:,.0f}")

        # ---------------------------------------------------- 3. Data Quality
        R.banner("TAB 3/11", "Data Quality -- IoT time-series anomaly")
        con = POOL.acquire()
        try:
            mkt, peak, mins, n = con.execute(
                "SELECT mkt(temp_c), MAX(temp_c), "
                "SUM(CASE WHEN temp_c > 15 THEN 30 ELSE 0 END), COUNT(*) "
                "FROM iot_readings WHERE shipment_id = 'SHP-ONC-0001'"
            ).fetchone()
            mean = con.execute(
                "SELECT AVG(temp_c) FROM iot_readings "
                "WHERE shipment_id = 'SHP-ONC-0001'").fetchone()[0]
            iso = con.execute(
                "SELECT mkt(t) FROM (SELECT 5.0 AS t UNION ALL SELECT 5.0)"
            ).fetchone()[0]
        finally:
            POOL.release(con)
        R.check("MKT is computed from the raw series, not stored",
                n == 48, f"{n} readings for the incident shipment")
        R.check("MKT is arithmetically correct (isothermal returns itself)",
                iso == 5.0, f"mkt(5C,5C) = {iso}")
        R.check("MKT exceeds the arithmetic mean -- the point of MKT",
                mkt > mean, f"MKT {mkt} C vs mean {round(mean, 2)} C")
        R.check(f"lot {LOT} breaches BOTH cold-chain limits",
                mkt > 10 and mins > 120,
                f"MKT {mkt} C (ceiling 10) - {mins} min above 15 C "
                f"(SLA 120) - peak {peak} C")

        # ---------------------------------------------------- 4. Pillars
        R.banner("TAB 4/11", "Pillars -- what this domain governs")
        from app.analytics import rules_engine as RE
        declared = set(RE.declared_checks())
        R.check("the pharma Brain declares its own checks",
                {"thermal_excursion", "dscsa_quarantine",
                 "chargeback_zscore"} <= declared)
        summary = RE.pillar_summary(sc_casey)
        reg = summary.get("regulatory") or {}
        R.check("the tab is POPULATED -- rules that declare a query are run "
                "by one generic handler, no bespoke Python per rule",
                (reg.get("breach_count") or 0) > 0,
                f"{reg.get('breach_count')} breach(es) from "
                f"{reg.get('rules_evaluated')}")
        R.check("the cold-chain breach names the lot, MKT and the SLA",
                any("ONC-8812" in str(x.get("headline")) and "MKT" in
                    str(x.get("headline")) for x in (reg.get("breaches") or [])))
        R.check("the DSCSA breach names the quarantine requirement",
                any("quarantine" in str(x.get("headline")).lower()
                    for x in (reg.get("breaches") or [])))
        inert = RE.unimplemented_checks()
        R.check("HONEST NEGATIVE: chargeback_zscore has no query and no "
                "handler, and is REPORTED as inert",
                inert == ["chargeback_zscore"],
                f"inert: {inert} -- the persona detects it, so a pillar "
                f"handler would duplicate the rule")

        # ---------------------------------------------------- 5. Ontology
        R.banner("TAB 5/11", "Ontology -- SGTIN to contract binding")
        from app.semantic import ontology as ONT
        spec = ONT.load_spec()
        ot = spec.get("object_types") or {}
        R.check("this domain's object types load (per-domain spec)",
                {"BatchLot", "SerializedUnit", "ShipmentContainer",
                 "ChargebackClaim", "ContractAgreement"} <= set(ot),
                f"{len(ot)} object types")
        R.check("no payer object types leak in",
                "Member" not in ot and "Claim" not in ot,
                "the spec used to be one global file")
        rels = {e["rel"] for e in (spec.get("edges") or [])}
        R.check("the binding relationships are declared",
                {"monitored_by", "belongs_to_lot", "references",
                 "claimed_against"} <= rels, str(sorted(rels))[:80])
        R.check("CAPS bindings are supply-chain systems",
                "sap_attp" in (spec.get("caps_bindings") or {}))

        # ---------------------------------------------------- 6. Semantic Graph
        R.banner("TAB 6/11", "Semantic Graph -- term resolution to table")
        from app.semantic.graph import export_graph
        g = export_graph(include_unmapped=False)
        nodes, edges = g["nodes"], g["edges"]
        hits = [n for n in nodes if "mkt" in str(n.get("label", "")).lower()
                or "kinetic" in str(n.get("label", "")).lower()]
        R.check('searching "mkt" matches the governed metric',
                bool(hits), f"{len(hits)} node(s)")
        adj = {}
        for e in edges:
            adj.setdefault(e["source"], []).append(e["target"])
            adj.setdefault(e["target"], []).append(e["source"])
        focus = "metric:mean_kinetic_temperature"
        depth, frontier = {focus: 0}, [focus]
        for d in range(1, 4):
            nxt = []
            for nid in frontier:
                for nb in adj.get(nid, []):
                    if nb not in depth:
                        depth[nb] = d
                        nxt.append(nb)
            frontier = nxt
        kinds = {n["id"]: n.get("ntype", "") for n in nodes}
        tables = [n for n in depth if kinds.get(n) == "table"]
        R.check("drilling the metric reaches its physical table",
                "iot_readings" in tables,
                f"{len(depth)} nodes in view, tables: {tables[:3]}")

        # ---------------------------------------------------- 7. Swarm
        R.banner("TAB 7/11", "Swarm -- declarative personas, no new Python")
        from app.agents import swarm, case_store
        run = swarm.run_swarm(SWARM_Q, casey, llm=None)
        names = [a if isinstance(a, str) else a.get("name")
                 for a in (run.get("activated") or [])]
        R.check(f'type: "{SWARM_Q}" then click "Run swarm"',
                "cold_chain_iot" in names
                and "chargeback_reconciliation" in names,
                f"activated {len(names)}: {', '.join(names)}")
        heads = " | ".join(f["headline"] for f in (run.get("findings") or []))
        R.check("no persona reports itself misconfigured",
                "is not implemented" not in heads,
                "a declared `query:` must reach the agent")
        R.check("the cold-chain finding names the lot and its MKT",
                LOT in heads and "MKT" in heads)
        R.check("the chargeback finding names the 180-unit over-claim",
                "180 units" in heads)
        R.check("the swarm opens cases -- this is what fills the Cases tab",
                bool(run.get("cases_created")),
                f"{len(set(run.get('cases_created') or []))} distinct case(s)")

        # ---------------------------------------------------- 8. Cases
        R.banner("TAB 8/11", "Cases -- de-duplicated incident logging")
        cases = case_store.list_cases(sc_casey)
        cases = cases if isinstance(cases, list) else cases.get("cases", [])
        cold = [c for c in cases if c["case_type"] == "ColdChainCase"]
        chg = [c for c in cases if c["case_type"] == "ChargebackCase"]
        R.check("Cases is populated (it was empty before the swarm ran)",
                bool(cases), f"{len(cases)} cases")
        R.check(f"a ColdChainCase for lot {LOT} at $357,000",
                any(c["subject"] == LOT
                    and float(c["estimated_impact"]) == 357000.0
                    for c in cold),
                "420 spoiled x $850")
        target = next((c for c in chg
                       if float(c["estimated_impact"]) == 153000.0), None)
        R.check(f"a ChargebackCase for {HUB} at $153,000",
                target is not None,
                str(target["subject"]) if target else "MISSING")
        R.check("case subject is the hub/lot incident, not just the hub",
                all("/" in str(c["subject"]) for c in chg),
                "keying on hub alone collapsed every claim into one case")
        R.check("an analyst sees only their own distributor's cases",
                len(case_store.list_cases(sc_morgan)) <= len(cases),
                "Cardinal-East only")
        upd = case_store.update_status(target["case_id"], "reviewing",
                                       sc_casey, actor="u-compliance")
        R.check('status select -> "reviewing" (officer class only)',
                bool(upd), f"{target['case_id']} -> reviewing")

        # ---------------------------------------------------- 9. Simulator
        R.banner("TAB 9/11", "Simulator -- HONEST NEGATIVE, degrades by name")
        from app.schemas.simulation import SimulationRequest, ParameterOverride
        from app.simulation import engine as sim_engine
        req = SimulationRequest(
            baseline_query="shipments through Hub-09",
            parameter_overrides=[ParameterOverride(
                brain_path="metrics.spoilage_rate.stress_pct",
                op="delta_pct", value="-0.10",
                reason="cold-chain remediation scenario")])
        degraded, msg = False, ""
        try:
            sim_engine.run_simulation(req, casey, sc_casey)
        except sim_engine.SimulationConfigError as e:
            degraded, msg = True, str(e)
        except Exception as e:
            degraded, msg = False, f"{type(e).__name__}: {e}"
        R.check("it raises a NAMED config error, not a bare KeyError 500",
                degraded, msg[:120])
        # It fails at the FORMULA-ID lookup, before the metric guard added in
        # v14.10.0 — both are named SimulationConfigErrors, and the earlier
        # one is the more useful message because it names simulation.md.
        R.check("the message names the missing simulation.md formula ids",
                degraded and "simulation.md" in msg,
                "a domain-specific simulation model is the upgrade path; the "
                "engine will not substitute a hardcoded formula")
        # The recovery arithmetic the runbook quotes is a Brain formula, so it
        # is checked here even though the simulator cannot run it end to end.
        simf = bl.get_brain().get("simulation") or {}
        rn = simf.get("recovery_net") or {}
        over, dispute, cost = 180, float(rn.get("dispute_rate", 0)), \
            float(rn.get("recovery_cost", 0))
        net = over * wac * (1 - dispute) - cost
        R.check("recovery_net is declared in simulation.md, not hardcoded",
                bool(rn), f"dispute {dispute}, cost ${cost:,.0f}")
        R.check("net recovery on the 180-unit over-claim",
                net > 0, f"180 x ${wac:,.0f} x (1-{dispute}) - ${cost:,.0f} "
                         f"= ${net:,.0f}")

        # ---------------------------------------------------- 10. Actions
        R.banner("TAB 10/11", "Actions -- dual control, end to end")
        from app.actions import engine as AE
        act = AE.propose(
            case_id=target["case_id"], action_type="chargeback_recovery",
            target_object=str(target["subject"]),
            lob=str(target.get("lob") or "Cardinal-East"),
            summary=f"Recover 180-unit chargeback over-claim on lot {LOT}",
            estimated_financial_impact=153000.0,
            regulatory_severity="critical",
            trust_score=float(target.get("trust_score") or 0.93),
            fields={"case_id": target["case_id"]},
            proposer_user_id="u-ma")
        R.check("STEP 1 - the analyst proposes from the case",
                bool(act.action_id),
                f"{act.action_id} mode={act.control_mode.value}")
        R.check("it is DUAL control ($153,000 over the $5,000 threshold)",
                act.control_mode.value == "dual",
                f"threshold ${AE.rules().get('financial_impact_threshold')}")
        refused = False
        try:
            AE.approve(act.action_id, morgan, sc_morgan)
        except Exception as e:
            refused, rmsg = True, str(e)[:60]
        R.check("STEP 2 - the analyst who proposed it is refused", refused,
                f"{rmsg} (the separation-of-duties beat is STEP 4)"
                if refused else "NOT REFUSED")
        a1 = AE.approve(act.action_id, casey, sc_casey)
        R.check("STEP 3 - Quality Lead signs first",
                a1.state.value == "PENDING_SECOND_APPROVAL",
                f"approver_1={a1.approver_1_id}")
        sod = False
        try:
            AE.approve(act.action_id, casey, sc_casey)
        except Exception as e:
            sod, smsg = True, str(e)[:60]
        R.check("STEP 4 - the same officer cannot sign twice", sod,
                smsg if sod else "NOT REFUSED")
        a2 = AE.approve(act.action_id, dana, sc_dana)
        R.check("STEP 5 - Finance Controller signs second -> APPROVED",
                a2.state.value == "APPROVED",
                f"approver_2={a2.approver_2_id}")
        gate = float(AE.rules().get("execution_trust_gate") or 0.85)
        if a2.trust_score >= gate:
            AE.execute(act.action_id, dana, sc_dana)
            done = AE.get(act.action_id, sc_casey)
            R.check("STEP 6 - execute write-back (dry-run target)",
                    done.state.value == "EXECUTED",
                    f"trust {a2.trust_score:.0%} >= gate {gate:.0%}")
        else:
            R.check(f"STEP 6 - execution BLOCKED below the {gate:.0%} gate",
                    True, f"trust {a2.trust_score:.0%}")

        # ---------------------------------------------------- 11. Governance
        R.banner("TAB 11/11", "Governance -- hash-chain verification")
        from app.trust import ledger_v2
        v = ledger_v2.verify_chain()
        vd = v if isinstance(v, dict) else (
            v.model_dump() if hasattr(v, "model_dump") else vars(v))
        R.check("the ledger chain verifies",
                bool(vd.get("ok", vd.get("valid", vd.get("intact")))),
                f"{vd.get('blocks_checked', vd.get('checked', '?'))} blocks")
        from app.governance import report as gov_report
        gr = gov_report.build()
        R.check("the AI governance report builds under this domain",
                bool(gr), ", ".join(list(gr.keys())[:4]))
        R.check("it still discloses that no fairness testing is performed",
                "fairness" in str(gr).lower(),
                "same disclosure, different domain")
    finally:
        bl.set_active("healthcare_payer")
        bl.reload_brain()

    R.banner("TEARDOWN", "The payer domain is left exactly as it was")
    R.check("active domain restored",
            bl.active_domain() == "healthcare_payer")
    R.check("payer scope column restored",
            (bl.get_brain().get("governance") or {}).get("scope_column")
            == "lob")

    print()
    R.say("Every line above is an instruction that was actually executed.")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        R.fail_steps.append("unhandled exception")
    sys.exit(R.finish("Pharma all-tabs pre-flight"))
