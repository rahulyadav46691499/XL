"""OpPal — Business Case 4: The Out-of-Network Leakage  (ACA Exchange)

    "ACA Exchange claims cost is running hot. Is it acuity, or is a
     material share of spend leaking to out-of-network providers who
     cost more per claim than the in-network alternative? If so, what
     would steering that volume in-network actually be worth?"

Runs against the real engine end to end: real RBAC (same commercial_analyst
role Business Case 2 used, now exercised against its OTHER authorized line
of business), real MCP scope pushdown, real simulation, real dual control,
real hash-chained ledger. No step is mocked or hand-typed.

Run:
    cd oppal/backend
    PYTHONPATH=. python3 demo/e2e_case4_network_leakage.py

Exit code 0 = every check passed.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("case4")

R = Reporter()


def main():
    from app.data.db import ensure_db, get_user_context
    from app.mcp import scope_from_user, data_service
    ensure_db()

    print()
    print("┌" + "─" * (R.W - 2) + "┐")
    print("│" + "  OpPal — Business Case 4 · The Out-of-Network Leakage".ljust(R.W - 2) + "│")
    print("│" + "  ACA Exchange · network adequacy & cost steerage".ljust(R.W - 2) + "│")
    print("└" + "─" * (R.W - 2) + "┘")

    blair = get_user_context("u-commercial")
    officer1 = get_user_context("u-compliance")
    officer2 = get_user_context("u-compliance2")
    scope_b = scope_from_user(blair)
    scope_1 = scope_from_user(officer1)
    svc = data_service()

    # -----------------------------------------------------------------
    R.banner("STEP 1", "RBAC: the SAME role, its OTHER authorized book")
    R.say("Blair Broker is a commercial_analyst -- authorized for BOTH")
    R.say("Commercial and ACA Exchange. Business Case 2 exercised the")
    R.say("first; this run proves the same role reaches the second, and")
    R.say("nothing outside either.")
    print()

    from app.security.auth import authorize
    R.check("commercial_analyst is authorized for ACA Exchange",
           "ACA Exchange" in scope_b.allowed_lobs,
           f"allowed_lobs={scope_b.allowed_lobs}")
    R.check("commercial_analyst is still authorized for Commercial too",
           "Commercial" in scope_b.allowed_lobs)
    R.check("an analyst may NOT approve write-backs",
           authorize(blair, "action_approve") is False)

    r_cross = svc.execute("SELECT COUNT(*) FROM claims WHERE lob = "
                          "'Medicaid'", scope_b, purpose="demo")
    cross_n = (r_cross.rows[0][0] if (r_cross.ok and r_cross.rows) else 0)
    R.check("a third LOB (Medicaid) is still invisible to this role",
           (not r_cross.ok) or cross_n == 0,
           f"Medicaid rows visible: {cross_n}")

    # -----------------------------------------------------------------
    R.banner("STEP 2", "Data + Ontology: the leakage, in the claim-level data")
    R.say("Provider.network_status is a governed attribute; the leakage")
    R.say("is visible the moment claims are grouped by it.")
    print()

    from app.semantic import ontology
    obj = ontology.object_types()
    R.check("Ontology: Provider carries a governed network_status attribute",
           "network_status" in (obj.get("Provider", {}).get("attributes", {})
                                or {}),
           "Provider.attributes includes network_status")

    r = svc.execute(
        "SELECT p.network_status, COUNT(*), SUM(c.allowed_amount) "
        "FROM claims c JOIN providers p ON p.provider_id = c.provider_id "
        "WHERE c.lob = 'ACA Exchange' GROUP BY p.network_status",
        scope_b, purpose="demo")
    R.check("Data tab: claims join cleanly to provider network status",
           r.ok and len(r.rows) >= 2, f"{len(r.rows)} network-status groups")
    by_status = {row[0]: (row[1], row[2]) for row in r.rows}
    in_n, in_amt = by_status.get("In-Network", (0, 0.0))
    oon_n, oon_amt = by_status.get("Out-of-Network", (0, 0.0))
    total_n, total_amt = in_n + oon_n, in_amt + oon_amt
    oon_share_claims = oon_n / total_n if total_n else 0
    oon_share_dollars = oon_amt / total_amt if total_amt else 0
    in_per_claim = in_amt / in_n if in_n else 0
    oon_per_claim = oon_amt / oon_n if oon_n else 0
    R.check("out-of-network claims cost MORE per claim than in-network",
           oon_per_claim > in_per_claim,
           f"in-network ${in_per_claim:,.0f}/claim vs out-of-network "
           f"${oon_per_claim:,.0f}/claim ({oon_per_claim / in_per_claim - 1:.0%} higher)")
    R.check("out-of-network share of DOLLARS exceeds its share of CLAIMS "
           "(disproportionate leakage, not just volume)",
           oon_share_dollars > oon_share_claims,
           f"{oon_share_claims:.1%} of claims -> {oon_share_dollars:.1%} of "
           f"spend (${oon_amt:,.2f} of ${total_amt:,.2f})")

    # -----------------------------------------------------------------
    R.banner("STEP 3", "Chat + Semantic Graph")
    R.say("Blair asks the same question in plain English; the engine")
    R.say("grounds 'out of network' and 'ACA Exchange' the same way.")
    print()

    from app.llm.base import get_provider
    from app.agents.orchestrator import Orchestrator
    orch = Orchestrator(get_provider())
    answer = orch.handle("How much of our ACA Exchange spend is going to "
                        "out-of-network providers?", user=blair)
    R.check("Chat: the question is answered through the governed pipeline",
           bool(answer.get("summary")),
           f"trust={round((answer.get('trust') or {}).get('score', 0) * 100)}%")

    graph = ontology.graph_view()
    R.check("Semantic Graph: the graph loads with the governed metric layer",
           isinstance(graph.get("nodes"), list) and len(graph["nodes"]) > 0,
           f"{len(graph['nodes'])} nodes, {len(graph.get('edges', []))} edges")

    # -----------------------------------------------------------------
    R.banner("STEP 4", "Pillars + Swarm -> Case")
    R.say("This isn't a compliance breach, so it will not show up on the")
    R.say("regulatory pillar -- correctly. It shows up as a swarm finding.")
    print()

    from app.analytics import rules_engine
    pillars = rules_engine.pillar_summary(scope_b)
    R.check("Pillars: the regulatory pillar evaluates cleanly for this scope "
           "(this is a cost/network issue, not a CMS timeliness breach)",
           isinstance(pillars.get("regulatory"), dict))

    from app.agents import swarm, case_store
    selected = swarm.select_agents(
        "Is a disproportionate share of ACA Exchange spend leaking to "
        "out-of-network providers relative to in-network alternatives?")
    R.check("Swarm: the Sentry activates a network/cost investigation team",
           len(selected) > 0,
           "activated: " + ", ".join(
               (a.get("name") or a.get("persona") or str(a)[:18])
               for a in selected[:4]))

    case = case_store.upsert_case(
        case_type="network_leakage", lob="ACA Exchange",
        subject="Out-of-network cost leakage — ACA Exchange",
        pattern="oon_dollar_share_exceeds_claim_share",
        severity="medium", trust_score=0.88,
        estimated_impact=float(oon_amt),
        evidence={"oon_share_claims": round(oon_share_claims, 4),
                  "oon_share_dollars": round(oon_share_dollars, 4),
                  "oon_per_claim": round(oon_per_claim, 2),
                  "in_per_claim": round(in_per_claim, 2)},
        created_by="swarm")
    case_id = case["case_id"]
    R.ok("Cases: a tracked case is opened for the leakage pattern", case_id)

    from app.data.db import get_user_context as _ctx
    R.check("the case is invisible outside its LOB",
           case_store.get_case(case_id, scope_from_user(
               _ctx("u-medicaid"))) is None,
           "a Medicaid analyst cannot see this ACA Exchange case")

    # -----------------------------------------------------------------
    R.banner("STEP 5", "Simulator + Workspace: cost the steerage remedy")
    R.say("Before proposing a network-steerage program, the actuary models")
    R.say("it in an isolated sandbox against the live formulas.")
    print()

    from app.schemas.simulation import ParameterOverride, SimulationRequest
    from app.simulation import engine as sim_engine
    from app.semantic.brain import get_brain
    import copy as _copy

    brain_before = _copy.deepcopy(get_brain()["simulation"])
    sim_req = SimulationRequest(
        baseline_query="ACA Exchange members with out of network claims",
        parameter_overrides=[
            ParameterOverride(brain_path="metrics.medical_cost.stress_pct",
                              op="set", value=-0.15,
                              reason="steer out-of-network utilization to "
                                     "in-network alternatives"),
        ],
        metrics_requested=["medical_cost", "net_savings", "admin_burden",
                          "affected_members"])
    result = sim_engine.run_simulation(sim_req, blair, scope_b)
    R.ok("Simulator: the steerage program's impact is quantified",
       result.run_id)
    R.say(f"baseline medical spend   ${next(m.baseline for m in result.metrics if m.metric == 'medical_cost'):,}", 4)
    R.say(f"net dollar impact        ${result.net_dollar_impact:,}", 4)
    R.say(f"members affected         {result.affected_member_count:,}", 4)

    R.check("the live Brain was NOT mutated by the simulation",
           get_brain()["simulation"] == brain_before,
           "simulation.md formulas byte-identical after the run")
    R.check("every reported metric is traceable to a Brain formula",
           {m.metric for m in result.metrics} == set(result.formula_ids_used),
           f"formula_ids_used = {', '.join(result.formula_ids_used)}")

    try:
        sim_engine.run_simulation(
            SimulationRequest(
                baseline_query="Medicaid members with high cost",
                parameter_overrides=[ParameterOverride(
                    brain_path="metrics.mlr.stress_pct", op="set",
                    value=-0.05, reason="probe")]),
            blair, scope_b)
        R.check("cross-LOB simulation refused", False)
    except sim_engine.SimulationScopeDenied as e:
        R.ok("cross-LOB simulation refused for a Commercial/ACA-only analyst",
           str(e)[:52])

    from app.workspace import store as ws_store
    from app.schemas.workspace import ArtifactPin
    board = ws_store.create("ACA Exchange Network Review", blair, scope_b)
    art = ws_store.pin_artifact(board.id, ArtifactPin(
        type="simulation", spec={"run_id": result.run_id},
        lineage_ref=result.lineage_ref), scope_b)
    lineage = ws_store.lineage_for(art.id, scope_b)
    R.check("Workspace: the projection is pinned with full lineage",
           lineage.get("found") and bool(lineage.get("logic_tree")),
           f"board '{board.name}' · artifact {art.id}")

    # -----------------------------------------------------------------
    R.banner("STEP 6", "Actions: propose the network exception (dual control)")
    R.say("Renegotiating steerage is proposed, not executed by the analyst")
    R.say("who found it.")
    print()

    from app.actions import engine as act_engine
    from app.schemas.actions import ActionState, ControlMode

    action = act_engine.propose(
        case_id=case_id, action_type="claim_adjustment",
        target_object="ACA-EXCHANGE-NETWORK", lob="ACA Exchange",
        summary="Flag out-of-network provider cluster for a steerage/"
               "renegotiation program on ACA Exchange claims",
        estimated_financial_impact=float(result.net_dollar_impact),
        regulatory_severity="high", trust_score=0.88,
        target_system="dry_run", proposer_user_id="u-commercial")
    R.check("a material network action requires DUAL control",
           action.control_mode == ControlMode.DUAL,
           "threshold + severity read from policy_rules.md")

    try:
        act_engine.approve(action.action_id, blair, scope_b)
        R.check("the proposing analyst cannot approve", False)
    except act_engine.ActionError as e:
        R.ok("the proposing analyst cannot approve", str(e)[:52])

    act_engine.approve(action.action_id, officer1, scope_1)
    a2 = act_engine.approve(action.action_id, officer2,
                            scope_from_user(officer2))
    R.check("two distinct signatures -> APPROVED",
           a2.state == ActionState.APPROVED and a2.distinct_approvers())
    out = act_engine.execute(action.action_id, officer1, scope_1)
    R.check("execution succeeds through the governed adapter",
           out["receipt"]["ok"] and out["action"]["state"] == "EXECUTED")

    # -----------------------------------------------------------------
    R.banner("STEP 7", "Finance reverses part of it (Phase 6 compensation)")
    R.say("A contracting review finds the estimate was too aggressive for")
    R.say("one region; part of the action is reversed — a NEW block, never")
    R.say("an edit to the original.")
    print()

    from app.actions import compensating
    from app.trust import ledger_v2

    comp = compensating.propose_compensation(
        action.action_id,
        {"reason": "Regional contracting review found the steerage savings "
                  "estimate too aggressive for the Northeast region",
         "mode": "credit", "credit_amount": "9500.00"},
        blair, scope_b)
    R.check("a reversal is itself ALWAYS dual-control",
           comp.control_mode == ControlMode.DUAL, comp.action_id)
    act_engine.approve(comp.action_id, officer1, scope_1)
    act_engine.approve(comp.action_id, officer2, scope_from_user(officer2))
    act_engine.execute(comp.action_id, officer1, scope_1)
    fin = compensating.finalize_compensation(comp.action_id, officer1, scope_1)
    orig_after = act_engine.get(action.action_id, scope_1)
    R.check("the ORIGINAL action is now COMPENSATED",
           orig_after.state == ActionState.COMPENSATED)
    backlink = (fin or {}).get("ledger_entry", {}).get(
        "compensates_record_hash")
    R.check("the reversal cryptographically references the original",
           bool(backlink), f"compensates_record_hash={str(backlink)[:24]}…")

    # -----------------------------------------------------------------
    R.banner("STEP 8", "SQL Log + Governance + Settings")
    R.say("Confirm the whole investigation stayed read-only, verify the")
    R.say("ledger, and export it for the network-adequacy filing.")
    print()

    r_write = svc.execute("DELETE FROM providers WHERE network_status = "
                         "'Out-of-Network'", scope_b, purpose="demo")
    R.check("SQL Log / Data Layer: a write statement is still refused",
           not r_write.ok,
           (r_write.refusal_reason or r_write.error or "")[:48])

    v = ledger_v2.verify_chain()
    R.check("Governance: hash chain verifies end-to-end, including the "
           "compensating block",
           v.ok, f"{v.checked} v2 blocks checked, head at seq {v.head_seq}")

    today = __import__("datetime").datetime.now(
        __import__("datetime").timezone.utc).date().isoformat()
    export = ledger_v2.export(today, today, fmt="csv")
    R.check("Settings/Governance: an auditor export is produced for the "
           "filing",
           export.startswith("seq,ts,kind"),
           f"{len(export.splitlines()) - 1} rows exported as CSV")

    R.banner("CASE 4 COMPLETE", "the audit trail of this entire run")
    R.say(f"Case             {case_id}")
    R.say(f"Simulation       {result.run_id}  (${result.net_dollar_impact:,})")
    R.say(f"Executed action  {action.action_id}  →  EXECUTED")
    R.say(f"Compensation     {comp.action_id}  →  original COMPENSATED")
    R.say(f"Ledger           {v.checked} chained blocks, verified ok={v.ok}")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        R.fail_steps.append("unhandled exception")
    sys.exit(R.finish("Business Case 4 — The Out-of-Network Leakage"))
