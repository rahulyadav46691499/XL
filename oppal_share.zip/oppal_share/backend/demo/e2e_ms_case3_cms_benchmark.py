"""OpPal — Medicare Sales Business Case 3: The CMS Market Benchmark
    (Medicare Advantage · onboarding an external file, market penetration)

    "Sales leadership wants to know whether the Southwest shortfall is
     OpPal's problem or the market's. Answering that needs a source the
     plan does not hold: the CMS monthly MA/Part D enrolment file by
     contract, plan, state and county. It arrives as a CSV, and it has
     to be governed like every other table rather than pivoted in a
     spreadsheet."

Runs against the real engine end to end: real CSV import, real column
profiling, real join suggestion, real auto-onboarding into the Context
Brain, real data-quality remediation, real hash-chained ledger.

Run:
    cd oppal_stage/backend
    PYTHONPATH=. python3 demo/e2e_ms_case3_cms_benchmark.py

Exit code 0 = every check passed.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("mscase3")

import _medicare as MS  # noqa: E402

R = Reporter()

CSV_PATH = os.path.join(os.path.dirname(__file__), "data",
                        "cms_market_enrollment.csv")
# The three contracts the file is known to be thin on. Asserted rather than
# described, so a regenerated fixture cannot quietly invalidate the document.
GAP_CONTRACTS = {"H3390", "S5678", "E7712"}


BRAIN_FILES = ("entities.md", "reference.md", "metrics.md", "vocabulary.md")


def main():
    cast = MS.setup()
    # Auto-onboarding WRITES to the domain's own Brain markdown. That is the
    # real product behaviour and the case is about exercising it -- but a demo
    # script must not leave the repo dirty, so the files are restored on the
    # way out and the restore is asserted.
    brain_before = {f: _brain_path(f).read_text()
                    for f in BRAIN_FILES}
    MS.title(R, "OpPal - Medicare Sales Business Case 3 - The CMS Market "
                "Benchmark",
             "Medicare Advantage - onboarding an external file end to end")

    try:
        # ------------------------------------------------------------------
        R.banner("STEP 1", "Context Brain -- the file is DECLARED before it "
                           "arrives")
        R.say("reference.md lists it under External Files, so the importer")
        R.say("has a documented destination instead of being a one-off.")
        print()
        from app.semantic import brain as bl
        ext = bl.read_file(MS.DOMAIN, "reference.md")
        R.check("the warehouse loaded first, without this file",
                len(cast.counts) == 11,
                f"{cast.rows:,} rows across {len(cast.counts)} tables")
        R.check("the CMS file is declared in the Brain as an external source",
                "cms_market_enrollment" in ext and "External Files" in ext,
                "declared, not improvised")
        R.check("its known data-quality defect is declared too",
                "plan_type is blank" in ext,
                "the gap is documented before anyone finds it")

        # ------------------------------------------------------------------
        R.banner("STEP 2", "Data -- import the file the way the tab does")
        from app.data import importer
        from app.data.db import POOL
        R.check("the source file exists and is non-trivial",
                os.path.exists(CSV_PATH) and os.path.getsize(CSV_PATH) > 1000,
                os.path.relpath(CSV_PATH, os.path.dirname(__file__)))
        out = importer.import_files(
            [("cms_market_enrollment.csv", open(CSV_PATH, "rb").read())])
        POOL.reset()
        R.check("the file imports as a new governed-catalog table",
                len(out) == 1 and out[0]["ok"] and out[0]["rows"] == 900,
                f"table={out[0].get('table')}, rows={out[0].get('rows')}")
        table = out[0]["table"]
        sug = out[0].get("suggested_joins", [])
        R.check("the importer profiles it and suggests joins back to the "
                "existing model",
                len(sug) > 0,
                f"{len(sug)} suggested join(s), e.g. {sug[0]['join']}"
                if sug else "none")

        from app.data.importer import data_status
        status = data_status()
        row = next((t for t in status["tables"] if t["name"] == table), None)
        R.check("Data Layer: it is catalogued alongside the eleven loaded "
                "tables",
                row is not None and row["origin"] in ("imported",
                                                      "core schema"),
                f"origin={row['origin'] if row else '?'}, "
                f"{len(status['tables'])} tables catalogued")

        # ------------------------------------------------------------------
        R.banner("STEP 3", "Data Quality -- the declared gap, found generically")
        R.say("The scanner does not know this table exists ahead of time. It")
        R.say("finds the gap reference.md warned about, from first principles.")
        print()
        from app.data import quality
        miss = quality.missing_report()
        hit = next((m for m in miss if m["table"] == table
                    and m["column"] == "plan_type"), None)
        R.check("the missing-value scan flags plan_type in the new table",
                hit is not None and hit["missing"] == 149,
                f"{hit['missing']} / {hit['total']} rows ({hit['pct']}%)"
                if hit else "not found")
        R.check("the measured gap matches what the Brain declared",
                hit is not None and abs(hit["pct"] - 16.6) < 0.1,
                "16.6% declared, 16.6% measured")

        from app.mcp import data_service
        svc = data_service()
        r = svc.execute(
            f"SELECT contract_id, SUM(CASE WHEN plan_type IS NULL OR "
            f"TRIM(CAST(plan_type AS TEXT)) = '' THEN 1 ELSE 0 END) blanks "
            f"FROM {table} GROUP BY contract_id ORDER BY blanks DESC LIMIT 3",
            cast.sc_morgan, purpose="demo")
        worst = {row[0] for row in r.rows}
        R.check("the gap concentrates in the three declared contracts",
                worst == GAP_CONTRACTS, f"worst three: {sorted(worst)}")

        dry = quality.impute(table, "plan_type", "mode", dry_run=True)
        R.check("a dry run previews the fill without writing",
                dry["ok"] and dry["would_fill"] == hit["missing"],
                dry["message"])
        still_blank = _blank_count(svc, cast.sc_morgan, table)
        R.check("the dry run really did not write",
                still_blank == 149, f"{still_blank} rows still blank")
        real = quality.impute(table, "plan_type", "mode", dry_run=False,
                              user_id="u-ma")
        POOL.reset()
        R.check("applying the fill writes exactly those rows, attributed",
                real["ok"] and real["filled"] == hit["missing"],
                f"filled {real.get('filled')} rows with "
                f"'{real.get('fill_value')}'")
        R.check("the column is no longer reported missing",
                not any(m["table"] == table and m["column"] == "plan_type"
                        for m in quality.missing_report()))

        # ------------------------------------------------------------------
        R.banner("STEP 4", "Context Brain + Semantic Graph -- auto-onboarding")
        R.say("The same step the Data tab triggers after every import, so the")
        R.say("table is queryable immediately -- uncertified until reviewed.")
        print()
        from app.semantic import onboarding, graph as sgraph
        nodes_before = len(sgraph.export_graph()["nodes"])
        joins = [j["brain_snippet"] for res in out if res.get("ok")
                 for j in res.get("suggested_joins", [])]
        ob = onboarding.onboard_tables([table], joins, user_id="u-ma",
                                       llm=None)
        R.check("the new table is drafted into the Context Brain",
                table in (ob.get("tables") or [])
                or "already" in str(ob.get("notes", "")),
                str(ob.get("brain_report", ""))[:70])
        g = sgraph.export_graph()
        R.check("the knowledge graph rebuilds without crashing on it",
                isinstance(g.get("nodes"), list) and len(g["nodes"]) > 0,
                f"{nodes_before} -> {len(g['nodes'])} nodes")
        R.check("it joins the Tables band, not the metric or document layer",
                any(n["ntype"] == "table" and n["label"] == table
                    for n in g["nodes"]),
                "an imported source is a table like any other")

        # ------------------------------------------------------------------
        R.banner("STEP 5", "Chat -- the market question the file was for")
        ask = MS.asker(cast.morgan)
        _, trust, rows = ask("qualified lead rate by market")
        R.check('the existing model still answers after the import',
                trust >= 85 and len(rows) > 0,
                f"trust {trust}% - onboarding did not destabilise the Brain")
        pen = svc.execute(
            f"SELECT state, ROUND(AVG(penetration_rate), 4) p FROM {table} "
            f"GROUP BY state ORDER BY p DESC LIMIT 3", cast.sc_morgan,
            purpose="demo")
        R.check("the benchmark itself is now queryable through the same gate",
                pen.ok and len(pen.rows) == 3,
                "top penetration: " + ", ".join(
                    f"{s}={p}" for s, p in pen.rows) if pen.ok else "")

        # ------------------------------------------------------------------
        R.banner("NEGATIVE CONTROL", "An imported table is not a back door")
        r_w = svc.execute(f"DELETE FROM {table}", cast.sc_morgan,
                          purpose="demo")
        R.check("a write against the newly imported table is still refused",
                not r_w.ok,
                (r_w.refusal_reason or r_w.error or "")[:56])
        R.check("importing a file did not create an ungoverned path",
                not r_w.ok,
                "the read-only contract covers imported tables too")

        # ------------------------------------------------------------------
        R.banner("STEP 6", "SQL Log + Governance -- the import is on the record")
        from app.data.db import SQL_LOG
        stmts = list(SQL_LOG)
        writes = [s for s in stmts
                  if not str(s.get("sql", "")).lstrip().upper()
                  .startswith("SELECT") and s.get("ok")]
        R.check("exactly ONE write happened in the whole session, and it is "
                "the data-quality fill",
                len(writes) == 1
                and "UPDATE cms_market_enrollment" in writes[0]["sql"]
                and "plan_type" in writes[0]["sql"],
                str(writes[0]["sql"])[:66] if writes else "no write logged")
        R.check("every other statement -- import, profile, analysis -- was a "
                "SELECT",
                len(stmts) - len(writes) == len(stmts) - 1,
                f"{len(stmts)} statements, 1 write, all attributed in the log")
        from app.trust import ledger_v2
        v = ledger_v2.verify_chain()
        vd = v if isinstance(v, dict) else (
            v.model_dump() if hasattr(v, "model_dump") else vars(v))
        R.check("the hash chain verifies after import, fill and onboarding",
                bool(vd.get("ok", vd.get("valid", vd.get("intact")))),
                f"{vd.get('blocks_checked', vd.get('checked', '?'))} blocks")
    finally:
        from app.semantic import brain as bl2
        for f, text in brain_before.items():
            _brain_path(f).write_text(text)
        bl2.reload_brain()
        R.banner("RESTORE", "The Context Brain is left exactly as it was")
        R.check("every Brain file this run wrote to is restored byte for byte",
                all(_brain_path(f).read_text() == t
                    for f, t in brain_before.items()),
                ", ".join(BRAIN_FILES))
        R.check("no auto-onboarded residue is left in entities.md",
                "auto-onboarded" not in _brain_path("entities.md").read_text(),
                "the script can be run repeatedly with no drift")
        MS.teardown(R)

    print()
    return R.finish("Medicare Sales Case 3 - The CMS Market Benchmark")


def _brain_path(fname: str):
    # Resolve through BRAIN_DIR, not a literal path: run_all_tests.sh points
    # the Brain at a scratch copy, and a literal path would snapshot/restore
    # the live files while the app edits the copy.
    import pathlib
    from app.semantic.brain import BRAIN_DIR
    return pathlib.Path(BRAIN_DIR) / MS.DOMAIN / fname


def _blank_count(svc, scope, table) -> int:
    r = svc.execute(f"SELECT COUNT(*) FROM {table} WHERE plan_type IS NULL "
                    f"OR TRIM(CAST(plan_type AS TEXT)) = ''", scope,
                    purpose="demo")
    return r.rows[0][0] if (r.ok and r.rows) else -1


if __name__ == "__main__":
    sys.exit(main())
