"""OpPal — Medicare Sales Business Case 4: The Broker Retention Leak
    (Medicare Advantage · effectuation, persistency and commission recovery)

    "The Northeast is writing enrolments and losing them. Twelve-month
     retention in the Broker channel has fallen well below the book, and
     rapid disenrolments -- members leaving inside 90 days -- are running
     at a multiple of every other channel. Under 42 CFR 422.2274(d) a
     rapid disenrolment obliges the plan to recover the compensation it
     paid. Is it being recovered, and what does fixing the channel cost?"

Runs against the real engine end to end: real declared policy rules, real
persona detection, real case store, real isolated simulation, real
dual-control approval with separation of duties, real hash-chained ledger.

Run:
    cd oppal_stage/backend
    PYTHONPATH=. python3 demo/e2e_ms_case4_retention_leak.py

Exit code 0 = every check passed.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("mscase4")

import _medicare as MS  # noqa: E402

R = Reporter()

CHANNEL, MARKET = "Broker", "Northeast"
SWARM_Q = ("Which channel is losing members after enrolment, and is "
           "commission being recovered on rapid disenrolments?")


def main():
    cast = MS.setup()
    MS.title(R, "OpPal - Medicare Sales Business Case 4 - The Broker "
                "Retention Leak",
             "Medicare Advantage - persistency, recoupment & dual control")

    try:
        # ------------------------------------------------------------------
        R.banner("STEP 1", "Context Brain -- the recovery obligation is "
                           "declared, with its citation")
        from app.semantic import brain as bl
        b = bl.get_brain()
        rules = {r.get("rule_id"): r for r in b["policy_rules"]}
        recoup = rules.get("CMS-RAPID-DISENROLL-RECOUP", {})
        floor = rules.get("RETENTION-FLOOR", {})
        R.check("the warehouse loaded from the supplied CSVs",
                len(cast.counts) == 11,
                f"{cast.rows:,} rows across {len(cast.counts)} tables")
        R.check("the recoupment obligation cites 42 CFR 422.2274(d)",
                "422.2274(d)" in recoup.get("citation", ""),
                recoup.get("citation", "")[:66])
        R.check("the retention floor is a declared number, not a hunch",
                bool(floor.get("threshold") or floor.get("min_retention")
                     or floor.get("query")),
                "declared in policy_rules.md RETENTION-FLOOR")
        R.check("the source document for the citation is in the Brain",
                "42 CFR §422.2274(d)" in bl.read_file(MS.DOMAIN,
                                                      "reference.md"),
                "a rule whose citation resolves to nothing is not governed")

        # ------------------------------------------------------------------
        R.banner("STEP 2", "Chat -- retention and rapid disenrolment by "
                           "channel")
        ask = MS.asker(cast.morgan)
        _, t1, ret_rows = ask("member retention rate by channel")
        _, t2, rap_rows = ask("rapid disenrollment rate by channel")
        R.check('type: "member retention rate by channel"',
                t1 >= 85 and len(ret_rows) > 0,
                f"trust {t1}% - {len(ret_rows)} channels")
        R.check('type: "rapid disenrollment rate by channel"',
                t2 >= 85 and len(rap_rows) > 0,
                f"trust {t2}% - worst: {rap_rows[0][0]}={rap_rows[0][1]}")
        R.check("Broker is the worst channel on rapid disenrolment, which is "
                "what sends the analyst to the Northeast",
                str(rap_rows[0][0]) == CHANNEL,
                f"{rap_rows[0][0]} at {rap_rows[0][1]}")

        # ------------------------------------------------------------------
        R.banner("STEP 3", "Data -- the channel/market cell behind the average")
        from app.mcp import data_service
        svc = data_service()
        cell = svc.execute(
            "SELECT COUNT(*), ROUND(AVG(retained_12mo_flag), 4), "
            "ROUND(AVG(rapid_disenroll_flag), 4) FROM enrollments "
            f"WHERE channel = '{CHANNEL}' AND market = '{MARKET}'",
            cast.sc_morgan, purpose="demo")
        n, ret, rapid = cell.rows[0]
        R.check(f"{CHANNEL}/{MARKET} is materially worse than the channel "
                f"average", ret < 0.70 and rapid > 0.20,
                f"{n} enrolments, {ret:.1%} retained, {rapid:.1%} rapid")
        book = svc.execute("SELECT ROUND(AVG(retained_12mo_flag), 4) "
                           "FROM enrollments", cast.sc_morgan,
                           purpose="demo").rows[0][0]
        R.check("the comparison is against the book, not against nothing",
                book > ret, f"book {book:.1%} vs cell {ret:.1%}")

        # ------------------------------------------------------------------
        R.banner("STEP 4", "Pillars -- the two rules that bite here")
        floor_b = MS.breaches(cast.sc_morgan, "RETENTION-FLOOR")
        R.check("the retention floor raises the cell by name",
                any(CHANNEL in str(x.get("headline"))
                    and MARKET in str(x.get("headline")) for x in floor_b),
                str(floor_b[0].get("headline"))[:92] if floor_b else "none")
        rec_b = MS.breaches(cast.sc_morgan, "CMS-RAPID-DISENROLL-RECOUP")
        R.check("the recoupment rule finds payments where no recovery was "
                "raised", len(rec_b) > 0,
                f"{len(rec_b)} agent(s); e.g. "
                + str(rec_b[0].get("headline"))[:70] if rec_b else "none")
        R.check("the breach names the dollar amount, so it is actionable "
                "rather than informational",
                any("USD" in str(x.get("headline")) for x in rec_b))
        R.check("each breach carries the remediation the business must do",
                bool(rec_b[0].get("remediation")),
                str(rec_b[0].get("remediation"))[:70] if rec_b else "")

        # ------------------------------------------------------------------
        R.banner("STEP 5", "Swarm + Cases -- an independent detector agrees")
        from app.agents import swarm, case_store
        run = swarm.run_swarm(SWARM_Q, cast.morgan, llm=None)
        names = [a if isinstance(a, str) else a.get("name")
                 for a in (run.get("activated") or [])]
        R.check("the enrolment-operations persona activates for this question",
                "enrollment_ops" in names, f"activated: {', '.join(names)}")
        heads = " | ".join(f["headline"] for f in (run.get("findings") or []))
        R.check("no persona reports itself misconfigured",
                "is not implemented" not in heads)
        R.check("the persona names the same channel and market the pillar did",
                CHANNEL in heads and MARKET in heads,
                "two independent computations, one conclusion")
        cases = case_store.list_cases(cast.sc_morgan)
        enr = [c for c in cases if c["case_type"] == "EnrollmentCase"]
        R.check("an EnrollmentCase is opened for the leak",
                len(enr) > 0,
                f"{enr[0]['case_id']} - {enr[0]['pattern']}, "
                f"${float(enr[0]['estimated_impact']):,.2f} at stake"
                if enr else f"{len(cases)} cases, none EnrollmentCase")
        R.check("the case is stamped with the LOB of the INCIDENT",
                enr and enr[0]["lob"] == "Medicare Advantage",
                f"lob={enr[0]['lob']}, subject={enr[0]['subject']}"
                if enr else "")
        swarm.run_swarm(SWARM_Q, cast.morgan, llm=None)
        after = case_store.list_cases(cast.sc_morgan)
        R.check("re-running the swarm de-duplicates instead of piling up",
                len(after) == len(cases),
                f"{len(cases)} cases before a second identical run, "
                f"{len(after)} after")

        # ------------------------------------------------------------------
        R.banner("STEP 6", "Simulator -- what does fixing the channel cost?")
        from app.schemas.simulation import (SimulationRequest,
                                            ParameterOverride)
        from app.simulation import engine as sim
        req = SimulationRequest(
            baseline_query=f"Medicare Advantage leads in the {MARKET}",
            parameter_overrides=[
                ParameterOverride(
                    brain_path="metrics.sim_lead_loss_ratio.stress_pct",
                    op="delta_pct", value="-0.20",
                    reason="tighten Broker onboarding and verification calls"),
                ParameterOverride(
                    brain_path="metrics.sim_commission_cost.stress_pct",
                    op="delta_pct", value="-0.10",
                    reason="recover compensation on rapid disenrolments")])
        res = sim.run_simulation(req, cast.morgan, cast.sc_morgan)
        R.check("the simulation returns real numbers for this domain",
                res.net_dollar_impact != 0,
                f"net ${float(res.net_dollar_impact):,.2f}, ratio "
                f"{res.mlr_delta_bps:+d} bps")
        R.check("every reported delta maps to a declared simulation formula",
                {m.metric for m in res.metrics} <= set(b["simulation"]),
                ", ".join(sorted(m.metric for m in res.metrics)))
        R.check("the live Brain was not mutated by the fork",
                "stress_pct" not in bl.get_brain()["metrics"]
                ["sim_commission_cost"],
                "overrides applied to the fork only")

        # ------------------------------------------------------------------
        R.banner("STEP 7", "Actions -- recovery under dual control")
        from app.actions import engine as AE
        com = next((c for c in case_store.list_cases(cast.sc_morgan)
                    if c["case_type"] == "CompensationCase"), None)
        R.check("a CompensationCase exists to propose from",
                com is not None,
                f"{com['case_id']} - ${float(com['estimated_impact']):,.2f}"
                if com else "none")
        amount = float(com["estimated_impact"])
        act = AE.propose(
            case_id=com["case_id"], action_type="commission_recovery",
            target_object=str(com["subject"]),
            lob=str(com.get("lob") or "Medicare Advantage"),
            summary="Recover compensation paid on enrolments that rapidly "
                    "disenrolled, under 42 CFR 422.2274(d)",
            estimated_financial_impact=amount,
            regulatory_severity="high",
            trust_score=float(com.get("trust_score") or 0.92),
            fields={"case_id": com["case_id"]},
            proposer_user_id="u-ma")
        R.check("the analyst proposes from the case",
                bool(act.action_id),
                f"{act.action_id} mode={act.control_mode.value} "
                f"(${amount:,.2f})")
        R.check("commission_recovery is ALWAYS dual control here, whatever "
                "the amount",
                act.control_mode.value == "dual",
                f"${amount:,.2f} is below the $10,000 threshold and it is "
                f"still dual")
        refused, rmsg = False, ""
        try:
            AE.approve(act.action_id, cast.morgan, cast.sc_morgan)
        except Exception as e:
            refused, rmsg = True, str(e)[:56]
        R.check("the proposer cannot approve her own proposal", refused, rmsg)
        a1 = AE.approve(act.action_id, cast.casey, cast.sc_casey)
        R.check("Casey signs first",
                a1.state.value == "PENDING_SECOND_APPROVAL",
                f"approver_1={a1.approver_1_id}")
        sod, smsg = False, ""
        try:
            AE.approve(act.action_id, cast.casey, cast.sc_casey)
        except Exception as e:
            sod, smsg = True, str(e)[:56]
        R.check("the same officer cannot sign twice", sod, smsg)
        a2 = AE.approve(act.action_id, cast.dana, cast.sc_dana)
        R.check("Dana signs second -> APPROVED",
                a2.state.value == "APPROVED",
                f"approver_2={a2.approver_2_id}")
        gate = float(AE.rules().get("execution_trust_gate") or 0.85)
        AE.execute(act.action_id, cast.dana, cast.sc_dana)
        done = AE.get(act.action_id, cast.sc_casey)
        R.check("execution clears the trust gate and writes back (dry run)",
                done.state.value == "EXECUTED",
                f"trust {a2.trust_score:.0%} >= gate {gate:.0%}")

        # ------------------------------------------------------------------
        R.banner("STEP 8", "SQL Log + Governance")
        from app.data.db import SQL_LOG
        stmts = list(SQL_LOG)
        writes = [s for s in stmts
                  if not str(s.get("sql", "")).lstrip().upper()
                  .startswith("SELECT") and s.get("ok")]
        R.check("no write reached the warehouse through a query",
                not writes, f"{len(stmts)} statements, all SELECT")
        scoped = [s for s in stmts if "lob" in str(s.get("sql", "")).lower()]
        R.check("scoped sessions carry the line-of-business predicate",
                len(scoped) > 0, f"{len(scoped)} statements carry it")
        from app.trust import ledger_v2
        v = ledger_v2.verify_chain()
        vd = v if isinstance(v, dict) else (
            v.model_dump() if hasattr(v, "model_dump") else vars(v))
        R.check("the hash chain verifies end to end",
                bool(vd.get("ok", vd.get("valid", vd.get("intact")))),
                f"{vd.get('blocks_checked', vd.get('checked', '?'))} blocks")
    finally:
        MS.teardown(R)

    print()
    return R.finish("Medicare Sales Case 4 - The Broker Retention Leak")


if __name__ == "__main__":
    sys.exit(main())
