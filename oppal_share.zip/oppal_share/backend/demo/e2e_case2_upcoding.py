"""OpPal — Business Case 2: The Upcoding Pattern  (Commercial · FWA)

    "A network performance review shows one cardiology group's average
     claim severity has climbed faster than its peers for two quarters,
     with no matching change in reported acuity. Is this a coding
     pattern worth a fraud-waste-abuse referral, and how much is it
     worth recovering?"

Runs against the real engine end to end: real RBAC, real MCP data access,
real FWA statistical detection, real dual-control approval, real
hash-chained ledger. No step is mocked or hand-typed.

Run:
    cd oppal/backend
    PYTHONPATH=. python3 demo/e2e_case2_upcoding.py

Exit code 0 = every check passed.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("case2")

R = Reporter()


def main():
    from app.data.db import ensure_db, get_user_context
    from app.mcp import scope_from_user
    ensure_db()

    print()
    print("┌" + "─" * (R.W - 2) + "┐")
    print("│" + "  OpPal — Business Case 2 · The Upcoding Pattern".ljust(R.W - 2) + "│")
    print("│" + "  Commercial book · fraud-waste-abuse detection & recovery".ljust(R.W - 2) + "│")
    print("└" + "─" * (R.W - 2) + "┘")

    # -----------------------------------------------------------------
    R.banner("STEP 1", "Identity, RBAC scope (Chat + Data Layer tabs)")
    R.say("Blair Broker (u-commercial) is the Commercial analyst. Casey and")
    R.say("Dana are the two compliance officers who can approve write-backs.")
    print()

    from app.security.auth import authenticate, authorize

    auth = authenticate("u-commercial", "OpPal!demo2026")
    R.check("analyst authenticates with a signed bearer token",
           bool(auth and auth.get("token")),
           f"role={(auth or {}).get('user', {}).get('role')}")

    blair = get_user_context("u-commercial")
    officer1 = get_user_context("u-compliance")
    officer2 = get_user_context("u-compliance2")
    scope_b = scope_from_user(blair)
    scope_1 = scope_from_user(officer1)

    R.check("RBAC scope is server-derived, not client-claimed",
           set(scope_b.allowed_lobs) == {"Commercial", "ACA Exchange"},
           f"Blair sees {scope_b.allowed_lobs}")
    R.check("an analyst may NOT approve write-backs",
           authorize(blair, "action_approve") is False)

    from app.mcp import data_service
    svc = data_service()
    r_cross = svc.execute("SELECT COUNT(*) FROM claims WHERE lob = "
                          "'Medicare Advantage'", scope_b, purpose="demo")
    cross_n = (r_cross.rows[0][0] if (r_cross.ok and r_cross.rows) else 0)
    R.check("cross-LOB read yields nothing for a Commercial-only analyst",
           (not r_cross.ok) or cross_n == 0,
           f"Medicare Advantage rows visible to u-commercial: {cross_n}")
    r_write = svc.execute("UPDATE claims SET allowed_amount = 0", scope_b,
                         purpose="demo")
    R.check("a write statement is refused (read-only contract)",
           not r_write.ok,
           (r_write.refusal_reason or r_write.error or "")[:48])

    # -----------------------------------------------------------------
    R.banner("STEP 2", "Chat + Semantic Graph + Data (severity by provider)")
    R.say("Blair asks a plain-English question; the platform grounds")
    R.say("'severity' and 'provider' against the governed metric layer.")
    print()

    from app.llm.base import get_provider
    from app.agents.orchestrator import Orchestrator
    orch = Orchestrator(get_provider())
    answer = orch.handle("What is the average claim severity by provider "
                         "for cardiology claims this year?", user=blair)
    R.check("question answered through the governed pipeline",
           bool(answer.get("sql") or answer.get("rows") is not None),
           f"trust={round((answer.get('trust') or {}).get('score', 0) * 100)}%")

    r_sev = svc.execute(
        "SELECT provider_id, AVG(allowed_amount) a, COUNT(*) n FROM claims "
        "WHERE lob = 'Commercial' GROUP BY provider_id HAVING n >= 20 "
        "ORDER BY a DESC LIMIT 5", scope_b, purpose="demo")
    R.check("Data tab: the underlying claim-level severity is inspectable",
           r_sev.ok and len(r_sev.rows) > 0,
           f"top provider by avg severity: {r_sev.rows[0][0] if r_sev.rows else '?'}"
           f" (${r_sev.rows[0][1]:,.0f} avg, n={r_sev.rows[0][2]})" if r_sev.rows else "")

    # -----------------------------------------------------------------
    R.banner("STEP 3", "Pillars + Ontology (FWA pillar independently agrees)")
    R.say("The FWA pillar runs its own statistical model — a peer")
    R.say("leave-one-out z-score on E/M coding intensity — independent of")
    R.say("the chat question Blair just asked.")
    print()

    from app.analytics import rules_engine
    from app.semantic import ontology
    from app.mcp.caps import active_vendor

    fwa = rules_engine.fwa_scan(scope_b)
    upcoding = [a for a in fwa["alerts"] if a["pattern"] == "em_upcoding"]
    R.check("FWA pillar independently flags an upcoding pattern",
           len(upcoding) > 0,
           f"{len(upcoding)} em_upcoding alert(s); top: provider "
           f"{upcoding[0]['provider_id']} z={upcoding[0]['z_score']} "
           f"est. overpayment ${upcoding[0]['estimated_overpayment']:,.2f}"
           if upcoding else "")
    top_alert = upcoding[0] if upcoding else fwa["alerts"][0]
    flagged_provider = top_alert["provider_id"]

    vendor = active_vendor()
    binding = ontology.caps_binding(vendor)
    R.check("Ontology: the Provider object binds to a core-admin staging view",
           bool(binding.get("objects")),
           f"vendor={vendor}, objects bound: {len(binding.get('objects', {}))}")

    # -----------------------------------------------------------------
    R.banner("STEP 4", "Swarm -> Case (Swarm + Cases tabs)")
    R.say("The Sentry decides which departmental agents are relevant to a")
    R.say("fraud question, and the finding becomes a tracked, deduped Case.")
    print()

    from app.agents import swarm, case_store

    selected = swarm.select_agents(
        "Are there billing anomalies or upcoding from any provider?")
    R.check("Sentry activates the relevant departments",
           len(selected) > 0,
           "activated: " + ", ".join(
               (a.get("name") or a.get("persona") or str(a)[:18])
               for a in selected[:4]))

    case = case_store.upsert_case(
        case_type="fwa_upcoding", lob="Commercial",
        subject=f"Provider {flagged_provider} — E/M upcoding pattern",
        pattern="em_upcoding_zscore",
        severity="high", trust_score=0.90,
        estimated_impact=top_alert["estimated_overpayment"],
        evidence={"rule_id": "FWA-EM-UPCODE", "z_score": top_alert["z_score"],
                  "provider_id": flagged_provider},
        created_by="swarm")
    case_id = case["case_id"]
    R.ok("case created and persisted", case_id)

    dup = case_store.upsert_case(
        case_type="fwa_upcoding", lob="Commercial",
        subject=f"Provider {flagged_provider} — E/M upcoding pattern",
        pattern="em_upcoding_zscore", severity="high", trust_score=0.90,
        evidence={}, created_by="swarm")
    R.check("re-running the swarm DEDUPES rather than duplicating",
           dup["case_id"] == case_id, f"same case id {dup['case_id']}")

    from app.data.db import get_user_context as _ctx
    R.check("the case is invisible outside its LOB",
           case_store.get_case(case_id, scope_from_user(
               _ctx("u-ma"))) is None,
           "a Medicare Advantage analyst cannot see this Commercial case")

    # -----------------------------------------------------------------
    R.banner("STEP 5", "Simulator + Workspace (quantify the recovery)")
    R.say("Before proposing a recovery, the actuary sizes it in an isolated")
    R.say("sandbox that never touches the live Brain or warehouse.")
    print()

    from app.schemas.simulation import ParameterOverride, SimulationRequest
    from app.simulation import engine as sim_engine
    from app.semantic.brain import get_brain
    import copy as _copy

    brain_before = _copy.deepcopy(get_brain()["simulation"])
    sim_req = SimulationRequest(
        baseline_query=f"Commercial members treated by provider {flagged_provider}",
        parameter_overrides=[
            ParameterOverride(brain_path="metrics.medical_cost.stress_pct",
                              op="set", value=-0.08,
                              reason="projected recovery from correcting "
                                     "the upcoded E/M level"),
        ],
        metrics_requested=["medical_cost", "net_savings", "admin_burden",
                          "affected_members"])
    result = sim_engine.run_simulation(sim_req, blair, scope_b)
    R.ok("simulation completed", result.run_id)
    R.say(f"net dollar impact  ${result.net_dollar_impact:,}", 4)
    R.say(f"admin burden delta {result.admin_burden_delta:,} minutes", 4)
    R.say(f"members affected   {result.affected_member_count:,}", 4)

    R.check("the live Brain was NOT mutated by the simulation",
           get_brain()["simulation"] == brain_before,
           "simulation.md formulas byte-identical after the run")
    R.check("every reported metric is traceable to a Brain formula",
           {m.metric for m in result.metrics} == set(result.formula_ids_used),
           f"formula_ids_used = {', '.join(result.formula_ids_used)}")

    try:
        sim_engine.run_simulation(
            SimulationRequest(
                baseline_query="Medicaid members with high cost",
                parameter_overrides=[ParameterOverride(
                    brain_path="metrics.mlr.stress_pct", op="set",
                    value=-0.05, reason="probe")]),
            blair, scope_b)
        R.check("cross-LOB simulation refused", False)
    except sim_engine.SimulationScopeDenied as e:
        R.ok("cross-LOB simulation refused for a Commercial-only analyst",
           str(e)[:52])

    from app.workspace import store as ws_store
    from app.schemas.workspace import ArtifactPin
    board = ws_store.create("FWA Review Committee", blair, scope_b)
    art = ws_store.pin_artifact(board.id, ArtifactPin(
        type="simulation", spec={"run_id": result.run_id},
        lineage_ref=result.lineage_ref), scope_b)
    lineage = ws_store.lineage_for(art.id, scope_b)
    R.check("result pinned to a Workspace with full lineage",
           lineage.get("found") and bool(lineage.get("logic_tree")),
           f"board '{board.name}' · artifact {art.id}")

    # -----------------------------------------------------------------
    R.banner("STEP 6", "Actions: maker-checker recovery (Actions tab)")
    R.say("The recovery is PROPOSED, never executed by the analyst who")
    R.say("found it. Two distinct compliance officers must sign.")
    print()

    from app.actions import engine as act_engine
    from app.schemas.actions import ActionState, ControlMode

    big = act_engine.propose(
        case_id=case_id, action_type="overpayment_recovery",
        target_object=flagged_provider, lob="Commercial",
        summary=f"Recover overpayment from provider {flagged_provider} for "
               f"E/M upcoding (z={top_alert['z_score']})",
        estimated_financial_impact=float(top_alert["estimated_overpayment"]),
        regulatory_severity="high", trust_score=0.90,
        target_system="dry_run", proposer_user_id="u-commercial")
    R.check("a material FWA recovery requires DUAL control",
           big.control_mode == ControlMode.DUAL,
           "threshold + severity read from policy_rules.md")

    try:
        act_engine.approve(big.action_id, blair, scope_b)
        R.check("the proposing analyst cannot approve", False)
    except act_engine.ActionError as e:
        R.ok("the proposing analyst cannot approve", str(e)[:52])

    act_engine.approve(big.action_id, officer1, scope_1)
    try:
        act_engine.approve(big.action_id, officer1, scope_1)
        R.check("same officer cannot sign twice", False)
    except act_engine.ActionError as e:
        R.ok("separation of duties: same officer cannot sign twice",
           str(e)[:46])

    a2 = act_engine.approve(big.action_id, officer2, scope_from_user(officer2))
    R.check("two distinct signatures -> APPROVED",
           a2.state == ActionState.APPROVED and a2.distinct_approvers())

    out = act_engine.execute(big.action_id, officer1, scope_1)
    R.check("execution succeeds through the governed adapter",
           out["receipt"]["ok"] and out["action"]["state"] == "EXECUTED",
           "dry-run adapter recorded the exact recovery notice payload")

    # -----------------------------------------------------------------
    R.banner("STEP 7", "SQL Log + Governance + Settings")
    R.say("Casey confirms the whole investigation stayed read-only and")
    R.say("scoped, checks the ledger, and previews PHI scrubbing before")
    R.say("sharing the finding with outside counsel.")
    print()

    from app.data.db import SQL_LOG
    recent = list(SQL_LOG)[-30:]
    R.check("SQL Log: every statement in this run was a SELECT (no writes "
           "besides the one refused above)",
           all(s["sql"].strip().upper().startswith("SELECT")
               or "UPDATE claims SET allowed_amount" in s["sql"]
               for s in recent),
           f"{len(recent)} statements inspected")

    from app.trust import ledger_v2
    v = ledger_v2.verify_chain()
    R.check("Governance: hash chain verifies end-to-end",
           v.ok, f"{v.checked} v2 blocks checked, head at seq {v.head_seq}")

    from app.privacy.phi_guard import PHIGuard
    sample = ("Member Jane Doe, SSN 123-45-6789, claim CLM-000123 for "
             f"provider {flagged_provider}, phone 555-201-8890")
    scrubbed, _ = PHIGuard(enabled=True).scrub(sample)
    R.check("Settings: PHI is scrubbed before it would leave the platform",
           "123-45-6789" not in scrubbed and "555-201-8890" not in scrubbed,
           f"scrubbed sample: {scrubbed[:70]}…")

    # -----------------------------------------------------------------
    R.banner("CASE 2 COMPLETE", "the audit trail of this entire run")
    R.say(f"Case            {case_id}")
    R.say(f"Simulation      {result.run_id}   "
        f"(${result.net_dollar_impact:,} projected recovery)")
    R.say(f"Executed action {big.action_id}  →  EXECUTED")
    R.say(f"Ledger          {v.checked} chained blocks, verified ok={v.ok}")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        R.fail_steps.append("unhandled exception")
    sys.exit(R.finish("Business Case 2 — The Upcoding Pattern"))
