"""Pre-flight for the HEDIS demo — run this BEFORE the meeting.

Every question in OpPal_HEDIS_Demo_UseCase.docx is asked here, in order,
against the real engine, and the answer is checked. If this prints PASS the
demo works out of the box; if a question stops grounding after some future
Brain edit, this fails here instead of in front of a client.

It also prints the exact Brain text to paste, so the document and the code
cannot drift apart: the metric blocks below ARE the ones the doc quotes.

Run:
    cd oppal/backend
    PYTHONPATH=. python3 demo/hedis_demo_verify.py
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("hedisverify")

R = Reporter()
CSV = os.path.join(os.path.dirname(__file__), "data",
                   "hedis_measure_results.csv")

# ---------------------------------------------------------------------------
# The three metric blocks the demo adds by hand, and the vocabulary that makes
# them askable. Kept HERE so the runnable check and the document share one
# source; the doc is generated from these strings.
def metric_block(table: str) -> str:
    return f"""
### cbp_gap_rate
- label: CBP Gap Rate (Controlling High Blood Pressure)
- definition: Share of CBP-eligible members with an open care gap. Triple-weighted for CMS Stars.
- formula: AVG(gap_open) WHERE measure_code = 'CBP'
- sql: ROUND(AVG(CASE WHEN t.measure_code = 'CBP' THEN t.gap_open * 1.0 END), 4)
- base: generic
- table: {table}
- time_column:
- dims: region, age_band
- needs_members: false
- average: true
- format: percent
- depends: {table}.gap_open, {table}.measure_code
- owner: Quality (HEDIS)
- certified: true

### star_measure_gap_rate
- label: Star Measure Gap Rate
- definition: Open care-gap share for every HEDIS measure in the vendor file, so measures can be ranked against each other.
- formula: AVG(gap_open)
- sql: ROUND(AVG(t.gap_open * 1.0), 4)
- base: generic
- table: {table}
- time_column:
- dims: measure_name, region, age_band
- needs_members: false
- average: true
- format: percent
- depends: {table}.gap_open
- owner: Quality (HEDIS)
- certified: true

### outreach_per_gap
- label: Outreach Attempts per Open Gap
- definition: Average outreach attempts recorded against members who STILL have an open gap. A low value means the gap was never worked, which is an operations problem rather than a clinical one.
- formula: AVG(outreach_attempts) WHERE gap_open = 1
- sql: ROUND(AVG(CASE WHEN t.gap_open = 1 THEN t.outreach_attempts * 1.0 END), 2)
- base: generic
- table: {table}
- time_column:
- dims: region, measure_name
- needs_members: false
- average: true
- format: number
- depends: {table}.outreach_attempts, {table}.gap_open
- owner: Quality (HEDIS)
- certified: true
"""


VOCAB_BLOCK = """- cbp => metric:cbp_gap_rate
- cbp gap rate => metric:cbp_gap_rate
- controlling high blood pressure => metric:cbp_gap_rate
- blood pressure control => metric:cbp_gap_rate
- star measure gap rate => metric:star_measure_gap_rate
- measure gap rate => metric:star_measure_gap_rate
- stars gap rate => metric:star_measure_gap_rate
- outreach per gap => metric:outreach_per_gap
- outreach attempts => metric:outreach_per_gap
"""

# The demo script, in order. (question, must_answer, note)
BASELINE = [
    "What is the HEDIS gap rate by region?",
    "What is the average RAF score by region?",
]
AFTER_EDIT = [
    "What is the CBP gap rate?",
    "CBP gap rate by region",
    "CBP gap rate by age band",
    "Star measure gap rate by measure name",
    "Star measure gap rate by region",
    "Outreach attempts per gap by region",
    "Outreach per gap by measure name",
]


def main():
    from app.data.db import ensure_db, get_user_context, POOL
    from app.llm.base import get_provider
    from app.agents.orchestrator import Orchestrator
    from app.semantic import brain as bl, onboarding
    from app.data import importer
    ensure_db()

    orch = Orchestrator(get_provider())
    casey = get_user_context("u-compliance")   # compliance_officer: brain_write

    # IDEMPOTENCE. _env resets the databases but NOT the Brain's markdown,
    # which lives in the package and persists across runs. A previous run (or
    # a rehearsal in the UI) leaves the three demo metrics behind — and then
    # PART 3, whose entire job is to show the question being REFUSED, sees a
    # perfectly good certified metric and reports 100%. Caught exactly that
    # way on first run. Strip them up front so every run starts from the
    # state a client would see.
    domain0 = bl.active_domain()
    _met = bl.read_file(domain0, "metrics.md")
    _voc = bl.read_file(domain0, "vocabulary.md")
    _cleaned = _met
    for mid in ("cbp_gap_rate", "star_measure_gap_rate", "outreach_per_gap"):
        s = _cleaned.find(f"### {mid}")
        while s != -1:
            e = _cleaned.find("\n### ", s + 1)
            e = len(_cleaned) if e == -1 else e
            _cleaned = _cleaned[:s] + _cleaned[e:]
            s = _cleaned.find(f"### {mid}")
    _voc_clean = "\n".join(
        ln for ln in _voc.splitlines()
        if "metric:cbp_gap_rate" not in ln
        and "metric:star_measure_gap_rate" not in ln
        and "metric:outreach_per_gap" not in ln) + "\n"
    if _cleaned != _met or _voc_clean != _voc:
        bl.write_file(domain0, "metrics.md", _cleaned)
        bl.write_file(domain0, "vocabulary.md", _voc_clean)
        bl.reload_brain()
        print("  (reset: removed demo metrics left by a previous run)")

    def ask(q):
        a = orch.handle(q, user=casey)
        rows = next((art["rows"] for art in a.get("artifacts", [])
                     if art.get("rows")), None)
        return (a.get("sql") != "-- withheld",
                round((a.get("trust") or {}).get("score", 0) * 100), rows)

    print()
    print("┌" + "─" * (R.W - 2) + "┐")
    print("│" + "  HEDIS demo pre-flight — every question in the use-case doc".ljust(R.W - 2) + "│")
    print("└" + "─" * (R.W - 2) + "┘")

    R.banner("PART 1", "Baseline — works before any import")
    for q in BASELINE:
        ok, tr, rows = ask(q)
        R.check(f"“{q}”", ok and tr >= 85, f"trust {tr}%")

    R.banner("PART 2", "Import the vendor file")
    R.check("the HEDIS file is present",
            os.path.exists(CSV) and os.path.getsize(CSV) > 100_000,
            f"{os.path.getsize(CSV):,} bytes")
    out = importer.import_files(
        [("hedis_measure_results.csv", open(CSV, "rb").read())])
    POOL.reset()
    R.check("it imports as a governed table",
            out and out[0].get("ok"), f"{out[0].get('rows'):,} rows")
    table = out[0]["table"]
    joins = [j["brain_snippet"] for r in out if r.get("ok")
             for j in r.get("suggested_joins", [])]
    onboarding.onboard_tables([table], joins, user_id="u-ma", llm=None)
    R.check("the ontology is drafted on demand", True, f"table={table}")

    R.banner("PART 3", "The question that SHOULD fail before the Brain edit")
    ok, tr, _ = ask("What is the CBP gap rate?")
    R.check("“What is the CBP gap rate?” is refused, and says why",
            (not ok) and tr < 85,
            f"trust {tr}% — semantic grounding 0%, SQL withheld (this is the "
            f"moment the demo is built around)")

    R.banner("PART 4", "Apply the Brain edit (Governed metrics + Vocabulary)")
    domain = domain0
    met_before = bl.read_file(domain, "metrics.md")
    voc_before = bl.read_file(domain, "vocabulary.md")
    try:
        bl.write_file(domain, "metrics.md", met_before + metric_block(table))
        bl.write_file(domain, "vocabulary.md", voc_before + VOCAB_BLOCK)
        rep = bl.reload_brain()
        R.check("the Brain reloads with no parse errors",
                not rep.get("errors"), rep.get("report", "")[:80])
        brain = bl.get_brain()
        for mid in ("cbp_gap_rate", "star_measure_gap_rate",
                    "outreach_per_gap"):
            R.check(f"{mid} is live and certified",
                    brain["metrics"].get(mid, {}).get("certified") is True)

        R.banner("PART 5", "Every demo question, in order")
        for q in AFTER_EDIT:
            ok, tr, rows = ask(q)
            head = ", ".join(f"{r[0]}={r[1]}" for r in (rows or [])[:2])
            R.check(f"“{q}”", ok and tr >= 85, f"trust {tr}% · {head}")

        R.banner("PART 6", "The finding the demo lands on")
        _, _, rows = ask("CBP gap rate by region")
        by = {r[0]: r[1] for r in (rows or [])}
        worst = max(by, key=by.get) if by else None
        best = min(by, key=by.get) if by else None
        R.check("Southeast is the outlier on the triple-weighted measure",
                worst == "Southeast",
                f"{worst} {by.get(worst, 0):.1%} vs {best} {by.get(best, 0):.1%}"
                if worst else "")
        R.check("the gap is large enough to be worth a slide",
                worst and best and by[worst] > by[best] * 1.8,
                f"{by[worst] / by[best]:.1f}x worse" if worst and best else "")
        _, _, orows = ask("Outreach attempts per gap by region")
        ob = {r[0]: r[1] for r in (orows or [])}
        R.check("and the CAUSE is visible in the same file — Southeast is "
                "the least-worked region",
                ob and min(ob, key=ob.get) == "Southeast",
                f"Southeast {ob.get('Southeast')} attempts/gap vs "
                f"{max(ob, key=ob.get)} {ob.get(max(ob, key=ob.get))}"
                if ob else "")
    finally:
        bl.write_file(domain, "metrics.md", met_before)
        bl.write_file(domain, "vocabulary.md", voc_before)
        bl.reload_brain()

    print()
    R.say("If every line above is ✓, the demo runs out of the box.")
    R.say("Paste the metric + vocabulary blocks from this file into")
    R.say("Context Brain ▸ Governed metrics and ▸ Vocabulary.")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        R.fail_steps.append("unhandled exception")
    sys.exit(R.finish("HEDIS demo pre-flight"))
