"""Shared setup for every e2e_*.py business-case script.

Why this exists: each business-case script is meant to be independently
runnable, in any order, on a laptop that has never run OpPal before OR has
run every other demo a dozen times. Two things get in the way of that if
left alone:

1. ``app/data/audit_log.jsonl`` is append-only and shared. A stale file left
   over from a previous run (or from packaging) can contain hash-chain
   blocks written by an OLDER version of ``app/trust/ledger_v2.py`` — for
   example, blocks written before the attribution-binding hardening that
   closed audit findings L-1/L-2. Verifying a chain that mixes pre-fix and
   post-fix blocks can make a genuine tamper-detection check silently pass
   on an old block, not because detection is broken, but because that
   specific block predates the protection. Resetting the ledger before each
   run guarantees every check reflects the CURRENT code, not old data.
2. The synthetic warehouse, actions/cases/simulation/workspace stores, and
   the signed-token secret are all files on disk. Re-running a script twice
   without clearing them re-uses seq numbers, IDs and a stale auth secret in
   ways that can produce confusing (not wrong, just confusing) diffs between
   runs.

``reset_demo_env(tag)`` deletes all of that, then callers call
``ensure_db()`` themselves to rebuild the (deterministic, fixed-seed)
warehouse fresh. ``tag`` isolates each case's auxiliary SQLite stores
(simulation/workspace/compensation/action/case) into their own /tmp files so
running case 2 does not see case 4's actions, even if both are run in the
same minute without an explicit reset in between.
"""
from __future__ import annotations

import glob
import os
import tempfile

_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DATA_DIR = os.path.join(_BACKEND_DIR, "app", "data")
_KEEP = {"settings.json"}     # user config, not demo state — see reset below


def reset_demo_env(tag: str = "shared") -> None:
    """Delete all persisted OpPal state so this process starts from a clean,
    reproducible slate. Call this BEFORE importing/using app.data.db or any
    module that opens a SQLite connection or reads the auth secret."""
    # 0. Isolate the ACTIVE DOMAIN pointer before app.semantic.brain is
    #    imported anywhere (step 3 below imports it). Without this the domain
    #    reset lands on app/data/active_domain.txt, which a running server is
    #    also reading — so a verify script silently moved the live app onto
    #    the payer Brain and the user's next question failed its trust gate.
    os.environ.setdefault(
        "OPPAL_ACTIVE_DOMAIN_FILE",
        os.path.join(tempfile.gettempdir(), f"oppal_demo_{tag}_domain.txt"))
    # 1. the shared warehouse, RBAC/auth store, and v1+v2 audit ledger
    #     settings.json is the one file under app/data that is NOT demo state:
    #     it holds the user's LLM provider and API key, typed into the
    #     Settings tab. The *.json glob was eating it, so running any demo
    #     script silently dropped the app back to the mock provider and the
    #     key had to be re-entered with nothing on screen explaining why.
    #     Skip by name rather than narrowing the glob — a new store that adds
    #     a .json here should still be reset.
    for pattern in ("*.db", "*.db-journal", "*.json", "audit_log.jsonl",
                    ".auth_secret"):
        for f in glob.glob(os.path.join(_DATA_DIR, pattern)):
            if os.path.basename(f) in _KEEP:
                continue
            try:
                os.remove(f)
            except OSError:
                pass

    # 1b. ...and the warehouse WHEREVER OPPAL_DB_PATH points. run_all_tests.sh
    #     exports it into a scratch directory, so the app/data glob above never
    #     touched it. Consequence, found the hard way: the pharma dataset adds
    #     distributor rows to role_lob_access, those rows survived every
    #     subsequent suite, and two payer tests asserting "ma_analyst is
    #     single-LOB" started seeing Cardinal-East. A reset that resets only
    #     the default location is not a reset.
    _db = os.environ.get("OPPAL_DB_PATH")
    if _db:
        for f in (_db, _db + "-journal", _db + "-wal", _db + "-shm"):
            try:
                os.remove(f)
            except OSError:
                pass

    # 2. this case's own isolated auxiliary stores (kept out of app/data so
    #    two cases run back-to-back never share simulation/action/case rows)
    tmp = tempfile.gettempdir()
    for f in glob.glob(os.path.join(tmp, f"oppal_demo_{tag}_*.db")):
        try:
            os.remove(f)
        except OSError:
            pass
    os.environ["OPPAL_SIM_DB"] = os.path.join(tmp, f"oppal_demo_{tag}_sim.db")
    os.environ["OPPAL_WORKSPACE_DB"] = os.path.join(tmp, f"oppal_demo_{tag}_ws.db")
    os.environ["OPPAL_COMPENSATION_DB"] = os.path.join(tmp, f"oppal_demo_{tag}_comp.db")
    os.environ["OPPAL_ACTION_DB"] = os.path.join(tmp, f"oppal_demo_{tag}_actions.db")
    os.environ["OPPAL_CASE_DB"] = os.path.join(tmp, f"oppal_demo_{tag}_cases.db")

    # 3. the ACTIVE DOMAIN. active_domain.txt is persisted, process-global
    #    state inside the package: a script that switches domains leaves the
    #    WHOLE install switched, and the next unrelated run silently executes
    #    the payer suite against another domain's Brain. Cost of finding that
    #    out the hard way: 25 suites and 88 checks failing for no reason
    #    visible in any diff. Every run starts on the payer domain; a script
    #    that wants another domain sets it explicitly.
    try:
        from app.semantic import brain as _bl
        _bl.set_active("healthcare_payer")
    except Exception:
        pass
    # Chat history is server-side as of v14.8.0 and is a per-user store like
    # the rest — isolate it per case so one demo cannot read back another's
    # transcripts, and so a rerun starts from an empty list.
    os.environ["OPPAL_HISTORY_DB"] = os.path.join(
        tmp, f"oppal_demo_{tag}_history.db")


# NOTE on the Context Brain's own "original" snapshot: deliberately NOT
# used for test/demo resets. ensure_baseline() captures whatever
# policy_rules.md etc. looked like the FIRST time it is ever called for a
# domain, and app/semantic/versions/ ships inside the package -- so an
# "original" snapshot taken during early development (before later phases
# added rules like CDAG-TAT-568 or FWA-EM-UPCODE) can be stale relative to
# the CURRENT shipped markdown. Rolling back to it would silently DELETE
# those later rules rather than restore a clean state. Case 5 avoids this
# by taking and restoring its OWN snapshot around its OWN edit instead of
# trusting the platform's "original" label. If you use the real Context
# Brain tab's "Revert to ORIGINAL" button, check what it actually restores
# before relying on it in a domain that has evolved since that snapshot
# was taken.


# ---------------------------------------------------------------------------
# Shared narrated-transcript reporter, identical output style to
# e2e_business_scenario.py, factored out so cases 2-5 don't each re-implement
# it. (e2e_business_scenario.py itself keeps its own inline copy — it was
# already independently verified and untouched code is lower risk.)
class Reporter:
    W = 78

    def __init__(self):
        self.ok_steps: list[str] = []
        self.fail_steps: list[str] = []

    def banner(self, phase: str, title: str):
        print()
        print("=" * self.W)
        print(f"  {phase}  ·  {title}")
        print("=" * self.W)

    def say(self, msg: str, indent: int = 2):
        print(" " * indent + msg)

    def ok(self, label: str, detail: str = ""):
        self.ok_steps.append(label)
        print(f"  ✓ {label}" + (f" — {detail}" if detail else ""))

    def check(self, label: str, condition: bool, detail: str = ""):
        if condition:
            self.ok(label, detail)
        else:
            self.fail_steps.append(label)
            print(f"  ✗ {label} — {detail or 'assertion failed'}")

    def finish(self, title: str) -> int:
        print()
        print("=" * self.W)
        total = len(self.ok_steps) + len(self.fail_steps)
        print(f"  {title}: {len(self.ok_steps)}/{total} checks passed")
        if self.fail_steps:
            print("  FAILED:")
            for f in self.fail_steps:
                print(f"    ✗ {f}")
        print("=" * self.W)
        return 1 if self.fail_steps else 0

