"""OpPal — End-to-End Business Scenario  (Phases 0 → 6, one continuous story)

    "The GLP-1 formulary change went live on 1 April 2026. Rejects spiked,
     coverage determinations started breaching the 72-hour CMS clock, and
     Finance wants to know what a tier rollback would actually cost."

This is the demo and acceptance script a Business Analyst can run to see every
phase of the platform do its job on ONE case, in order, with real data and real
controls. It is deliberately written as a narrated transcript: each step prints
what it did, what the platform enforced, and which acceptance criteria it
demonstrates.

Nothing here is mocked. Every call goes through the same governed path the UI
uses — the same RBAC scope, the same MCP data service, the same dual-control
engine, the same hash-chained ledger.

Run:
    cd oppal/backend
    PYTHONPATH=. python3 demo/e2e_business_scenario.py

Exit code 0 = every phase behaved as specified.
"""
from __future__ import annotations

import os
import sys
import traceback

# Reset all persisted state FIRST, before any app.* module is imported, so
# this script is independently runnable from a clean slate regardless of
# what ran (or was packaged) before it. See demo/_env.py for why this
# matters — most importantly, a stale app/data/audit_log.jsonl can contain
# hash-chain blocks written before the L-1/L-2 attribution-binding fix,
# which would make the Phase 6 tamper-detection check below silently pass
# on an old, unprotected block instead of the current code's real behavior.
sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env  # noqa: E402
reset_demo_env("case1")

STEPS_OK, STEPS_FAIL = [], []
W = 78


def banner(phase: str, title: str):
    print()
    print("═" * W)
    print(f"  {phase}  ·  {title}")
    print("═" * W)


def say(msg, indent=2):
    print(" " * indent + msg)


def ok(label, detail=""):
    STEPS_OK.append(label)
    print(f"  ✓ {label}" + (f" — {detail}" if detail else ""))


def check(label, condition, detail=""):
    if condition:
        ok(label, detail)
    else:
        STEPS_FAIL.append(label)
        print(f"  ✗ {label} — {detail or 'assertion failed'}")


# ===========================================================================
def main():
    from app.data.db import ensure_db, get_user_context
    from app.mcp import scope_from_user
    ensure_db()

    print()
    print("┌" + "─" * (W - 2) + "┐")
    print("│" + "  OpPal — Agentic Payer Engine · End-to-End Business Scenario".ljust(W - 2) + "│")
    print("│" + "  GLP-1 formulary change · Medicare Advantage contract H1234".ljust(W - 2) + "│")
    print("└" + "─" * (W - 2) + "┘")

    # -------------------------------------------------------------------
    banner("PHASE 0", "Identity, RBAC scope and the governed answer")
    say("Morgan Advantage (u-ma) is an MA analyst. Casey Compliance and Dana")
    say("Controls are the two compliance officers who can approve write-backs.")
    print()

    from app.security.auth import authenticate, verify_token, authorize

    auth = authenticate("u-ma", "OpPal!demo2026")
    check("Phase 0 · analyst authenticates with a signed bearer token",
          bool(auth and auth.get("token")),
          f"role={(auth or {}).get('user', {}).get('role')}")
    claims = verify_token(auth["token"]) if auth else None
    check("Phase 0 · token verifies (HMAC-SHA256, exp claim)",
          bool(claims and claims.get("sub") == "u-ma"),
          f"sub={(claims or {}).get('sub')}, exp in "
          f"{int(((claims or {}).get('exp', 0) - __import__('time').time()) / 3600)}h")
    check("Phase 0 · a tampered token is rejected",
          verify_token(auth["token"][:-4] + "AAAA") is None if auth else False)

    analyst = get_user_context("u-ma")
    officer1 = get_user_context("u-compliance")
    officer2 = get_user_context("u-compliance2")
    scope_a = scope_from_user(analyst)
    scope_1 = scope_from_user(officer1)

    check("Phase 0 · RBAC scope is server-derived, not client-claimed",
          scope_a.allowed_lobs == ["Medicare Advantage"],
          f"analyst sees {scope_a.allowed_lobs}")
    check("Phase 0 · an analyst may NOT approve write-backs",
          authorize(analyst, "action_approve") is False)
    check("Phase 0 · a compliance officer may",
          authorize(officer1, "action_approve") is True)

    from app.llm.base import get_provider
    from app.agents.orchestrator import Orchestrator
    orch = Orchestrator(get_provider())
    answer = orch.handle("What is the pharmacy reject rate for Medicare "
                         "Advantage members?", user=analyst)
    trust = (answer.get("trust") or {})
    check("Phase 0 · question answered through the governed pipeline",
          bool(answer.get("sql") or answer.get("rows") is not None),
          f"trust={round(trust.get('score', 0) * 100)}%")
    say(f"SQL issued: {str(answer.get('sql', ''))[:66]}…", 4)

    # -------------------------------------------------------------------
    banner("PHASE 1", "Zero-Copy MCP data access with scope pushdown")
    say("Every read is brokered by the MCP layer. The analyst's LOB scope is")
    say("pushed into the query; it is not a filter the caller can drop.")
    print()

    from app.mcp import data_service
    svc = data_service()

    r_ok = svc.execute("SELECT COUNT(*) FROM claims c WHERE c.lob = "
                       "'Medicare Advantage'", scope_a, purpose="demo")
    check("Phase 1 · in-scope read succeeds", r_ok.ok,
          f"{r_ok.rows[0][0] if r_ok.rows else 0:,} MA claims")

    r_write = svc.execute("DELETE FROM claims", scope_a, purpose="demo")
    check("Phase 1 · a write statement is refused (read-only contract)",
          not r_write.ok,
          (r_write.refusal_reason or r_write.error or "")[:48])

    r_cross = svc.execute("SELECT COUNT(*) FROM claims c WHERE c.lob = "
                          "'Commercial'", scope_a, purpose="demo")
    cross_n = (r_cross.rows[0][0] if (r_cross.ok and r_cross.rows) else 0)
    check("Phase 1 · cross-LOB read yields nothing for an MA-only analyst",
          (not r_cross.ok) or cross_n == 0,
          f"Commercial rows visible to u-ma: {cross_n}")

    # -------------------------------------------------------------------
    banner("PHASE 2", "Ontology, CAPS bindings and the compliance pillars")
    say("The CMS rulebook is declarative. The pillars evaluate it against the")
    say("warehouse and tell us the 72-hour clock is being breached.")
    print()

    from app.semantic import ontology
    from app.analytics import rules_engine

    check("Phase 2 · ontology spec loads with typed object types + edges",
          len(ontology.object_types()) > 0 and len(ontology.edges()) > 0,
          f"{len(ontology.object_types())} object types, "
          f"{len(ontology.edges())} edges")
    vendors = ontology.caps_vendors()
    check("Phase 2 · CAPS vendor bindings present (Facets / QNXT)",
          len(vendors) > 0, f"vendors: {', '.join(vendors)}")

    tat = rules_engine.determination_timeliness(scope_a)
    breaches = tat.get("breaches", tat.get("breach_count", 0))
    breaches = len(breaches) if isinstance(breaches, list) else breaches
    check("Phase 2 · CDAG-TAT-568 timeliness evaluated from the Brain rule",
          "rule_id" in str(tat) or breaches is not None,
          f"{breaches} determinations breaching the 72h clock")

    pillars = rules_engine.pillar_summary(scope_a)
    check("Phase 2 · pillar summary produced for the analyst's scope",
          isinstance(pillars, dict) and len(pillars) > 0,
          f"pillars evaluated: {', '.join(list(pillars)[:4])}")

    # -------------------------------------------------------------------
    banner("PHASE 3", "Agent swarm triage → a persistent, deduped Case")
    say("The Sentry decides which departmental agents are relevant, they run")
    say("on the shared framework, and the finding becomes a tracked Case.")
    print()

    from app.agents import swarm
    from app.agents import case_store

    selected = swarm.select_agents(
        "Pharmacy rejects spiked after the April GLP-1 formulary change and "
        "coverage determinations are breaching the 72 hour clock")
    check("Phase 3 · Sentry activates only the relevant departments",
          len(selected) > 0,
          "activated: " + ", ".join(
              (a if isinstance(a, str)
               else (a.get("name") or a.get("agent_id") or a.get("persona")
                     or a.get("title") or str(a)[:18]))
              for a in selected[:4]))

    case = case_store.upsert_case(
        case_type="pbm_reject_spike", lob="Medicare Advantage",
        subject="GLP-1 tier move — reject 75 spike",
        pattern="reject_75_spike_2026Q2",
        severity="high", trust_score=0.91,
        evidence={"rule_id": "CDAG-PA-75",
                  "citation": "42 CFR §423.568(b)",
                  "observed_reject_75": 1840,
                  "formulary_change": "2026-04-01 GLP-1 tier 2→3"},
        created_by="swarm")
    case_id = case["case_id"]
    ok("Phase 3 · case created and persisted", case_id)

    dup = case_store.upsert_case(
        case_type="pbm_reject_spike", lob="Medicare Advantage",
        subject="GLP-1 tier move — reject 75 spike",
        pattern="reject_75_spike_2026Q2",
        severity="high", trust_score=0.91, evidence={},
        created_by="swarm")
    check("Phase 3 · re-running the swarm DEDUPES rather than duplicating",
          dup["case_id"] == case_id, f"same case id {dup['case_id']}")

    check("Phase 3 · the case is invisible outside its LOB",
          case_store.get_case(case_id, scope_from_user(
              get_user_context("u-commercial"))) is None,
          "a Commercial analyst cannot see this MA case")

    # -------------------------------------------------------------------
    banner("PHASE 5", "What-If: model the tier rollback BEFORE proposing it")
    say("Before anyone asks for approval, the actuary simulates the rollback")
    say("in a sandbox. The live Brain is never touched.")
    print()

    from app.schemas.simulation import ParameterOverride, SimulationRequest
    from app.simulation import engine as sim_engine
    from app.semantic.brain import get_brain
    import copy as _copy

    brain_before = _copy.deepcopy(get_brain()["simulation"])

    sim_req = SimulationRequest(
        baseline_query="Medicare Advantage members with pharmacy claims",
        parameter_overrides=[
            ParameterOverride(brain_path="metrics.pharmacy_cost.stress_pct",
                              op="set", value=-0.12,
                              reason="roll GLP-1 back from tier 3 to tier 2"),
            ParameterOverride(brain_path="metrics.reject_count.stress_pct",
                              op="set", value=-0.40,
                              reason="rollback clears ~40% of reject-75s"),
            ParameterOverride(brain_path="metrics.mlr.stress_pct",
                              op="set", value=-0.018,
                              reason="lower pharmacy spend pulls the loss "
                                     "ratio down ~1.8%"),
        ],
        metrics_requested=["mlr", "net_savings", "admin_burden",
                           "affected_members"])
    result = sim_engine.run_simulation(sim_req, analyst, scope_a)

    ok("Phase 5 · simulation completed", result.run_id)
    say(f"baseline MLR {result.baseline_mlr_bps} bps  →  simulated "
        f"{result.simulated_mlr_bps} bps   (Δ {result.mlr_delta_bps} bps)", 4)
    say(f"net dollar impact  ${result.net_dollar_impact:,}", 4)
    say(f"admin burden delta {result.admin_burden_delta:,} minutes", 4)
    say(f"members affected   {result.affected_member_count:,}", 4)

    check("Phase 5 · the live Brain was NOT mutated by the simulation",
          get_brain()["simulation"] == brain_before,
          "simulation.md formulas byte-identical after the run")
    check("Phase 5 · every reported metric is traceable to a Brain formula",
          {m.metric for m in result.metrics} == set(result.formula_ids_used),
          f"formula_ids_used = {', '.join(result.formula_ids_used)}")
    check("Phase 5 · MLR delta is internally consistent",
          result.mlr_delta_bps ==
          result.simulated_mlr_bps - result.baseline_mlr_bps)

    try:
        sim_engine.run_simulation(
            SimulationRequest(
                baseline_query="Commercial members with high cost",
                parameter_overrides=[ParameterOverride(
                    brain_path="metrics.mlr.stress_pct", op="set",
                    value=-0.05, reason="probe")]),
            analyst, scope_a)
        check("Phase 5 · cross-LOB simulation refused", False)
    except sim_engine.SimulationScopeDenied as e:
        ok("Phase 5 · cross-LOB simulation refused for an MA-only analyst",
           str(e)[:52])

    from app.workspace import store as ws_store
    from app.schemas.workspace import ArtifactPin
    board = ws_store.create("Q2 GLP-1 Review", analyst, scope_a)
    art = ws_store.pin_artifact(board.id, ArtifactPin(
        type="simulation", spec={"run_id": result.run_id},
        lineage_ref=result.lineage_ref), scope_a)
    lineage = ws_store.lineage_for(art.id, scope_a)
    check("Phase 5 · result pinned to a Workspace with full lineage",
          lineage.get("found") and bool(lineage.get("logic_tree")),
          f"board '{board.name}' · artifact {art.id}")

    # -------------------------------------------------------------------
    banner("PHASE 4", "Promote to a real action — maker-checker dual control")
    say("The simulation is worth acting on. Promotion PROPOSES an action; it")
    say("never executes one. Two distinct officers must sign.")
    print()

    from app.actions import engine as act_engine
    from app.schemas.actions import ActionState, ControlMode

    action = sim_engine.promote(
        result.run_id,
        "Roll GLP-1 back to tier 2 for H1234 and reprocess affected rejects",
        analyst, scope_a)
    ok("Phase 4 · promotion queued an action", action.action_id)
    check("Phase 4 · promotion did NOT execute anything",
          action.state in (ActionState.PENDING_FIRST_APPROVAL,
                           ActionState.PENDING_SECOND_APPROVAL),
          f"state = {action.state.value}")

    # a material, critical-severity action for the full dual-control path
    big = act_engine.propose(
        case_id=case_id, action_type="claim_adjustment",
        target_object="RX-BATCH-2026Q2", lob="Medicare Advantage",
        summary="Reprocess 1,840 reject-75 pharmacy claims under tier 2",
        estimated_financial_impact=420000.0,
        regulatory_severity="critical", trust_score=0.93,
        target_system="dry_run", proposer_user_id="u-ma")
    check("Phase 4 · a $420k critical action requires DUAL control",
          big.control_mode == ControlMode.DUAL,
          "threshold + severity read from policy_rules.md")

    try:
        act_engine.approve(big.action_id, analyst, scope_a)
        check("Phase 4 · analyst cannot approve", False)
    except act_engine.ActionError as e:
        ok("Phase 4 · the proposing analyst cannot approve", str(e)[:52])

    a1 = act_engine.approve(big.action_id, officer1, scope_1)
    check("Phase 4 · first signature leaves it PENDING_SECOND_APPROVAL",
          a1.state == ActionState.PENDING_SECOND_APPROVAL,
          "and a notification fired to the approver channel")

    try:
        act_engine.execute(big.action_id, officer1, scope_1)
        check("Phase 4 · execution blocked before the second signature", False)
    except act_engine.ActionError:
        ok("Phase 4 · execution blocked until a SECOND distinct officer signs")

    try:
        act_engine.approve(big.action_id, officer1, scope_1)
        check("Phase 4 · same officer cannot sign twice", False)
    except act_engine.ActionError as e:
        ok("Phase 4 · separation of duties: same officer cannot sign twice",
           str(e)[:46])

    a2 = act_engine.approve(big.action_id, officer2, scope_from_user(officer2))
    check("Phase 4 · two distinct signatures → APPROVED",
          a2.state == ActionState.APPROVED and a2.distinct_approvers())

    out = act_engine.execute(big.action_id, officer1, scope_1)
    check("Phase 4 · execution succeeds through the governed adapter",
          out["receipt"]["ok"] and out["action"]["state"] == "EXECUTED",
          "dry-run adapter recorded the exact outbound payload")

    # -------------------------------------------------------------------
    banner("PHASE 6", "Tamper-evident ledger, reversal, notifications, cost")
    say("Everything above is now cryptographically committed. Finance then")
    say("reverses part of the batch — which is a NEW block, never an edit.")
    print()

    from app.trust import ledger_v2
    from app.actions import compensating

    v = ledger_v2.verify_chain()
    check("Phase 6 · hash chain verifies end-to-end",
          v.ok, f"{v.checked} v2 blocks checked, head at seq {v.head_seq}")

    comp = compensating.propose_compensation(
        big.action_id,
        {"reason": "Finance reversed 260 of the reprocessed claims after "
                   "a duplicate-payment review",
         "mode": "credit", "credit_amount": "58400.00"},
        analyst, scope_a)
    check("Phase 6 · a reversal is itself ALWAYS dual-control",
          comp.control_mode == ControlMode.DUAL, comp.action_id)

    act_engine.approve(comp.action_id, officer1, scope_1)
    act_engine.approve(comp.action_id, officer2, scope_from_user(officer2))
    act_engine.execute(comp.action_id, officer1, scope_1)
    fin = compensating.finalize_compensation(comp.action_id, officer1, scope_1)

    orig_after = act_engine.get(big.action_id, scope_1)
    check("Phase 6 · the ORIGINAL action is now COMPENSATED",
          orig_after.state == ActionState.COMPENSATED)
    backlink = (fin or {}).get("ledger_entry", {}).get(
        "compensates_record_hash")
    check("Phase 6 · the reversal cryptographically references the original",
          bool(backlink), f"compensates_record_hash={str(backlink)[:24]}…")

    v2 = ledger_v2.verify_chain()
    check("Phase 6 · chain still verifies after the compensating block",
          v2.ok, f"{v2.checked} blocks")

    # tamper demonstration on a COPY — never the live ledger
    import json
    import shutil
    import tempfile
    tmp_led = os.path.join(tempfile.gettempdir(), "oppal_demo_tamper.jsonl")
    tmp_head = os.path.join(tempfile.gettempdir(), "oppal_demo_tamper_head.json")
    real_led, real_head, real_lock = (ledger_v2.LEDGER_PATH,
                                      ledger_v2.HEAD_PATH, ledger_v2.LOCK_PATH)
    try:
        shutil.copyfile(real_led, tmp_led)
        shutil.copyfile(real_head, tmp_head)
        ledger_v2.LEDGER_PATH, ledger_v2.HEAD_PATH = tmp_led, tmp_head
        ledger_v2.LOCK_PATH = tmp_head + ".lock"
        lines = open(tmp_led).read().splitlines()
        v2recs = [i for i, l in enumerate(lines)
                  if '"_ledger_version": 2' in l or '"_ledger_version":2' in l]
        if v2recs:
            i = v2recs[0]
            rec = json.loads(lines[i])
            rec["actor"] = "u-attacker"          # forge WHO did it
            lines[i] = json.dumps(rec)
            open(tmp_led, "w").write("\n".join(lines) + "\n")
            bad = ledger_v2.verify_chain()
            check("Phase 6 · forging the actor on a historical block is "
                  "DETECTED", not bad.ok,
                  f"first_broken_seq={bad.first_broken_seq}")
    finally:
        ledger_v2.LEDGER_PATH, ledger_v2.HEAD_PATH = real_led, real_head
        ledger_v2.LOCK_PATH = real_lock

    from app.notify.bus import configured_channels
    ch = configured_channels()
    check("Phase 6 · notification channels degrade cleanly when unconfigured",
          all(isinstance(c.get("available"), bool) for c in ch.values()),
          f"{ {k: v['available'] for k, v in ch.items()} } — no exception, "
          f"workflow unaffected")

    from app.finops import telemetry
    t = telemetry.snapshot()
    check("Phase 6 · FinOps reconciles (session ≤ global, Decimal money)",
          t.session_cost_usd <= t.global_cost_usd and
          0.0 <= t.cache_hit_rate <= 1.0,
          f"provider={t.provider} · session ${t.session_cost_usd} / global "
          f"${t.global_cost_usd} · cache {round(t.cache_hit_rate * 100)}%")

    today = __import__("datetime").datetime.now(
        __import__("datetime").timezone.utc).date().isoformat()
    export = ledger_v2.export(today, today, fmt="csv")
    check("Phase 6 · auditor export produced for the date range",
          export.startswith("seq,ts,kind"),
          f"{len(export.splitlines()) - 1} rows exported as CSV")

    # -------------------------------------------------------------------
    banner("SCENARIO COMPLETE", "the audit trail of this entire run")
    say(f"Case            {case_id}")
    say(f"Simulation      {result.run_id}   (Δ {result.mlr_delta_bps} bps, "
        f"${result.net_dollar_impact:,})")
    say(f"Promoted action {action.action_id}")
    say(f"Executed action {big.action_id}  →  EXECUTED")
    say(f"Compensation    {comp.action_id}  →  original COMPENSATED")
    say(f"Ledger          {v2.checked} chained blocks, verified ok={v2.ok}")


# ===========================================================================
if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        STEPS_FAIL.append("unhandled exception")

    print()
    print("═" * W)
    total = len(STEPS_OK) + len(STEPS_FAIL)
    print(f"  {len(STEPS_OK)}/{total} scenario checks passed")
    if STEPS_FAIL:
        print("  FAILED:")
        for f in STEPS_FAIL:
            print(f"    ✗ {f}")
    print("═" * W)
    sys.exit(1 if STEPS_FAIL else 0)
