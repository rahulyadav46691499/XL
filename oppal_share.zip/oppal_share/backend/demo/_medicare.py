"""Shared setup for the Medicare Sales business-case scripts.

The four case scripts (e2e_ms_case2..5) each need the same six lines: build
the warehouse from the supplied CSVs, switch the Context Brain to this
domain, invalidate the cached scope universe, and resolve the four personas.
Repeating that four times is how the payer scripts drifted apart, so it
lives here once.

Users are resolved AFTER the domain switch on purpose: get_user_context()
intersects role_lob_access with ALL_LOBS(), the ACTIVE domain's scope
universe. A real caller never hits this — their domain is already switched,
through the UI, before any request lands.

Import order matters: callers must have called reset_demo_env() BEFORE
importing this module, because app.data.db opens SQLite on import.
"""
from __future__ import annotations

import os
import sys

DOMAIN = "medicare_sales"
PAYER = "healthcare_payer"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "data"))


class Cast:
    """The four personas plus their server-derived scopes."""

    def __init__(self, counts, brain_report):
        from app.data.db import get_user_context
        from app.mcp import scope_from_user
        self.counts = counts
        self.brain_report = brain_report
        self.casey = get_user_context("u-compliance")    # officer, full scope
        self.dana = get_user_context("u-compliance2")    # 2nd, distinct signer
        self.morgan = get_user_context("u-ma")           # MA analyst
        self.max_m = get_user_context("u-medicaid")      # Medicaid analyst
        self.sc_casey = scope_from_user(self.casey)
        self.sc_dana = scope_from_user(self.dana)
        self.sc_morgan = scope_from_user(self.morgan)
        self.sc_max = scope_from_user(self.max_m)

    @property
    def rows(self) -> int:
        return sum(self.counts.values())


def setup() -> Cast:
    """Build the warehouse, activate the Medicare Sales Brain, resolve users."""
    from app.data.db import ensure_db, POOL, invalidate_scope_values
    from app.semantic import brain as bl
    import make_medicare_sales_dataset as mk

    ensure_db()
    counts = mk.build()
    POOL.reset()
    bl.set_active(DOMAIN)
    report = bl.reload_brain()
    invalidate_scope_values()
    return Cast(counts, report)


def teardown(R) -> None:
    """Leave the payer domain exactly as it was found.

    Every case script asserts this rather than just doing it: a case that
    silently leaves another domain active makes the NEXT script's failures
    unreadable, which is how a green suite starts lying.
    """
    from app.data.db import invalidate_scope_values
    from app.semantic import brain as bl
    bl.set_active(PAYER)
    bl.reload_brain()
    invalidate_scope_values()
    R.banner("TEARDOWN", "The payer domain is left exactly as it was")
    R.check("active domain restored", bl.active_domain() == PAYER)
    R.check("payer metrics restored", "mlr" in bl.get_brain()["metrics"])


def title(R, line1: str, line2: str) -> None:
    print()
    print("+" + "-" * (R.W - 2) + "+")
    for line in (line1, line2):
        print("|" + ("  " + line).ljust(R.W - 2) + "|")
    print("+" + "-" * (R.W - 2) + "+")


def asker(user):
    """A chat caller returning (sql, trust_pct, rows) like the all-tabs script."""
    from app.llm.base import get_provider
    from app.agents.orchestrator import Orchestrator
    orch = Orchestrator(get_provider())

    def ask(q, as_user=None):
        a = orch.handle(q, user=as_user or user)
        rows = next((art["rows"] for art in a.get("artifacts", [])
                     if art.get("rows")), None)
        return (a.get("sql"),
                round((a.get("trust") or {}).get("score", 0) * 100),
                rows or [])
    return ask


def breaches(scope, rule_id: str) -> list:
    """Every Pillars breach raised by one policy rule, at this scope.

    The rules engine returns all query-bearing rules under the `regulatory`
    key regardless of each rule's declared `pillar:` — see the note in
    medicare_sales_alltabs_verify.py. Filtering by rule id here keeps the
    case scripts honest about which rule produced which finding.
    """
    from app.analytics import rules_engine
    reg = rules_engine.pillar_summary(scope).get("regulatory") or {}
    return [b for b in (reg.get("breaches") or []) if b.get("rule") == rule_id]
