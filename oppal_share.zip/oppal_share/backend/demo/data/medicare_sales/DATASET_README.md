# Healthcare Sales (Medicare Distribution) — sample dataset

Twelve tables covering the Medicare Sales lifecycle, generated from a fixed
seed. Every figure quoted below is real output of
`make_healthcare_sales_dataset.py`, captured from a run, not a design target.

```bash
python3 make_healthcare_sales_dataset.py     # regenerates all 12 CSVs, 35/35 checks
```

Re-running is idempotent: same seed, byte-identical CSVs.

## Provenance — read this first

This schema is a **design**, derived from
`Medicare_Sales_Reporting_Analytics_Engineering.docx` by mapping its §2 source
domains onto table grains, its §5 KPIs onto required measures, and its §7
reporting dimensions onto dimension columns. It is **not** a transcription of an
existing warehouse — that document contains no schema. Column names come from
three places: back-solving the KPIs (`effectuated_flag`, `disenroll_days`,
`turnaround_hours` exist because §5.4 asks for those KPIs), the document's own
dimension list, and standard Medicare-distribution vocabulary (NPN, AHIP, SOA,
CTM, PBP, effectuation, rapid disenrolment, AEP/OEP/SEP/ICEP, LIS, D-SNP/C-SNP).

**An SME should review the column list before this is wired into the platform.**
If a real CRM export or warehouse model exists, that should drive the schema
instead and this generator should be retargeted to mirror its column names.

Values that are explicitly illustrative and need replacing with real figures:

- `agent_commissions.fmv_cap` — placeholder CMS fair-market-value compensation
  caps ($694 MA / $109 PDP). CMS publishes these annually.
- `A1001` — ACA has no CMS contract number; this is an internal issuer id.
- `enrollments.revenue_per_enrollment` — plan revenue (CMS capitation bid), not
  member premium, which is why it is non-zero on $0-premium plans.

## The funnel

The spine of the data. Rates vary by channel, market and lead source, so
aggregates are not flat.

| Stage | Rows | Of prior stage |
|---|---:|---:|
| leads | 3,000 | |
| contacted | 1,884 | 62.8% |
| applications | 1,050 | 55.7% |
| approved | 944 | 89.9% |
| effectuated | 889 | 94.2% |
| retained 12 months | 791 | 89.0% |

## Tables

| Table | Rows | Grain | Scope class |
|---|---:|---|---|
| `leads` | 3,000 | one prospect | governed by `lob` |
| `lead_activities` | 10,339 | one outreach / disposition event | transitive via `lead_id` |
| `applications` | 1,050 | one MA/MAPD/PDP application | governed by `lob` |
| `enrollments` | 944 | one approved enrolment + its outcome | governed by `lob` |
| `agent_commissions` | 1,203 | one compensation payment | governed by `lob` |
| `interactions` | 800 | one call, complaint or CTM grievance | governed by `lob` |
| `sales_targets` | 240 | agent × quarter goal | governed by `lob` |
| `sales_agents` | 60 | one agent / broker | ungoverned reference |
| `agent_certifications` | 180 | agent × plan-year × cert type | ungoverned reference |
| `campaigns` | 12 | one campaign | ungoverned reference |
| `plan_benefit_packages` | 24 | contract / plan / PBP | ungoverned reference |
| `cms_market_enrollment` | 900 | contract × plan × county × month | ungoverned (public CMS file) |

**Scope class** is how OpPal's row-level security would treat each table.
Governed tables carry `lob` directly (Medicare Advantage, Medicaid, Commercial,
ACA Exchange) so the existing persona cast and `role_lob_access` grants apply
unchanged. `lead_activities` carries no scope column and is scoped by joining up
to its lead — the same pattern the payer domain uses for `products → plans`.

Reporting dimensions available on the fact tables: `market`, `state`, `county`,
`channel`, `lead_source`, `campaign_id`, `cohort`, `contract_id`, `plan_id`,
`pbp_id`, `plan_type`, `funnel_stage`, `enrollment_period`.

## Join map

```
lead_activities.lead_id         = leads.lead_id
applications.lead_id            = leads.lead_id
enrollments.application_id      = applications.application_id
agent_commissions.enrollment_id = enrollments.enrollment_id
interactions.lead_id            = leads.lead_id
leads.assigned_agent_id         = sales_agents.agent_id
applications.agent_id           = sales_agents.agent_id
enrollments.agent_id            = sales_agents.agent_id
agent_certifications.agent_id   = sales_agents.agent_id
sales_targets.agent_id          = sales_agents.agent_id
leads.campaign_id               = campaigns.campaign_id
enrollments.pbp_id              = plan_benefit_packages.pbp_id
cms_market_enrollment.contract_id = plan_benefit_packages.contract_id   -- LEFT
```

The CMS join is a **left** join by design: the public file contains competitor
contracts (Aetna, Humana, UnitedHealthcare, Elevance) that we do not sell. That
is what makes market penetration computable.

All twelve joins are asserted orphan-free by the self-check, along with two
denormalisation invariants (`applications.lob` matches its lead,
`enrollments.lob` matches its application), premium reconciliation
(`enrollments.monthly_premium` equals its plan's published premium) and quarter
derivation (`enrollment_quarter` matches `effective_date`).

## Planted findings

Six findings are planted deterministically so pillars, agents and data-quality
scans have something real to catch. Each is asserted in the self-check, so a
tuning change that quietly destroys one fails there instead of in a demo.

**1. AEP lead-quality collapse.** Vendor source `LS-TELE-03` in the Southwest
during AEP 2026Q4.

- Qualified-lead rate **62.0% → 24.2%**; peer sources hold at 65.9% in the same quarter
- Cost per qualified lead **$33.89 → $104.32 (3.1×)**
- Lead-to-enrolment **11.8% vs 30.6%** for peers

**2. Phantom effectuation.** Agent `AG-0027`.

- **29 of 41** approved enrolments effectuated (**70.7%**) vs a peer mean of 95.0%
- Peer leave-one-out **z = 3.89**, clearing a z_threshold of 3.0 with margin
- Initial commission paid on **9** enrolments that never effectuated = **$5,542.64**

**3. Broker channel retention leakage.** Broker channel, Northeast market.

- Rapid disenrolment (≤90 days) **26.7%** (n=45) vs 4.7% across every other segment
- Unrecovered clawback exposure **$5,734.02**

**4. Certification gaps.** **31** applications written by **3** agents after
their AHIP or state licence had expired. Application dates are clamped to the
2026 plan year so a January date cannot falsely breach a 31 December expiry.

**5. `lost_reason` completeness.** **156 of 834** Lost leads (18.7%) carry no
reason, concentrated at three agents — AG-0013 58%, AG-0031 73%, AG-0048 72% —
against a maximum of 22% among the 19 other agents with 15+ Lost leads.

**6. `cms_market_enrollment.plan_type` gap.** **149 of 900** rows (16.6%) blank,
concentrated in three contracts — H3390 62%, S5678 61%, E7712 58% — against
under 10% everywhere else. This is the file to use for an import / onboarding
walkthrough.

Also present: **31** initial commissions above the FMV cap ($1,314.01 in
excess), SOA missing on ~3.5% of applications and signed inside the 48-hour
window on a further slice, and duplicate leads at ~2%.

## Notes on the generator

Pure stdlib — `csv`, `random`, `statistics`, `datetime`. One `random.Random(SEED)`
threaded through everything; no module-level `random.` calls. Referential
integrity is maintained **by construction**: every downstream row is generated
from its parent, so `lob`, `market`, `state`, `county`, `channel`, `contract_id`
and `plan_id` are denormalised down the funnel and cannot disagree.

Every planted-finding knob draws its random numbers unconditionally and then
overrides the value, so retuning one rate cannot silently re-roll every table
generated after it. If you change a knob, re-run — the self-check will tell you
whether the finding survived.

**AEP enrolments are effective 1 January**, as CMS requires, so
`enrollment_quarter` (derived from `effective_date`) is sparse in Q4 and heavy
in Q1 — 356 in 2026Q1 and 287 in 2027Q1, against 39 in 2026Q4. Measure selling
pace on `applications.application_quarter`; measure membership on
`enrollments.enrollment_quarter`. Sales-to-goal attainment by market lands
between 0.54 and 1.06 on the application quarter, and the CTM complaint rate is
7.9 per 1,000 effectuated enrolments.

`funnel_stage` takes the furthest stage a lead reached: `Lead` (never
contacted), `Lost` (contacted, no application), `Application` (applied, denied
or withdrawn), `Approved` (approved, never effectuated), `Effectuated`.
