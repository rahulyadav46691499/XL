"""Medicare Sales warehouse loader — 11 tables from the supplied CSV dataset.

WHY THIS IS A LOADER, NOT A GENERATOR
-------------------------------------
``make_pharma_dataset.py`` and ``generate.py`` synthesise their rows from a
fixed seed. This domain's dataset was delivered as CSVs and reviewed as CSVs,
so the CSVs are the source of truth: re-generating them here would mean the
data an SME signed off on and the data the platform queries could drift apart
without either file changing. The loader reads them verbatim.

Determinism therefore comes from the files rather than a seed — same CSVs, same
warehouse, byte for byte.

WHAT IT LOADS, AND THE ONE TABLE IT DELIBERATELY DOES NOT
---------------------------------------------------------
Eleven tables land in the warehouse. The twelfth, ``cms_market_enrollment``,
ships as ``demo/data/cms_market_enrollment.csv`` and is NOT loaded: it is the
never-before-ingested monthly CMS file that Business Case 3 imports through the
Data tab, the same way the payer document's Case 3 ships
``medicaid_coding_worksheet.csv`` alongside its script. Loading it here would
turn an ingestion walkthrough into a query against data the platform already
had.

RBAC GRANTS: NONE NEEDED
------------------------
The pharma builder had to seed ``role_lob_access`` because its scope column is
``distributor_id`` with a vocabulary the payer grants know nothing about. This
dataset's ``lob`` values are exactly the payer's four — Medicare Advantage,
Medicaid, Commercial, ACA Exchange — so the grants ``generate.py`` already
seeds apply unchanged and Morgan/Max/Blair/Casey/Dana resolve correctly with no
new rows. Adding grants here would be a no-op at best and a cross-domain leak
at worst.

Written to the SAME sqlite file as the payer warehouse (OPPAL_DB_PATH) so the
pool, scope enforcer and connectors need no change: a domain switch changes the
Brain, not the plumbing.

Run:  PYTHONPATH=. python3 demo/data/make_medicare_sales_dataset.py
"""
from __future__ import annotations

import csv
import os
import sqlite3

CSV_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "medicare_sales")

# Loaded in parent-before-child order so a FK read during the self-check never
# sees a half-built graph. cms_market_enrollment is absent by design (see the
# module docstring).
TABLES = [
    "campaigns",
    "sales_agents",
    "agent_certifications",
    "plan_benefit_packages",
    "sales_targets",
    "leads",
    "lead_activities",
    "applications",
    "enrollments",
    "agent_commissions",
    "interactions",
]

# Column affinity. Everything not named here is TEXT.
#
# This is declared rather than sniffed from the data on purpose. SQLite compares
# across storage classes without coercing, so a flag column left with TEXT
# affinity makes `WHERE effectuated_flag = 1` silently match zero rows — a
# governed metric that returns 0 instead of failing is the worst outcome
# available. Sniffing (the Data tab importer's `_infer`) reads only the first
# 200 rows, which is enough to mis-type `disenroll_days`: it is blank for the
# 90% of enrolments that never disenrolled, so a sample of the head sees no
# numeric value at all and settles on TEXT.
#
# Column names are consistent across the dataset, so one flat map is enough.
# `county_fips` is deliberately absent: it is an identifier with significant
# leading zeros, not a number.
NUMERIC = {
    # flags and counts
    "aep_flag": "INTEGER", "dual_eligible": "INTEGER",
    "lis_eligible": "INTEGER", "qualified_flag": "INTEGER",
    "duplicate_flag": "INTEGER", "days_to_first_contact": "INTEGER",
    "attempt_number": "INTEGER", "duration_seconds": "INTEGER",
    "followed_up_within_sla": "INTEGER", "soa_on_file": "INTEGER",
    "verification_call_completed": "INTEGER",
    "effectuated_flag": "INTEGER",
    "cancel_before_effective_flag": "INTEGER",
    "disenroll_days": "INTEGER", "rapid_disenroll_flag": "INTEGER",
    "retained_12mo_flag": "INTEGER", "recoupment_due_flag": "INTEGER",
    "ctm_flag": "INTEGER", "resolved_flag": "INTEGER",
    "escalated_flag": "INTEGER", "plan_year": "INTEGER",
    "carrier_appointed": "INTEGER", "ce_credits_completed": "INTEGER",
    "ce_credits_required": "INTEGER", "impressions": "INTEGER",
    "responses": "INTEGER", "leads_generated": "INTEGER",
    "target_enrollments": "INTEGER", "selling_days": "INTEGER",
    "part_d_included": "INTEGER", "enrolled": "INTEGER",
    "eligible": "INTEGER",
    # measures
    "qualification_score": "REAL", "cost_allocated": "REAL",
    "turnaround_hours": "REAL", "annual_premium": "REAL",
    "monthly_premium": "REAL", "revenue_per_enrollment": "REAL",
    "commission_paid": "REAL", "fmv_cap": "REAL", "override_paid": "REAL",
    "bonus_paid": "REAL", "clawback_amount": "REAL",
    "resolution_hours": "REAL", "target_premium": "REAL",
    "target_retention_rate": "REAL", "required_daily_pace": "REAL",
    "acquisition_budget": "REAL", "productive_hours_quarter": "REAL",
    "star_rating": "REAL", "premium": "REAL", "moop": "REAL",
    "spend": "REAL", "penetration_rate": "REAL",
}

# Every declared relationship in the dataset, asserted by the self-check. The
# same list is declared in the Brain's entities.md `## Joins`; keeping it here
# too means a schema drift fails the loader instead of quietly producing a
# domain whose semantic graph describes joins that no longer resolve.
JOINS = [
    ("lead_activities", "lead_id", "leads", "lead_id"),
    ("applications", "lead_id", "leads", "lead_id"),
    ("enrollments", "application_id", "applications", "application_id"),
    ("agent_commissions", "enrollment_id", "enrollments", "enrollment_id"),
    ("applications", "agent_id", "sales_agents", "agent_id"),
    ("enrollments", "agent_id", "sales_agents", "agent_id"),
    ("agent_certifications", "agent_id", "sales_agents", "agent_id"),
    ("leads", "campaign_id", "campaigns", "campaign_id"),
    ("enrollments", "pbp_id", "plan_benefit_packages", "pbp_id"),
    ("interactions", "lead_id", "leads", "lead_id"),
    ("sales_targets", "agent_id", "sales_agents", "agent_id"),
    ("leads", "assigned_agent_id", "sales_agents", "agent_id"),
]


def _db_path(db_path: str | None = None) -> str:
    return db_path or os.environ.get(
        "OPPAL_DB_PATH",
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__)))), "app", "data", "oppal.db"))


def _read_csv(name: str) -> tuple[list[str], list[list]]:
    path = os.path.join(CSV_DIR, f"{name}.csv")
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    if not rows:
        raise ValueError(f"{name}.csv is empty")
    header = [c.strip() for c in rows[0]]
    return header, rows[1:]


def _coerce(value: str, affinity: str):
    """CSV text -> the declared storage class. Blank is NULL, never 0.

    A missing value that loads as 0 is indistinguishable from a real zero, and
    the Data Quality tab's missing-value scan — which Business Case 3 runs — is
    then measuring nothing. Two planted findings in this dataset (blank
    `lost_reason`, blank `plan_type`) depend on blanks staying NULL.
    """
    s = "" if value is None else str(value).strip()
    if s == "":
        return None
    if affinity == "TEXT":
        return s
    try:
        return int(s) if affinity == "INTEGER" else float(s.replace(",", ""))
    except ValueError:
        # A value that does not parse is data to look at, not data to drop:
        # keep the original text so the quality scan can surface it.
        return s


def build(db_path: str | None = None) -> dict:
    """Create and fill the Medicare Sales tables. Returns {table: row_count}.

    Re-runnable: each table is dropped and rebuilt, so a rebuild after a Data
    tab import restores the shipped dataset exactly.
    """
    path = _db_path(db_path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    con = sqlite3.connect(path)
    out = {}
    try:
        for table in TABLES:
            header, rows = _read_csv(table)
            affinities = [NUMERIC.get(c, "TEXT") for c in header]
            con.execute(f"DROP TABLE IF EXISTS {table}")
            con.execute(f"CREATE TABLE {table} (" + ", ".join(
                f"{c} {a}" for c, a in zip(header, affinities)) + ")")
            placeholders = ",".join("?" * len(header))
            con.executemany(
                f"INSERT INTO {table} VALUES ({placeholders})",
                [[_coerce(r[i] if i < len(r) else None, affinities[i])
                  for i in range(len(header))] for r in rows])
            out[table] = len(rows)
        con.commit()
    finally:
        con.close()
    return out


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import statistics
    import sys

    print(f"loading from {CSV_DIR}")
    counts = build()
    for t in TABLES:
        print(f"  {t:24s} {counts[t]:>7,} rows")
    print(f"  {'TOTAL':24s} {sum(counts.values()):>7,} rows")

    con = sqlite3.connect(_db_path())
    con.row_factory = sqlite3.Row
    fails = []

    def check(label, cond, detail=""):
        print(f"  {'ok  ' if cond else 'FAIL'} {label}"
              + (f" — {detail}" if detail else ""))
        if not cond:
            fails.append(label)

    def one(sql, *args):
        return con.execute(sql, args).fetchone()[0]

    print("\nreferential integrity")
    for child, ckey, parent, pkey in JOINS:
        orphans = one(
            f"SELECT COUNT(*) FROM {child} c WHERE c.{ckey} IS NOT NULL "
            f"AND c.{ckey} NOT IN (SELECT {pkey} FROM {parent})")
        check(f"{child}.{ckey} -> {parent}.{pkey}", orphans == 0,
              f"{orphans} orphan(s)")

    print("\nfunnel shape")
    stages = dict(con.execute(
        "SELECT funnel_stage, COUNT(*) FROM leads GROUP BY funnel_stage"))
    n_leads = sum(stages.values())
    n_apps = one("SELECT COUNT(*) FROM applications")
    n_appr = one("SELECT COUNT(*) FROM applications WHERE status='Approved'")
    n_eff = one("SELECT COUNT(*) FROM enrollments WHERE effectuated_flag=1")
    n_ret = one("SELECT COUNT(*) FROM enrollments WHERE retained_12mo_flag=1")
    print(f"  {n_leads:,} leads -> {n_apps:,} applications -> {n_appr:,} "
          f"approved -> {n_eff:,} effectuated -> {n_ret:,} retained 12mo")
    check("the funnel narrows at every step",
          n_leads > n_apps > n_appr >= n_eff > n_ret * 0.5)
    check("effectuation is the majority outcome of approval",
          n_eff / n_appr > 0.8, f"{n_eff / n_appr:.1%}")

    # ---- F1 AEP lead-quality collapse -----------------------------------
    print("\nF1  AEP lead-quality collapse — LS-TELE-03, Southwest")
    rows = con.execute(
        "SELECT lead_quarter, COUNT(*) n, AVG(qualified_flag) qr, "
        "SUM(cost_allocated) cost, SUM(qualified_flag) q "
        "FROM leads WHERE lead_source='LS-TELE-03' AND market='Southwest' "
        "GROUP BY lead_quarter ORDER BY lead_quarter").fetchall()
    for r in rows:
        cpql = r["cost"] / r["q"] if r["q"] else 0
        print(f"    {r['lead_quarter']}  n={r['n']:>4}  qualified="
              f"{r['qr']:.3f}  cost/qualified=${cpql:,.2f}")
    aep = next(r for r in rows if r["lead_quarter"] == "2026Q4")
    base = [r for r in rows if r["lead_quarter"] != "2026Q4"]
    base_qr = statistics.mean(r["qr"] for r in base)
    aep_cpql = aep["cost"] / aep["q"]
    base_cpql = statistics.mean(r["cost"] / r["q"] for r in base if r["q"])
    check("qualified-lead rate collapses in AEP 2026Q4",
          aep["qr"] < 0.30 and base_qr > 0.50,
          f"{aep['qr']:.1%} vs {base_qr:.1%} in prior quarters")
    check("cost per qualified lead roughly triples",
          2.5 < aep_cpql / base_cpql < 4.0,
          f"${aep_cpql:,.2f} vs ${base_cpql:,.2f} = "
          f"{aep_cpql / base_cpql:.1f}x")
    peer = con.execute(
        "SELECT AVG(qualified_flag) FROM leads WHERE lead_source='LS-TELE-01' "
        "AND market='Southwest' AND lead_quarter='2026Q4'").fetchone()[0]
    check("the peer lead source in the same market/quarter is stable",
          peer > 0.55, f"LS-TELE-01 {peer:.1%} vs LS-TELE-03 {aep['qr']:.1%}")

    # ---- F2 effectuation outlier ----------------------------------------
    print("\nF2  effectuation outlier — AG-0027")
    rates = {r[0]: r[1] for r in con.execute(
        "SELECT agent_id, AVG(effectuated_flag) FROM enrollments "
        "GROUP BY agent_id HAVING COUNT(*) >= 5")}
    target = "AG-0027"
    peers = [v for a, v in rates.items() if a != target]
    z = (rates[target] - statistics.mean(peers)) / statistics.pstdev(peers)
    n27 = one("SELECT COUNT(*) FROM enrollments WHERE agent_id=?", target)
    print(f"    {target} {rates[target]:.4f} on {n27} enrolments vs peer mean "
          f"{statistics.mean(peers):.4f} (sd {statistics.pstdev(peers):.4f})")
    check("the agent is a peer leave-one-out outlier",
          z < -3.0, f"z = {z:.2f} (below peers)")
    paid, npay = con.execute(
        "SELECT ROUND(SUM(c.commission_paid + c.bonus_paid + "
        "c.override_paid), 2), COUNT(*) FROM agent_commissions c "
        "JOIN enrollments e ON e.enrollment_id = c.enrollment_id "
        "WHERE e.effectuated_flag = 0").fetchone()
    paid27 = one(
        "SELECT ROUND(SUM(c.commission_paid + c.bonus_paid + "
        "c.override_paid), 2) FROM agent_commissions c "
        "JOIN enrollments e ON e.enrollment_id = c.enrollment_id "
        "WHERE e.effectuated_flag = 0 AND c.agent_id = ?", target)
    check("commission was paid on enrolments that never effectuated",
          npay > 0 and paid > 0, f"{npay} payment(s), ${paid:,.2f}")
    check("the whole exposure sits with the outlier agent",
          abs(paid27 - paid) < 0.01, f"{target} accounts for ${paid27:,.2f}")

    # ---- F4 channel retention leakage ------------------------------------
    print("\nF4  channel retention leakage — Broker / Northeast")
    worst = con.execute(
        "SELECT channel, market, COUNT(*) n, AVG(rapid_disenroll_flag) rd, "
        "AVG(cancel_before_effective_flag) cx, AVG(retained_12mo_flag) ret "
        "FROM enrollments GROUP BY channel, market HAVING n >= 20 "
        "ORDER BY rd DESC LIMIT 3").fetchall()
    for r in worst:
        print(f"    {r['channel']:9s}/{r['market']:10s} n={r['n']:>3}  "
              f"rapid={r['rd']:.3f}  cancel={r['cx']:.3f}  "
              f"retained={r['ret']:.3f}")
    top = worst[0]
    check("Broker/Northeast is the worst retention cell",
          (top["channel"], top["market"]) == ("Broker", "Northeast"),
          f"rapid disenrolment {top['rd']:.1%}")
    direct = con.execute(
        "SELECT AVG(rapid_disenroll_flag) FROM enrollments "
        "WHERE channel='Direct'").fetchone()[0]
    check("it is materially worse than the Direct channel",
          top["rd"] > direct, f"{top['rd']:.1%} vs Direct {direct:.1%}")
    exposure, ncb = con.execute(
        "SELECT ROUND(SUM(clawback_amount), 2), COUNT(*) "
        "FROM agent_commissions WHERE recoupment_due_flag = 1 "
        "AND clawback_status = 'Not Recovered'").fetchone()
    check("clawback exposure is outstanding, not recouped",
          exposure > 0, f"{ncb} payment(s), ${exposure:,.2f} not recovered")

    # ---- F5 missing lost_reason -------------------------------------------
    print("\nF5  missing lost_reason on Lost leads (Data Quality target)")
    blank, lost = con.execute(
        "SELECT SUM(CASE WHEN lost_reason IS NULL THEN 1 ELSE 0 END), "
        "COUNT(*) FROM leads WHERE funnel_stage='Lost'").fetchone()
    check("blanks survived the load as NULL, not as empty text",
          blank > 0, f"{blank}/{lost} = {blank / lost:.1%}")
    conc = con.execute(
        "SELECT assigned_agent_id, COUNT(*) n, "
        "SUM(CASE WHEN lost_reason IS NULL THEN 1 ELSE 0 END) b "
        "FROM leads WHERE funnel_stage='Lost' GROUP BY assigned_agent_id "
        "HAVING n >= 10 ORDER BY (b * 1.0 / n) DESC LIMIT 3").fetchall()
    for r in conc:
        print(f"    {r['assigned_agent_id']}  {r['b']}/{r['n']} = "
              f"{r['b'] / r['n']:.1%}")
    check("the blanks concentrate at a small number of agents",
          all(r["b"] / r["n"] > 0.50 for r in conc),
          ", ".join(r["assigned_agent_id"] for r in conc))

    # ---- F6 certification gaps -------------------------------------------
    print("\nF6  applications written on an expired certification")
    gaps = one(
        "SELECT COUNT(DISTINCT a.application_id) FROM applications a "
        "JOIN agent_certifications c ON c.agent_id = a.agent_id "
        "WHERE c.cert_type IN ('AHIP','State License') "
        "AND c.expiry_date < a.application_date")
    check("some applications were written on a lapsed AHIP or licence",
          gaps > 0, f"{gaps} application(s) — 42 CFR 422.2274(b)")

    # ---- the un-ingested Use Case 3 file ---------------------------------
    print("\nUse Case 3 import file (deliberately NOT loaded)")
    uc3 = os.path.join(os.path.dirname(CSV_DIR), "cms_market_enrollment.csv")
    check("cms_market_enrollment.csv ships alongside the script",
          os.path.exists(uc3), uc3)
    present = {r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    check("and is absent from the warehouse, so the import is genuine",
          "cms_market_enrollment" not in present)
    with open(uc3, newline="", encoding="utf-8-sig") as f:
        cms = list(csv.DictReader(f))
    nblank = sum(1 for r in cms if not (r["plan_type"] or "").strip())
    bycon: dict = {}
    for r in cms:
        c = bycon.setdefault(r["contract_id"], [0, 0])
        c[0] += 1
        if not (r["plan_type"] or "").strip():
            c[1] += 1
    hot = sorted(bycon.items(), key=lambda kv: -kv[1][1] / kv[1][0])[:3]
    check("plan_type is blank on a material share of rows",
          0.10 < nblank / len(cms) < 0.25,
          f"{nblank}/{len(cms)} = {nblank / len(cms):.1%}")
    check("the blanks concentrate in exactly 3 contracts",
          all(v[1] / v[0] > 0.50 for _, v in hot),
          ", ".join(f"{k} {v[1] / v[0]:.0%}" for k, v in hot))

    con.close()
    print()
    if fails:
        print(f"  FAILED {len(fails)} check(s):")
        for f in fails:
            print(f"    - {f}")
        sys.exit(1)
    print("  self-check OK — every planted finding is real and measurable")
