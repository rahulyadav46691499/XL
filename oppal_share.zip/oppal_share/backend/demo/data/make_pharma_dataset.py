"""Synthetic pharma cold-chain + chargeback dataset.

Six tables, fixed seed, planted findings the Brain's rules must catch:

  * Lot ONC-8812 through Hub-09 suffers a thermal excursion (>15 C for
    >120 min). MKT lands above the 10 C stability ceiling; 420 vials spoil.
  * Hub-09 claims 600 vials of chargeback against that lot. The 180-vial
    excess at $850 WAC is $153,000 of leakage.
  * Peer hubs claim close to what they spoil, so Hub-09's claims-per-spoiled
    ratio is a leave-one-out z-score outlier (~3.65).
  * Some SGTINs ship with a broken chain of custody -> DSCSA quarantine.

Written to the SAME sqlite file as the payer warehouse (OPPAL_DB_PATH) so the
pool, scope enforcer and connectors need no change: a domain switch changes
the Brain, not the plumbing.

Run:  PYTHONPATH=. python3 demo/data/make_pharma_dataset.py
"""
from __future__ import annotations

import os
import random
import sqlite3

SEED = 8812
WAC_UNIT = 850.0
IWP_DISCOUNT = 0.28
TARGET_LOT = "ONC-8812"
TARGET_HUB = "Hub-09"
SPOILED = 420
CLAIMED = 600

HUBS = [f"Hub-{i:02d}" for i in (1, 3, 5, 7, 9, 11, 13, 15)]
DISTRIBUTORS = {"Hub-01": "McK-Central", "Hub-03": "McK-Central",
                "Hub-05": "Cardinal-East", "Hub-07": "Cardinal-East",
                "Hub-09": "Cardinal-East", "Hub-11": "ABC-West",
                "Hub-13": "ABC-West", "Hub-15": "McK-Central"}
PRODUCTS = [
    ("58160-899-11", "00358160899117", "Oncolytive 40mg/mL", 2.0, 8.0, 1),
    ("00069-1085-01", "00300691085015", "Vaxaria RSV", 2.0, 8.0, 1),
    ("00002-8215-01", "00300028215012", "Insulistat U-100", 2.0, 8.0, 1),
    ("50242-070-01", "00350242070018", "Nephrolate 500mg", 15.0, 25.0, 0),
]
QUARTERS = ["2025Q1", "2025Q2", "2025Q3", "2025Q4",
            "2026Q1", "2026Q2", "2026Q3", "2026Q4"]

DDL = """
CREATE TABLE drug_products (
  ndc TEXT PRIMARY KEY, gtin TEXT, product_name TEXT,
  storage_min_c REAL, storage_max_c REAL, biologic INTEGER, wac_unit REAL);
CREATE TABLE batch_lots (
  lot_id TEXT PRIMARY KEY, ndc TEXT, manufacturer TEXT,
  units_released INTEGER, expiry_date TEXT);
CREATE TABLE shipments (
  shipment_id TEXT PRIMARY KEY, lot_id TEXT, ndc TEXT,
  distributor_id TEXT, hub_id TEXT, dispenser_id TEXT,
  ship_date TEXT, ship_quarter TEXT, units_shipped INTEGER,
  units_spoiled INTEGER, status TEXT);
CREATE TABLE iot_readings (
  reading_id INTEGER PRIMARY KEY, shipment_id TEXT, sensor_id TEXT,
  reading_ts TEXT, temp_c REAL, minutes_since_start INTEGER);
CREATE TABLE chargeback_claims (
  claim_id TEXT PRIMARY KEY, shipment_id TEXT, lot_id TEXT,
  distributor_id TEXT, hub_id TEXT, claim_quarter TEXT,
  units_claimed INTEGER, wac_claimed REAL, iwp_contract REAL,
  amount_claimed REAL, amount_contract REAL);
CREATE TABLE serialized_units (
  sgtin TEXT PRIMARY KEY, lot_id TEXT, shipment_id TEXT,
  distributor_id TEXT, verified INTEGER, custody_broken INTEGER,
  quarantined INTEGER, last_event TEXT);
"""


def _series(rng, shipment_id, excursion):
    """24h of readings every 30 min. `excursion` = minutes above 15 C."""
    rows = []
    for i in range(48):
        mins = i * 30
        if excursion and 300 <= mins < 300 + excursion:
            temp = round(rng.uniform(16.5, 22.0), 2)     # cooling failed
        else:
            temp = round(rng.uniform(3.2, 7.4), 2)       # inside 2-8 C
        rows.append((shipment_id, f"DL-{shipment_id[-4:]}",
                     f"2026-05-12T{(mins // 60):02d}:{(mins % 60):02d}:00Z",
                     temp, mins))
    return rows


def build(db_path: str | None = None):
    path = db_path or os.environ.get(
        "OPPAL_DB_PATH",
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__)))), "app", "data", "oppal.db"))
    rng = random.Random(SEED)
    con = sqlite3.connect(path)
    for t in ("drug_products", "batch_lots", "shipments", "iot_readings",
              "chargeback_claims", "serialized_units"):
        con.execute(f"DROP TABLE IF EXISTS {t}")
    con.executescript(DDL)
    con.executemany("INSERT INTO drug_products VALUES (?,?,?,?,?,?,?)",
                    [(n, g, nm, lo, hi, b, WAC_UNIT)
                     for n, g, nm, lo, hi, b in PRODUCTS])

    lots, ship_rows, iot_rows, claim_rows, sgtins = [], [], [], [], []
    rid = 0
    lots.append((TARGET_LOT, PRODUCTS[0][0], "BioNexa", 2400, "2027-03-31"))
    for i in range(1, 24):
        lots.append((f"LOT-{7000 + i}", PRODUCTS[i % 4][0],
                     rng.choice(["BioNexa", "Helix", "Kaplan Bio"]),
                     rng.randint(800, 3000), "2027-06-30"))

    def add_shipment(sid, lot, ndc, hub, q, units, spoiled, exc):
        nonlocal rid
        ship_rows.append((sid, lot, ndc, DISTRIBUTORS[hub], hub,
                          f"DSP-{rng.randint(100, 999)}", "2026-05-12", q,
                          units, spoiled, "spoiled" if spoiled else "delivered"))
        for r in _series(rng, sid, exc):
            rid += 1
            iot_rows.append((rid,) + r)

    # --- the planted incident -------------------------------------------
    add_shipment("SHP-ONC-0001", TARGET_LOT, PRODUCTS[0][0], TARGET_HUB,
                 "2026Q2", 2400, SPOILED, 240)          # 240 min > 15 C
    claim_rows.append(("CB-ONC-0001", "SHP-ONC-0001", TARGET_LOT,
                       DISTRIBUTORS[TARGET_HUB], TARGET_HUB, "2026Q2",
                       CLAIMED, WAC_UNIT,
                       round(WAC_UNIT * (1 - IWP_DISCOUNT), 2),
                       CLAIMED * WAC_UNIT,
                       round(CLAIMED * WAC_UNIT * (1 - IWP_DISCOUNT), 2)))
    for i in range(12):
        sgtins.append((f"SGTIN-{TARGET_LOT}-{i:04d}", TARGET_LOT,
                       "SHP-ONC-0001", DISTRIBUTORS[TARGET_HUB],
                       0 if i < 5 else 1, 1 if i < 5 else 0, 0,
                       "shipping" if i < 5 else "receiving"))

    # --- peer traffic ----------------------------------------------------
    n = 0
    for hub in HUBS:
        for q in QUARTERS:
            for _ in range(3):
                n += 1
                lot = lots[rng.randrange(1, len(lots))]
                units = rng.randint(400, 2200)
                exc = 150 if rng.random() < 0.12 else 0
                spoiled = int(units * rng.uniform(0.10, 0.22)) if exc else 0
                sid = f"SHP-{n:05d}"
                add_shipment(sid, lot[0], lot[1], hub, q, units, spoiled, exc)
                if spoiled:
                    # honest hubs claim 0.915-1.085x what they spoiled. Range
                    # tuned so Hub-09's leave-one-out Z lands ~3.65: tighter
                    # peers inflate Z (5.98 at 0.95-1.06), looser hide it (2.5).
                    claimed = max(1, int(spoiled * rng.uniform(0.915, 1.085)))
                    claim_rows.append((
                        f"CB-{n:05d}", sid, lot[0], DISTRIBUTORS[hub], hub, q,
                        claimed, WAC_UNIT,
                        round(WAC_UNIT * (1 - IWP_DISCOUNT), 2),
                        claimed * WAC_UNIT,
                        round(claimed * WAC_UNIT * (1 - IWP_DISCOUNT), 2)))
                for k in range(2):
                    broken = 1 if rng.random() < 0.03 else 0
                    sgtins.append((f"SGTIN-{sid}-{k}", lot[0], sid,
                                   DISTRIBUTORS[hub], 0 if broken else 1,
                                   broken, 0, "receiving"))

    con.executemany("INSERT INTO batch_lots VALUES (?,?,?,?,?)", lots)
    con.executemany("INSERT INTO shipments VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    ship_rows)
    con.executemany("INSERT INTO iot_readings VALUES (?,?,?,?,?,?)", iot_rows)
    con.executemany(
        "INSERT INTO chargeback_claims VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        claim_rows)
    con.executemany("INSERT INTO serialized_units VALUES (?,?,?,?,?,?,?,?)",
                    sgtins)

    # RBAC grants for THIS domain's scope column. allowed_lobs is read from
    # role_lob_access (db.get_user_context), which the payer generator seeds
    # with payer LOB values. Without pharma grants every governed query
    # compiles to `WHERE distributor_id IN ('Medicare Advantage', ...)` and
    # returns zero rows — the scope predicate working exactly as designed,
    # against a vocabulary this domain does not use. Grants are data, not code.
    if con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' "
                   "AND name='role_lob_access'").fetchone()[0]:
        dists = sorted(set(DISTRIBUTORS.values()))
        grants = [(r, d) for r in ("compliance_officer", "ma_analyst",
                                   "medicaid_analyst", "commercial_analyst")
                  for d in dists]
        # An analyst sees one distributor; an officer sees all three. Same
        # shape as the payer seed, so the isolation demo still has teeth.
        grants = [(r, d) for r, d in grants
                  if r == "compliance_officer" or d == "Cardinal-East"]
        con.executemany(
            "INSERT OR IGNORE INTO role_lob_access (role, lob) VALUES (?,?)",
            grants)
    con.commit()
    out = {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
           for t in ("drug_products", "batch_lots", "shipments",
                     "iot_readings", "chargeback_claims", "serialized_units")}
    con.close()
    return out


if __name__ == "__main__":
    import statistics
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))))
    print(build())
    con = sqlite3.connect(os.environ.get(
        "OPPAL_DB_PATH",
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__)))), "app", "data", "oppal.db")))
    from app.ai.functions import register_sql_functions
    register_sql_functions(con)

    spoiled, claimed = con.execute(
        "SELECT s.units_spoiled, c.units_claimed FROM shipments s "
        "JOIN chargeback_claims c ON c.shipment_id = s.shipment_id "
        "WHERE s.lot_id = ?", (TARGET_LOT,)).fetchone()
    leak = (claimed - spoiled) * WAC_UNIT
    assert (spoiled, claimed) == (SPOILED, CLAIMED), (spoiled, claimed)
    assert leak == 153000.0, leak
    print(f"  leakage: {claimed} claimed - {spoiled} spoiled = "
          f"{claimed - spoiled} x ${WAC_UNIT:,.0f} = ${leak:,.0f}")

    mkt, mx, over = con.execute(
        "SELECT mkt(temp_c), MAX(temp_c), "
        "SUM(CASE WHEN temp_c > 15 THEN 30 ELSE 0 END) "
        "FROM iot_readings WHERE shipment_id = 'SHP-ONC-0001'").fetchone()
    assert mkt > 10, mkt
    assert over > 120, over
    print(f"  MKT {mkt} C (ceiling 10) - peak {mx} C - {over} min above 15 C")

    ratios = {}
    for hub, sp, cl in con.execute(
            "SELECT s.hub_id, SUM(s.units_spoiled), SUM(c.units_claimed) "
            "FROM shipments s JOIN chargeback_claims c "
            "ON c.shipment_id = s.shipment_id GROUP BY s.hub_id"):
        if sp:
            ratios[hub] = cl / sp
    peers = [v for h, v in ratios.items() if h != TARGET_HUB]
    z = (ratios[TARGET_HUB] - statistics.mean(peers)) / statistics.pstdev(peers)
    print(f"  claims/spoiled: {TARGET_HUB} {ratios[TARGET_HUB]:.2f} vs peers "
          f"{statistics.mean(peers):.2f} -> leave-one-out Z = {z:.2f}")
    assert 3.4 < z < 3.9, z    # planted outlier, not a knife-edge
    print("  self-check OK")
