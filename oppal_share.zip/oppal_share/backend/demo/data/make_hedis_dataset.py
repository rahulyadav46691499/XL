"""Generate the HEDIS measure-level file used by Business Case 6.

This mimics what a payer's quality vendor actually sends: ONE ROW PER
MEMBER PER MEASURE, denormalised, with a few real-world warts (a blank
last_service_date on some rows, a vendor-specific measure code column).
OpPal has never seen this shape — that is the point of the demo: the
ontology for it is created on demand at upload time.

It is deliberately CONSISTENT with OpPal's synthetic book:
  * every member_id is a real Medicare Advantage member
  * a member's number of open gaps equals members.hedis_gap_count, so the
    new file agrees with the certified `hedis_gap_rate` metric instead of
    contradicting it (a demo that disagrees with its own warehouse is
    worse than no demo)

Planted, defensible signal — the thing the demo is meant to FIND:
  * the Southeast region closes the TRIPLE-WEIGHTED CBP measure far worse
    than the rest of the book, and has markedly fewer outreach attempts.
    Cause and effect are both in the data, so the analyst's conclusion is
    earned rather than asserted.

Run:
    cd oppal/backend
    PYTHONPATH=. python3 demo/data/make_hedis_dataset.py
"""
from __future__ import annotations

import csv
import os
import random
import sqlite3
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, "..", ".."))

OUT = os.path.join(_HERE, "hedis_measure_results.csv")
YEAR = 2026

# (code, name, star_weight, base_compliance) — weights mirror CMS Star
# weighting: intermediate-outcome measures carry 3x.
MEASURES = [
    ("CBP", "Controlling High Blood Pressure", 3, 0.74),
    ("HBD", "Hemoglobin A1c Poor Control (>9%)", 3, 0.71),
    ("EED", "Eye Exam for Patients With Diabetes", 1, 0.68),
    ("COL", "Colorectal Cancer Screening", 1, 0.66),
    ("BCS", "Breast Cancer Screening", 1, 0.72),
    ("SPC", "Statin Therapy for Cardiovascular Disease", 1, 0.79),
    ("TRC", "Transitions of Care", 1, 0.63),
]
LAGGING_REGION = "Southeast"


def build(db_path: str | None = None, out_path: str = OUT) -> str:
    from app.data.generate import DB_PATH, build as build_db
    db = db_path or DB_PATH
    if not os.path.exists(db) or os.path.getsize(db) == 0:
        build_db(db)
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    members = con.execute(
        "SELECT member_id, region, age_band, dual_eligible, hedis_gap_count "
        "FROM members WHERE lob = 'Medicare Advantage' ORDER BY member_id"
    ).fetchall()

    rng = random.Random(20260825)
    rows = []
    for mid, region, age_band, dual, gap_count in members:
        # Which measures is this member eligible for? Everyone gets CBP/COL/
        # TRC; the diabetes pair and BCS/SPC are eligibility-gated so the
        # denominators differ per measure, as they really do.
        eligible = ["CBP", "COL", "TRC"]
        if rng.random() < 0.42:
            eligible += ["HBD", "EED"]
        if rng.random() < 0.35:
            eligible.append("BCS")
        if rng.random() < 0.48:
            eligible.append("SPC")

        # Exactly `gap_count` of the eligible measures are left open, so this
        # file reconciles with members.hedis_gap_count row for row.
        n_open = min(gap_count, len(eligible))
        # A lagging region's gaps concentrate on the 3x-weighted measure —
        # the finding the demo is designed to surface.
        order = sorted(eligible, key=lambda c: (
            0 if (region == LAGGING_REGION and c == "CBP") else 1,
            rng.random()))
        open_set = set(order[:n_open])

        for code in eligible:
            name, weight, base = next(
                (n, w, b) for c, n, w, b in MEASURES if c == code)
            compliant = 0 if code in open_set else 1
            attempts = rng.choice([0, 1, 1, 2, 3]) if not compliant else \
                rng.choice([1, 2])
            if region == LAGGING_REGION and not compliant:
                attempts = rng.choice([0, 0, 1])     # under-worked
            # ~3% of vendor rows arrive with no service date at all — the
            # Data Quality tab has something real to find.
            if compliant:
                q = rng.choice(["03", "05", "07", "09", "11"])
                svc = f"{YEAR}-{q}-{rng.randint(10, 27):02d}"
            else:
                svc = "" if rng.random() < 0.09 else \
                    f"{YEAR - 1}-{rng.choice(['08', '10', '12'])}-" \
                    f"{rng.randint(10, 27):02d}"
            # COLUMN ORDER IS DELIBERATE. Auto-onboarding drafts metrics for
            # the first few numeric "measure" columns it finds, so the three
            # that carry the business meaning — the open gap, compliance and
            # how hard the member was worked — lead the file. Left in their
            # natural vendor order, the platform would have dutifully drafted
            # "average measurement_year", which is true and useless.
            rows.append({
                "member_id": mid,
                "measure_code": code,
                "measure_name": name,
                "gap_open": 0 if compliant else 1,
                "numerator_compliant": compliant,
                "outreach_attempts": attempts,
                "star_weight": weight,
                "measurement_year": YEAR,
                "denominator_eligible": 1,
                "region": region,
                "age_band": age_band,
                "dual_eligible": dual,
                "last_service_date": svc,
            })

    with open(out_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return out_path


if __name__ == "__main__":
    path = build()
    import collections
    with open(path) as f:
        data = list(csv.DictReader(f))
    print(f"wrote {path}  ({len(data):,} rows)")
    by_region = collections.defaultdict(lambda: [0, 0])
    for r in data:
        if r["measure_code"] != "CBP":
            continue
        by_region[r["region"]][0] += int(r["gap_open"])
        by_region[r["region"]][1] += 1
    print("\nCBP (3x weighted) gap rate by region:")
    for reg, (gaps, tot) in sorted(by_region.items(),
                                   key=lambda kv: -kv[1][0] / kv[1][1]):
        print(f"  {reg:<10} {gaps / tot:6.1%}  ({gaps:,}/{tot:,})")
    blanks = sum(1 for r in data if not r["last_service_date"])
    print(f"\nblank last_service_date: {blanks:,} rows "
          f"({blanks / len(data):.1%}) — for the Data Quality tab")
