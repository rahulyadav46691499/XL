"""ALL-TABS pre-flight for the Medicare Sales domain.

Same contract as pharma_alltabs_verify.py and hedis_alltabs_verify.py: every
step the use-case document tells a presenter to take is executed here against
the real engine, so the document is generated from verified output rather than
from memory. Seventeen tabs, in the order the documentation lists them.

Two results below are HONEST NEGATIVES and are asserted as such, because a
demo that hides them fails in the room instead of here:

  * Data Quality — anomaly_overview()'s two detectors are payer-shaped
    (claims.allowed_amount quarterly series and record-level outlier claims).
    Under this Brain they degrade to an empty result with a note. The real
    Data Quality signal for this domain is the missing-value scan, which is
    table-agnostic and finds the planted lost_reason gap.
  * Pillars — rules_engine registers its generic query handler against the
    `regulatory` pillar and returns that key regardless of each rule's own
    declared `pillar:`. All twelve sales rules evaluate and render; they
    render under one heading rather than three. Same shared behaviour
    pharma_supply_chain has.

Run:
    cd oppal_stage/backend
    PYTHONPATH=. python3 demo/medicare_sales_alltabs_verify.py
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "data"))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("medicaresalesalltabs")

R = Reporter()

DOMAIN = "medicare_sales"
SWARM_Q = ("Is lead quality collapsing at any lead source, and is any agent "
           "an effectuation or commission outlier?")
CHAT_QS = [
    "qualified lead rate by market",
    "lead to enrollment rate by lead source",
    "cost per qualified lead by lead source",
    "effectuated enrollments by market",
    "member retention rate by channel",
    "rapid disenrollment rate by channel",
    "commission paid by agent",
    "ctm complaint rate by market",
]
SOURCE, AGENT, CHANNEL, MARKET = "LS-TELE-03", "AG-0027", "Broker", "Northeast"


def main():
    from app.data.db import (ensure_db, get_user_context, POOL, SQL_LOG,
                             invalidate_scope_values, ALL_LOBS)
    from app.semantic import brain as bl
    import make_medicare_sales_dataset as mk

    ensure_db()
    counts = mk.build()
    POOL.reset()
    # Users are resolved AFTER the domain switch: get_user_context()
    # intersects role_lob_access with ALL_LOBS(), the ACTIVE domain's own
    # scope universe. A real caller does not hit this — a user's domain is
    # already switched, via the UI, before any of their requests land.
    bl.set_active(DOMAIN)
    bl.reload_brain()
    invalidate_scope_values()

    casey = get_user_context("u-compliance")     # compliance officer, full
    dana = get_user_context("u-compliance2")     # second, distinct approver
    morgan = get_user_context("u-ma")            # Medicare Advantage analyst
    max_m = get_user_context("u-medicaid")       # Medicaid analyst
    from app.mcp import scope_from_user
    sc_casey, sc_dana = scope_from_user(casey), scope_from_user(dana)
    sc_morgan, sc_max = scope_from_user(morgan), scope_from_user(max_m)

    print()
    print("+" + "-" * (R.W - 2) + "+")
    print("|" + "  Medicare Sales -- ALL 17 TABS pre-flight".ljust(R.W - 2)
          + "|")
    print("+" + "-" * (R.W - 2) + "+")

    try:
        rep = bl.reload_brain()
        R.banner("SETUP", "Switch the Context Brain to the Medicare Sales "
                          "domain")
        R.check("the Medicare Sales warehouse is built from the supplied CSVs",
                len(counts) == 11,
                f"{sum(counts.values()):,} rows across {len(counts)} tables")
        R.check("the Brain reloads with no parse errors",
                not rep.get("errors"), rep.get("report", "")[:72])
        b = bl.get_brain()
        R.check("scope is the line of business, as the payer domain is",
                (b.get("governance") or {}).get("scope_column") == "lob")
        R.check("the scope universe is the four lines of business",
                {"Medicare Advantage", "Medicaid", "Commercial",
                 "ACA Exchange"} <= set(ALL_LOBS()),
                str(sorted(ALL_LOBS()))[:78])
        R.check("no new RBAC grants were needed -- Morgan is Medicare "
                "Advantage only",
                morgan["allowed_lobs"] == ["Medicare Advantage"],
                "the payer's role_lob_access rows apply unchanged")
        R.check("Casey holds all four books as first approver",
                len(casey["allowed_lobs"]) == 4)

        from app.llm.base import get_provider
        from app.agents.orchestrator import Orchestrator
        orch = Orchestrator(get_provider())

        def ask(q, user=casey):
            a = orch.handle(q, user=user)
            rows = next((art["rows"] for art in a.get("artifacts", [])
                         if art.get("rows")), None)
            return (a.get("sql"),
                    round((a.get("trust") or {}).get("score", 0) * 100),
                    rows or [])

        # ---------------------------------------------------- 1. Settings
        R.banner("TAB 1/17", "Settings -- provider and TLS posture")
        from app import config
        cfg = config.masked()
        R.check("the active LLM provider is reported",
                bool(cfg.get("llm", {}).get("provider")),
                f"provider={cfg['llm']['provider']}")
        R.check("TLS verification is on", cfg["network"]["ssl_verify"] is True)
        R.check("PHI protection is on", cfg["privacy"]["phi_protection"]
                is True)
        from app.privacy.phi_guard import PHIGuard
        scrubbed, hits = PHIGuard(enabled=True).scrub(
            "Beneficiary SSN 123-45-6789, phone 415-555-0142")
        R.check("PHI scrubbing is demonstrable before anything leaves",
                "123-45-6789" not in scrubbed and hits,
                scrubbed[:60])

        # ---------------------------------------------------- 2. Context Brain
        R.banner("TAB 2/17", "Context Brain -- the governed rulebook")
        rules = {r.get("rule_id"): r for r in b["policy_rules"]}
        R.check("the CMS certification rule is a versioned declaration",
                "CMS-AGENT-CERT-2274" in rules,
                rules.get("CMS-AGENT-CERT-2274", {}).get("citation", "")[:52])
        R.check("the lead-quality floor is a markdown bullet, not code",
                rules.get("LEAD-QUALITY-FLOOR", {}).get(
                    "qualified_rate_floor") == "0.40")
        R.check("dual control is declared with its own threshold",
                b["action_rules"]["financial_impact_threshold"] == 10000.0,
                f"${b['action_rules']['financial_impact_threshold']:,.0f}")
        R.check("commission_recovery is a dual-control action type",
                "commission_recovery" in
                b["action_rules"]["dual_control_action_types"])
        txt = bl.read_file(DOMAIN, "policy_rules.md")
        R.check("the file is readable and searchable in the tab",
                "LEAD-QUALITY-FLOOR" in txt, f"{len(txt):,} chars")
        R.check("the Brain save gate now accepts this domain",
                _save_gate_ok(DOMAIN),
                "brain_eval floors are per-domain; a non-payer save used to "
                "be refused outright")

        # ---------------------------------------------------- 3. Chat
        R.banner("TAB 3/17", "Chat -- every question the document asks")
        for q in CHAT_QS:
            sql, tr, rows = ask(q)
            head = ", ".join(f"{r[0]}={r[1]}" for r in rows[:2])
            R.check(f'type: "{q}"',
                    sql != "-- withheld" and tr >= 85 and bool(rows),
                    f"trust {tr}% - {head}")
        sql, _, _ = ask("qualified lead rate by market", morgan)
        R.check("the scope predicate is pushed down on lob",
                "lob IN" in sql, sql[:88])
        R.check('"by market" resolves the dimension to leads.market',
                "market" in sql)

        R.banner("FACTS", "Full result sets behind the document narrative")
        for q in ("qualified lead rate by lead source",
                  "cost per qualified lead by lead source",
                  "member retention rate by channel",
                  "rapid disenrollment rate by channel"):
            _, tr, rows = ask(q)
            R.say(f'"{q}"  [trust {tr}%]')
            for rr in rows[:6]:
                R.say(f"     {str(rr[0]):14s} {rr[1]}", indent=4)

        # ---------------------------------------------------- 4. Data
        R.banner("TAB 4/17", "Data -- lead, enrolment and commission "
                             "drill-down")
        con = POOL.acquire()
        try:
            aep_n, aep_q = con.execute(
                "SELECT COUNT(*), ROUND(AVG(qualified_flag), 4) FROM leads "
                "WHERE lead_source = ? AND market = 'Southwest' "
                "AND lead_quarter = '2026Q4'", (SOURCE,)).fetchone()
            peer_q = con.execute(
                "SELECT ROUND(AVG(qualified_flag), 4) FROM leads "
                "WHERE lead_source = 'LS-TELE-01' AND market = 'Southwest' "
                "AND lead_quarter = '2026Q4'").fetchone()[0]
            eff_n, eff_r = con.execute(
                "SELECT COUNT(*), ROUND(AVG(effectuated_flag), 4) "
                "FROM enrollments WHERE agent_id = ?", (AGENT,)).fetchone()
            overpaid, npay = con.execute(
                "SELECT ROUND(SUM(c.commission_paid + c.bonus_paid + "
                "c.override_paid), 2), COUNT(*) FROM agent_commissions c "
                "JOIN enrollments e ON e.enrollment_id = c.enrollment_id "
                "WHERE e.effectuated_flag = 0").fetchone()
            ret, rapid = con.execute(
                "SELECT ROUND(AVG(retained_12mo_flag), 4), "
                "ROUND(AVG(rapid_disenroll_flag), 4) FROM enrollments "
                "WHERE channel = ? AND market = ?",
                (CHANNEL, MARKET)).fetchone()
        finally:
            POOL.release(con)
        R.check(f"{SOURCE} in the Southwest collapses during AEP 2026Q4",
                aep_q < 0.30 and peer_q > 0.55,
                f"{aep_q:.1%} on {aep_n} leads vs peer LS-TELE-01 {peer_q:.1%}")
        R.check(f"agent {AGENT} sits far below the book on effectuation",
                eff_r < 0.80, f"{eff_r:.2%} on {eff_n} enrolments")
        R.check("commission was paid on enrolments that never effectuated",
                npay == 9 and abs(overpaid - 5542.64) < 0.01,
                f"{npay} payments, ${overpaid:,.2f}")
        R.check(f"{CHANNEL}/{MARKET} is the retention leak",
                ret < 0.70 and rapid > 0.20,
                f"retention {ret:.1%}, rapid disenrolment {rapid:.1%}")

        # ---- figures the use-case document quotes -----------------------
        # Medicare_Sales_Use_Case.md states these verbatim. The previous
        # revision of that document quoted the SCOPED cost per qualified lead
        # ($104.32) as the answer to the GLOBAL chat question, which returns
        # $50.00 -- a presenter typing the documented question saw a different
        # number on screen. Both are asserted here so the document cannot
        # drift back, and so the gap between them stays visible.
        con = POOL.acquire()
        try:
            SW = ("market = 'Southwest' AND aep_flag = 1 "
                  "AND lead_quarter = '2026Q4'")
            cpql = dict(con.execute(
                f"SELECT lead_source, ROUND(SUM(cost_allocated) / "
                f"NULLIF(SUM(qualified_flag), 0), 2) FROM leads WHERE {SW} "
                f"GROUP BY 1").fetchall())
            qual = dict(con.execute(
                f"SELECT lead_source, ROUND(AVG(qualified_flag), 4) "
                f"FROM leads WHERE {SW} GROUP BY 1").fetchall())
            global_cpql = con.execute(
                "SELECT ROUND(SUM(cost_allocated) / "
                "NULLIF(SUM(qualified_flag), 0), 2) FROM leads "
                "WHERE lead_source = ?", (SOURCE,)).fetchone()[0]
            book_eff = con.execute(
                "SELECT ROUND(AVG(effectuated_flag), 4) "
                "FROM enrollments").fetchone()[0]
            by_lob = dict(con.execute(
                "SELECT e.lob, ROUND(SUM(c.commission_paid + c.bonus_paid + "
                "c.override_paid), 2) FROM agent_commissions c JOIN "
                "enrollments e ON e.enrollment_id = c.enrollment_id "
                "WHERE e.effectuated_flag = 0 AND e.agent_id = ? "
                "GROUP BY 1", (AGENT,)).fetchall())
        finally:
            POOL.release(con)

        R.check("the document's cost per qualified lead is the SCOPED one",
                abs(cpql[SOURCE] - 104.32) < 0.01,
                f"Southwest/AEP/2026Q4 ${cpql[SOURCE]}")
        R.check("...and the GLOBAL chat answer is a different number, "
                "which is why the document names the scope on every figure",
                abs(global_cpql - 50.0) < 0.01
                and abs(cpql[SOURCE] - global_cpql) > 50,
                f"all markets ${global_cpql} vs scoped ${cpql[SOURCE]}")
        R.check("the named peer's cost per qualified lead is quoted right",
                abs(cpql["LS-TELE-01"] - 34.57) < 0.01,
                f"LS-TELE-01 ${cpql['LS-TELE-01']}")
        R.check("the reallocation targets named in the Outcome really do "
                "hold the floor in that market and period",
                qual["LS-BRK-01"] > 0.80 and qual["LS-WEB-02"] >= 0.80,
                f"LS-BRK-01 {qual['LS-BRK-01']:.1%}, "
                f"LS-WEB-02 {qual['LS-WEB-02']:.1%}")
        R.check("the book effectuation rate is 0.9417, not the 95.38% the "
                "previous document revision claimed",
                abs(book_eff - 0.9417) < 0.0001, f"book {book_eff}")
        # The document quotes Morgan-scope figures too, because that is the
        # seat a presenter demos from. Verified in the browser: the same
        # question returns a different number to Morgan than to Casey, and
        # quoting one as the other is this domain's most common error.
        con = POOL.acquire()
        try:
            morgan_cpql = con.execute(
                "SELECT ROUND(SUM(cost_allocated) / NULLIF("
                "SUM(qualified_flag), 0), 2) FROM leads WHERE lead_source = ? "
                "AND lob = 'Medicare Advantage'", (SOURCE,)).fetchone()[0]
        finally:
            POOL.release(con)
        R.check("the document's Morgan-scope cost per qualified lead is what "
                "the UI actually shows a presenter",
                abs(morgan_cpql - 53.20) < 0.01,
                f"Medicare Advantage only ${morgan_cpql} "
                f"(all books ${global_cpql})")

        R.check(f"{AGENT} is overpaid in THREE books, and the total only "
                f"resolves at full scope",
                len(by_lob) == 3
                and abs(sum(by_lob.values()) - 5542.64) < 0.01
                and abs(by_lob["Medicare Advantage"] - 2682.64) < 0.01,
                " + ".join(f"{k.split()[0]} ${v:,.2f}"
                           for k, v in sorted(by_lob.items()))
                + f" = ${sum(by_lob.values()):,.2f}")

        # ---------------------------------------------------- 5. Data Layer
        R.banner("TAB 5/17", "Data Layer -- the governed catalog")
        from app.mcp import data_service
        cat = data_service().catalog(sc_morgan)
        names = {t.name if hasattr(t, "name") else t["name"] for t in cat}
        governed = {t.name if hasattr(t, "name") else t["name"] for t in cat
                    if (t.governed if hasattr(t, "governed")
                        else t["governed"])}
        R.check("all eleven Medicare Sales tables are catalogued",
                {"leads", "applications", "enrollments", "agent_commissions",
                 "interactions", "sales_targets", "lead_activities",
                 "sales_agents", "agent_certifications", "campaigns",
                 "plan_benefit_packages"} <= names,
                f"{len(names)} tables")
        R.check("the six beneficiary-bearing tables are governed",
                {"leads", "applications", "enrollments", "agent_commissions",
                 "interactions", "sales_targets"} <= governed)
        R.check("lead_activities is governed transitively through its lead",
                "lead_activities" in governed
                or "lead_activities" in
                (b["governance"].get("transitive_tables") or {}))
        R.check("the agent directory is ungoverned reference data",
                "sales_agents" not in governed,
                "an agent who sells three books must be visible in all three")
        R.check("no payer or pharma table leaks into this catalog",
                not ({"claims", "members", "shipments"} & names))

        R.banner("NEGATIVE CONTROL", "Cross-line-of-business reads and writes")
        res = data_service().run_legacy(
            "SELECT COUNT(*) FROM leads WHERE lob = 'Medicaid'", sc_morgan,
            purpose="negative_control")
        got = (res.get("rows") or [[None]])[0][0]
        R.check("Morgan cannot see Medicaid leads -- ZERO rows, not an error",
                res["ok"] and got == 0,
                f"count = {got} (structurally filtered, not text-inspected)")
        wr = data_service().run_legacy(
            "UPDATE leads SET qualified_flag = 1", sc_casey,
            purpose="negative_control")
        R.check("even a compliance officer's write is refused",
                not wr["ok"], "read-only gate, live-fire tested")

        # ---------------------------------------------------- 6. Data Quality
        R.banner("TAB 6/17", "Data Quality -- the planted lost_reason gap")
        from app.data import quality
        report = quality.missing_report()
        lead_gaps = [r for r in report
                     if r["table"] == "leads" and r["column"] == "lost_reason"]
        R.check("the missing-value scan finds the lost_reason gap",
                bool(lead_gaps),
                f"{lead_gaps[0]['missing']} of {lead_gaps[0]['total']} rows "
                f"({lead_gaps[0]['pct']}%)" if lead_gaps else "MISSING")
        R.check("it is offered a mode fill, being a categorical column",
                lead_gaps and "mode" in lead_gaps[0]["techniques"])
        dry = quality.impute("leads", "lost_reason", "mode", dry_run=True,
                             user_id="u-ma")
        R.check("a dry run previews the fill without changing data",
                dry.get("ok") and dry.get("dry_run"),
                f"would fill {dry.get('affected')} rows with "
                f"'{dry.get('fill_value')}'")
        con = POOL.acquire()
        try:
            still = con.execute(
                "SELECT COUNT(*) FROM leads WHERE lost_reason IS NULL "
                "AND funnel_stage = 'Lost'").fetchone()[0]
        finally:
            POOL.release(con)
        R.check("the dry run really did not write", still > 0,
                f"{still} Lost leads still have no reason")
        ao = quality.anomaly_overview()
        R.check("HONEST NEGATIVE: the anomaly detectors are payer-shaped and "
                "degrade with a note rather than scanning another domain",
                bool(ao.get("note")) or not ao.get("metrics"),
                str(ao.get("note", ""))[:70])

        # ---------------------------------------------------- 7. Semantic Graph
        R.banner("TAB 7/17", "Semantic Graph -- term to governed metric to "
                             "column")
        from app.semantic.graph import export_graph
        g = export_graph(include_unmapped=False)
        nodes, edges = g["nodes"], g["edges"]
        R.check("the graph builds for this domain",
                len(nodes) > 10 and len(edges) > 10,
                f"{len(nodes)} nodes, {len(edges)} edges")
        hits = [n for n in nodes
                if "qualified" in str(n.get("label", "")).lower()]
        R.check('searching "qualified" matches the governed metric',
                bool(hits), f"{len(hits)} node(s)")
        adj = {}
        for e in edges:
            adj.setdefault(e["source"], []).append(e["target"])
            adj.setdefault(e["target"], []).append(e["source"])
        kinds = {n["id"]: n.get("ntype", "") for n in nodes}
        focus = "metric:qualified_lead_rate"
        depth, frontier = {focus: 0}, [focus]
        for _ in range(3):
            nxt = []
            for nid in frontier:
                for nb in adj.get(nid, []):
                    if nb not in depth:
                        depth[nb] = 1
                        nxt.append(nb)
            frontier = nxt
        tables = [n for n in depth if kinds.get(n) == "table"]
        R.check("drilling the metric reaches its physical table",
                "leads" in tables,
                f"{len(depth)} nodes in view, tables: {tables[:3]}")

        # ---------------------------------------------------- 8. Ontology
        R.banner("TAB 8/17", "Ontology -- the formal object model")
        from app.semantic import ontology as ONT
        ONT.reload_spec()
        spec = ONT.load_spec()
        ot = spec.get("object_types") or {}
        R.check("this domain's own object types load (per-domain spec)",
                {"Lead", "Application", "Enrollment", "SalesAgent",
                 "Commission", "AgentCertification"} <= set(ot),
                f"{len(ot)} object types")
        R.check("no payer object types leak in",
                "Claim" not in ot and "Member" not in ot,
                "the spec resolves per domain")
        rels = {e["rel"] for e in (spec.get("edges") or [])}
        R.check("the funnel relationships are declared",
                {"originated_from", "granted_by", "paid_against",
                 "certifies"} <= rels, str(sorted(rels))[:78])
        R.check("CAPS bindings are sales and enrolment systems",
                "salesforce_hc" in (spec.get("caps_bindings") or {}))
        val = ONT.validate()
        R.check("the object model validates against the Brain's tables",
                isinstance(val, dict),
                f"{len(val.get('object_types', val))} checked"
                if isinstance(val, dict) else "")

        # ---------------------------------------------------- 9. Pillars
        R.banner("TAB 9/17", "Pillars -- what this domain governs")
        from app.analytics import rules_engine as RE
        declared = set(RE.declared_checks())
        R.check("the Brain declares this domain's own checks",
                {"agent_certification_currency", "effectuation_outlier",
                 "lead_quality_floor", "retention_floor"} <= declared,
                f"{len(declared)} declared checks")
        summary = RE.pillar_summary(sc_casey)
        reg = summary.get("regulatory") or {}
        R.check("the tab is POPULATED -- one generic handler runs every rule "
                "that declares a query, no bespoke Python per rule",
                (reg.get("breach_count") or 0) > 0,
                f"{reg.get('breach_count')} breach(es) from "
                f"{len(reg.get('rules_evaluated') or [])} rules")
        heads = " | ".join(str(x.get("headline"))
                           for x in (reg.get("breaches") or []))
        R.check("the certification breach names the agent and the expiry",
                "expired on" in heads and "AG-00" in heads)
        R.check("the lead-quality breach names the source, market and quarter",
                SOURCE in heads and "2026Q4" in heads)
        R.check("the retention breach names the channel and market",
                f"{CHANNEL} channel in {MARKET}" in heads)
        R.check("the compensation breach names the FMV cap",
                "FMV cap" in heads)
        R.check("HONEST NEGATIVE: every query-bearing rule renders under the "
                "regulatory key, because that is the pillar the shared "
                "generic handler is registered against",
                len(reg.get("rules_evaluated") or []) >= 10
                and "sales_performance" not in summary,
                "same shared behaviour pharma_supply_chain has")
        inert = RE.unimplemented_checks()
        R.check("no declared check is left inert", not inert,
                f"inert: {inert}" if inert else "all twelve carry a query")

        # ---------------------------------------------------- 10. Audiences
        R.banner("TAB 10/17", "Audiences -- a named, reusable population")
        from app.agents.cohort_agent import CohortAgent, compile_where
        from app.analytics import cohort_insights
        ca = CohortAgent(llm=None)
        parsed = ca.parse(
            f"Medicare Advantage leads from lead source {SOURCE} in the "
            f"Southwest")
        where, needs_m = compile_where(parsed["filters"], _validated=True)
        R.check("the plain-English audience parses to a real predicate",
                "lead_source" in (where or ""), where)
        auto = cohort_insights.analyze(where or "1=1", needs_m, "AEP Lead "
                                                                "Quality")
        prof = auto["profile"]
        R.check("the audience profiles against THIS domain's base table",
                not prof.get("empty") and prof.get("generic"),
                f"{prof.get('count')} {prof.get('count_label')}, "
                f"${prof.get('measure', 0):,.0f} "
                f"{prof.get('measure_label', '')}")
        R.check("lift analysis runs on this domain's own dimensions",
                bool(auto["lifts"]),
                "; ".join(f"{l['dimension']}={l['value']} {l['lift']}x"
                          for l in auto["lifts"][:2]))
        R.check("the in-audience trend series resolves on lead_quarter",
                bool((auto.get("trend") or {}).get("rows")),
                str((auto.get("trend") or {}).get("rows", [])[:3]))
        cohort = ca.create("Medicare Advantage leads from lead source "
                           f"{SOURCE} in the Southwest", prof, parsed,
                           "AEP Lead Quality", user=morgan)
        R.check("the audience is saved and reusable in the Simulator",
                bool(cohort.get("id")),
                f"{cohort.get('name')} ({cohort.get('id')})")

        # ---------------------------------------------------- 11. Swarm
        R.banner("TAB 11/17", "Swarm -- declarative personas, no new Python")
        from app.agents import swarm, case_store
        run = swarm.run_swarm(SWARM_Q, casey, llm=None)
        names = [a if isinstance(a, str) else a.get("name")
                 for a in (run.get("activated") or [])]
        R.check(f'type: "{SWARM_Q[:44]}..." then "Run swarm"',
                "lead_quality" in names and "compensation_siu" in names,
                f"activated {len(names)}: {', '.join(names)}")
        R.check("only the relevant specialists activate, not the roster",
                len(names) <= int(b["swarm_settings"]["max_active_agents"]) + 2,
                f"{len(names)} of {len(b['agents'])} personas")
        heads = " | ".join(f["headline"] for f in (run.get("findings") or []))
        R.check("no persona reports itself misconfigured",
                "is not implemented" not in heads,
                "a declared `query:` must reach the agent")
        R.check("the lead-quality finding names the source and the peer rate",
                SOURCE in heads and "peer" in heads.lower())
        R.check("the compensation finding names the overpayment",
                AGENT in heads and "never effectuated" in heads)
        R.check("the swarm opens cases -- this is what fills the Cases tab",
                bool(run.get("cases_created")),
                f"{len(set(run.get('cases_created') or []))} distinct case(s)")

        R.banner("NEGATIVE CONTROL", "Agents as securable objects")
        from app.security import agent_acl
        R.check("every persona declares its required permission",
                all(p.get("required_permission")
                    for p in b["agents"].values()),
                "an undeclared persona falls to the restrictive default")
        R.check("the compliance persona is restricted to officers",
                agent_acl.required_permission("sales_compliance")
                == "agent_invoke_compliance")
        R.check("an analyst cannot invoke it",
                not agent_acl.can_invoke_agent(morgan, "sales_compliance"),
                f"role '{morgan['role']}' lacks agent_invoke_compliance")
        R.check("but the FWA persona stays open to analysts, so "
                "maker-checker does not collapse",
                agent_acl.can_invoke_agent(morgan, "compensation_siu"))
        run_m = swarm.run_swarm("agent certification and licence compliance",
                                morgan, llm=None)
        withheld = [w["agent"] for w in (run_m.get("withheld") or [])]
        R.check("an auto-selected agent Morgan may not invoke is WITHHELD "
                "and disclosed, not silently dropped",
                "sales_compliance" in withheld or not withheld,
                f"withheld: {withheld}")

        # ---------------------------------------------------- 12. Cases
        R.banner("TAB 12/17", "Cases -- de-duplicated, scoped case queue")
        cases = case_store.list_cases(sc_casey)
        cases = cases if isinstance(cases, list) else cases.get("cases", [])
        R.check("Cases is populated (it was empty before the swarm ran)",
                bool(cases), f"{len(cases)} cases")
        by_type = {}
        for c in cases:
            by_type.setdefault(c["case_type"], []).append(c)
        R.check("the case types are this domain's own",
                {"LeadQualityCase", "CompensationCase"} <= set(by_type),
                ", ".join(sorted(by_type)))
        lea = next((c for c in cases if c["case_type"] == "LeadQualityCase"),
                   None)
        R.check(f"a LeadQualityCase opened for {SOURCE}",
                lea is not None and lea["subject"] == SOURCE,
                f"{lea['case_id']} — ${float(lea['estimated_impact']):,.0f} "
                f"spend at stake" if lea else "MISSING")
        com = next((c for c in cases if c["case_type"] == "CompensationCase"),
                   None)
        R.check(f"a CompensationCase opened for agent {AGENT}",
                com is not None and com["subject"] == AGENT,
                f"{com['case_id']} — ${float(com['estimated_impact']):,.2f} "
                f"recoverable" if com else "MISSING")
        R.check("the case id prefix is derived from the case type",
                lea and lea["case_id"].startswith("LEA-")
                and com["case_id"].startswith("COM-"))
        again = swarm.run_swarm(SWARM_Q, casey, llm=None)
        after = case_store.list_cases(sc_casey)
        after = after if isinstance(after, list) else after.get("cases", [])
        R.check("re-running the swarm de-duplicates instead of piling up",
                len(after) == len(cases),
                f"{len(after)} cases after a second identical run")
        R.check("a case is stamped with the LOB of the INCIDENT, not the "
                "runner's scope",
                lea and lea["lob"] != "ALL", f"lob={lea['lob']}" if lea else "")
        R.check("a Medicaid analyst cannot see a Medicare Advantage case",
                len(case_store.list_cases(sc_max)) < len(cases),
                f"Max sees {len(case_store.list_cases(sc_max))} of "
                f"{len(cases)}")
        upd = case_store.update_status(com["case_id"], "reviewing",
                                       sc_casey, actor="u-compliance")
        R.check('status select -> "reviewing" (officer class only)',
                bool(upd), f"{com['case_id']} -> reviewing")
        siu = case_store.update_status(com["case_id"], "referred_siu",
                                        sc_casey, actor="u-compliance")
        R.check('status select -> "referred_siu" for the SIU hand-off',
                bool(siu), f"{com['case_id']} -> referred_siu")

        # ---------------------------------------------------- 13. Simulator
        R.banner("TAB 13/17", "Simulator -- an isolated Brain fork")
        from app.schemas.simulation import (SimulationRequest,
                                            ParameterOverride)
        from app.simulation import engine as sim
        bind = sim.bindings(bl.get_brain())
        R.check("the simulator is bound to THIS domain's metrics and tables",
                bind["ratio_metric"] == "sim_lead_loss_ratio"
                and bind["cost_a_from"] == "FROM leads c",
                f"ratio={bind['ratio_metric']}, "
                f"costs={bind['cost_a_metric']}/{bind['cost_b_metric']}")
        req = SimulationRequest(
            baseline_query=f"Medicare Advantage leads from lead source "
                           f"{SOURCE} in the Southwest",
            parameter_overrides=[
                ParameterOverride(
                    brain_path="metrics.sim_acquisition_cost.stress_pct",
                    op="delta_pct", value="-0.25",
                    reason="pause the underperforming lead source"),
                ParameterOverride(
                    brain_path="metrics.sim_lead_loss_ratio.stress_pct",
                    op="delta_pct", value="-0.15",
                    reason="reallocate the budget to compliant sources")])
        res = sim.run_simulation(req, morgan, sc_morgan)
        R.check("the Simulator RETURNS REAL NUMBERS -- it was a dead tab off "
                "the payer domain before the bindings",
                res.net_dollar_impact != 0,
                f"net ${float(res.net_dollar_impact):,.2f}, ratio "
                f"{res.mlr_delta_bps:+d} bps")
        got_metrics = {m.metric for m in res.metrics}
        R.check("every reported delta maps to a declared simulation.md "
                "formula",
                got_metrics <= set(bl.get_brain()["simulation"]),
                ", ".join(sorted(got_metrics)))
        R.check("trust is scored on the run", res.trust_score > 0,
                f"{res.trust_score:.0%}")
        live = bl.get_brain()["metrics"]["sim_acquisition_cost"]
        R.check("the live Brain was never mutated -- the fork is isolated",
                "stress_pct" not in live,
                "overrides applied to the fork only")
        denied, dmsg = False, ""
        try:
            sim.run_simulation(
                SimulationRequest(
                    baseline_query="Medicaid leads in the Northeast",
                    parameter_overrides=[ParameterOverride(
                        brain_path="metrics.sim_acquisition_cost.stress_pct",
                        op="delta_pct", value="-0.10",
                        reason="cross-scope attempt")]),
                morgan, sc_morgan)
        except sim.SimulationScopeDenied as e:
            denied, dmsg = True, str(e)[:70]
        except Exception as e:
            dmsg = f"{type(e).__name__}: {e}"[:70]
        R.check("a cross-line-of-business baseline is REFUSED, not silently "
                "emptied", denied, dmsg or "NOT REFUSED")
        refused = False
        try:
            sim.run_simulation(
                SimulationRequest(
                    baseline_query="Medicare Advantage leads",
                    parameter_overrides=[ParameterOverride(
                        brain_path="metrics.sim_acquisition_cost.sql",
                        op="set", value="1",
                        reason="injection attempt")]),
                morgan, sc_morgan)
        except Exception as e:
            refused = "tamper" in str(e).lower() or "refused" in str(e).lower()
        R.check("an override targeting SQL text is refused, not run", refused,
                "a what-if lever is a number, never a query")

        # ---------------------------------------------------- 14. Workspace
        R.banner("TAB 14/17", "Workspace -- a pinned, lineage-backed board")
        from app.workspace import store as ws_store
        from app.schemas.workspace import ArtifactPin
        ws = ws_store.create("AEP Lead Quality Review", morgan, sc_morgan)
        pin = ws_store.pin_artifact(ws.id, ArtifactPin(
            type="simulation",
            spec={"title": f"{SOURCE} lead-quality remediation",
                  "run_id": res.run_id,
                  "net_dollar_impact": str(res.net_dollar_impact),
                  "ratio_delta_bps": res.mlr_delta_bps,
                  "trust_score": float(res.trust_score)},
            lineage_ref=res.lineage_ref), sc_morgan)
        R.check("the projection pins to a named dashboard",
                bool(pin.id), f"{ws.name} / {pin.spec.get('title')}")
        lin = ws_store.lineage_for(pin.id, sc_morgan)
        R.check("the trust score and logic tree travel with the pin",
                bool(lin) and pin.lineage_ref == res.lineage_ref,
                f"trust {float(res.trust_score):.0%}, "
                f"lineage {pin.lineage_ref}")
        R.check("a Medicaid analyst cannot see Morgan's board",
                all(getattr(w, "id", None) != ws.id
                    for w in ws_store.list_for(sc_max)),
                "a dashboard is private to its owner until shared")

        # ---------------------------------------------------- 15. Actions
        R.banner("TAB 15/17", "Actions -- dual control, end to end")
        from app.actions import engine as AE
        amount = float(com["estimated_impact"])
        act = AE.propose(
            case_id=com["case_id"], action_type="commission_recovery",
            target_object=str(com["subject"]),
            lob=str(com.get("lob") or "Medicare Advantage"),
            summary=f"Recover commission paid to {AGENT} on enrolments that "
                    f"never effectuated",
            estimated_financial_impact=amount,
            regulatory_severity="high",
            trust_score=float(com.get("trust_score") or 0.92),
            fields={"case_id": com["case_id"], "agent_id": AGENT},
            proposer_user_id="u-ma")
        R.check("STEP 1 - the analyst proposes from the case",
                bool(act.action_id),
                f"{act.action_id} mode={act.control_mode.value} "
                f"(${amount:,.2f})")
        R.check("it is DUAL control -- commission_recovery is always dual "
                "control in this domain's rulebook, whatever the amount",
                act.control_mode.value == "dual",
                "declared in policy_rules.md ACT-DUAL-CONTROL")
        refused = False
        try:
            AE.approve(act.action_id, morgan, sc_morgan)
        except Exception as e:
            refused, rmsg = True, str(e)[:58]
        R.check("STEP 2 - the analyst who proposed it cannot approve it",
                refused, rmsg if refused else "NOT REFUSED")
        a1 = AE.approve(act.action_id, casey, sc_casey)
        R.check("STEP 3 - Casey signs first",
                a1.state.value == "PENDING_SECOND_APPROVAL",
                f"approver_1={a1.approver_1_id}")
        sod = False
        try:
            AE.approve(act.action_id, casey, sc_casey)
        except Exception as e:
            sod, smsg = True, str(e)[:58]
        R.check("STEP 4 - the same officer cannot sign twice", sod,
                smsg if sod else "NOT REFUSED")
        a2 = AE.approve(act.action_id, dana, sc_dana)
        R.check("STEP 5 - Dana signs second -> APPROVED",
                a2.state.value == "APPROVED",
                f"approver_2={a2.approver_2_id}")
        gate = float(AE.rules().get("execution_trust_gate") or 0.85)
        if a2.trust_score >= gate:
            AE.execute(act.action_id, dana, sc_dana)
            done = AE.get(act.action_id, sc_casey)
            R.check("STEP 6 - execute write-back (dry-run target)",
                    done.state.value == "EXECUTED",
                    f"trust {a2.trust_score:.0%} >= gate {gate:.0%}")
        else:
            R.check(f"STEP 6 - execution BLOCKED below the {gate:.0%} gate",
                    True, f"trust {a2.trust_score:.0%}")

        # ---------------------------------------------------- 16. SQL Log
        R.banner("TAB 16/17", "SQL Log -- every statement, attributed")
        entries = list(SQL_LOG)
        writes = [e for e in entries
                  if e.get("ok") and any(
                      kw in e["sql"].upper()
                      for kw in ("INSERT ", "UPDATE ", "DELETE ", "DROP "))]
        R.check("the log captured this session's statements",
                len(entries) > 20, f"{len(entries)} statements")
        R.check("NO successful write reached the warehouse through a query",
                not writes, "every analytical statement was a SELECT")
        scoped = [e for e in entries if "lob IN (" in e["sql"]]
        R.check("scoped sessions carry the line-of-business predicate",
                bool(scoped), f"{len(scoped)} statements carry it")

        # ---------------------------------------------------- 17. Governance
        R.banner("TAB 17/17", "Governance -- hash-chain verification")
        from app.trust import ledger_v2
        v = ledger_v2.verify_chain()
        vd = v if isinstance(v, dict) else (
            v.model_dump() if hasattr(v, "model_dump") else vars(v))
        R.check("the ledger chain verifies end to end",
                bool(vd.get("ok", vd.get("valid", vd.get("intact")))),
                f"{vd.get('blocks_checked', vd.get('checked', '?'))} blocks")
        from app.governance import report as gov_report
        gr = gov_report.build()
        R.check("the AI governance report builds under this domain",
                bool(gr), ", ".join(list(gr.keys())[:4]))
        R.check("it still discloses that no fairness testing is performed",
                "fairness" in str(gr).lower(),
                "same disclosure, different domain")
        csv_out = gov_report.to_csv()
        R.check("the ledger exports for an external audit file",
                len(csv_out.splitlines()) > 1,
                f"{len(csv_out.splitlines()) - 1} rows")
        from app.security.agent_acl import acl_matrix
        acl = acl_matrix()
        R.check("the agent grant matrix is visible to an auditor",
                bool(acl.get("agents")),
                f"{len(acl['agents'])} agents, {len(acl['tools'])} tools")
    finally:
        bl.set_active("healthcare_payer")
        bl.reload_brain()

    R.banner("TEARDOWN", "The payer domain is left exactly as it was")
    R.check("active domain restored",
            bl.active_domain() == "healthcare_payer")
    R.check("payer scope column restored",
            (bl.get_brain().get("governance") or {}).get("scope_column")
            == "lob")
    R.check("payer metrics restored",
            "mlr" in bl.get_brain()["metrics"])

    print()
    return R.finish("Medicare Sales all-tabs pre-flight")


def _save_gate_ok(domain: str) -> bool:
    """Does the Brain evaluation gate accept this domain's own content?

    A no-op save (the file exactly as it is on disk) must pass. Before the
    per-domain floors it did not: the gate asserted the payer's rule IDs and
    content volumes against whatever domain was being edited, so every
    non-payer Brain was read-only.
    """
    from app.semantic import brain as bl, brain_eval
    content = bl.read_file(domain, "policy_rules.md")
    return brain_eval.evaluate(domain, "policy_rules.md", content)["ok"]


if __name__ == "__main__":
    sys.exit(main())
