"""Every figure and parameter in Medicare_Sales_Functionality_Chain.md.

Same method as the walkthrough verifier: never type a literal — take what the
engine returns, format it the way the doc writes it, and grep for that.

    cd oppal_stage/backend
    PYTHONPATH=. python demo/verify_functionality_chain.py
"""
from __future__ import annotations

import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("verifychain")

import _medicare as MS  # noqa: E402

R = Reporter()
AGENT = "AG-0027"
SWARM_Q = ("Why is agent AG-0027 an effectuation outlier and is commission "
           "being recovered?")
_MD = os.path.join(os.path.dirname(__file__), "..", "..",
                   "Medicare_Sales_Functionality_Chain.md")
DOC = " ".join(re.sub(r"(?m)^>\s?", "", open(_MD).read()).split())

# The six questions the doc locks the demo to, and the column the doc quotes.
SIX = ["commission paid by agent", "effectuation rate by agent",
       "effectuated enrollments by agent", "member retention rate by agent",
       "qualified lead rate by market", "member retention rate by channel"]


def usd(x): return f"${float(x):,.2f}"


def fact(label, value, shown):
    R.check(label, shown in DOC, f"{shown}" if shown in DOC
            else f"{shown!r} NOT in doc")


def main():
    cast = MS.setup()
    from app.analytics import rules_engine
    from app.agents import swarm, case_store
    from app.llm.base import get_provider
    from app.semantic import brain as bl, ontology
    from app.schemas.simulation import SimulationRequest, ParameterOverride
    from app.simulation import engine as sim

    MS.title(R, "Medicare_Sales_Functionality_Chain.md",
             "every quoted figure and every parameter, against the engine")

    # -- 1 Pillars ----------------------------------------------------------
    R.banner("TAB 1", "Pillars — the finding you did not ask for")
    breaches = [b for v in rules_engine.pillar_summary(cast.sc_morgan).values()
                if isinstance(v, dict) for b in (v.get("breaches") or [])]
    per: dict[str, set] = {}
    for b in breaches:
        a = (b.get("evidence") or {}).get("agent_id")
        if a:
            per.setdefault(a, set()).add(b["rule"])
    fact("49 breaches / 12 rules", len(breaches),
         f"**{len(breaches)} breaches across {len({b['rule'] for b in breaches})} rules**")
    mine = [b for b in breaches
            if (b.get("evidence") or {}).get("agent_id") == AGENT]
    fact("AG-0027 in 4 rules, 9 rows", len(mine),
         f"**{len(per[AGENT])} rules, {len(mine)} breach rows**")
    R.check("every other agent appears in exactly one rule",
            {len(v) for k, v in per.items() if k != AGENT} == {1},
            f"{len(per) - 1} other agents, all single-rule")
    for rule in ("SALES-EFFECTUATION-Z", "SALES-BONUS-EXCEPTION",
                 "CMS-COMP-CAP-2274E", "CMS-AGENT-CERT-2274"):
        R.check(f"the doc's Pillars search term {rule} is a real rule",
                any(b["rule"] == rule for b in breaches) and rule in DOC,
                "searchable in the tab")
    by_rule: dict[str, list] = {}
    for b in mine:
        by_rule.setdefault(b["rule"], []).append(b["evidence"])
    bonus = round(sum(e["overpaid_usd"]
                      for e in by_rule["SALES-BONUS-EXCEPTION"]), 2)
    cap = round(sum(e["excess_usd"]
                    for e in by_rule["CMS-COMP-CAP-2274E"]), 2)
    rd = by_rule["CMS-RAPID-DISENROLL-RECOUP"][0]["unrecouped_usd"]
    z = by_rule["SALES-EFFECTUATION-Z"][0]
    fact("headline overpayment", bonus, usd(bonus))
    fact("unrecovered clawback", rd, usd(rd))
    fact("cap excess", cap, usd(cap))
    fact("effectuation vs book", z["book_rate"],
         f"{z['effectuation_rate']} effectuation against a {z['book_rate']} book")

    # -- 2 Chat -------------------------------------------------------------
    R.banner("TAB 2", "Chat — the six locked questions")
    ask = MS.asker(cast.morgan)
    from app.llm.base import get_provider as _gp
    from app.agents.orchestrator import Orchestrator
    orch = Orchestrator(_gp())
    for q in SIX:
        a = orch.handle(q, user=cast.morgan)
        arts = a.get("artifacts", [])
        chart = next((x for x in arts if x["type"] == "chart"), None)
        rows = next((x["rows"] for x in arts if x.get("rows")), []) or []
        trust = round((a.get("trust") or {}).get("score", 0) * 100)
        R.check(f'"{q}" charts at >=85% trust',
                bool(chart) and trust >= 85,
                f"{chart['chart_type'] if chart else 'NO CHART'}, "
                f"{len(rows)} rows, trust {trust}%")
        R.check(f'"{q}" is quoted in the doc', f"`{q}`" in DOC, "verbatim")
    # the three figures the doc builds the reveal on
    ranks = {}
    for q in ("commission paid by agent", "effectuation rate by agent",
              "effectuated enrollments by agent"):
        _, _, rows = ask(q)
        d = dict(rows)
        ranks[q] = (d[AGENT], list(d).index(AGENT) + 1, len(d))
    v, r, n = ranks["commission paid by agent"]
    fact("paid #1", v, f"| `commission paid by agent` | **{usd(v)}** | **{r} of {n}** |")
    v, r, n = ranks["effectuation rate by agent"]
    fact("delivers 59th", v, f"| `effectuation rate by agent` | **{v}** | **{r} of {n}** |")
    v, r, n = ranks["effectuated enrollments by agent"]
    fact("3rd on volume", v, f"| `effectuated enrollments by agent` | **{v}** | **{r} of {n}** |")
    # the doc's warning about the wrong spelling
    _, _, wrong = ask("effectuation enrollments by agent")
    _, _, right = ask("effectuated enrollments by agent")
    _, _, rate = ask("effectuation rate by agent")
    R.check("\"effectuation enrollments\" really does duplicate the RATE",
            dict(wrong) == dict(rate) and dict(right) != dict(rate),
            "the doc's spelling warning is real")
    _, t_typo, _ = ask("comission paid by agent")
    R.check("the misspelling really is gated below 85%", t_typo < 85,
            f"trust {t_typo}% — SQL withheld")

    # -- 2b the AG-0027 case detail carried over from the walkthrough -------
    R.banner("TAB 2b", "The AG-0027 case detail, same as the walkthrough")
    from app.data.db import POOL

    def sql(q):
        c = POOL.acquire()
        try:
            return [tuple(r) for r in c.execute(q).fetchall()]
        finally:
            POOL.release(c)

    ag = sql(f"SELECT * FROM sales_agents WHERE agent_id='{AGENT}'")[0]
    fact("NPN", ag[2], f"NPN {ag[2]}")
    fact("agency and type", ag[4], f"**{ag[3]}**, a **{ag[4]}**")
    fact("market", ag[6], f"{ag[5]}, **{ag[6]}**, New Jersey")
    fact("hire date", ag[9], "**January 2024**. Status **Active**.")
    certs = sql(f"""SELECT cert_type, expiry_date, status FROM
        agent_certifications WHERE agent_id='{AGENT}'""")
    R.check("all three credentials current — not a licensing case",
            len(certs) == 3 and {c[2] for c in certs} == {"Active"}
            and {c[1] for c in certs} == {"2026-12-31"}
            and "this is not a licensing case" in DOC,
            f"3 credentials, all Active to {certs[0][1]}")
    fact("credential expiry", certs[0][1],
         f"**all three Active** through {certs[0][1]}")

    # the channel money split — the doc presents this FROM PILLARS, so assert
    # it against the breach rows a presenter can actually pull up on screen
    chan = {e["channel"]: e for e in by_rule["SALES-BONUS-EXCEPTION"]}
    for ch, e in chan.items():
        mark = "**" if ch == "DTC" else ""
        fact(f"channel money {ch}", e["overpaid_usd"],
             f"| {mark}{ch}{mark} | {mark}{e['payments']}{mark} | "
             f"{mark}{usd(e['overpaid_usd'])}{mark} |")
    share = round(chan["DTC"]["overpaid_usd"] / bonus * 100)
    fact("DTC share of the overpayment", share,
         f"**{share}% of the overpayment sits in one channel.**")

    counts = dict((r[0], (r[1], r[2])) for r in sql(f"""SELECT channel,
        COUNT(*), SUM(effectuated_flag) FROM enrollments
        WHERE agent_id='{AGENT}' AND lob='Medicare Advantage'
        GROUP BY channel"""))
    R.check("DTC is 4 enrolments with 1 effectuated",
            counts["DTC"] == (4, 1)
            and "of his four DTC enrolments only **one** effectuated" in DOC,
            str(counts["DTC"]))
    zero = sql(f"""SELECT COUNT(*) FROM enrollments WHERE agent_id='{AGENT}'
        AND lob='Medicare Advantage' AND channel='DTC'
        AND effectuated_flag=0 AND annual_premium=0""")[0][0]
    fact("two failed DTC enrolments carry no premium", zero,
         "**$0 of annual premium**")
    fact("the book split by channel", counts["Web"][0],
         f"Web {counts['Web'][0]} · Broker {counts['Broker'][0]} · "
         f"Telesales {counts['Telesales'][0]} · **DTC {counts['DTC'][0]}** · "
         f"Agency {counts['Agency'][0]}")

    months = dict(sql(f"""SELECT substr(effective_date,1,7), COUNT(*)
        FROM enrollments WHERE agent_id='{AGENT}'
        AND lob='Medicare Advantage' GROUP BY 1"""))
    pre = [v for k, v in months.items() if k < "2026-11"]
    R.check("1-5 a month, then 10 in January 2027",
            min(pre) == 1 and max(pre) == 5 and months["2027-01"] == 10
            and "**one to five**" in DOC
            and "**January 2027 he writes ten**" in DOC,
            f"pre-Nov range {min(pre)}-{max(pre)}, Jan-27 {months['2027-01']}")
    worst_q = max(by_rule["CMS-COMP-CAP-2274E"],
                  key=lambda e: e["excess_usd"])
    R.check("2027Q1 really is his worst cap quarter",
            worst_q["comm_quarter"] == "2027Q1"
            and f"**{usd(worst_q['excess_usd'])}** over the cap" in DOC,
            f"{worst_q['comm_quarter']} {usd(worst_q['excess_usd'])}")

    # -- 3 Ontology ---------------------------------------------------------
    R.banner("TAB 3", "Ontology — the join behind the number")
    view = ontology.graph_view()
    val = ontology.validate()
    names = {n["id"] for n in view["nodes"]}
    R.check("20 object types, 20 edges, no warnings",
            val["stats"]["object_types"] == 20 and len(view["edges"]) == 20
            and not val["warnings"] and val["ok"],
            f"{val['stats']['object_types']} types, {len(view['edges'])} edges")
    for obj in ("Lead", "Enrollment", "SalesAgent", "Commission",
                "AgentCertification", "CompensationCase"):
        R.check(f"the doc names a real object type: {obj}",
                obj in names and obj in DOC, "declared in the ontology")
    edge = next(e for e in view["edges"]
                if e["from"] == "Commission" and e["to"] == "Enrollment")
    fact("the Commission→Enrollment join key", edge["on"], edge["on"])
    # THE claim of this tab: the rule walks the declared edge
    rule_sql = next(r["query"] for r in bl.get_brain()["policy_rules"]
                    if r.get("rule_id") == "SALES-BONUS-EXCEPTION")
    lhs, rhs = [s.strip() for s in edge["on"].split("=")]
    R.check("SALES-BONUS-EXCEPTION joins on the SAME declared key",
            lhs.split(".")[-1] in rule_sql and rhs.split(".")[-1] in rule_sql
            and "effectuated_flag = 0" in rule_sql,
            "the rule walks the ontology edge, it does not improvise")

    # -- 3b Context Brain — the threshold defence ---------------------------
    R.banner("TAB 3b", "Context Brain — is the bar he failed a fair one?")
    zr = next(r for r in bl.get_brain()["policy_rules"]
              if r.get("rule_id") == "SALES-EFFECTUATION-Z")
    for key in ("min_enrollments", "effectuation_floor", "z_threshold",
                "breach_action"):
        fact(f"declared {key}", zr[key], f"| `{key}` | **{zr[key]}** |")
    R.check("the rule cites CMS, not only internal policy",
            "422.2274" in zr["citation"] and "**42 CFR §422.2274**" in DOC,
            zr["citation"][:58])
    R.check("28 enrolments clears the rule's own volume floor",
            z["enrollments"] > int(zr["min_enrollments"])
            and f"He has **{z['enrollments']}**" in DOC,
            f"{z['enrollments']} > {zr['min_enrollments']}")
    R.check("the remediation refuses to jump to fraud",
            "genuinely requested" in zr["remediation"]
            and "confirm each application was genuinely requested" in DOC,
            "restraint is in the rulebook, not left to the analyst")

    # -- 4 Swarm ------------------------------------------------------------
    R.banner("TAB 4", "Swarm — independent agreement")
    run = swarm.run_swarm(SWARM_Q, cast.morgan, llm=get_provider())
    R.check("three investigating departments activate",
            {"compensation_siu", "agent_performance", "enrollment_ops"}
            <= set(run["activated"]), ", ".join(run["activated"]))
    fact("run trust", run["trust"],
         f"**6 findings, run trust {run['trust']}** against a 0.85 gate")
    heads = {f.get("agent"): f["headline"] for f in run["findings"]}
    R.check("Enrolment Ops raises the channel nobody asked about",
            "0.3125" in heads["enrollment_ops"]
            and "Northeast" in heads["enrollment_ops"]
            and "**31.25% of members leaving inside ninety days.**" in DOC,
            heads["enrollment_ops"][:64])

    # -- 5 Cases ------------------------------------------------------------
    R.banner("TAB 5", "Cases — the parameters and the pattern→action map")
    R.check("the status dropdown offers exactly the four declared states",
            list(case_store.STATES) == ["open", "reviewing", "referred_siu",
                                        "closed"]
            and all(f"`{s}`" in DOC for s in case_store.STATES),
            " · ".join(case_store.STATES))
    cases = {c["case_type"]: c for c in case_store.list_cases(cast.sc_morgan)}
    R.check("three cases open", len(cases) == 3, str(len(cases)))
    for ct, c in cases.items():
        fact(f"case {ct} id", c["case_id"], c["case_id"])
        fact(f"case {ct} value", c["estimated_impact"],
             f"**{usd(c['estimated_impact'])}**")
    # the doc's pattern→action table must match the UI's real mapping
    jsx = open(os.path.join(os.path.dirname(__file__), "..", "..", "frontend",
                            "src", "components", "CasesTab.jsx")).read()
    mapping = dict(re.findall(r"^\s*(\w+):\s*'([\w_]+)',", jsx, re.M))
    for pattern, action in (("compensation_overpayment", "commission_recovery"),
                            ("agent_effectuation_outlier", "agent_remediation"),
                            ("retention_leakage", "enrollment_reconciliation"),
                            ("certification_lapse", "agent_suspension"),
                            ("lead_quality_collapse", "lead_source_suspension"),
                            ("funnel_fallout", "campaign_pause")):
        R.check(f"pattern {pattern} → {action}",
                mapping.get(pattern) == action
                and f"`{pattern}` | **`{action}`**" in DOC
                or mapping.get(pattern) == action
                and f"`{pattern}` | `{action}`" in DOC,
                f"UI maps it to {mapping.get(pattern)}")
    R.check("the case the doc tells you to act on carries the headline amount",
            float(cases["CompensationCase"]["estimated_impact"]) == bonus,
            f"COM case = {usd(bonus)}")
    before = len(cases)
    swarm.run_swarm(SWARM_Q, cast.morgan, llm=get_provider())
    R.check("a second run de-duplicates rather than piling up",
            len(case_store.list_cases(cast.sc_morgan)) == before,
            f"{before} before, {before} after")

    # -- 6 Simulator --------------------------------------------------------
    R.banner("TAB 6", "Simulator — the four levers and the doc's recipe")
    b = bl.get_brain()
    sb = b["simulation"]["simulator_bindings"]
    levers = [sb[f"{r}_stress_key"] for r in ("ratio", "cost_a", "cost_b",
                                              "volume")]
    R.check("exactly four levers exist, and the doc names all four",
            sorted(levers) == sorted(k for k in b["metrics"]
                                     if k.startswith("sim_"))
            and all(f"`metrics.{k}.stress_pct`" in DOC or f"`{k}`" in DOC
                    for k in levers),
            ", ".join(sorted(levers)))
    rec = b["simulation"]["commission_recovery_net"]
    rate_, cost = float(rec["dispute_rate"]), float(rec["recovery_cost"])
    fact("dispute rate", rate_, f"dispute rate **{rate_}**")
    fact("recovery cost", cost, f"recovery cost **${cost:,.0f}**")
    net = round(bonus * (1 - rate_) - cost, 2)
    fact("net recovery", net, f"| **Net recovery** | **{usd(net)}** |")
    R.check("the doc does not oversell the headline",
            f"{round(net / bonus * 100)}% of the headline" in DOC,
            f"{usd(net)} is {round(net / bonus * 100)}% of {usd(bonus)}")

    BASE = "Medicare Advantage leads in the Northeast"
    R.check("the doc's baseline audience is quoted verbatim",
            f"`{BASE}`" in DOC, BASE)

    def run_sim(pairs):
        return sim.run_simulation(SimulationRequest(
            baseline_query=BASE,
            parameter_overrides=[ParameterOverride(
                brain_path=f"metrics.{k}.stress_pct", op="delta_pct",
                value=v, reason="verified by demo/verify_functionality_chain")
                for k, v in pairs]), cast.morgan, cast.sc_morgan)

    both = run_sim([("sim_commission_cost", "-0.10"),
                    ("sim_lead_loss_ratio", "-0.15")])
    fact("combined net", both.net_dollar_impact,
         f"**Result: net {usd(both.net_dollar_impact)} · "
         f"{both.mlr_delta_bps:+d} bps · trust {float(both.trust_score)}.**")
    # the table explaining WHY two overrides
    for key, val_, in (("sim_commission_cost", "-0.10"),
                       ("sim_lead_loss_ratio", "-0.15"),
                       ("sim_acquisition_cost", "-0.15"),
                       ("sim_cancellation_count", "-0.25")):
        r_ = run_sim([(key, val_)])
        money = usd(r_.net_dollar_impact) if r_.net_dollar_impact else "$0.00"
        bps = f"{r_.mlr_delta_bps:+d} bps" if r_.mlr_delta_bps else "+0 bps"
        # Compare on the numbers, not on which cell the doc chose to bold.
        R.check(f"solo lever {key} {val_}",
                f"| `{key}` `{val_}` | {money} | {bps} |"
                in DOC.replace("**", ""), f"{money} / {bps}")

    # -- 7 Actions ----------------------------------------------------------
    R.banner("TAB 7", "Actions — where the analyst's authority ends")
    from app.actions import engine as AE
    rules = {r.get("rule_id"): r for r in b["policy_rules"]}
    com = cases["CompensationCase"]
    act = AE.propose(
        case_id=com["case_id"], action_type="commission_recovery",
        target_object=AGENT, lob="Medicare Advantage",
        summary="Recover compensation paid on enrolments that never effectuated",
        estimated_financial_impact=bonus, regulatory_severity="high",
        trust_score=float(com["trust_score"]),
        fields={"case_id": com["case_id"]}, proposer_user_id="u-ma")
    R.check("the proposal is dual control", act.control_mode.value == "dual",
            act.state.value)
    thresh = float(rules["ACT-DUAL-CONTROL"]["financial_impact_threshold"])
    R.check("dual control is NOT earned by the amount", bonus < thresh,
            f"{usd(bonus)} < {usd(thresh)} — the action type is why")
    fact("dual-control money threshold", thresh, f"**${thresh:,.0f}**")

    def refused(u, sc):
        try:
            AE.approve(act.action_id, u, sc)
            return ""
        except Exception as e:            # noqa: BLE001 — the message IS the check
            return str(e)

    msg = refused(cast.morgan, cast.sc_morgan)
    R.check("the analyst cannot approve ANY write-back",
            "not authorized to approve" in msg and msg in DOC, msg[:60])
    R.check("Casey signs first",
            AE.approve(act.action_id, cast.casey,
                       cast.sc_casey).state.value == "PENDING_SECOND_APPROVAL",
            "one signature is not enough")
    R.check("the same officer cannot sign twice",
            "separation of duties" in refused(cast.casey, cast.sc_casey),
            "separation of duties holds")
    R.check("Dana signs second",
            AE.approve(act.action_id, cast.dana,
                       cast.sc_dana).state.value == "APPROVED",
            "two distinct officers")

    MS.teardown(R)


if __name__ == "__main__":
    main()
    sys.exit(R.finish("Functionality chain"))
