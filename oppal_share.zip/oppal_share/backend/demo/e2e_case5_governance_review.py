"""OpPal — Business Case 5: The Quarterly Governance Review  (all LOBs)

    "After a coding-accuracy audit finding, Compliance reviews the
     PA/UM auto-approval gate across the WHOLE book, tightens the
     trust threshold in the Brain (not the code), proves the effect
     with before/after numbers, and rolls the change back afterward
     -- all while checking the ledger, FinOps spend, and notification
     posture stay healthy."

Unlike Cases 1-4, the protagonist here is the compliance officer herself,
reviewing every line of business at once, rather than a single-LOB analyst.
Runs against the real engine end to end: real full-scope RBAC, a real
Brain edit + reload + snapshot/rollback, real before/after re-evaluation of
the PA/UM triage rule, real dual-control action, real hash-chained ledger.

Run:
    cd oppal/backend
    PYTHONPATH=. python3 demo/e2e_case5_governance_review.py

Exit code 0 = every check passed.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("case5")

R = Reporter()


def main():
    from app.data.db import ensure_db, get_user_context
    from app.mcp import scope_from_user
    ensure_db()

    print()
    print("┌" + "─" * (R.W - 2) + "┐")
    print("│" + "  OpPal — Business Case 5 · The Quarterly Governance Review".ljust(R.W - 2) + "│")
    print("│" + "  All lines of business · PA/UM auto-approval gate, full-scope audit".ljust(R.W - 2) + "│")
    print("└" + "─" * (R.W - 2) + "┘")

    casey = get_user_context("u-compliance")
    dana = get_user_context("u-compliance2")
    scope_c = scope_from_user(casey)
    scope_d = scope_from_user(dana)

    # -----------------------------------------------------------------
    R.banner("STEP 1", "RBAC: full scope, from the OTHER side of the story")
    R.say("Cases 1-4 showed a LOB-scoped analyst. Casey is compliance_officer")
    R.say("-- full scope across all four lines of business, and the only")
    R.say("role that can read the ledger or edit the Brain.")
    print()

    from app.security.auth import authorize
    R.check("compliance_officer sees every line of business",
           set(scope_c.allowed_lobs) ==
           {"Medicare Advantage", "Medicaid", "Commercial", "ACA Exchange"},
           f"allowed_lobs={scope_c.allowed_lobs}")
    R.check("compliance_officer may read the audit ledger",
           authorize(casey, "audit_read") is True)
    R.check("compliance_officer may edit the Context Brain",
           authorize(casey, "brain_write") is True)

    from app.mcp import data_service
    svc = data_service()
    r_all = svc.execute("SELECT lob, COUNT(*) FROM claims GROUP BY lob",
                       scope_c, purpose="demo")
    R.check("a full-scope read sees claims from every line of business "
           "in one query",
           r_all.ok and len(r_all.rows) == 4,
           f"{dict((row[0], row[1]) for row in r_all.rows)}")

    # -----------------------------------------------------------------
    R.banner("STEP 2", "Pillars: the whole-book PA/UM picture (Pillars tab)")
    R.say("Across the whole book, every approved prior-auth case already")
    R.say("clears the current trust gate for straight-through processing --")
    R.say("full automation headroom, and exactly what a coding-accuracy")
    R.say("finding elsewhere makes Casey want to give some of up, on purpose.")
    print()

    from app.analytics import rules_engine
    before = rules_engine.pa_triage(scope_c)
    R.ok("Pillars: whole-book PA/UM triage summary retrieved",
       str(before["summary"]))
    approved = before["summary"]["approved"]
    eligible_before = before["summary"]["auto_approve_eligible"]
    gate_before = before["summary"]["gate"]
    R.check("at the current gate, every approved case already clears "
           "straight-through (the comfortable position Casey is about to "
           "deliberately give up some of)",
           eligible_before == approved and eligible_before > 0,
           f"{eligible_before} of {approved} approved cases clear the "
           f"current {gate_before} gate automatically")

    # -----------------------------------------------------------------
    R.banner("STEP 3", "Context Brain: tighten the gate — a markdown edit, "
                     "not a deployment")
    R.say("A coding-accuracy finding elsewhere this quarter makes Casey")
    R.say("want a SAFER (higher) bar before anything auto-clears, not a")
    R.say("looser one. She edits policy_rules.md directly.")
    print()

    from app.semantic import brain as brain_loader

    domain = brain_loader.active_domain()
    snapshot_id = brain_loader.snapshot(
        domain, "before Case 5 auto_approve_trust tightening")
    R.ok("Context Brain: a safety snapshot is taken before editing",
       snapshot_id)

    content = brain_loader.read_file(domain, "policy_rules.md")
    old_line = f"- auto_approve_trust: {gate_before}"
    new_gate = 0.92
    new_line = f"- auto_approve_trust: {new_gate}"
    R.check("the exact declared threshold line is found in the markdown "
           "(this is the ONLY place this number lives)",
           old_line in content, old_line)
    new_content = content.replace(old_line, new_line)
    save = brain_loader.write_file(domain, "policy_rules.md", new_content)
    R.check("Context Brain: the edit saves cleanly",
           save.get("saved") is True, save.get("report", ""))
    brain_loader.reload_brain()

    after = rules_engine.pa_triage(scope_c)
    eligible_after = after["summary"]["auto_approve_eligible"]
    gate_after = after["summary"]["gate"]
    R.check("the pillar's displayed gate reflects the edited markdown "
           "immediately, with no code change or restart",
           gate_after == new_gate, f"gate now reads {gate_after}")
    R.check("tightening the gate MEASURABLY reduces straight-through "
           "auto-approval eligibility (proof the Brain declaration is "
           "not just cosmetic)",
           eligible_after < eligible_before,
           f"{eligible_before} -> {eligible_after} eligible "
           f"({eligible_before - eligible_after} more cases now require a "
           f"nurse's manual sign-off)")

    # -----------------------------------------------------------------
    R.banner("STEP 4", "Ontology + Semantic Graph: nothing else broke")
    R.say("Editing one governance rule must not silently change what the")
    R.say("rest of the platform believes about the data model.")
    print()

    from app.semantic import ontology
    R.check("Ontology: the object model still validates after the edit",
           len(ontology.object_types()) > 0 and len(ontology.edges()) > 0)
    graph = ontology.graph_view()
    R.check("Semantic Graph: the graph still loads after the edit",
           isinstance(graph.get("nodes"), list) and len(graph["nodes"]) > 0,
           f"{len(graph['nodes'])} nodes")

    fwa_before_after = rules_engine.fwa_scan(scope_c)
    R.check("FWA pillar is unaffected by a PA/UM-only rule change "
           "(each pillar rule is independently scoped)",
           fwa_before_after["alert_count"] > 0,
           f"{fwa_before_after['alert_count']} FWA alerts, unchanged pillar")

    # -----------------------------------------------------------------
    R.banner("STEP 5", "Actions: staff the widened manual-review queue "
                     "(dual control)")
    n_gap = eligible_before - eligible_after
    R.say(f"The {n_gap} cases that now need manual sign-off are proposed as")
    R.say("a staffing action, attributed to the review itself rather than")
    R.say("to either officer -- so BOTH Casey and Dana remain eligible, and")
    R.say("neither distinct, un-conflicted signature is short-circuited.")
    print()

    from app.agents import case_store
    from app.actions import engine as act_engine
    from app.schemas.actions import ActionState, ControlMode

    case = case_store.upsert_case(
        case_type="um_gate_tightened", lob="Medicare Advantage",
        subject="PA/UM auto-approval gate tightened 0.85 -> 0.92",
        pattern="auto_approve_trust_change",
        severity="medium", trust_score=0.95,
        evidence={"gate_before": gate_before, "gate_after": gate_after,
                  "eligible_before": eligible_before,
                  "eligible_after": eligible_after},
        created_by="compliance_officer")
    R.ok("Cases: the policy change itself is logged as a tracked case",
       case["case_id"])

    action = act_engine.propose(
        case_id=case["case_id"], action_type="auth_override",
        target_object="UM-NURSE-QUEUE", lob="Medicare Advantage",
        summary=f"Add temporary UM nurse capacity for the {n_gap} cases "
               "that no longer auto-clear under the tightened gate",
        estimated_financial_impact=22000.0,
        regulatory_severity="medium", trust_score=0.95,
        target_system="dry_run", proposed_by="quarterly_governance_review",
        proposer_user_id="")
    R.check("even a compliance-initiated staffing action requires a "
           "SECOND, distinct compliance officer",
           action.control_mode == ControlMode.DUAL,
           "threshold + severity read from policy_rules.md")
    a1 = act_engine.approve(action.action_id, casey, scope_c)
    R.check("first signature leaves it pending a second, DISTINCT officer",
           a1.state == ActionState.PENDING_SECOND_APPROVAL)
    try:
        act_engine.approve(action.action_id, casey, scope_c)
        R.check("Casey cannot sign her own proposal twice", False)
    except act_engine.ActionError as e:
        R.ok("separation of duties: Casey cannot sign her own proposal "
           "twice", str(e)[:46])
    a2 = act_engine.approve(action.action_id, dana, scope_d)
    R.check("Dana's distinct signature -> APPROVED",
           a2.state == ActionState.APPROVED and a2.distinct_approvers())
    out = act_engine.execute(action.action_id, casey, scope_c)
    R.check("execution succeeds through the governed adapter",
           out["receipt"]["ok"] and out["action"]["state"] == "EXECUTED")

    # -----------------------------------------------------------------
    R.banner("STEP 6", "Context Brain: roll the gate back to baseline")
    R.say("The staffing plan is in place; Casey restores the ORIGINAL")
    R.say("gate from the snapshot taken in Step 3 -- proving a governance")
    R.say("change is reversible with the same rigor as a write-back.")
    print()

    rb = brain_loader.rollback(domain, snapshot_id)
    R.check("Context Brain: rollback restores the pristine snapshot",
           rb.get("ok") is True, rb.get("restored", ""))
    brain_loader.reload_brain()
    restored = rules_engine.pa_triage(scope_c)
    R.check("the gate and eligibility count are back to their original "
           "values after rollback",
           restored["summary"]["gate"] == gate_before and
           restored["summary"]["auto_approve_eligible"] == eligible_before,
           f"gate={restored['summary']['gate']}, "
           f"eligible={restored['summary']['auto_approve_eligible']}")

    # -----------------------------------------------------------------
    R.banner("STEP 7", "FinOps + Governance + SQL Log: the platform's own "
                     "health")
    R.say("Before closing the quarter, Casey checks what the platform")
    R.say("itself cost to run, the notification posture, and exports the")
    R.say("ledger for the compliance file.")
    print()

    from app.finops import telemetry
    t = telemetry.snapshot()
    R.check("FinOps: session spend reconciles against global spend "
           "(Decimal money, no float drift)",
           t.session_cost_usd <= t.global_cost_usd and
           0.0 <= t.cache_hit_rate <= 1.0,
           f"provider={t.provider} · session ${t.session_cost_usd} / "
           f"global ${t.global_cost_usd}")

    from app.notify.bus import configured_channels
    ch = configured_channels()
    R.check("Settings: notification channels degrade cleanly when "
           "unconfigured (no crash, no silent drop)",
           all(isinstance(c.get("available"), bool) for c in ch.values()),
           f"{ {k: v['available'] for k, v in ch.items()} }")

    from app.data.db import SQL_LOG
    recent = [s for s in list(SQL_LOG)][-30:]
    R.check("SQL Log: this entire full-scope review never issued a write "
           "statement",
           all(s["sql"].strip().upper().startswith("SELECT")
               for s in recent) if recent else True,
           f"{len(recent)} statements inspected")

    from app.trust import ledger_v2
    v = ledger_v2.verify_chain()
    R.check("Governance: hash chain verifies end-to-end for the whole "
           "quarter's activity",
           v.ok, f"{v.checked} v2 blocks checked, head at seq {v.head_seq}")

    today = __import__("datetime").datetime.now(
        __import__("datetime").timezone.utc).date().isoformat()
    export = ledger_v2.export(today, today, fmt="csv")
    R.check("an auditor export is produced for the quarterly compliance "
           "file",
           export.startswith("seq,ts,kind"),
           f"{len(export.splitlines()) - 1} rows exported as CSV")

    R.banner("CASE 5 COMPLETE", "the audit trail of this entire run")
    R.say(f"Case            {case['case_id']}")
    R.say(f"Gate change     {gate_before} -> {gate_after} -> {gate_before} "
        f"(tightened, staffed, then restored)")
    R.say(f"Executed action {action.action_id}  →  EXECUTED")
    R.say(f"Ledger          {v.checked} chained blocks, verified ok={v.ok}")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        R.fail_steps.append("unhandled exception")
    sys.exit(R.finish("Business Case 5 — The Quarterly Governance Review"))
