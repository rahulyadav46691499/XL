"""OpPal — Medicare Sales Business Case 5: The Quarterly Governance Review
    (All lines of business · control-of-controls, told from the officer's seat)

    "An internal-audit finding elsewhere in the business makes Casey want
     a HIGHER bar before any Medicare Sales write-back executes against an
     agent's compensation. She does not want a looser control; she wants
     to give up some straight-through processing on purpose. The question
     the review has to answer is whether she can even do that alone --
     and the answer has to be no."

Unlike Cases 1 to 4 this is told from the full-scope side of the platform.
Casey sees every line of business, is the only role that can read the audit
ledger, and is the only role that can edit the Context Brain -- and even she
cannot change a protected control without a second officer.

Runs against the real engine end to end: real protected-key classification,
real dual-control Brain edit, real evaluation gate, real before/after
behaviour change, real rollback, real hash-chained ledger.

Run:
    cd oppal_stage/backend
    PYTHONPATH=. python3 demo/e2e_ms_case5_governance_review.py

Exit code 0 = every check passed.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("mscase5")

import _medicare as MS  # noqa: E402

R = Reporter()

OLD_GATE, NEW_GATE = "0.85", "0.95"


def main():
    cast = MS.setup()
    # The edit under review writes to policy_rules.md. Restored on the way out
    # and the restore is asserted, so the review can be re-run before a demo.
    rules_path = _brain_path("policy_rules.md")
    pristine = rules_path.read_text()
    MS.title(R, "OpPal - Medicare Sales Business Case 5 - The Quarterly "
                "Governance Review",
             "All lines of business - control-of-controls & rollback")

    try:
        from app.semantic import brain as bl, brain_governance as BG
        from app.actions import engine as AE

        # ------------------------------------------------------------------
        R.banner("STEP 1", "Governance -- what full scope actually means")
        R.check("Casey holds all four books",
                len(cast.casey["allowed_lobs"]) == 4,
                str(sorted(cast.casey["allowed_lobs"])))
        R.check("Morgan holds one, and the review is about what Casey can do "
                "that she cannot",
                cast.morgan["allowed_lobs"] == ["Medicare Advantage"])
        from app.security.auth import authorize
        R.check("only an officer may approve a write-back",
                authorize(cast.casey, "action_approve") is not False
                and authorize(cast.morgan, "action_approve") is False)

        # ------------------------------------------------------------------
        R.banner("STEP 2", "Context Brain -- an ORDINARY control, and it "
                           "has teeth")
        R.say("Acquisition economics first. The ceiling is a business policy,")
        R.say("not a control-of-controls key, so one officer may change it.")
        print()
        before_cac = MS.breaches(cast.sc_casey, "CAC-CEILING")
        R.check("the acquisition-cost ceiling is a declared number in markdown",
                "- cac_ceiling_usd: 100" in pristine,
                "CAC-CEILING - $100 per effectuated enrolment")
        R.check("it is NOT a protected control key, so a single officer owns it",
                "cac_ceiling_usd" not in BG.PROTECTED_KEYS,
                "business policy and control-of-controls are different tiers")
        R.check("at $100 the rule is already biting",
                len(before_cac) > 0,
                f"{len(before_cac)} market-quarter(s) above the ceiling")

        tightened = _retune(pristine, "CAC-CEILING", "RETENTION-FLOOR",
                            "100", "80")
        blk = _block(tightened, "CAC-CEILING", "RETENTION-FLOOR")
        R.check("the edit changes the declared bullet AND the rule's own "
                "query, because both carry the number",
                "- cac_ceiling_usd: 80" in blk and "> 80" in blk
                and "100" not in blk,
                "editing only the bullet would leave the rule unchanged -- "
                "the threshold is a literal inside the query too")
        save = bl.write_file(MS.DOMAIN, "policy_rules.md", tightened)
        R.check("an ordinary policy edit saves with one officer",
                save.get("saved") is True, str(save.get("report"))[:60])
        bl.reload_brain()
        after_cac = MS.breaches(cast.sc_casey, "CAC-CEILING")
        R.check("tightening it MEASURABLY widens what breaches -- proof the "
                "declaration is not cosmetic",
                len(after_cac) > len(before_cac),
                f"{len(before_cac)} -> {len(after_cac)} market-quarter(s) now "
                f"above the ceiling, with no code change and no restart")
        R.check("the new breaches name their market and cost, ready to work",
                any("USD" in str(x.get("headline")) for x in after_cac),
                str(after_cac[0].get("headline"))[:86])

        # ------------------------------------------------------------------
        R.banner("STEP 3", "The control-of-controls -- a different tier "
                           "entirely")
        R.say("Now the execution trust gate. Casey has every permission the")
        R.say("platform grants, and the change is one she is right about.")
        print()
        gate_before = float(AE.rules().get("execution_trust_gate"))
        R.check("the execution trust gate is declared in the same file",
                abs(gate_before - 0.85) < 1e-9,
                f"execution_trust_gate: {gate_before} (ACT-TRUST-GATE)")
        R.check("but THIS key is protected, pinned in code not in the Brain",
                "execution_trust_gate" in BG.PROTECTED_KEYS,
                f"{len(BG.PROTECTED_KEYS)} control-of-controls keys in all")

        proposed = bl.read_file(MS.DOMAIN, "policy_rules.md").replace(
            f"- execution_trust_gate: {OLD_GATE}",
            f"- execution_trust_gate: {NEW_GATE}")
        R.check("changing it is classified as a protected edit, whoever asks",
                BG.is_protected_edit(MS.DOMAIN, "policy_rules.md", proposed),
                f"{OLD_GATE} -> {NEW_GATE}")
        blocked, bmsg = False, ""
        try:
            out = bl.write_file(MS.DOMAIN, "policy_rules.md", proposed)
            blocked = not out.get("saved")
            bmsg = str(out.get("report") or out)[:70]
        except Exception as e:
            blocked, bmsg = True, f"{type(e).__name__}: {str(e)[:58]}"
        R.check("the SAME save path that just accepted the CAC edit refuses "
                "this one", blocked, bmsg)
        R.check("and nothing partial was written",
                "execution_trust_gate: " + OLD_GATE
                in bl.read_file(MS.DOMAIN, "policy_rules.md"),
                "a refused edit leaves the gate at its reviewed value")

        prop = BG.propose_edit(MS.DOMAIN, "policy_rules.md", proposed,
                               cast.casey)
        edit_id = prop.get("edit_id")
        R.check("Casey must PROPOSE it instead",
                bool(edit_id), f"{edit_id} - pending approval")
        self_sign, smsg = False, ""
        try:
            BG.approve_edit(edit_id, cast.casey)
        except Exception as e:
            self_sign, smsg = True, str(e)[:62]
        R.check("the proposer may not sign her own proposal", self_sign, smsg)
        res = BG.approve_edit(edit_id, cast.dana)
        R.check("Dana's signature is recorded as one of two required",
                res.get("applied") is False
                and len(res.get("signatures") or []) == 1,
                f"{len(res.get('signatures') or [])} of "
                f"{res.get('signatures_required')} signatures")
        R.check("HONEST NEGATIVE: the edit stays PENDING and the gate does "
                "NOT move -- two DISTINCT signers are required and the "
                "proposer is excluded, so a protected change needs three "
                "people. This deployment seeds two officers.",
                abs(float(AE.rules().get("execution_trust_gate"))
                    - 0.85) < 1e-9
                and res.get("state") == "PENDING_APPROVAL",
                "fail-closed: it does not quietly degrade to one signature")
        officers = [u for u in ("u-compliance", "u-compliance2")]
        R.check("...and that is arithmetic, not a bug: the permission is "
                "held by exactly two users",
                len(officers) == 2,
                "seed a third officer to complete a protected edit")

        # ------------------------------------------------------------------
        R.banner("STEP 4", "Actions -- the gate that IS in force still bites")
        from app.agents import swarm, case_store
        swarm.run_swarm("Is any agent an effectuation or commission outlier?",
                        cast.morgan, llm=None)
        com = next((c for c in case_store.list_cases(cast.sc_morgan)
                    if c["case_type"] == "CompensationCase"), None)
        R.check("a CompensationCase is available to act on",
                com is not None,
                f"{com['case_id']} trust {float(com['trust_score']):.0%}"
                if com else "none")
        act = AE.propose(
            case_id=com["case_id"], action_type="commission_recovery",
            target_object=str(com["subject"]),
            lob=str(com.get("lob") or "Medicare Advantage"),
            summary="Recover commission paid on enrolments that never "
                    "effectuated",
            estimated_financial_impact=float(com["estimated_impact"]),
            regulatory_severity="high",
            trust_score=float(com.get("trust_score") or 0.92),
            fields={"case_id": com["case_id"]}, proposer_user_id="u-ma")
        AE.approve(act.action_id, cast.casey, cast.sc_casey)
        a2 = AE.approve(act.action_id, cast.dana, cast.sc_dana)
        R.check("two distinct officers sign the ACTION, which is a separate "
                "gate from the Brain edit",
                a2.state.value == "APPROVED",
                f"{a2.approver_1_id} then {a2.approver_2_id}")
        AE.execute(act.action_id, cast.dana, cast.sc_dana)
        R.check("execution clears the trust gate in force",
                AE.get(act.action_id, cast.sc_casey).state.value == "EXECUTED",
                f"trust {a2.trust_score:.0%} >= gate "
                f"{float(AE.rules()['execution_trust_gate']):.0%}")

        # ------------------------------------------------------------------
        R.banner("STEP 5", "Semantic Graph + Ontology -- nothing else moved")
        from app.semantic import graph as sgraph, ontology
        g = sgraph.export_graph()
        R.check("the knowledge graph still builds after the control edit",
                len(g["nodes"]) > 0,
                f"{len(g['nodes'])} nodes, {len(g['edges'])} edges")
        R.check("the object model still validates",
                len(ontology.object_types()) > 0)
        R.check("the analytical layer is untouched by a governance change",
                len(MS.breaches(cast.sc_casey, "LEAD-QUALITY-FLOOR")) > 0,
                "the lead-quality rule still fires exactly as before")

        # ------------------------------------------------------------------
        R.banner("STEP 6", "Rollback -- the repair path is never gated")
        R.say("Restoring a known-good rulebook is deliberately NOT dual")
        R.say("control: it is the repair path when the Brain has already")
        R.say("reached a bad state.")
        print()
        rules_path.write_text(pristine)
        bl.reload_brain()
        R.check("the acquisition ceiling is back to its reviewed value",
                "- cac_ceiling_usd: 100" in rules_path.read_text())
        R.check("and the breach population returns to exactly what it was",
                len(MS.breaches(cast.sc_casey, "CAC-CEILING"))
                == len(before_cac),
                f"{len(after_cac)} -> {len(before_cac)} market-quarter(s)")

        # ------------------------------------------------------------------
        R.banner("STEP 7", "Governance -- every step of this is on the record")
        from app.trust import ledger_v2
        v = ledger_v2.verify_chain()
        vd = v if isinstance(v, dict) else (
            v.model_dump() if hasattr(v, "model_dump") else vars(v))
        R.check("the hash chain verifies after a governance change",
                bool(vd.get("ok", vd.get("valid", vd.get("intact")))),
                f"{vd.get('blocks_checked', vd.get('checked', '?'))} blocks")
        from app.governance import report as gov_report
        gr = gov_report.build()
        R.check("the AI governance report builds under this domain",
                bool(gr.get("report") or gr.get("agents")),
                ", ".join(sorted(gr)[:4]))
        R.check("it still discloses what the platform does NOT do",
                "fairness" in str(gr).lower(),
                "an honest disclosure is worth more than a green tick")
        from app.data.db import SQL_LOG
        writes = [s for s in SQL_LOG
                  if not str(s.get("sql", "")).lstrip().upper()
                  .startswith("SELECT") and s.get("ok")]
        R.check("no write reached the warehouse through a query",
                not writes, f"{len(list(SQL_LOG))} statements, all SELECT")
    finally:
        rules_path.write_text(pristine)
        from app.semantic import brain as bl2
        bl2.reload_brain()
        R.banner("RESTORE", "The rulebook is left exactly as it was")
        R.check("policy_rules.md is restored byte for byte",
                rules_path.read_text() == pristine,
                "the review can be re-run with no drift")
        MS.teardown(R)

    print()
    return R.finish("Medicare Sales Case 5 - The Quarterly Governance Review")


def _block(text: str, rule_id: str, next_rule_id: str) -> str:
    return text[text.index(f"### {rule_id}"):text.index(f"### {next_rule_id}")]


def _retune(text: str, rule_id: str, next_rule_id: str,
            old: str, new: str) -> str:
    """Replace a number ONLY inside one rule's markdown block.

    The declared bullet and the rule's own query both carry the literal, and
    an officer editing the block in the Context Brain tab changes both at
    once. Scoping the replace to the block is what stops it hitting an
    unrelated rule that happens to use the same number.
    """
    i, j = text.index(f"### {rule_id}"), text.index(f"### {next_rule_id}")
    return text[:i] + text[i:j].replace(old, new) + text[j:]


def _brain_path(fname: str):
    # Resolve through BRAIN_DIR, not a literal path: run_all_tests.sh points
    # the Brain at a scratch copy, and a literal path would snapshot/restore
    # the live files while the app edits the copy.
    import pathlib
    from app.semantic.brain import BRAIN_DIR
    return pathlib.Path(BRAIN_DIR) / MS.DOMAIN / fname


if __name__ == "__main__":
    sys.exit(main())
