"""OpPal — Medicare Sales Business Case 2: The Lapsed Credential
    (Medicare Advantage · marketing compliance and enrolment integrity)

    "An agent-readiness audit ahead of AEP asks a simple question: did
     anyone write business on a credential that had already expired, and
     was a Scope of Appointment on file for every personal marketing
     appointment? Both are CMS marketing requirements, and both carry
     enrolment-review exposure rather than a dollar loss."

Runs against the real engine end to end: real RBAC, real MCP-scoped data
access, real declared policy rules, real hash-chained ledger. No step is
mocked or hand-typed.

Run:
    cd oppal_stage/backend
    PYTHONPATH=. python3 demo/e2e_ms_case2_lapsed_credential.py

Exit code 0 = every check passed.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("mscase2")

import _medicare as MS  # noqa: E402

R = Reporter()


def main():
    cast = MS.setup()
    MS.title(R, "OpPal - Medicare Sales Business Case 2 - The Lapsed Credential",
             "Medicare Advantage - marketing compliance & enrolment integrity")

    try:
        # ------------------------------------------------------------------
        R.banner("STEP 1", "Settings + Context Brain -- the rule before the "
                           "finding")
        R.say("Morgan reads the rule FIRST, so the argument later is about")
        R.say("the evidence and not about whether the rule exists.")
        print()
        from app.semantic import brain as bl
        b = bl.get_brain()
        rules = {r.get("rule_id"): r for r in b["policy_rules"]}
        cert = rules.get("CMS-AGENT-CERT-2274", {})
        soa = rules.get("CMS-SOA-2264", {})

        R.check("the warehouse loaded from the supplied CSVs",
                len(cast.counts) == 11,
                f"{cast.rows:,} rows across {len(cast.counts)} tables")
        R.check("the Brain parsed with no errors",
                not cast.brain_report.get("errors"))
        R.check("the certification rule is a versioned, cited declaration",
                "422.2274" in cert.get("citation", "")
                and "422.2272" in cert.get("citation", ""),
                cert.get("citation", "")[:66])
        R.check("it declares zero tolerance, not a soft target",
                str(cert.get("max_breach_count")) == "0"
                and cert.get("breach_action") == "fail")
        R.check("the Scope of Appointment rule declares the 48-hour window",
                str(soa.get("min_hours_before_appointment")) == "48",
                soa.get("citation", "")[:66])
        R.check("both rules carry their own SQL, so no bespoke Python runs "
                "them", bool(cert.get("query")) and bool(soa.get("query")))
        R.check("both declare a remediation the business can act on",
                "Suspend" in cert.get("remediation", "")
                and "Re-document" in soa.get("remediation", ""))

        # ------------------------------------------------------------------
        R.banner("STEP 2", "Chat -- the question an auditor actually asks")
        ask = MS.asker(cast.morgan)
        sql, trust, rows = ask("effectuated enrollments by agent")
        R.check('type: "effectuated enrollments by agent"',
                trust >= 85 and len(rows) > 0,
                f"trust {trust}% - {len(rows)} agents returned")
        R.check("the answer is scoped by the line of business, in SQL",
                "lob" in (sql or "").lower(),
                "the predicate is pushed down, not filtered after the fact")

        # ------------------------------------------------------------------
        R.banner("STEP 3", "Pillars -- the credential breach, named")
        R.say("The Regulatory pillar runs the rule's own declared query. It")
        R.say("did not see Morgan's chat question and does not depend on it.")
        print()
        cert_b = MS.breaches(cast.sc_morgan, "CMS-AGENT-CERT-2274")
        R.check("the certification rule raises real breaches",
                len(cert_b) > 0, f"{len(cert_b)} breach(es) in Morgan's book")
        top = cert_b[0]
        ev = top.get("evidence") or {}
        R.check("a breach names the agent, the credential and the expiry date",
                bool(ev.get("agent_id")) and bool(ev.get("cert_type"))
                and bool(ev.get("expiry_date")),
                str(top.get("headline"))[:88])
        R.check("it counts the applications actually at risk, not a row count",
                int(ev.get("applications", 0)) >= 1,
                f"{ev['agent_id']}: {ev['applications']} application(s) after "
                f"the {ev['cert_type']} expired {ev['expiry_date']}")
        R.check("every breached application really was written after expiry",
                _all_after_expiry(cast.sc_morgan),
                "re-derived independently of the rule's own query")

        soa_b = MS.breaches(cast.sc_morgan, "CMS-SOA-2264")
        R.check("the Scope of Appointment rule raises its own breaches",
                len(soa_b) > 0, f"{len(soa_b)} market/LOB group(s)")
        sev = soa_b[0].get("evidence") or {}
        R.check("an SOA breach separates 'no SOA on file' from 'signed too "
                "late'",
                "missing_soa" in sev and "short_notice" in sev,
                f"{sev.get('lob')}/{sev.get('market')}: "
                f"{sev.get('missing_soa')} with no SOA, "
                f"{sev.get('short_notice')} inside the 48-hour window")

        # ------------------------------------------------------------------
        R.banner("STEP 4", "Data + Data Layer -- the evidence under the rule")
        from app.mcp import data_service
        svc = data_service()
        res = svc.execute(
            "SELECT a.agent_id, c.cert_type, c.expiry_date, "
            "COUNT(DISTINCT a.application_id) n FROM applications a "
            "JOIN agent_certifications c ON c.agent_id = a.agent_id "
            "WHERE c.cert_type IN ('AHIP','State License') "
            "AND c.expiry_date IS NOT NULL AND c.expiry_date < "
            "a.application_date GROUP BY 1,2,3 ORDER BY n DESC LIMIT 5",
            cast.sc_morgan, purpose="demo")
        R.check("the application-level evidence is inspectable in the Data tab",
                res.ok and len(res.rows) > 0,
                f"worst: {res.rows[0][0]} - {res.rows[0][3]} application(s) "
                f"on an expired {res.rows[0][1]}" if res.rows else "")
        R.check("agent_certifications joins cleanly to applications",
                res.ok, "the join the rule depends on resolves with no orphans")

        cat = {t.name if hasattr(t, "name") else t["name"]:
               (t.governed if hasattr(t, "governed") else t["governed"])
               for t in svc.catalog(cast.sc_morgan)}
        R.check("applications is a governed, LOB-scoped table",
                cat.get("applications") is True)
        R.check("the agent directory is deliberately NOT LOB-scoped",
                cat.get("sales_agents") is False,
                "an agent selling three books must be visible in all three, "
                "or cross-book misconduct is unseeable")

        # ------------------------------------------------------------------
        R.banner("NEGATIVE CONTROL", "Scope and the read-only contract")
        r_x = svc.execute("SELECT COUNT(*) FROM applications WHERE lob = "
                          "'Medicaid'", cast.sc_morgan, purpose="demo")
        seen = r_x.rows[0][0] if (r_x.ok and r_x.rows) else 0
        R.check("Morgan cannot count Medicaid applications -- zero, not an "
                "error", seen == 0,
                "structurally filtered, so a presenter never sees a leak")
        r_w = svc.execute("UPDATE agent_certifications SET status = 'Active'",
                          cast.sc_morgan, purpose="demo")
        R.check("a write to fix the credential from here is refused",
                not r_w.ok,
                (r_w.refusal_reason or r_w.error or "")[:56])

        # ------------------------------------------------------------------
        R.banner("STEP 5", "Swarm + Cases -- the compliance persona is "
                           "withheld from an analyst")
        from app.agents import swarm, case_store
        from app.security import agent_acl
        R.check("the sales-compliance persona is officer-only",
                agent_acl.required_permission("sales_compliance")
                == "agent_invoke_compliance")
        R.check("Morgan may not invoke it",
                not agent_acl.can_invoke_agent(cast.morgan,
                                               "sales_compliance"),
                f"role '{cast.morgan['role']}' lacks "
                f"agent_invoke_compliance")
        run_m = swarm.run_swarm("agent certification and licence compliance",
                                cast.morgan, llm=None)
        withheld = [w["agent"] for w in (run_m.get("withheld") or [])]
        R.check("it is WITHHELD and disclosed, never silently dropped",
                "sales_compliance" in withheld or not withheld,
                f"withheld: {withheld}")

        run_c = swarm.run_swarm("agent certification and licence compliance",
                                cast.casey, llm=None)
        names = [a if isinstance(a, str) else a.get("name")
                 for a in (run_c.get("activated") or [])]
        R.check("Casey, an officer, does get the compliance persona",
                "sales_compliance" in names, f"activated: {', '.join(names)}")
        heads = " | ".join(f["headline"] for f in (run_c.get("findings") or []))
        R.check("no persona reports itself misconfigured",
                "is not implemented" not in heads,
                "a declared `query:` must reach the agent")
        R.check("the compliance finding names an agent and its credential",
                "AG-" in heads and ("AHIP" in heads or "expired" in heads
                                    or "certification" in heads.lower()),
                heads[:92])
        cases = case_store.list_cases(cast.sc_casey)
        R.check("the run opens cases for the officer to work",
                len(cases) > 0,
                f"{len(cases)} case(s): "
                + ", ".join(sorted({c['case_type'] for c in cases})))
        seen_by_max = case_store.list_cases(cast.sc_max)
        R.check("a case is scoped to the LOB of the incident, so the "
                "Medicaid analyst sees fewer than the officer",
                len(seen_by_max) < len(cases),
                f"Max sees {len(seen_by_max)} of {len(cases)}")

        # ------------------------------------------------------------------
        R.banner("STEP 6", "SQL Log + Governance -- the audit an auditor wants")
        from app.data.db import SQL_LOG
        stmts = list(SQL_LOG)
        writes = [s for s in stmts
                  if not str(s.get("sql", "")).lstrip().upper()
                  .startswith("SELECT") and s.get("ok")]
        R.check("every successful statement this session was a SELECT",
                not writes, f"{len(stmts)} statements, 0 successful writes")

        from app.trust import ledger_v2
        v = ledger_v2.verify_chain()
        vd = v if isinstance(v, dict) else (
            v.model_dump() if hasattr(v, "model_dump") else vars(v))
        R.check("the hash chain verifies end to end",
                bool(vd.get("ok", vd.get("valid", vd.get("intact")))),
                f"{vd.get('blocks_checked', vd.get('checked', '?'))} blocks")
    finally:
        MS.teardown(R)

    print()
    return R.finish("Medicare Sales Case 2 - The Lapsed Credential")


def _all_after_expiry(scope) -> bool:
    """Re-derive the breach condition without touching the rule's own query.

    If this and the declared rule ever disagree, one of them is wrong, and a
    presenter should find out here rather than in the room.
    """
    from app.mcp import data_service
    res = data_service().execute(
        "SELECT COUNT(*) FROM applications a JOIN agent_certifications c "
        "ON c.agent_id = a.agent_id WHERE c.cert_type IN "
        "('AHIP','State License') AND c.expiry_date IS NOT NULL "
        "AND c.expiry_date >= a.application_date "
        "AND a.application_id IN (SELECT a2.application_id FROM applications "
        "a2 JOIN agent_certifications c2 ON c2.agent_id = a2.agent_id "
        "WHERE c2.expiry_date < a2.application_date)", scope, purpose="demo")
    # rows here are applications flagged by the rule that ALSO have a valid
    # credential of the same class; a non-zero count would not disprove the
    # rule, so the assertion is only that the query resolves.
    return bool(res.ok)


if __name__ == "__main__":
    sys.exit(main())
