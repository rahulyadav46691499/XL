"""Every figure in Medicare_Sales_Analyst_Walkthrough.md, checked against the
live engine.

The doc is quoted at a partner demo, so the failure it has to catch is a
number drifting apart from the engine that produced it. Method: never type a
literal. Take the value the engine returns, format it the way the doc writes
it, and grep the doc for that. A typo in the doc fails; a change in the engine
fails; a formatting difference cannot produce a false alarm.

Run:
    cd oppal_stage/backend
    PYTHONPATH=. python demo/verify_analyst_walkthrough.py
"""
from __future__ import annotations

import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from _env import reset_demo_env, Reporter  # noqa: E402
reset_demo_env("verifywalk")

import _medicare as MS  # noqa: E402

R = Reporter()
AGENT = "AG-0027"
SWARM_Q = ("Why is agent AG-0027 an effectuation outlier and is commission "
           "being recovered?")

# Blockquotes and hard wraps are markdown, not content: flatten both once so
# no assertion has to know how a line happened to break.
_MD = os.path.join(os.path.dirname(__file__), "..", "..",
                   "Medicare_Sales_Analyst_Walkthrough.md")
DOC = " ".join(re.sub(r"(?m)^>\s?", "", open(_MD).read()).split())


def usd(x) -> str:
    return f"${float(x):,.2f}"


def fact(label, value, shown=None):
    """The engine says `value`; assert the doc says it too.

    `shown` is DERIVED from value (usd(value), a rank, a count) — never an
    independently typed literal, which is what makes a drift detectable.
    """
    shown = str(value) if shown is None else shown
    R.check(label, shown in DOC, f"{shown}"
            if shown in DOC else f"{shown!r} NOT in doc")


def main():
    cast = MS.setup()
    from app.analytics import rules_engine
    from app.agents import swarm, case_store
    from app.llm.base import get_provider
    from app.semantic import brain as bl
    from app.data.db import POOL, SQL_LOG

    def sql(q):
        c = POOL.acquire()
        try:
            return [tuple(r) for r in c.execute(q).fetchall()]
        finally:
            POOL.release(c)

    MS.title(R, "Medicare_Sales_Analyst_Walkthrough.md",
             "every quoted figure, against the live engine")

    # -- Step 1: Pillars -----------------------------------------------------
    R.banner("STEP 1", "Pillars — why this agent gets picked")
    breaches = [b for v in rules_engine.pillar_summary(cast.sc_morgan).values()
                if isinstance(v, dict) for b in (v.get("breaches") or [])]
    rules_per_agent: dict[str, set] = {}
    for b in breaches:
        a = (b.get("evidence") or {}).get("agent_id")
        if a:
            rules_per_agent.setdefault(a, set()).add(b["rule"])
    fact("49 breaches", len(breaches), f"**{len(breaches)} breaches across "
         f"{len({b['rule'] for b in breaches})} rules**")
    mine = [b for b in breaches
            if (b.get("evidence") or {}).get("agent_id") == AGENT]
    fact(f"{AGENT} spans 4 rules / 9 rows", len(mine),
         f"**{len(rules_per_agent[AGENT])} rules, {len(mine)} separate "
         f"breach rows**")
    R.check("every other agent appears in exactly one rule",
            {len(v) for k, v in rules_per_agent.items() if k != AGENT} == {1},
            f"{len(rules_per_agent) - 1} other agents, all single-rule")
    # The doc's table shows a sample of those, not all of them: assert the
    # rows it does print, not every agent the engine found.
    for other in re.findall(r"\| (AG-\d+) \| 1 rule \|", DOC):
        R.check(f"{other} really is single-rule",
                len(rules_per_agent.get(other, ())) == 1,
                f"{sorted(rules_per_agent.get(other, ()))}")

    by_rule: dict[str, list] = {}
    for b in mine:
        by_rule.setdefault(b["rule"], []).append(b["evidence"])
    z = by_rule["SALES-EFFECTUATION-Z"][0]
    fact("effectuation rate", z["effectuation_rate"], f"**{z['effectuation_rate']}** effectuation")
    fact("enrolment count", z["enrollments"], f"**{z['enrollments']}** enrolments")
    fact("book rate", z["book_rate"], f"**{z['book_rate']}** book rate")

    bonus = {e["channel"]: e for e in by_rule["SALES-BONUS-EXCEPTION"]}
    for ch, e in bonus.items():
        fact(f"bonus {ch}", e["overpaid_usd"],
             f"{ch} — {e['payments']} payment"
             f"{'s' if e['payments'] > 1 else ''}, **{usd(e['overpaid_usd'])}**")
    bonus_total = round(sum(e["overpaid_usd"] for e in bonus.values()), 2)
    fact("bonus total", bonus_total, f"**Total {usd(bonus_total)} across "
         f"{sum(e['payments'] for e in bonus.values())} payments**")

    rd = by_rule["CMS-RAPID-DISENROLL-RECOUP"][0]
    fact("unrecouped", rd["unrecouped_usd"],
         f"**{usd(rd['unrecouped_usd'])}** ({rd['channel']})")

    cap = {e["comm_quarter"]: e for e in by_rule["CMS-COMP-CAP-2274E"]}
    for qtr, e in cap.items():
        fact(f"cap {qtr}", e["excess_usd"], f"{qtr} **{usd(e['excess_usd'])}**")
    cap_total = round(sum(e["excess_usd"] for e in cap.values()), 2)
    fact("cap total", cap_total, f"**Total {usd(cap_total)} across "
         f"{sum(e['payments'] for e in cap.values())} payments, in four "
         f"different quarters**")
    fact("step 1 exposure", round(bonus_total + rd["unrecouped_usd"] + cap_total, 2),
         f"= {usd(bonus_total + rd['unrecouped_usd'] + cap_total)}")

    # -- Step 2: Chat --------------------------------------------------------
    R.banner("STEP 2", "Chat — who the analyst is dealing with")
    ask = MS.asker(cast.morgan)

    def ranked(question):
        _, trust, rows = ask(question)
        d = dict(rows)
        return trust, d[AGENT], list(d).index(AGENT) + 1, len(d)

    for question, form in (
            ("commission paid by agent", usd),
            ("effectuation rate by agent", str),
            ("effectuated enrollments by agent", str),
            ("member retention rate by agent", str)):
        trust, value, rank, n = ranked(question)
        R.check(f'"{question}" answers at 100% trust', trust == 100, f"{trust}%")
        fact(f"{question} — value and rank", value,
             f"**{AGENT} — {form(value).lstrip('$') if form is str else form(value)}"
             f". Rank {rank} of {n}.**")

    agent = sql(f"SELECT * FROM sales_agents WHERE agent_id='{AGENT}'")[0]
    fact("NPN", agent[2], f"NPN {agent[2]}")
    fact("agency and type", agent[4], f"**{agent[3]}**, a **{agent[4]}**")
    fact("market", agent[6], f"{agent[5]}, **{agent[6]}**, New Jersey")
    certs = sql(f"SELECT cert_type, expiry_date, status FROM "
                f"agent_certifications WHERE agent_id='{AGENT}'")
    R.check("all three credentials are current — not a licensing case",
            {c[2] for c in certs} == {"Active"} and len(certs) == 3,
            f"{len(certs)} credentials, all Active to {certs[0][1]}")
    fact("credentials current", certs[0][1],
         f"**all three Active** through {certs[0][1]}")

    channels = sql(f"""SELECT channel, COUNT(*), SUM(effectuated_flag),
        ROUND(AVG(retained_12mo_flag),4) FROM enrollments
        WHERE agent_id='{AGENT}' AND lob='Medicare Advantage' GROUP BY 1""")
    for ch, n, eff, ret in channels:
        mark = "**" if ch == "DTC" else ""
        fact(f"channel {ch}", n,
             f"| {mark}{ch}{mark} | {mark}{n}{mark} | {mark}{eff}{mark} | "
             f"{mark}{ret:.4f}{mark} |")
    spike = sql(f"""SELECT COUNT(*) FROM enrollments WHERE agent_id='{AGENT}'
        AND lob='Medicare Advantage' AND effective_date LIKE '2027-01%'""")[0][0]
    # The doc spells this one out ("he writes ten"), so tie the claim to the
    # count rather than grepping for a numeral that is not there.
    R.check("the January 2027 spike is real and the doc's word matches",
            spike == max(n for _, n in sql(f"""SELECT substr(effective_date,1,7),
                COUNT(*) FROM enrollments WHERE agent_id='{AGENT}'
                AND lob='Medicare Advantage' GROUP BY 1"""))
            and f"January 2027 he writes ten" in DOC and spike == 10,
            f"{spike} enrolments, the busiest month in the book")
    R.check("the worst cap quarter is the spike quarter",
            max(cap.items(), key=lambda kv: kv[1]["excess_usd"])[0] == "2027Q1",
            "the volume spike and the overpayment are one event")

    # -- Step 3: Context Brain ----------------------------------------------
    R.banner("STEP 3", "Context Brain — the rule she has to defend")
    rules = {r.get("rule_id"): r for r in bl.get_brain()["policy_rules"]}
    zr = rules["SALES-EFFECTUATION-Z"]
    for key in ("min_enrollments", "effectuation_floor", "z_threshold",
                "breach_action"):
        fact(f"declared {key}", zr[key], f"| `{key}` | **{zr[key]}** |")
    R.check("the rule cites CMS, not just internal policy",
            "422.2274" in zr["citation"], zr["citation"][:60])
    R.check("the remediation refuses to jump to fraud",
            "genuinely requested" in zr["remediation"],
            "confirm each application was genuinely requested")
    R.check("the companion rule cites 422.2274(e)",
            "422.2274(e)" in rules["SALES-BONUS-EXCEPTION"]["citation"],
            "no compensation on an enrolment that never took effect")

    # -- Step 4: Swarm -------------------------------------------------------
    R.banner("STEP 4", "Swarm — independent agreement she did not compute")
    run = swarm.run_swarm(SWARM_Q, cast.morgan, llm=get_provider())
    R.check("three investigating departments activate",
            {"compensation_siu", "agent_performance", "enrollment_ops"}
            <= set(run["activated"]), ", ".join(run["activated"]))
    fact("run trust", run["trust"],
         f"run trust **{run['trust']}** against a **{run['gate']}** gate")
    R.check("the run clears its own gate", run["gate_passed"],
            f"{run['trust']} >= {run['gate']}")
    heads = {f.get("agent"): f["headline"] for f in run["findings"]}
    R.check("Distribution reaches the same two numbers independently",
            f"{z['effectuation_rate']} effectuation" in heads["agent_performance"],
            "three routes, one answer")
    R.check("Finance & SIU reaches the same money independently",
            str(bonus_total) in heads["compensation_siu"], usd(bonus_total))
    R.check("Enrolment Ops answers about the channel she did not ask about",
            "Northeast" in heads["enrollment_ops"], heads["enrollment_ops"][:70])

    # -- Step 5: Cases -------------------------------------------------------
    R.banner("STEP 5", "Cases — screens become work someone owns")
    cases = {c["case_type"]: c for c in case_store.list_cases(cast.sc_morgan)}
    for ctype, c in cases.items():
        fact(f"case {ctype}", c["case_id"], c["case_id"])
        fact(f"case {ctype} value", c["estimated_impact"],
             f"**{usd(c['estimated_impact'])}**")
    before = len(cases)
    swarm.run_swarm(SWARM_Q, cast.morgan, llm=get_provider())
    R.check("a second identical run de-duplicates instead of piling up",
            len(case_store.list_cases(cast.sc_morgan)) == before,
            f"{before} cases before, {before} after")

    # -- Step 6: Simulator ---------------------------------------------------
    R.banner("STEP 6", "Simulator — what the recovery actually nets")
    rec = bl.get_brain()["simulation"]["commission_recovery_net"]
    rate, cost = float(rec["dispute_rate"]), float(rec["recovery_cost"])
    fact("dispute rate and recovery cost", rate,
         f"dispute rate **{rate}** · recovery cost **{usd(cost).rstrip('0').rstrip('.')}**")
    gross = float(cases["CompensationCase"]["estimated_impact"])
    net = round(gross * (1 - rate) - cost, 2)
    fact("net recovery", net, f"| **Net recovery** | **{usd(net)}** |")
    fact("dispute leg", round(gross * rate, 2), f"− {usd(gross * rate)}")
    R.check("the doc does not oversell the headline",
            f"{round(net / gross * 100)}% of the headline" in DOC,
            f"{usd(net)} is {round(net / gross * 100)}% of {usd(gross)}")

    # -- Step 7: Actions -----------------------------------------------------
    R.banner("STEP 7", "Actions — she proposes and is refused, by role")
    from app.actions import engine as AE
    com = cases["CompensationCase"]
    act = AE.propose(
        case_id=com["case_id"], action_type="commission_recovery",
        target_object=AGENT, lob="Medicare Advantage",
        summary="Recover compensation paid on enrolments that never "
                "effectuated, under 42 CFR 422.2274(e)",
        estimated_financial_impact=gross, regulatory_severity="high",
        trust_score=float(com["trust_score"]),
        fields={"case_id": com["case_id"]}, proposer_user_id="u-ma")
    R.check("the proposal is dual control", act.control_mode.value == "dual",
            act.state.value)
    threshold = float(rules["ACT-DUAL-CONTROL"]["financial_impact_threshold"])
    R.check("dual control is NOT earned by the amount", gross < threshold,
            f"{usd(gross)} is below {usd(threshold)} — the action type is why")

    def refused(user, scope):
        try:
            AE.approve(act.action_id, user, scope)
            return ""
        except Exception as e:                     # noqa: BLE001 - message IS the check
            return str(e)

    msg = refused(cast.morgan, cast.sc_morgan)
    R.check("the analyst cannot approve ANY write-back, not just her own",
            "not authorized to approve" in msg, msg[:64])
    R.check("the refusal reason is quoted in the doc verbatim", msg in DOC, msg[:64])
    R.check("Casey signs first",
            AE.approve(act.action_id, cast.casey, cast.sc_casey).state.value
            == "PENDING_SECOND_APPROVAL", "one signature is not enough")
    sod = refused(cast.casey, cast.sc_casey)
    R.check("the same officer cannot sign twice",
            "separation of duties" in sod, sod[:64])
    R.check("Dana signs second",
            AE.approve(act.action_id, cast.dana, cast.sc_dana).state.value
            == "APPROVED", "two distinct officers")
    AE.execute(act.action_id, cast.dana, cast.sc_dana)
    R.check("execution clears the trust gate",
            AE.get(act.action_id, cast.sc_casey).state.value == "EXECUTED",
            f"trust {com['trust_score']} >= gate "
            f"{AE.rules()['execution_trust_gate']}")

    # -- Step 8: receipts, and the scope caveat ------------------------------
    R.banner("STEP 8", "Receipts — and the number she cannot see")
    R.check("nothing the analysis ran could have changed a number",
            not [s for s in SQL_LOG if s.get("ok") and not
                 str(s.get("sql", "")).lstrip().upper().startswith("SELECT")],
            f"{len(SQL_LOG)} statements, all SELECT")
    from app.trust import ledger_v2
    chain = ledger_v2.verify_chain()
    R.check("the approval chain verifies end to end",
            bool((chain if isinstance(chain, dict) else vars(chain)).get("ok")),
            "approvals cannot be rewritten after the fact")
    full = sql(f"""SELECT ROUND(SUM(c.commission_paid + c.bonus_paid +
        c.override_paid),2), COUNT(*), COUNT(DISTINCT c.lob)
        FROM agent_commissions c JOIN enrollments e
        ON e.enrollment_id = c.enrollment_id WHERE e.effectuated_flag = 0
        AND (c.commission_paid + c.bonus_paid + c.override_paid) > 0
        AND c.agent_id='{AGENT}'""")[0]
    fact("officer-scope total", full[0],
         f"**{usd(full[0])} across {full[1]} payments**")
    R.check("the officer's number really is bigger than the analyst's",
            full[0] > gross and full[2] == 3,
            f"{usd(gross)} in MA vs {usd(full[0])} across {full[2]} books")

    MS.teardown(R)


if __name__ == "__main__":
    main()
    sys.exit(R.finish("Analyst walkthrough"))
