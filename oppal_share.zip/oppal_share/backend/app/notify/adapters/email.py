"""SMTP email notifier — driver-guarded (stdlib smtplib/email only)."""
from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage

from .base import AdapterUnavailable, NotifierAdapter


class EmailAdapter(NotifierAdapter):
    channel = "email"

    def _settings(self) -> dict:
        return {
            "host": os.environ.get("OPPAL_NOTIFY_SMTP_HOST")
            or self.config.get("smtp_host", ""),
            "port": int(os.environ.get("OPPAL_NOTIFY_SMTP_PORT")
                       or self.config.get("smtp_port", 587) or 587),
            "user": os.environ.get("OPPAL_NOTIFY_SMTP_USER")
            or self.config.get("smtp_user", ""),
            "password": os.environ.get("OPPAL_NOTIFY_SMTP_PASSWORD")
            or self.config.get("smtp_password", ""),
            "from_addr": os.environ.get("OPPAL_NOTIFY_FROM")
            or self.config.get("from_addr", ""),
            "to_addr": os.environ.get("OPPAL_NOTIFY_TO")
            or self.config.get("to_addr", ""),
        }

    def _send(self, event) -> dict:
        s = self._settings()
        if not (s["host"] and s["from_addr"] and s["to_addr"]):
            raise AdapterUnavailable("SMTP host/from/to not configured")
        msg = EmailMessage()
        msg["Subject"] = f"[OpPal] {event.severity.upper()} — {event.event}"
        msg["From"] = s["from_addr"]
        msg["To"] = s["to_addr"]
        body = event.summary
        if event.action_id:
            body += f"\naction: {event.action_id}"
        if event.lob:
            body += f"\nlob: {event.lob}"
        msg.set_content(body)
        with smtplib.SMTP(s["host"], s["port"], timeout=10) as smtp:
            smtp.starttls()
            if s["user"]:
                smtp.login(s["user"], s["password"])
            smtp.send_message(msg)
        return {"to": s["to_addr"]}

    def healthcheck(self) -> dict:
        s = self._settings()
        available = bool(s["host"] and s["from_addr"] and s["to_addr"])
        return {"name": self.channel, "available": available,
               "detail": "SMTP configured" if available
               else "SMTP host/from/to not set"}


__all__ = ["EmailAdapter"]
