"""NotifierAdapter — the notification-channel abstraction (Phase 6),
mirroring ``app/actions/base.py``'s guarded pattern:

  * ``send()`` is FINAL (an ``__init_subclass__`` guard resolves it across
    the whole MRO — same lesson as the action-adapter and MCP-connector
    bases: a mixin cannot slip past a ``__dict__``-only check).
  * An unconfigured channel raises :class:`AdapterUnavailable`; the base
    turns that into a clean, LOGGED no-op — never an exception the caller has
    to handle, and never something that blocks the action/simulation/ledger
    workflow that triggered the notification (G2).
  * The event payload reaching ``_send`` is ALREADY PHI-scrubbed by
    ``NotificationEvent`` upstream; adapters never see a raw payload (G3).

Adapters implement only ``_send`` and ``healthcheck``.
"""
from __future__ import annotations

import abc
import logging

log = logging.getLogger("oppal.notify")
if not log.handlers:
    log.addHandler(logging.NullHandler())


class AdapterUnavailable(Exception):
    """Raised when the channel's configuration (URL/SMTP host/etc.) is
    absent — never a hard failure, always degrades to a no-op."""


class NotifierAdapter(abc.ABC):
    channel: str = "abstract"

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if cls.send is not NotifierAdapter.send:
            raise TypeError(
                f"{cls.__name__} (or a base/mixin) overrides send(); this is "
                "forbidden. Implement _send(). Degrade-to-no-op behavior "
                "lives in NotifierAdapter.send() by design.")

    def __init__(self, name: str, config: dict | None = None):
        self.name = name
        self.config = config or {}

    @abc.abstractmethod
    def _send(self, event) -> dict:
        """Transmit the (already PHI-scrubbed) NotificationEvent. Return a
        receipt dict. Raise AdapterUnavailable if not configured."""

    @abc.abstractmethod
    def healthcheck(self) -> dict:
        ...

    def send(self, event) -> dict:
        try:
            receipt = self._send(event)
            log.info("notify.send ok channel=%s event=%s", self.channel,
                     event.event)
            return {"ok": True, "channel": self.channel, **(receipt or {})}
        except AdapterUnavailable as e:
            log.info("notify.send skipped (unconfigured) channel=%s: %s",
                     self.channel, e)
            return {"ok": False, "skipped": True, "channel": self.channel,
                   "reason": str(e)}
        except Exception as e:                       # degrade, never raise
            log.warning("notify.send failed channel=%s: %s", self.channel, e)
            return {"ok": False, "skipped": False, "channel": self.channel,
                   "reason": f"{type(e).__name__}: {e}"}


__all__ = ["NotifierAdapter", "AdapterUnavailable"]
