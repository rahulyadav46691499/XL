"""Slack webhook notifier — driver-guarded (no extra dependency; stdlib
urllib, same pattern as ``app/actions/adapters/webhook.py``)."""
from __future__ import annotations

import json
import os
import urllib.request

from .base import AdapterUnavailable, NotifierAdapter

_SEVERITY_EMOJI = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}


class SlackAdapter(NotifierAdapter):
    channel = "slack"

    def _webhook_url(self) -> str:
        return (os.environ.get("OPPAL_NOTIFY_SLACK_WEBHOOK")
               or self.config.get("webhook_url", ""))

    def _send(self, event) -> dict:
        url = self._webhook_url()
        if not url:
            raise AdapterUnavailable("no Slack webhook_url configured")
        text = (f"{_SEVERITY_EMOJI.get(event.severity, '')} "
               f"*OpPal — {event.event}*\n{event.summary}"
               + (f"\naction: `{event.action_id}`" if event.action_id
                  else "")
               + (f"\nlob: `{event.lob}`" if event.lob else ""))
        body = json.dumps({"text": text}).encode()
        req = urllib.request.Request(
            url, data=body, headers={"Content-Type": "application/json"},
            method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            return {"status": resp.status}

    def healthcheck(self) -> dict:
        available = bool(self._webhook_url())
        return {"name": self.channel, "available": available,
               "detail": "Slack webhook configured" if available
               else "OPPAL_NOTIFY_SLACK_WEBHOOK not set"}


__all__ = ["SlackAdapter"]
