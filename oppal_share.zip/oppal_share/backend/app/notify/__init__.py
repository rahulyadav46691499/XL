"""Notification Event Bus (Phase 6 amendment, Phase 4 handoff Limitation 3).

Public surface: ``app.notify.bus.emit(NotificationEvent)``.
"""
from .bus import emit, configured_channels, test_channel

__all__ = ["emit", "configured_channels", "test_channel"]
