"""Notification Event Bus (Phase 6 amendment, Limitation 3).

``emit(event)`` fans an already-validated ``NotificationEvent`` out to every
configured channel. Unconfigured channels degrade to a logged no-op (G2);
nothing here ever raises back to the caller — a notification failure must
never block the action/simulation/ledger workflow that triggered it. Every
emission is itself written to the ledger (``kind="system"``,
``event="notified"``) so the notification itself is tamper-evident.
"""
from __future__ import annotations

import logging

from ..schemas.notify import NotificationEvent
from .adapters.email import EmailAdapter
from .adapters.slack import SlackAdapter

log = logging.getLogger("oppal.notify.bus")

_ADAPTERS = {"slack": SlackAdapter, "email": EmailAdapter}


def _channel_config(name: str) -> dict:
    from .. import config
    return (config.load().get("notify", {}) or {}).get(name, {})


def _scrub_summary(event: NotificationEvent) -> NotificationEvent:
    """Defense in depth: the summary SHOULD already be PHI-scrubbed by the
    caller (NotificationEvent's docstring contract), but re-scrub here too —
    an adapter must never be the first line of defense against a leak."""
    try:
        from ..privacy.phi_guard import PHIGuard
        guard = PHIGuard(enabled=True)
        data = event.model_dump()
        data["summary"] = guard.scrub_value(data["summary"])
        return NotificationEvent(**data)
    except Exception:                                     # never block emit
        return event


def emit(event: NotificationEvent) -> dict:
    event = _scrub_summary(event)
    results = {}
    for name, cls in _ADAPTERS.items():
        adapter = cls(name, _channel_config(name))
        results[name] = adapter.send(event)

    try:
        from ..trust import ledger_v2
        ledger_v2.append(
            "system", "notified", "system",
            {"notification_event": event.event, "severity": event.severity,
             "action_id": event.action_id, "lob": event.lob,
             "summary": event.summary, "channel_results": results})
    except Exception:                                     # pragma: no cover
        log.debug("failed to ledger the notification emission",
                 exc_info=True)
    return results


def configured_channels() -> dict:
    return {name: cls(name, _channel_config(name)).healthcheck()
           for name, cls in _ADAPTERS.items()}


def test_channel(name: str) -> dict:
    cls = _ADAPTERS.get(name)
    if not cls:
        return {"ok": False, "detail": f"unknown channel '{name}'"}
    adapter = cls(name, _channel_config(name))
    receipt = adapter.send(NotificationEvent(
        event="pending_second_approval", summary="OpPal test notification —"
        " if you can read this, the channel is wired up correctly."))
    if receipt.get("skipped"):
        return {"ok": False, "detail": receipt.get("reason", "unconfigured")}
    return {"ok": bool(receipt.get("ok")),
           "detail": receipt.get("reason", "sent")}


__all__ = ["emit", "configured_channels", "test_channel"]
