"""Agents and MCP tools as securable objects (Upgrade 2).

WHAT THIS CLOSES
----------------
Before this module, OpPal governed DATA access precisely — every query carried
a line-of-business predicate pushed down by the MCP scope enforcer — but it did
not govern COMPUTE access at all. ``swarm.select_agents()`` and
``swarm.run_swarm()`` checked that the caller had *some* authorized LOB scope
and then activated whichever of the ten departmental personas the Sentry
triage picked. Any authenticated user who could reach the orchestrator could
cause any agent to run, and nothing recorded which agent ran for whom.

Databricks' Unity AI Gateway makes agents, MCP servers and model endpoints
securable objects you grant like a table. This module is the equivalent: an
agent is a governed object, invoking it requires a named permission, and every
invocation and every refusal is written to the audit ledger.

TWO ENFORCEMENT SEMANTICS, DELIBERATELY DIFFERENT
-------------------------------------------------
Triage relevance and authorization are separate concerns, so they get separate
treatment:

  * DIRECT invocation of an agent the caller may not use is REFUSED
    (``AgentAccessDenied``). The caller expressed explicit intent; silently
    doing nothing would be dishonest.

  * SENTRY AUTO-SELECTION of an agent the caller may not use is FILTERED, and
    the withholding is disclosed in the run result and written to the ledger.
    Sentry picked that persona from ambient relevance, not from the user's
    request — refusing the entire investigation because one specialist is out
    of reach would be least-useful, not least-privilege. The user is told
    exactly which specialists were withheld and why.

``select_agents()`` itself is intentionally left pure: it answers "what is
relevant to this question", takes no user, and is unchanged. Authorization is
applied on the invocation path. Mixing the two would make relevance
untestable in isolation and would tempt callers into treating a filtered
triage result as a complete one.

THE CODE FLOOR, AND WHY IT IS NOT IN THE BRAIN
----------------------------------------------
``AGENT_PERMISSIONS`` and ``TOOL_PERMISSIONS`` are pinned in code, for the same
reason ``brain_governance.PROTECTED_KEYS`` is: ``agents.md`` is editable
markdown, so a mapping stored there could be edited to lower an agent's
required permission, and the control would defeat itself in one save.

``agents.md`` may still declare ``required_permission`` per persona, but the
overlay may only TIGHTEN — the declared permission is honoured solely when the
set of roles holding it is a subset of the roles holding the code-floor
permission. A declaration that would widen access is ignored and reported.
This is the same additive-overlay rule recommended for pluggable service
policies: configuration may add restriction, never remove it.

DENY BY DEFAULT
---------------
An agent or tool not present in the maps below resolves to the most
restrictive permission, not the least. A customer who registers a custom agent
and forgets to declare its permission gets a locked-down agent rather than an
open one.
"""
from __future__ import annotations

import logging

log = logging.getLogger("oppal.agent_acl")

# ---------------------------------------------------------------------------
# THE CODE FLOOR — do not move to markdown. See module docstring.
#
# Rationale per tier:
#   triage        Sentry decides which specialists are relevant. Every
#                 authenticated analyst needs it or no investigation can start.
#   analytics     Read-only departmental analysis. Data exposure is already
#                 bounded by the caller's LOB scope, so the agent adds no
#                 reach beyond what the user could query directly.
#   fwa           Fraud/SIU analysis. Open to analysts by default because
#                 first-line FWA review is an analyst function (Business Case 2
#                 is exactly that workflow); tighten per your SIU policy if
#                 investigations are confidential to the SIU team.
#   prescriptive  Converts findings into PROPOSED actions. Open to analysts on
#                 purpose: under maker-checker the analyst proposes and two
#                 officers approve. Restricting proposal to officers would
#                 collapse the separation of duties, not strengthen it.
#   compliance    Produces CMS/state audit-readiness posture (CDAG/ODAG
#                 universes, 42 CFR timeliness, MLR floor). Restricted to
#                 compliance officers: a regulatory audit-posture assessment is
#                 a compliance-department artifact, and one generated casually
#                 by an analyst is discoverable material.
AGENT_PERMISSIONS = {
    "sentry":              "agent_invoke_triage",
    "medical_economics":   "agent_invoke_analytics",
    "pbm_forensics":       "agent_invoke_analytics",
    "clinical_um":         "agent_invoke_analytics",
    "network":             "agent_invoke_analytics",
    "quality_hedis":       "agent_invoke_analytics",
    "risk_hcc":            "agent_invoke_analytics",
    "fwa_siu":             "agent_invoke_fwa",
    "compliance":          "agent_invoke_compliance",
    "prescriptive_action": "agent_invoke_prescriptive",
}

# MCP / framework tools as securable objects. This is not redundant with the
# agent check: agents.md is editable, so a persona's `tools:` allow-list can be
# widened. Gating the tool itself means adding propose_action to an analytics
# persona does not silently hand that persona a write-adjacent capability.
TOOL_PERMISSIONS = {
    "anomaly_scan":              "tool_invoke_read",
    "metric_trend":              "tool_invoke_read",
    "root_cause_additive":       "tool_invoke_read",
    "root_cause_average":        "tool_invoke_read",
    "pbm_reject_decomposition":  "tool_invoke_read",
    "network_scan":              "tool_invoke_read",
    "pa_triage":                 "tool_invoke_read",
    "quality_scan":              "tool_invoke_read",
    "risk_scan":                 "tool_invoke_read",
    "fwa_scan":                  "tool_invoke_read",
    "determination_timeliness":  "tool_invoke_compliance",
    "policy_check":              "tool_invoke_compliance",
    "propose_action":            "tool_invoke_action",
}

# Most restrictive permission in each family — used for anything unmapped.
DEFAULT_AGENT_PERMISSION = "agent_invoke_compliance"
DEFAULT_TOOL_PERMISSION = "tool_invoke_compliance"


class AgentAccessDenied(Exception):
    """Raised when a caller directly invokes an agent or tool they may not."""


# ---------------------------------------------------------------------------
def _roles_for(permission: str) -> set:
    from .auth import PERMISSIONS
    return set(PERMISSIONS.get(permission, []))


def _overlay_permission(agent_id: str) -> str | None:
    """A `required_permission` declared for this persona in agents.md, if any."""
    try:
        from ..semantic.brain import get_brain
        persona = (get_brain().get("agents", {}) or {}).get(agent_id) or {}
    except Exception:                                    # pragma: no cover
        return None
    value = persona.get("required_permission")
    if not value:
        return None
    return " ".join(str(value).split()).lower() or None


def required_permission(agent_id: str) -> str:
    """Resolve the permission needed to invoke `agent_id`.

    For an agent WITH a code floor, the floor applies and an `agents.md`
    overlay is honoured only if it is strictly no wider (roles(overlay) is a
    subset of roles(floor)). An attempt to widen is ignored and logged —
    configuration may tighten a control, never loosen it. That property is
    what the ACL exists for and it is unchanged.

    For an agent the code has NEVER HEARD OF, there is no floor to tighten
    from, and treating the most-restrictive default as an immovable floor made
    a second domain impossible rather than merely careful: every new persona
    resolved to compliance-officer-only and could never be granted to an
    analyst, because widening is forbidden. The persona would appear in the
    roster and be denied to everyone who needed it.

    So for an unpinned agent the Brain's declaration is authoritative, and the
    restrictive default applies only when the Brain declares nothing. This is
    not a hole: agents.md is writable only by `brain_write` holders (compliance
    officers), edits to it are ledgered, and the declared permission must be a
    real permission that grants a non-empty role set. A compliance officer
    declaring the required permission for a new department's agent is a
    governance act by an authorised person — whereas widening one of the
    pinned payer agents remains impossible, for anyone, including them.
    """
    pinned = agent_id in AGENT_PERMISSIONS
    floor = AGENT_PERMISSIONS.get(agent_id, DEFAULT_AGENT_PERMISSION)
    overlay = _overlay_permission(agent_id)
    if not overlay or overlay == floor:
        return floor
    if not pinned:
        # Unknown permission names must not silently become "allow nobody",
        # which would look identical to a bug in the agent itself.
        if not _roles_for(overlay):
            log.warning("agents.md declares required_permission '%s' for "
                        "unpinned agent '%s', but no role holds it; falling "
                        "back to the restrictive default '%s'",
                        overlay, agent_id, DEFAULT_AGENT_PERMISSION)
            return DEFAULT_AGENT_PERMISSION
        if _roles_for(overlay) > _roles_for(floor):
            log.info("agent '%s' is not pinned in code; honouring the "
                     "Brain-declared permission '%s' (default would have "
                     "been '%s')", agent_id, overlay, floor)
        return overlay
    if _roles_for(overlay) <= _roles_for(floor):
        return overlay
    log.warning("agents.md tried to WIDEN access for agent '%s' "
                "(%s -> %s); ignoring the overlay and keeping the code floor",
                agent_id, floor, overlay)
    return floor


def required_tool_permission(tool_name: str) -> str:
    return TOOL_PERMISSIONS.get(tool_name, DEFAULT_TOOL_PERMISSION)


# ---------------------------------------------------------------------------
def can_invoke_agent(user: dict, agent_id: str) -> bool:
    from .auth import authorize
    return bool(authorize(user or {}, required_permission(agent_id)))


def can_invoke_tool(user: dict, tool_name: str) -> bool:
    from .auth import authorize
    return bool(authorize(user or {}, required_tool_permission(tool_name)))


def assert_can_invoke_agent(user: dict, agent_id: str) -> None:
    """Explicit-intent path: refuse rather than silently skip."""
    if not can_invoke_agent(user, agent_id):
        perm = required_permission(agent_id)
        _ledger_denial(user, "agent", agent_id, perm)
        raise AgentAccessDenied(
            f"role '{(user or {}).get('role')}' is not authorized to invoke "
            f"agent '{agent_id}' (requires '{perm}')")


def assert_can_invoke_tool(user: dict, tool_name: str) -> None:
    if not can_invoke_tool(user, tool_name):
        perm = required_tool_permission(tool_name)
        _ledger_denial(user, "tool", tool_name, perm)
        raise AgentAccessDenied(
            f"role '{(user or {}).get('role')}' is not authorized to invoke "
            f"tool '{tool_name}' (requires '{perm}')")


def partition(user: dict, personas: list) -> tuple:
    """Split Sentry's selection into (authorized, withheld).

    `personas` are persona dicts as returned by swarm.select_agents(). The
    withheld entries carry the reason so the run result can disclose them
    instead of quietly returning a thinner investigation.
    """
    authorized, withheld = [], []
    for p in personas or []:
        name = p.get("name") or ""
        if can_invoke_agent(user, name):
            authorized.append(p)
        else:
            withheld.append({
                "agent": name,
                "department": p.get("department"),
                "required_permission": required_permission(name),
                "reason": f"role '{(user or {}).get('role')}' lacks "
                          f"'{required_permission(name)}'",
            })
    return authorized, withheld


# ---------------------------------------------------------------------------
def acl_matrix() -> dict:
    """The full grant matrix, for the Governance tab.

    "You grant access to an agent the same way you grant access to a table"
    is only a real claim if an auditor can SEE the grants.
    """
    agents = {}
    for agent_id in sorted(AGENT_PERMISSIONS):
        perm = required_permission(agent_id)
        agents[agent_id] = {
            "required_permission": perm,
            "granted_to_roles": sorted(_roles_for(perm)),
            "code_floor": AGENT_PERMISSIONS[agent_id],
            "overlay_applied": perm != AGENT_PERMISSIONS[agent_id],
        }
    tools = {}
    for tool in sorted(TOOL_PERMISSIONS):
        perm = required_tool_permission(tool)
        tools[tool] = {"required_permission": perm,
                       "granted_to_roles": sorted(_roles_for(perm))}
    return {"agents": agents, "tools": tools,
            "default_agent_permission": DEFAULT_AGENT_PERMISSION,
            "default_tool_permission": DEFAULT_TOOL_PERMISSION,
            "policy": "deny by default; agents.md may tighten, never widen"}


# ---------------------------------------------------------------------------
def _ledger(event: str, actor: str, payload: dict) -> None:
    try:
        from ..trust import ledger_v2
        ledger_v2.append("agent_invoke", event, actor or "system", payload)
    except Exception:                                    # pragma: no cover
        log.debug("agent_acl ledger write failed", exc_info=True)


def _ledger_denial(user: dict, kind: str, name: str, perm: str) -> None:
    _ledger(f"{kind}_invocation_denied", (user or {}).get("user_id") or "", {
        "object_type": kind, "object": name, "required_permission": perm,
        "role": (user or {}).get("role"), "decision": "denied"})


def record_run(user: dict, question: str, invoked: list,
               withheld: list) -> None:
    """One ledger block per swarm run: who ran which agents, and which
    relevant agents were withheld from them."""
    _ledger("swarm_agents_invoked", (user or {}).get("user_id") or "", {
        "role": (user or {}).get("role"),
        "invoked": sorted(invoked),
        "withheld": sorted(w["agent"] for w in withheld),
        "withheld_detail": withheld,
        "decision": "partial" if withheld else "allowed",
    })
