"""Semantic caching for frequent analytical pulls (e.g. daily MLR).

Keys are SEMANTIC, not literal: the normalized bag of grounded terms +
intent + filters + LOB scope + cohort — so "How's our MLR trending?"
and "show medical loss ratio trend" hit the same entry, skipping the
full agent pipeline (and any LLM calls) entirely.

Backend: Redis when REDIS_URL is set (enterprise deploy), otherwise a
thread-safe in-process TTL store. Swap-in is transparent.
"""
import hashlib
import json
import os
import threading
import time

def _ttl():
    return int(os.environ.get("OPPAL_CACHE_TTL", "900"))   # 15 min default

TTL_SECONDS = _ttl()

_redis_client = None
_redis_url_used = None


def _redis():
    """Lazily (re)connect when Settings changes REDIS_URL."""
    global _redis_client, _redis_url_used
    url = os.environ.get("REDIS_URL", "")
    if url != _redis_url_used:
        _redis_url_used = url
        _redis_client = None
        if url:
            try:
                import redis as redis_lib
                _redis_client = redis_lib.Redis.from_url(
                    url, socket_connect_timeout=2)
                _redis_client.ping()
            except Exception:
                _redis_client = None    # fall back to in-process
    return _redis_client


class SemanticCache:
    def __init__(self):
        self._store: dict[str, tuple[float, str]] = {}
        self._lock = threading.Lock()
        self.hits = 0
        self.misses = 0

    @staticmethod
    def _brain_version() -> str:
        """Fingerprint of the semantic layer the answer was scored against.

        Belt AND braces. Callers that mutate the Brain are supposed to call
        invalidate_all(), and mostly do — but /api/brain/activate reloaded the
        Brain for a long time without doing so, and any future reload path can
        forget the same way. Because the trust score is computed FROM the Brain
        (lineage certainty depends on whether a metric is certified) and then
        cached alongside the answer, a missed invalidation does not just serve
        a stale number — it serves a stale GOVERNANCE VERDICT.

        Folding the fingerprint into the key makes that structurally
        impossible: change any Brain file and every prior key is unreachable,
        whether or not anyone remembered to invalidate.
        """
        try:
            from ..trust.provenance import brain_fingerprint
            return str((brain_fingerprint() or {}).get("brain_version", ""))
        except Exception:
            # No fingerprint available -> fall back to a constant. The cache
            # still works; it just loses the automatic-invalidation property.
            return ""

    @staticmethod
    def key(grounding: dict, intent: dict, allowed_lobs, cohort_id) -> str:
        sig = {
            "terms": sorted(grounding.get("matched_terms", [])),
            "metric": intent.get("metric"),
            "intent": intent.get("intent"),
            "group_by": intent.get("group_by"),
            "filters": dict(sorted((intent.get("filters") or {}).items())),
            "lobs": sorted(allowed_lobs or []),
            "cohort": cohort_id or "",
            "brain": SemanticCache._brain_version(),
        }
        return "bi:" + hashlib.sha256(
            json.dumps(sig, sort_keys=True).encode()).hexdigest()

    def get(self, k: str):
        r = _redis()
        if r:
            v = r.get(k)
            if v is not None:
                self.hits += 1
                return json.loads(v)
            self.misses += 1
            return None
        with self._lock:
            entry = self._store.get(k)
            if entry and time.time() - entry[0] < _ttl():
                self.hits += 1
                return json.loads(entry[1])
            if entry:
                del self._store[k]
        self.misses += 1
        return None

    def put(self, k: str, value: dict):
        payload = json.dumps(value, default=str)
        r = _redis()
        if r:
            r.setex(k, _ttl(), payload)
            return
        with self._lock:
            if len(self._store) > 500:      # bounded
                oldest = min(self._store, key=lambda x: self._store[x][0])
                del self._store[oldest]
            self._store[k] = (time.time(), payload)

    def invalidate_all(self):
        with self._lock:
            self._store.clear()
        r = _redis()
        if r:
            for k in r.scan_iter("bi:*"):
                r.delete(k)

    def stats(self) -> dict:
        return {"backend": "redis" if _redis() else "in-process",
                "entries": len(self._store), "hits": self.hits,
                "misses": self.misses, "ttl_seconds": _ttl()}


CACHE = SemanticCache()
