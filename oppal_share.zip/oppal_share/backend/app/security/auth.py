"""OpPal authentication & authorization core (framework-free —
importable and testable without FastAPI).

Enterprise hardening vs the Conversational AI POC:
  * DENY BY DEFAULT — no X-User-Id header, no fallback identity
  * Signed bearer tokens (HMAC-SHA256, exp claim, constant-time verify)
  * Passwords stored as salted PBKDF2 hashes in the users table
  * Permission map: action -> allowed roles (checked server-side on
    every mutating endpoint; UI role-gating is cosmetic only)
  * Failed logins & 403s are audit-ledger events
"""
import base64
import hashlib
import hmac
import json
import os
import time

SECRET = os.environ.get("OPPAL_AUTH_SECRET", "")
if not SECRET:
    # generated per install; persisted so restarts keep sessions
    _secret_file = os.path.join(os.path.dirname(__file__), "..", "data",
                                ".auth_secret")
    if os.path.exists(_secret_file):
        SECRET = open(_secret_file).read().strip()
    else:
        SECRET = base64.urlsafe_b64encode(os.urandom(32)).decode()
        os.makedirs(os.path.dirname(_secret_file), exist_ok=True)
        with open(_secret_file, "w") as f:
            f.write(SECRET)

TOKEN_TTL_SECONDS = int(os.environ.get("OPPAL_TOKEN_TTL", "28800"))  # 8h

# action -> roles allowed (deny anything not listed to non-listed roles)
PERMISSIONS = {
    "ask": ["compliance_officer", "ma_analyst", "medicaid_analyst",
            "commercial_analyst"],
    "brain_write": ["compliance_officer"],
    "brain_rollback": ["compliance_officer"],
    # Governance-of-governance: signing off an edit to the control keys that
    # decide whether an action needs dual control. Two DISTINCT holders of
    # this permission are required per edit (see semantic/brain_governance.py).
    "brain_policy_approve": ["compliance_officer"],
    "data_import": ["compliance_officer", "ma_analyst",
                    "medicaid_analyst", "commercial_analyst"],
    "impute": ["compliance_officer"],
    "settings_write": ["compliance_officer"],
    "audit_read": ["compliance_officer"],
    "review_resolve": ["compliance_officer"],
    "action_approve": ["compliance_officer"],   # Phase 4 expands per ontology
    # Phase 5/6 — Actuarial Simulator, Workspace, Ledger, FinOps, Compensation
    "simulate": ["compliance_officer", "ma_analyst", "medicaid_analyst",
                "commercial_analyst"],
    "workspace_write": ["compliance_officer", "ma_analyst",
                        "medicaid_analyst", "commercial_analyst"],
    "ledger_export": ["compliance_officer"],
    "action_compensate": ["compliance_officer"],
    # ---- Upgrade 2: agents and MCP tools as securable objects -------------
    # The agent->permission mapping is pinned in security/agent_acl.py (a
    # Brain-editable mapping could lower its own requirement). These grants
    # are the role side of that matrix.
    "agent_invoke_triage": ["compliance_officer", "ma_analyst",
                            "medicaid_analyst", "commercial_analyst"],
    "agent_invoke_analytics": ["compliance_officer", "ma_analyst",
                               "medicaid_analyst", "commercial_analyst"],
    "agent_invoke_fwa": ["compliance_officer", "ma_analyst",
                         "medicaid_analyst", "commercial_analyst"],
    # analysts PROPOSE, officers APPROVE — restricting proposal to officers
    # would collapse maker-checker rather than strengthen it
    "agent_invoke_prescriptive": ["compliance_officer", "ma_analyst",
                                  "medicaid_analyst", "commercial_analyst"],
    # regulatory audit-posture generation is a compliance-department function
    "agent_invoke_compliance": ["compliance_officer"],
    "tool_invoke_read": ["compliance_officer", "ma_analyst",
                         "medicaid_analyst", "commercial_analyst"],
    "tool_invoke_action": ["compliance_officer", "ma_analyst",
                           "medicaid_analyst", "commercial_analyst"],
    "tool_invoke_compliance": ["compliance_officer"],
}


# ---------- passwords -------------------------------------------------------
def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120_000)
    return base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_b64, dk_b64 = stored.split("$", 1)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(dk_b64)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120_000)
        return hmac.compare_digest(dk, expected)
    except Exception:
        return False


# ---------- tokens -----------------------------------------------------------
def _sign(payload_b64: str) -> str:
    return base64.urlsafe_b64encode(
        hmac.new(SECRET.encode(), payload_b64.encode(),
                 hashlib.sha256).digest()).decode().rstrip("=")


def issue_token(user_id: str, role: str) -> str:
    payload = {"sub": user_id, "role": role,
               "exp": int(time.time()) + TOKEN_TTL_SECONDS,
               "iat": int(time.time())}
    p64 = base64.urlsafe_b64encode(
        json.dumps(payload).encode()).decode().rstrip("=")
    return f"{p64}.{_sign(p64)}"


def verify_token(token: str) -> dict | None:
    """Returns payload dict or None. Constant-time signature check."""
    try:
        p64, sig = token.split(".", 1)
        if not hmac.compare_digest(sig, _sign(p64)):
            return None
        pad = "=" * (-len(p64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(p64 + pad))
        if payload.get("exp", 0) < time.time():
            return None
        return payload
    except Exception:
        return None


# Every role name the permission map knows about. Derived from the map rather
# than typed again, so the two cannot drift apart.
_KNOWN_ROLES = {r for roles in PERMISSIONS.values() for r in roles}


# ---------- authorization ----------------------------------------------------
# PERMISSIONS above enumerates payer role names. A pharma or banking
# deployment needs its own vocabulary — Quality Lead, Finance Controller —
# and under the old lookup such a role failed EVERY action, including "ask",
# because deny-by-default plus an unlisted name means no access at all.
#
# Rather than loosen the map or duplicate it per domain, a domain may declare
# ROLE ALIASES in governance.md:
#
#     ## Role Aliases
#     - quality_lead: compliance_officer
#     - finance_controller: compliance_officer
#     - logistics_analyst: ma_analyst
#
# An alias says "this domain's role has the capability class of that known
# role". The permission map itself is untouched, deny-by-default is untouched,
# and an alias can only ever point AT an existing capability class — it cannot
# invent a permission or grant something no known role holds. governance.md is
# writable only by brain_write holders and every edit is ledgered, so
# declaring an alias is a governance act by an authorised person.
def _role_aliases() -> dict:
    try:
        from ..semantic.brain import get_brain
        gov = get_brain().get("governance") or {}
        aliases = gov.get("role_aliases") or {}
        return {str(k).strip(): str(v).strip() for k, v in aliases.items()}
    except Exception:
        return {}


def effective_role(role: str) -> str:
    """Resolve a deployment role name to a known capability class."""
    if not role or role in _KNOWN_ROLES:
        return role
    target = _role_aliases().get(role)
    # One hop only. An alias chain would let a mis-edited file build a cycle,
    # and an alias to another alias is not a capability class anyway.
    if target and target in _KNOWN_ROLES:
        return target
    return role


def authorize(user_ctx: dict, action: str) -> bool:
    """RBAC check: does this user's role permit the action?"""
    role = user_ctx.get("role")
    allowed = PERMISSIONS.get(action, [])
    if not role:
        return False
    if role in allowed:
        return True
    # Deny-by-default is preserved: an unaliased unknown role still fails.
    return effective_role(role) in allowed


def authenticate(user_id: str, password: str) -> dict | None:
    """Validate credentials against the users table; returns full RBAC
    context + fresh token, or None."""
    from ..data.db import get_user_context, POOL, ensure_db
    ensure_db()
    con = POOL.acquire()
    try:
        row = con.execute("SELECT password_hash FROM users WHERE user_id=?",
                          (user_id,)).fetchone()
    finally:
        POOL.release(con)
    if not row or not row[0] or not verify_password(password, row[0]):
        try:
            from ..trust.audit_ledger import _write
            from datetime import datetime, timezone
            _write({"ts": datetime.now(timezone.utc).isoformat(),
                    "kind": "auth", "event": "login_failed",
                    "user_id": user_id})
        except Exception:
            pass
        return None
    ctx = get_user_context(user_id)
    if not ctx.get("authorized"):
        return None
    return {"token": issue_token(user_id, ctx["role"]), "user": ctx}
