"""Human-in-the-loop review queue (graceful degradation target).

When the system refuses to answer (unresolved semantic hop, or trust
score below the 85% hard gate), the full query payload is queued here
for an analyst/compliance officer to triage.
"""
import json
import os
import time
import uuid

QUEUE_PATH = os.environ.get(
    "OPPAL_REVIEW_QUEUE",
    os.path.join(os.path.dirname(__file__), "..", "data",
                 "review_queue.json"))


def _load() -> list:
    if os.path.exists(QUEUE_PATH):
        with open(QUEUE_PATH) as f:
            return json.load(f)
    return []


def _save(items: list):
    os.makedirs(os.path.dirname(QUEUE_PATH), exist_ok=True)
    with open(QUEUE_PATH, "w") as f:
        json.dump(items, f, indent=1, default=str)


def enqueue(question: str, user_id: str, reason: str, trust: dict,
            grounding_terms: list) -> dict:
    items = _load()
    item = {"id": str(uuid.uuid4())[:8],
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "user_id": user_id, "question": question, "reason": reason,
            "trust_score": (trust or {}).get("score"),
            "grounded_terms": grounding_terms,
            "status": "open", "resolution": ""}
    items.insert(0, item)
    _save(items[:200])
    return item


def list_items(status: str | None = None, user_id: str | None = None,
               all_users: bool = False) -> list:
    """Queued refusals.

    ``user_id`` restricts the list to one requester's own items. A refused
    question is still the analyst's question — it contains their phrasing and
    the reason it was withheld — so the default caller sees only their own.
    ``all_users=True`` is the compliance-officer triage view: resolving the
    queue is that role's job, so it is an explicit, permissioned widening
    rather than the accidental everyone-sees-everything behaviour this
    function had before.
    """
    items = _load()
    out = []
    for i in items:
        if status and i["status"] != status:
            continue
        if not all_users and user_id is not None \
                and i.get("user_id") != user_id:
            continue
        out.append(i)
    return out


def resolve(item_id: str, resolution: str, reviewer: str) -> bool:
    items = _load()
    for i in items:
        if i["id"] == item_id:
            i.update(status="resolved", resolution=resolution,
                     reviewer=reviewer,
                     resolved_ts=time.strftime("%Y-%m-%d %H:%M:%S"))
            _save(items)
            return True
    return False
