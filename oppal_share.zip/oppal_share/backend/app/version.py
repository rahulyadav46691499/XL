"""THE single source of truth for what build this is.

Why this file exists: the FastAPI app declared ``version="0.1.0-phase0"``
while the shipped archives were at v13.x. Nobody noticed because the two
lived in different places — the zip filename was typed by hand at package
time and the API string was set once and forgotten. A version that only
exists in a filename cannot be asked for by a running system, which makes
"which build is this environment on?" unanswerable from inside the product.

Everything that reports a version now reads THIS constant: the FastAPI app
metadata, the /api/about endpoint, and the Help tab's About panel. Bump it
here and the whole surface moves together.
"""
from __future__ import annotations

# Bump on every release. Keep the zip filename in step with this string.
VERSION = "14.14.0"

# What changed in this build, shown verbatim in the Help ▸ About panel so an
# operator can tell two environments apart without reading a changelog file.
RELEASE_NOTE = (
    "Field testing against the regenerated pharma runbook found two real "
    "bugs. (1) A partial-scope analyst (Morgan, Cardinal-East only) saw ZERO "
    "cases after signing in, even for her own hub's incidents -- root cause: "
    "PrescriptiveActionAgent.propose_actions() stamped EVERY case with the "
    "swarm RUNNER's own scope label, not the finding's actual LOB. Casey "
    "(compliance_officer) is full-scope for pharma, so her cases were all "
    "labeled 'ALL', and a CROSS_LOB-labeled case is visible only to another "
    "full-scope viewer -- Morgan's own Hub-09 chargeback and cold-chain "
    "cases were invisible to her regardless of being in her scope. Fixed by "
    "reading the domain's declared governance.scope_column "
    "(distributor_id for pharma) off the finding's own row-level evidence, "
    "when a persona query selects it, and using that value as the case's "
    "label instead of the runner's blanket scope -- the two single-row-per-"
    "incident personas (cold-chain, chargeback) now select distributor_id; "
    "the lot-level DSCSA query, which can span multiple distributors per "
    "row, is deliberately left unchanged. (2) Context Brain's domain switch "
    "updated the engine immediately but the header's 'authorized LOBs' badge "
    "kept showing the previous domain's values until a full page reload, "
    "because App.jsx's /api/me fetch was keyed only on [session] with no "
    "way to know a domain switch had happened. Fixed with the same event "
    "pattern already used for workspace pins: activate() now fires "
    "'oppal-domain-changed', and App.jsx re-fetches /api/me on that event. "
    "Both proven against a reverted copy (fails pre-fix, passes post-fix); "
    "the case-visibility fix's own test previously read '<=' and would pass "
    "on the pre-fix zero-case bug -- strengthened to assert Morgan's own "
    "Hub-09 cases are actually present. Suite 1298/1298."
)
# ISO date of this build. Deliberately a literal, not datetime.now(): the
# build date must describe when the CODE was cut, not when the server booted.
BUILD_DATE = "2026-09-02"

# Named for release-note continuity across the phase-based earlier history.
CODENAME = "Stars"


def version_string() -> str:
    """e.g. 'v14.1.0 (Stars, 2026-08-25)' — for logs and window titles."""
    return f"v{VERSION} ({CODENAME}, {BUILD_DATE})"


__all__ = ["VERSION", "RELEASE_NOTE", "BUILD_DATE", "CODENAME",
           "version_string"]
