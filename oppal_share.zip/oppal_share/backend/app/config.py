"""Runtime settings: LLM provider + keys, and data connection.

Persisted to settings.json so the app remembers configuration across
restarts. API keys are stored locally only and masked in GET responses.
"""
import json
import os

SETTINGS_PATH = os.environ.get(
    "OPPAL_SETTINGS_PATH",
    os.path.join(os.path.dirname(__file__), "data", "settings.json"))

DEFAULTS = {
    "llm": {"provider": "mock", "api_key": "", "model": "",
            "endpoint": "", "deployment": ""},
    "data": {"type": "sqlite_demo", "params": {}, "caps_vendor": "facets"},
    "privacy": {"phi_protection": True, "send_row_samples": True},
    "network": {"ssl_verify": True, "ca_bundle": ""},
    "cache": {"redis_url": "", "ttl_seconds": 900},
    "ui": {"theme": "light"},
    # Welcome-bar briefing (weather + industry headlines). Entirely OPTIONAL
    # and OFF by default: on a corporate network that re-signs TLS, an
    # unreachable third-party widget is worse than no widget, so anything
    # unconfigured is simply not rendered rather than shown as an error.
    # weather_url/news_url accept a {lat},{lon},{location} template.
    "briefing": {"enabled": True, "weather_url": "", "news_url": "",
                 "location": "", "cache_seconds": 900},
    # Phase 4 write-back targets. Default is the dry-run simulator; real
    # endpoints/credentials come from settings or OPPAL_* env vars.
    "actions": {"default_target": "dry_run",
                "dry_run": {"simulated_system": "facets"},
                "webhook": {"endpoint": "", "secret": ""},
                "facets": {"endpoint": ""}, "qnxt": {"endpoint": ""}},
    # Phase 6 amendment — Notification Event Bus (Limitation 3). Unconfigured
    # channels degrade to a logged no-op; nothing here blocks the underlying
    # action/simulation/ledger workflow.
    "notify": {"slack": {"webhook_url": ""},
              "email": {"smtp_host": "", "smtp_port": 587,
                        "smtp_user": "", "smtp_password": "",
                        "from_addr": "", "to_addr": ""}},
    # MCP Zero-Copy / Zero-Persistence data layer (Phase 1). Every value is
    # overridable by environment variable (see mcp_config()); nothing about
    # data movement is hardcoded in the connectors.
    "mcp": {
        "active_connector": "local_reference",
        "zero_persistence": True,      # never write result rows to disk
        "max_result_rows": 100000,     # hard cap streamed into memory
        "max_bytes_billed": 5_000_000_000,   # warehouse safety guard (5 GB)
        "statement_timeout_seconds": 60,
        "page_size": 5000,             # server-side streaming page size
        "redact_phi_in_logs": True,
    },
}

# Environment overrides for the MCP layer (operational config, not business
# logic). Business/domain scoping rules live in the Context Brain governance.md.
_MCP_ENV = {
    "active_connector": ("OPPAL_MCP_CONNECTOR", str),
    "zero_persistence": ("OPPAL_MCP_ZERO_PERSISTENCE", "bool"),
    "max_result_rows": ("OPPAL_MCP_MAX_ROWS", int),
    "max_bytes_billed": ("OPPAL_MCP_MAX_BYTES", int),
    "statement_timeout_seconds": ("OPPAL_MCP_TIMEOUT", int),
    "page_size": ("OPPAL_MCP_PAGE_SIZE", int),
    "redact_phi_in_logs": ("OPPAL_MCP_REDACT_PHI", "bool"),
}


def mcp_config() -> dict:
    """Resolved MCP settings: DEFAULTS <- settings.json <- environment."""
    cfg = dict(DEFAULTS["mcp"])
    cfg.update(load().get("mcp", {}))
    for key, (env, typ) in _MCP_ENV.items():
        raw = os.environ.get(env)
        if raw is None or raw == "":
            continue
        if typ == "bool":
            cfg[key] = raw.strip().lower() in ("1", "true", "yes", "on")
        elif typ is int:
            try:
                cfg[key] = int(raw)
            except ValueError:
                pass
        else:
            cfg[key] = raw
    return cfg

DATA_CONNECTORS = {
    "sqlite_demo": {"label": "Demo SQLite (bundled healthcare claims)",
                    "params": [], "driver": None},
    "bigquery": {"label": "Google BigQuery",
                 "params": ["project_id", "dataset", "service_account_json",
                            "tables"],
                 "driver": "google.cloud.bigquery"},
    "snowflake": {"label": "Snowflake",
                  "params": ["account", "warehouse", "database", "schema",
                             "user", "password", "tables"],
                  "driver": "snowflake.connector"},
    "redshift": {"label": "Amazon Redshift",
                 "params": ["host", "port", "database", "user", "password",
                            "tables"],
                 "driver": "redshift_connector"},
    "databricks": {"label": "Databricks SQL",
                   "params": ["server_hostname", "http_path", "access_token",
                              "tables"],
                   "driver": "databricks.sql"},
    "postgres": {"label": "PostgreSQL",
                 "params": ["host", "port", "database", "user", "password",
                            "tables"],
                 "driver": "psycopg2"},
    "azure_synapse": {"label": "Azure Synapse",
                      "params": ["server", "database", "user", "password"],
                      "driver": "pyodbc"},
}

SECRET_FIELDS = {"api_key", "password", "access_token", "service_account_json"}


def load() -> dict:
    if os.path.exists(SETTINGS_PATH):
        with open(SETTINGS_PATH) as f:
            saved = json.load(f)
        out = json.loads(json.dumps(DEFAULTS))
        for section in DEFAULTS:
            out[section].update(saved.get(section, {}))
        return out
    return json.loads(json.dumps(DEFAULTS))


def save(settings: dict):
    os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
    with open(SETTINGS_PATH, "w") as f:
        json.dump(settings, f, indent=1)


def _mask(v: str) -> str:
    return (v[:4] + "•" * 8 + v[-4:]) if v and len(v) > 12 \
        else ("•" * len(v) if v else "")


def masked() -> dict:
    s = load()
    s["llm"] = {**s["llm"], "api_key": _mask(s["llm"].get("api_key", ""))}
    params = {k: (_mask(v) if k in SECRET_FIELDS else v)
              for k, v in s["data"].get("params", {}).items()}
    s["data"] = {**s["data"], "params": params}
    s["connectors"] = {k: {"label": v["label"], "params": v["params"]}
                       for k, v in DATA_CONNECTORS.items()}
    return s


def update(new: dict) -> dict:
    """Merge updates; ignore masked secrets (bullets) so partial saves work."""
    s = load()
    for section in ("llm", "data", "privacy", "network", "cache", "ui",
                    "notify"):
        if section in new:
            for k, v in new[section].items():
                if isinstance(v, str) and "•" in v:
                    continue
                if k == "params" and isinstance(v, dict):
                    merged = dict(s[section].get("params", {}))
                    for pk, pv in v.items():
                        if not (isinstance(pv, str) and "•" in pv):
                            merged[pk] = pv
                    s[section]["params"] = merged
                else:
                    s[section][k] = v
    save(s)
    return s


def apply_llm_env(s: dict | None = None):
    """Export settings as env vars so llm.base.get_provider() picks them up."""
    s = s or load()
    llm = s["llm"]
    net = s.get("network", DEFAULTS["network"])
    os.environ["OPPAL_SSL_VERIFY"] = "1" if net.get("ssl_verify", True) else "0"
    os.environ["OPPAL_CA_BUNDLE"] = net.get("ca_bundle", "") or ""
    cache = s.get("cache", DEFAULTS["cache"])
    os.environ["REDIS_URL"] = cache.get("redis_url", "") or ""
    os.environ["OPPAL_CACHE_TTL"] = str(cache.get("ttl_seconds", 900))
    os.environ["LLM_PROVIDER"] = llm.get("provider", "mock")
    key = llm.get("api_key", "")
    if llm["provider"] == "anthropic" and key:
        os.environ["ANTHROPIC_API_KEY"] = key
        if llm.get("model"):
            os.environ["ANTHROPIC_MODEL"] = llm["model"]
    elif llm["provider"] == "openai" and key:
        os.environ["OPENAI_API_KEY"] = key
        if llm.get("model"):
            os.environ["OPENAI_MODEL"] = llm["model"]
        if llm.get("endpoint"):
            os.environ["OPENAI_BASE_URL"] = llm["endpoint"]
    elif llm["provider"] == "gemini" and key:
        os.environ["GEMINI_API_KEY"] = key
        if llm.get("model"):
            os.environ["GEMINI_MODEL"] = llm["model"]
    elif llm["provider"] == "azure" and key:
        os.environ["AZURE_OPENAI_API_KEY"] = key
        if llm.get("endpoint"):
            os.environ["AZURE_OPENAI_ENDPOINT"] = llm["endpoint"]
        if llm.get("deployment"):
            os.environ["AZURE_OPENAI_DEPLOYMENT"] = llm["deployment"]


def test_data_connection(dtype: str) -> dict:
    """Check whether the driver for a connector is installed."""
    meta = DATA_CONNECTORS.get(dtype)
    if not meta:
        return {"ok": False, "message": f"Unknown connector '{dtype}'"}
    if meta["driver"] is None:
        from .data.db import run_query
        r = run_query("SELECT COUNT(*) FROM claims")
        return {"ok": r["ok"],
                "message": f"Demo database reachable — {r['rows'][0][0]:,} claims"
                if r["ok"] else "Demo database not built yet"}
    try:
        __import__(meta["driver"].split(".")[0])
        return {"ok": True,
                "message": f"{meta['label']} driver installed. Connection "
                           "config saved — executor swap is the "
                           "production-hardening step (see README)."}
    except ImportError:
        return {"ok": False,
                "message": f"Driver '{meta['driver']}' not installed. "
                           f"pip install it to enable {meta['label']}."}
