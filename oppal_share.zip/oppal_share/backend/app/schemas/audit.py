"""Hash-chained audit ledger contracts (Phase 6).

``AuditLedgerEntry`` is the typed shape of a v2 ledger block (see
``app/trust/ledger_v2.py`` for the hashing math: ``record_hash =
SHA256(canon({seq, ts, kind, payload, prev_hash}))``, full 64-hex). Entries are
``frozen`` — a written block is immutable; the ledger is append-only, and a
reversal is always a NEW block that cryptographically references the original
via ``compensates_record_hash`` (never an edit).

The ``payload`` validator is defense-in-depth: even though every caller is
expected to PHI-scrub before constructing an entry, construction itself fails
closed if an obviously un-scrubbed identifier pattern slips through.
"""
from __future__ import annotations

import re
from enum import Enum
from typing import Literal, Optional

from ..mcp._models_base import BaseModel, ConfigDict, Field, field_validator, \
    model_validator


class LedgerKind(str, Enum):
    PROMPT = "prompt"
    SQL = "sql"
    TRUST = "trust"
    BRAIN_EDIT = "brain_edit"
    AGENT_INVOKE = "agent_invoke"      # Upgrade 2: agents as securable objects
    PROVENANCE = "provenance"          # Recommendation 2: answer provenance
    ACTION = "action"
    SIMULATION = "simulation"
    AUTH = "auth"
    SYSTEM = "system"


# un-scrubbed identifier patterns that must NEVER reach a ledger payload.
_PHI_LEAK_PATTERNS = (
    re.compile(r"\bM-\d{6}\b"),                                    # member id
    re.compile(r"\bC-\d{7}\b"),                                    # claim id
    re.compile(r"\b[1-9][AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y0-9]\d-"),   # MBI head
)


class AuditLedgerEntry(BaseModel):
    # frozen: a written block is immutable; append-only ledger
    model_config = ConfigDict(extra="forbid", frozen=True,
                              str_strip_whitespace=True, validate_assignment=True)

    seq: int = Field(ge=0)
    ts: str
    kind: LedgerKind
    actor: str                            # user_id or agent name; never blank
    payload: dict                         # PHI-scrubbed BEFORE construction
    # min_length=7, not 8: the genesis sentinel "GENESIS" (7 chars) is
    # unchanged from the Phase 0-4 ledger per the TDD's own migration note —
    # every real hash is a full 64-hex string, so 7 is still high enough to
    # reject empty/garbage values while admitting the one legitimate
    # non-hash value the chain ever uses.
    prev_hash: str = Field(min_length=7)
    record_hash: str = Field(min_length=64, max_length=64)   # full sha256 hex
    # optional cryptographic backlinks (compensating entries)
    compensates_record_hash: Optional[str] = None

    @field_validator("actor")
    @classmethod
    def _actor_present(cls, v: str) -> str:
        if not v:
            raise ValueError("every ledger entry must attribute an actor")
        return v

    @field_validator("payload")
    @classmethod
    def _payload_is_phi_scrubbed(cls, v: dict) -> dict:
        # defense in depth: reject raw identifiers that indicate the caller
        # forgot to scrub (mirrors phi_guard patterns). Fail closed.
        blob = str(v)
        for pat in _PHI_LEAK_PATTERNS:
            if pat.search(blob):
                raise ValueError("payload appears to contain un-scrubbed PHI")
        return v


class ChainVerification(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    ok: bool
    checked: int
    first_broken_seq: Optional[int] = None
    expected_hash: Optional[str] = None
    found_hash: Optional[str] = None
    head_seq: int
    head_hash: str


class LedgerExportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    date_from: str                        # YYYY-MM-DD
    date_to: str
    kinds: Optional[list[LedgerKind]] = None
    fmt: Literal["jsonl", "csv"] = "jsonl"

    @model_validator(mode="after")
    def _range_ordered(self):
        if self.date_from > self.date_to:
            raise ValueError("date_from must be ≤ date_to")
        return self


__all__ = ["LedgerKind", "AuditLedgerEntry", "ChainVerification",
           "LedgerExportRequest"]
