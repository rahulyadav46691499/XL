"""Actuarial "What-If" Simulator contracts (Phase 5).

Strict Pydantic v2 boundaries per the Phase 5/6 TDD §2.1:

  * ``ParameterOverride`` — a single, typed change applied ONLY to a forked
    (deep-copied) Brain, never the live singleton. Overrides can never target
    governance/approver/action-rule sections (defense in depth vs NFR-2), and
    numeric ops must carry a numeric value.
  * ``SimulationRequest`` — the inbound contract. ``lob_scope`` is a
    server-authoritative echo field: any client-supplied value is REJECTED at
    construction, so a caller cannot smuggle a wider scope than
    ``scope_from_user`` grants (the endpoint is the only place that populates
    it, after validation).
  * ``SimulationResult`` — frozen (a completed simulation record never
    mutates); ``mlr_delta_bps`` is cross-checked against
    ``simulated - baseline`` and negative MLR basis points are rejected as a
    mathematical impossibility (a ratio of non-negative dollars).

No arithmetic literal for MLR/savings/burden/abrasion lives in this module or
in ``app/simulation/*.py`` — every formula id referenced here is resolved from
the Context Brain's ``simulation.md`` (NFR-1).
"""
from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Optional

from ..mcp._models_base import (BaseModel, ConfigDict, Field, field_validator,
                                model_validator)


class OverrideOp(str, Enum):
    SET = "set"
    DELTA_ABS = "delta_abs"
    DELTA_PCT = "delta_pct"
    TIER_SHIFT = "tier_shift"


class ParameterOverride(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    brain_path: str                      # dotted target in the FORKED brain,
    # e.g. "metrics.pharmacy_cost.tier"
    op: OverrideOp
    value: str | int | float | Decimal   # interpreted per `op`
    reason: str = ""

    @field_validator("brain_path")
    @classmethod
    def _no_write_to_auth_or_governance_tables(cls, v: str) -> str:
        # overrides may target metrics/parameters, NEVER governance.md scope
        # rules, excluded tables, or approver roles (defense in depth vs NFR-2)
        forbidden = ("governance.", "excluded_tables", "approver_roles",
                     "action_rules.")
        if any(v.startswith(p) or p in v for p in forbidden):
            raise ValueError(f"override target '{v}' is not permitted")
        return v

    @model_validator(mode="after")
    def _numeric_ops_need_numbers(self):
        if self.op in (OverrideOp.DELTA_ABS, OverrideOp.DELTA_PCT):
            try:
                Decimal(str(self.value))
            except Exception:
                raise ValueError(f"{self.op} requires a numeric value")
        return self


class SimulationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    baseline_query: str = Field(min_length=3, max_length=1000)   # NL cohort
    parameter_overrides: list[ParameterOverride] = Field(min_length=1,
                                                          max_length=50)
    metrics_requested: list[str] = Field(
        default_factory=lambda: ["mlr", "net_savings", "admin_burden",
                                 "affected_members"])
    # RBAC scope is NEVER taken from the client body; it is injected
    # server-side from the authenticated principal. Present here only as an
    # out-bound echo:
    lob_scope: Optional[list[str]] = None      # server-populated, input ignored

    @field_validator("lob_scope")
    @classmethod
    def _scope_is_server_authoritative(cls, v):
        # any client-supplied scope is discarded; the endpoint overwrites it
        # from scope_from_user(). Rejecting a non-null inbound value makes the
        # contract explicit.
        if v is not None:
            raise ValueError("lob_scope is server-derived and must not be "
                             "supplied")
        return v


class MetricDelta(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, validate_assignment=True)

    metric: str
    baseline: Decimal
    simulated: Decimal
    delta: Decimal
    unit: str                            # "bps" | "usd" | "count" | "minutes"
    direction: str                       # "favorable" | "adverse" | "neutral"


class SimulationResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, validate_assignment=True)

    run_id: str
    requested_by: str
    lob_scope: list[str]
    baseline_mlr_bps: int
    simulated_mlr_bps: int
    mlr_delta_bps: int                   # REQ-5.3
    net_dollar_impact: Decimal           # +savings / -exposure
    admin_burden_delta: Decimal          # projected PA-processing volume delta
    affected_member_count: int           # member abrasion
    metrics: list[MetricDelta]
    trust_score: float
    trust_gate_passed: bool
    formula_ids_used: list[str]          # provenance of every Brain formula
    # applied (NFR-1)
    lineage_ref: str                     # -> journey/trust/logic-tree snapshot
    created_at: str
    warehouse_ms: float
    truncated: bool = False
    # ADDITIVE EXTENSION beyond the TDD's literal §2.1 field list, required to
    # satisfy TDD §4.4/D3 ("MLR with zero earned premium returns null/'n/a',
    # not inf"). `baseline_mlr_bps: int` cannot express "undefined", so a
    # zero-premium cohort would otherwise be indistinguishable from a real 0%
    # loss ratio. False => the MLR figures are not meaningful; render "n/a".
    mlr_available: bool = True

    @model_validator(mode="after")
    def _mlr_delta_is_consistent(self):
        if self.mlr_delta_bps != (self.simulated_mlr_bps -
                                  self.baseline_mlr_bps):
            raise ValueError("mlr_delta_bps must equal simulated − baseline")
        return self

    @field_validator("baseline_mlr_bps", "simulated_mlr_bps")
    @classmethod
    def _mlr_bps_physically_possible(cls, v: int) -> int:
        # MLR is a ratio of non-negative money; it cannot be negative. It may
        # exceed 10000 bps (>100%, an underwater book), so only the lower
        # bound is a hard mathematical impossibility.
        if v < 0:
            raise ValueError(
                "MLR basis points cannot be negative (ratio of "
                "non-negative dollars)")
        return v


__all__ = ["OverrideOp", "ParameterOverride", "SimulationRequest",
           "MetricDelta", "SimulationResult"]
