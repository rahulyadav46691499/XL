"""VS Workspace dashboard contracts (Phase 5, REQ-5.6–5.8).

A workspace pins durable artifacts — simulation results, saved charts/grids —
onto a named, drag/resize-able dashboard, each with a ``lineage_ref`` back to
the journey/trust/logic-tree snapshot that produced it (REQ-5.8), so a
compliance reviewer can always answer "why does this number say what it
says" without re-running anything.
"""
from __future__ import annotations

from typing import Literal, Optional

from ..mcp._models_base import BaseModel, ConfigDict, Field


class GridItem(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    artifact_id: str
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    w: int = Field(ge=1)
    h: int = Field(ge=1)


class Artifact(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    id: str
    type: Literal["chart", "grid", "simulation"]
    spec: dict = Field(default_factory=dict)
    lineage_ref: str = ""
    created_at: str = ""


class ShareGrant(BaseModel):
    """An explicit, per-USER grant on one dashboard.

    A dashboard is private to its owner. Visibility is never inferred from a
    shared LOB scope: two analysts with identical LOB authorization are still
    two different people, and one must not read the other's board. Sharing is
    therefore an affirmative act, recorded per grantee, with a level.
    """
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    user_id: str = Field(min_length=1)
    level: Literal["view", "edit"] = "view"
    granted_by: str = ""
    granted_at: str = ""


class WorkspaceSummary(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    id: str
    name: str
    owner: str
    lob: str
    artifact_count: int = 0
    updated_at: str = ""
    # How the CALLER reached this board: "owner" | "view" | "edit".
    # Lets the UI label a shared board and hide controls the caller can't use.
    access: str = "owner"
    shared_with: list[ShareGrant] = Field(default_factory=list)


class Workspace(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    id: str
    name: str
    owner: str
    lob: str
    layout: list[GridItem] = Field(default_factory=list)
    artifacts: list[Artifact] = Field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""
    shared_with: list[ShareGrant] = Field(default_factory=list)


class WorkspaceCreate(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    name: str = Field(min_length=1, max_length=80)


class WorkspaceLayout(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    layout: list[GridItem] = Field(default_factory=list)


class ArtifactPin(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    type: Literal["chart", "grid", "simulation"]
    spec: dict = Field(default_factory=dict)
    lineage_ref: str = ""


class ShareRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True,
                              validate_assignment=True)

    user_id: str = Field(min_length=1, max_length=64)
    level: Literal["view", "edit"] = "view"


__all__ = ["GridItem", "Artifact", "ShareGrant", "WorkspaceSummary",
           "Workspace", "WorkspaceCreate", "WorkspaceLayout", "ArtifactPin",
           "ShareRequest"]
