"""Action & write-back contracts (Phase 4).

Pydantic-first models (via the shared compatibility layer) that strictly
validate an action from proposal through approval to the outbound payload.
The state machine encodes impact-threshold dual control:

    PROPOSED
       └─► PENDING_FIRST_APPROVAL
              ├─(single control)─► APPROVED ─► EXECUTED
              └─(dual control)──► PENDING_SECOND_APPROVAL ─► APPROVED ─► EXECUTED
       └─► REJECTED   (from any pending state; reason is mandatory)
       └─► FAILED     (adapter/transport failure after APPROVED)

Invariants enforced here (and re-checked in the engine and the adapter base):
  * approver_1_id != approver_2_id (separation of duties)
  * the proposer may not approve unless the Brain allows self-approval
  * no transition to EXECUTED unless state == APPROVED and trust >= gate
  * every outbound payload is validated by ``ActionPayload`` before it can
    reach an adapter
"""
from __future__ import annotations

import enum
import hashlib
import json
from decimal import Decimal
from typing import Literal, Optional

from ..mcp._models_base import (BaseModel, ConfigDict, Field, ValidationError,
                                model_validator)


class ActionState(str, enum.Enum):
    PROPOSED = "PROPOSED"
    PENDING_FIRST_APPROVAL = "PENDING_FIRST_APPROVAL"
    PENDING_SECOND_APPROVAL = "PENDING_SECOND_APPROVAL"
    APPROVED = "APPROVED"
    EXECUTED = "EXECUTED"
    REJECTED = "REJECTED"
    FAILED = "FAILED"
    # -- Phase 6 amendment (compensating / void-credit actions) --------------
    PENDING_COMPENSATION = "PENDING_COMPENSATION"
    COMPENSATED = "COMPENSATED"


class ControlMode(str, enum.Enum):
    SINGLE = "single"
    DUAL = "dual"


#: legal state transitions — the engine refuses anything not listed here
TRANSITIONS: dict = {
    ActionState.PROPOSED: {ActionState.PENDING_FIRST_APPROVAL,
                           ActionState.REJECTED},
    ActionState.PENDING_FIRST_APPROVAL: {ActionState.PENDING_SECOND_APPROVAL,
                                         ActionState.APPROVED,
                                         ActionState.REJECTED},
    ActionState.PENDING_SECOND_APPROVAL: {ActionState.APPROVED,
                                          ActionState.REJECTED},
    ActionState.APPROVED: {ActionState.EXECUTED, ActionState.FAILED,
                           ActionState.REJECTED},
    # Phase 6 amendment (Limitation 2 — compensating/void-credit actions):
    # an EXECUTED action may be reversed, but only through the same
    # dual-control queue as any other action, never a direct edit.
    ActionState.EXECUTED: {ActionState.PENDING_COMPENSATION},
    ActionState.REJECTED: set(),
    ActionState.FAILED: {ActionState.APPROVED},      # retry after remediation
    ActionState.PENDING_COMPENSATION: {ActionState.COMPENSATED},
    ActionState.COMPENSATED: set(),
}


class ApprovalSignature(BaseModel):
    """A cryptographic approval signature appended to the audit ledger."""
    approver_id: str
    approver_role: str
    decision: str                     # approved | rejected
    at: str                           # ISO timestamp
    reason: str = ""                  # mandatory on rejection
    signature: str = ""               # sha256 over the canonical tuple

    @staticmethod
    def sign(action_id: str, approver_id: str, decision: str, at: str,
             reason: str, payload_hash: str) -> str:
        canonical = "|".join([action_id, approver_id, decision, at, reason,
                              payload_hash])
        return hashlib.sha256(canonical.encode()).hexdigest()


class ActionPayload(BaseModel):
    """The validated outbound write-back payload.

    Nothing reaches an adapter unless it is an instance of this model: the
    adapter base type-checks it, so a malformed or unapproved payload cannot
    be transmitted.
    """
    action_id: str
    action_type: str                  # claim_adjustment | overpayment_recovery…
    target_system: str                # facets | qnxt | webhook | dry_run
    target_object: str                # e.g. claim_id / auth_id / provider_id
    lob: str
    operation: str = "update"         # update | create | close | resubmit
    fields: dict = Field(default_factory=dict)   # the change to apply
    idempotency_key: str = ""
    effective_date: Optional[str] = None
    note: str = ""

    def canonical(self) -> str:
        return json.dumps(self.model_dump(), sort_keys=True, default=str)

    def payload_hash(self) -> str:
        return hashlib.sha256(self.canonical().encode()).hexdigest()


class ActionRequest(BaseModel):
    """A proposed action awaiting human review, with everything a reviewer
    needs: impact, trust, and the compliance logic tree."""
    action_id: str
    case_id: str = ""
    action_type: str
    target_system: str = "dry_run"
    target_object: str
    lob: str
    proposed_by: str                          # agent name
    proposer_user_id: str = ""                # human on whose behalf it ran
    summary: str = ""
    estimated_financial_impact: float = 0.0
    regulatory_severity: str = "medium"
    trust_score: float = 0.0
    control_mode: ControlMode = ControlMode.SINGLE
    state: ActionState = ActionState.PROPOSED
    approver_1_id: Optional[str] = None
    approver_2_id: Optional[str] = None
    signatures: list = Field(default_factory=list)     # list[ApprovalSignature]
    compliance_logic: dict = Field(default_factory=dict)  # logic tree
    payload: Optional[ActionPayload] = None
    rejection_reason: str = ""
    created_at: str = ""
    updated_at: str = ""
    executed_at: Optional[str] = None
    execution_receipt: dict = Field(default_factory=dict)

    # -- state machine -----------------------------------------------------
    def can_transition(self, to: ActionState) -> bool:
        return to in TRANSITIONS.get(self.state, set())

    def assert_transition(self, to: ActionState) -> None:
        if not self.can_transition(to):
            raise ValidationError(
                f"illegal transition {self.state.value} → {to.value}")

    def requires_second_approval(self) -> bool:
        return (self.control_mode == ControlMode.DUAL
                and self.state == ActionState.PENDING_SECOND_APPROVAL)

    def distinct_approvers(self) -> bool:
        """Separation of duties: the two approvers must differ."""
        if self.approver_1_id and self.approver_2_id:
            return self.approver_1_id != self.approver_2_id
        return True

    def gate_passed(self, gate: float) -> bool:
        return self.trust_score >= gate

    def approval_signatures(self) -> list:
        """Only signatures that actually record an approval decision."""
        out = []
        for s in self.signatures or []:
            decision = (s.decision if hasattr(s, "decision")
                        else (s or {}).get("decision"))
            approver = (s.approver_id if hasattr(s, "approver_id")
                        else (s or {}).get("approver_id"))
            if str(decision).lower() == "approved" and approver:
                out.append(s)
        return out

    def approver_ids_from_signatures(self) -> list:
        ids = []
        for s in self.approval_signatures():
            aid = (s.approver_id if hasattr(s, "approver_id")
                   else s.get("approver_id"))
            norm = str(aid or "").strip().lower()
            if norm and norm not in ids:
                ids.append(norm)
        return ids

    def executable(self, gate: float) -> tuple:
        """(ok, reason) — the double gate the UI mirrors and the adapter
        re-checks.

        The state label is NOT accepted as proof of approval: the required
        number of DISTINCT approval SIGNATURES must actually be present, so a
        row whose state was forced to APPROVED (or a hand-built in-memory
        object) cannot transmit.
        """
        if self.state != ActionState.APPROVED:
            return False, f"action is {self.state.value}, not APPROVED"
        if not self.gate_passed(gate):
            return False, (f"trust {self.trust_score:.0%} is below the "
                           f"{gate:.0%} execution gate")
        signers = self.approver_ids_from_signatures()
        required = 2 if self.control_mode == ControlMode.DUAL else 1
        if len(signers) < required:
            return False, (f"{required} approval signature(s) required; "
                           f"{len(signers)} present — state label alone is "
                           f"not proof of approval")
        # recorded approver fields must agree with the signatures
        a1 = str(self.approver_1_id or "").strip().lower()
        if not a1 or a1 not in signers:
            return False, "approver_1_id missing or not backed by a signature"
        if self.control_mode == ControlMode.DUAL:
            a2 = str(self.approver_2_id or "").strip().lower()
            if not a2 or a2 not in signers:
                return False, ("approver_2_id missing or not backed by a "
                               "signature")
            if a1 == a2:
                return False, ("separation of duties violated: "
                               "approver_1_id == approver_2_id")
        if self.payload is None:
            return False, "no validated payload"
        return True, ""


class CompensationRequest(BaseModel):
    """Phase 6 amendment (Limitation 2) — request to reverse an EXECUTED
    action. Always dual-control (see ``ACT-COMPENSATION`` in
    policy_rules.md, enforced defensively in ``app/actions/compensating.py``
    even if that Brain rule were ever removed): the reversal is proposed,
    approved and executed through the SAME maker-checker + double-gate +
    adapter path as any other action — see §2.3 of the Phase 5/6 TDD."""
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    original_action_id: str
    reason: str = Field(min_length=8)                       # mandatory, audited
    mode: Literal["void", "credit"] = "void"
    credit_amount: Optional[Decimal] = None                 # required iff mode=="credit"

    @model_validator(mode="after")
    def _credit_needs_amount(self):
        if self.mode == "credit" and (self.credit_amount is None
                                      or self.credit_amount <= 0):
            raise ValueError(
                "a credit compensation requires a positive credit_amount")
        return self
