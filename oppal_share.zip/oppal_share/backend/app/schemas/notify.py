"""Notification Event Bus contract (Phase 6 amendment, Limitation 3).

Fired by the action engine at the ``-> PENDING_SECOND_APPROVAL`` transition
(maker-checker trigger), and by ``compensating.py``/``ledger_v2.py`` on
``compensated``/``chain_broken``/``sim_promoted``. Adapters (Slack/email)
NEVER receive a raw payload — only this PHI-scrubbed summary.
"""
from __future__ import annotations

from typing import Literal, Optional

from ..mcp._models_base import BaseModel, ConfigDict


class NotificationEvent(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    event: Literal["pending_second_approval", "compensated", "chain_broken",
                   "sim_promoted"]
    action_id: Optional[str] = None
    lob: Optional[str] = None
    summary: str
    severity: Literal["info", "warning", "critical"] = "info"


__all__ = ["NotificationEvent"]
