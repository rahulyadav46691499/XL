"""Typed domain models for the mid-market operational pillars.

Authored as Pydantic models via the shared compatibility layer
(``app.mcp._models_base``), so they validate types today and swap to real
Pydantic transparently in production. No business logic lives here beyond a
few pure, deterministic derivations — the agents (Phase 2+) own behavior.
"""
from __future__ import annotations

import enum
from typing import Optional

from ..mcp._models_base import BaseModel, Field


# ---------------------------------------------------------------------------
# Pillar 4 — Member Out-of-Pocket & Risk Analytics
# ---------------------------------------------------------------------------
class RiskTier(str, enum.Enum):
    LOW = "low"
    RISING = "rising"
    HIGH = "high"
    CATASTROPHIC = "catastrophic"


class RiskProfile(BaseModel):
    """Member clinical/financial risk snapshot (RAF + ACG + PMPM)."""
    member_id: str
    lob: str
    raf_score: float = 0.0
    acg_risk_band: Optional[str] = None          # Johns Hopkins ACG grouping
    dual_eligible: bool = False
    hedis_gap_count: int = 0
    pmpm_cost: float = 0.0
    risk_tier: RiskTier = RiskTier.LOW

    @staticmethod
    def tier_for(raf_score: float) -> "RiskTier":
        if raf_score >= 2.5:
            return RiskTier.CATASTROPHIC
        if raf_score >= 1.5:
            return RiskTier.HIGH
        if raf_score >= 1.0:
            return RiskTier.RISING
        return RiskTier.LOW


class MOOPStatus(BaseModel):
    """Member Maximum-Out-Of-Pocket accumulation + reinsurance attachment."""
    member_id: str
    lob: str
    moop_limit: float                             # benefit-year MOOP ceiling
    moop_accum: float = 0.0                        # YTD accumulation
    reinsurance_attachment: Optional[float] = None  # stop-loss attach point
    ytd_plan_paid: float = 0.0

    def remaining(self) -> float:
        return max(self.moop_limit - self.moop_accum, 0.0)

    def pct_consumed(self) -> float:
        return round(100.0 * self.moop_accum / self.moop_limit, 1) \
            if self.moop_limit else 0.0

    def moop_reached(self) -> bool:
        return self.moop_accum >= self.moop_limit > 0

    def over_reinsurance(self) -> bool:
        return (self.reinsurance_attachment is not None
                and self.ytd_plan_paid >= self.reinsurance_attachment)


# ---------------------------------------------------------------------------
# Pillar 5 — Regulatory Reporting Compliance (CDAG/ODAG universes)
# ---------------------------------------------------------------------------
class RegulatoryUniverse(str, enum.Enum):
    """The CMS Program-Audit universes. NOT a closed set for the platform.

    These four are payer-specific. A closed enum here meant any other
    domain's universe name raised ValidationError deep inside
    determination_timeliness, which `pillar_summary` caught and turned into
    `{"error": ...}` — so a pharma cold-chain universe presented as a broken
    pillar rather than an unmodelled one. The record below therefore accepts
    a plain string and uses these as well-known constants, not a whitelist.
    """
    CDAG_CD = "CDAG_CD"        # Part D coverage determinations
    CDAG_ED_R = "CDAG_ED_R"    # Part D effectuation / redeterminations
    ODAG_OD = "ODAG_OD"        # Part C organization determinations
    ODAG_RC = "ODAG_RC"        # Part C reconsiderations


class CDAGUniverseRecord(BaseModel):
    """One row of a CMS Program-Audit universe (42 CFR §423.568 / §422.568)."""
    case_id: str
    # str, not RegulatoryUniverse: see the note on that enum. Domain-specific
    # universe names must be representable, not rejected.
    universe: str
    # Optional because the subject of a timeliness obligation is not always a
    # member — for a supply-chain domain it is a shipment or a lot.
    member_id: str = ""
    subject_id: str = ""
    lob: str
    standard: str = "standard"                    # standard | expedited
    received_at: str                              # ISO timestamp
    decision_at: Optional[str] = None
    timeliness_hours: Optional[float] = None
    threshold_hours: float = 72.0
    notice_sent: bool = False
    compliant: Optional[bool] = None

    def evaluate(self) -> "CDAGUniverseRecord":
        """Deterministic pass/fail: within threshold AND notice sent."""
        if self.timeliness_hours is not None:
            self.compliant = bool(
                self.timeliness_hours <= self.threshold_hours
                and self.notice_sent)
        return self


# ---------------------------------------------------------------------------
# Pillar 2 — Claims Triage / UM (foundational result contract)
# ---------------------------------------------------------------------------
class TriageDecision(str, enum.Enum):
    APPROVED = "approved"
    DENIED = "denied"
    PENDED = "pended"


class PriorAuthTriageResult(BaseModel):
    auth_id: str
    # Optional for the same reason as CDAGUniverseRecord: a triage subject is
    # a member in a payer domain and a shipment/lot elsewhere.
    member_id: str = ""
    subject_id: str = ""
    guideline_source: str = "InterQual"           # InterQual | MCG | CMS_* | formulary
    decision: TriageDecision = TriageDecision.PENDED
    trust_score: float = 0.0
    criteria_met: bool = False
    turnaround_hours: Optional[float] = None
    rationale: str = ""

    def gated(self, hard_gate: float = 0.85) -> bool:
        """Auto-approve only if criteria met AND trust clears the hard gate."""
        return (self.decision == TriageDecision.APPROVED
                and self.criteria_met and self.trust_score >= hard_gate)


# ---------------------------------------------------------------------------
# Pillar 3 — FWA / Overpayment (foundational alert contract)
# ---------------------------------------------------------------------------
class FWAPattern(str, enum.Enum):
    """Well-known payer fraud patterns. Also NOT a closed set.

    A fraud/leakage pattern is domain-specific: a supply-chain deployment
    detects chargeback duplication and thermal-excursion misreporting, which
    are the same SHAPE of finding (a peer outlier with an estimated dollar
    exposure) under different names. `FWAAlert.pattern` is a string so those
    are expressible without editing this file.
    """
    UNBUNDLING = "unbundling"
    EM_UPCODING = "em_upcoding"
    PHANTOM_HOURS = "phantom_hours"
    DUPLICATE_BILLING = "duplicate_billing"
    IMPOSSIBLE_DAY = "impossible_day"


class FWAAlert(BaseModel):
    fwa_id: str
    pattern: str
    # The accused party. Named provider_id for payer continuity; for a
    # supply-chain domain this carries a distributor or hub id.
    provider_id: str
    lob: str
    z_score: Optional[float] = None
    estimated_overpayment: float = 0.0
    claim_ids: list = Field(default_factory=list)
    status: str = "open"                           # open|reviewing|referred_siu|closed
    detail: str = ""
