"""FinOps / LLM telemetry contract (Phase 6, REQ-6.4–6.6).

All money is ``Decimal`` — never ``float`` — to avoid the classic
floating-point drift when the platform's own cost dashboard is doing the
accusing. ``price_in_per_m``/``price_out_per_m`` are provenance fields: they
echo the exact ``PRICING_PER_M`` entry the cost figures were computed from, so
the widget never needs (and the endpoint never contains) a hardcoded price
literal of its own — see ``app/finops/telemetry.py``.
"""
from __future__ import annotations

from decimal import Decimal

from ..mcp._models_base import BaseModel, ConfigDict, Field, field_validator, \
    model_validator


class FinOpsTelemetry(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    # counters
    session_tokens_in: int = Field(ge=0)
    session_tokens_out: int = Field(ge=0)
    global_tokens_in: int = Field(ge=0)
    global_tokens_out: int = Field(ge=0)
    llm_calls: int = Field(ge=0)
    # money (Decimal — never float)
    session_cost_usd: Decimal = Field(ge=0)
    global_cost_usd: Decimal = Field(ge=0)
    cache_savings_usd: Decimal = Field(ge=0)          # REQ-6.6
    # performance
    p95_latency_ms: float = Field(ge=0)
    cache_hit_rate: float = Field(ge=0, le=1)         # REQ-6.5
    # provenance
    provider: str
    price_in_per_m: Decimal                            # from PRICING_PER_M
    price_out_per_m: Decimal

    @model_validator(mode="after")
    def _costs_reconcile(self):
        # session cost cannot exceed global cost; a sanity invariant the
        # widget relies on
        if self.session_cost_usd > self.global_cost_usd:
            raise ValueError("session cost cannot exceed global cost")
        if self.session_tokens_in > self.global_tokens_in or \
                self.session_tokens_out > self.global_tokens_out:
            raise ValueError("session tokens cannot exceed global tokens")
        return self

    @field_validator("cache_hit_rate")
    @classmethod
    def _rate_is_fraction(cls, v: float) -> float:
        return round(v, 4)


__all__ = ["FinOpsTelemetry"]
