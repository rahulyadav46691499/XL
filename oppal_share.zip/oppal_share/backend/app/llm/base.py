"""Pluggable LLM provider abstraction.

Set LLM_PROVIDER=anthropic|openai|gemini|azure|mock (default: mock).
Mock mode makes the whole POC runnable offline: agents fall back to
deterministic rule-based logic when complete() returns None.
"""
import json
import os
import threading
from abc import ABC, abstractmethod


# ---- token/cost metering (approx 4 chars/token) --------------------------
#
# Per-MODEL pricing. Costing at provider granularity is not good enough once
# tiered routing exists: "anthropic" spans a 5x price range from Haiku 4.5 to
# Opus 5, so a single provider-level rate silently mis-bills every routed
# request. FinOps resolves by model first and only falls back to the provider
# rate for providers we do not tier.
#
# Verified against platform.claude.com/docs/en/about-claude/pricing
# (retrieved 18 August 2026). These are STANDARD rates — the Batch API is 50%
# lower and prompt-cache reads are 0.1x base input; do not confuse the batch
# column for the standard one.
#
#                                (input $/1M, output $/1M, cache-read $/1M)
MODEL_PRICING_PER_M = {
    "claude-fable-5":      (10.00, 50.00, 1.00),
    "claude-opus-5":        (5.00, 25.00, 0.50),
    "claude-sonnet-5":      (2.00, 10.00, 0.20),
    "claude-haiku-4-5-20251001": (1.00, 5.00, 0.10),
    # convenience aliases
    "claude-haiku-4.5":     (1.00,  5.00, 0.10),
    "claude-haiku-4-5":     (1.00,  5.00, 0.10),
}

# Routing tiers for Upgrade 4 (smart routing / fallback orchestration).
# NOTE: declared here but deliberately NOT yet wired into the orchestrator.
# Routing a request to a cheaper tier changes its trust score, and trust score
# gates action execution (execution_trust_gate) and is written to the immutable
# ledger — so tiered routing must not ship before answer provenance
# (provider + model + prompt hash + brain version) is recorded per answer.
# Wiring this up is Upgrade 4, gated on that work.
MODEL_TIERS = {
    "cheap":    "claude-haiku-4-5-20251001",  # classification, routing, tagging
    "standard": "claude-sonnet-5",            # default production workload
    "deep":     "claude-opus-5",              # complex multi-step reasoning
}

# Tasks that must NEVER be downgraded to a cheaper tier, because their output
# feeds a governance decision (a trust score, a proposed write-back, or a
# policy evaluation) rather than a cosmetic one.
TRUST_CRITICAL_TASKS = frozenset({
    "sql_generation", "trust_scoring", "action_proposal",
    "policy_evaluation", "compliance_audit",
})

PRICING_PER_M = {   # provider-level fallback (input $/1M, output $/1M)
    "anthropic": (2.00, 10.00),   # = Sonnet 5, the default model
    "openai": (2.50, 10.00),
    "azure": (2.50, 10.00), "gemini": (0.10, 0.40), "mock": (0.0, 0.0),
}


def price_for(provider: str, model: str | None = None) -> tuple:
    """(input, output) $/1M tokens — model-specific when we know the model."""
    if model:
        row = MODEL_PRICING_PER_M.get(model)
        if row:
            return row[0], row[1]
    return PRICING_PER_M.get(provider, (0.0, 0.0))


def cache_read_price(model: str | None) -> float:
    """Prompt-cache read rate ($/1M), 0.1x base input for Claude models."""
    row = MODEL_PRICING_PER_M.get(model or "")
    return row[2] if row else 0.0


def model_for_tier(tier: str) -> str:
    return MODEL_TIERS.get(tier, MODEL_TIERS["standard"])


# ---------------------------------------------------------------------------
# PROCESS-WIDE cumulative totals.
#
# METER below is deliberately BOTH thread-local AND reset at the top of every
# /api/ask (orchestrator._handle) — that is correct for the per-answer usage
# chip, which must report only the tokens THIS question spent.
#
# It is exactly wrong for the floating FinOps widget. That widget polls
# GET /api/finops, which FastAPI serves on a different worker thread from the
# one that ran /api/ask, so it read a freshly-constructed TokenMeter and
# reported "0 tokens, provider mock" no matter how much Gemini traffic the
# session had actually generated. Even same-thread it would have been wrong,
# since the per-request reset() discards everything but the last question.
#
# So: session totals accumulate here, guarded by a lock, and are never reset by
# the per-request reset(). Two different questions ("what did THIS answer
# cost?" vs "what has this session spent?") now have two different counters
# instead of one counter answering the first question and pretending to answer
# the second.
_CUM_LOCK = threading.Lock()
_CUMULATIVE = {"tokens_in": 0, "tokens_out": 0, "llm_calls": 0,
               "provider": "mock", "model": ""}


def cumulative_snapshot() -> dict:
    """Process-wide LLM usage since start — safe to call from any thread."""
    with _CUM_LOCK:
        c = dict(_CUMULATIVE)
    pin, pout = price_for(c["provider"], c["model"])
    cost = (c["tokens_in"] * pin + c["tokens_out"] * pout) / 1_000_000
    c["est_cost_usd"] = round(cost, 6)
    return c


def reset_cumulative() -> None:
    """Test-only: clear process-wide totals so suites start from zero."""
    with _CUM_LOCK:
        _CUMULATIVE.update({"tokens_in": 0, "tokens_out": 0, "llm_calls": 0,
                            "provider": "mock", "model": ""})


class TokenMeter(threading.local):
    """PER-REQUEST usage. Reset at the start of each question by design."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.tokens_in = 0
        self.tokens_out = 0
        self.llm_calls = 0
        self.provider = "mock"
        self.model = ""

    def add(self, provider, sys_text, user_text, out_text, model=None):
        self.provider = provider
        if model:
            self.model = model
        self.llm_calls += 1
        t_in = (len(sys_text or "") + len(user_text or "")) // 4
        t_out = len(out_text or "") // 4
        self.tokens_in += t_in
        self.tokens_out += t_out
        # Same numbers, second destination: the process-wide session total the
        # FinOps widget reads. Recorded here (not at the call site) so no
        # future provider can spend tokens without the session seeing them.
        with _CUM_LOCK:
            _CUMULATIVE["tokens_in"] += t_in
            _CUMULATIVE["tokens_out"] += t_out
            _CUMULATIVE["llm_calls"] += 1
            _CUMULATIVE["provider"] = provider
            if model:
                _CUMULATIVE["model"] = model

    def snapshot(self):
        pin, pout = price_for(self.provider, self.model)
        cost = (self.tokens_in * pin + self.tokens_out * pout) / 1_000_000
        return {"tokens_in": self.tokens_in, "tokens_out": self.tokens_out,
                "llm_calls": self.llm_calls, "provider": self.provider,
                "model": self.model,
                "est_cost_usd": round(cost, 6)}


METER = TokenMeter()

try:
    import httpx  # only required for real providers, not mock mode
except ImportError:
    httpx = None


def _ssl_verify():
    """SSL verification for provider calls.

    Corporate proxies (Zscaler/Netskope) re-sign TLS certificates with a
    self-signed root, which breaks default verification. Configure in
    Settings -> Network:
      - CA bundle: path to the corporate root CA .pem (recommended)
      - ssl_verify off: skip verification (POC/testing only)
    Also honors REQUESTS_CA_BUNDLE / SSL_CERT_FILE env vars.
    """
    ca = os.environ.get("OPPAL_CA_BUNDLE") \
        or os.environ.get("REQUESTS_CA_BUNDLE") \
        or os.environ.get("SSL_CERT_FILE")
    if ca and os.path.exists(ca):
        return ca
    return os.environ.get("OPPAL_SSL_VERIFY", "1") != "0"


def _post(url: str, headers: dict, body: dict) -> dict:
    r = httpx.post(url, headers=headers, json=body, timeout=60,
                   verify=_ssl_verify())
    r.raise_for_status()
    return r.json()


class LLMProvider(ABC):
    name = "base"

    @abstractmethod
    def _complete(self, system: str, user: str, json_mode: bool = False) -> str | None:
        ...

    def complete(self, system: str, user: str, json_mode: bool = False) -> str | None:
        # Sprint B item 6: hard budget caps and the kill switch are enforced
        # HERE, at the single choke point every real provider call passes
        # through. Returning None rather than raising means a breached budget
        # degrades each agent to its deterministic path — the platform keeps
        # answering, just without the model — instead of surfacing a stack
        # trace to an analyst. The refusal itself is ledgered by the enforcer.
        if self.name != "mock":
            try:
                from ..finops import enforcement
                enforcement.check(task="llm_completion")
            except ImportError:                          # pragma: no cover
                pass
            except Exception as e:
                if type(e).__name__ in ("BudgetExceeded", "KillSwitchEngaged"):
                    log.warning("LLM call refused: %s", e)
                    return None
                raise
        out = self._complete(system, user, json_mode)
        if self.name != "mock":
            METER.add(self.name, system, user, out,
                      model=getattr(self, "model", None))
        return out

    def complete_json(self, system: str, user: str) -> dict | None:
        raw = self.complete(system, user, json_mode=True)
        if raw is None:
            return None
        try:
            raw = raw.strip()
            if raw.startswith("```"):
                raw = raw.split("```")[1].removeprefix("json").strip()
            return json.loads(raw)
        except (json.JSONDecodeError, IndexError):
            return None


class MockProvider(LLMProvider):
    """Returns None so agents use their deterministic fallback paths."""
    name = "mock"

    def _complete(self, system, user, json_mode=False):
        return None


class AnthropicProvider(LLMProvider):
    name = "anthropic"

    def __init__(self):
        self.key = os.environ["ANTHROPIC_API_KEY"]
        self.model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

    def _complete(self, system, user, json_mode=False):
        out = _post(
            "https://api.anthropic.com/v1/messages",
            {"x-api-key": self.key, "anthropic-version": "2023-06-01"},
            {"model": self.model, "max_tokens": 2000, "system": system,
             "messages": [{"role": "user", "content": user}]})
        return out["content"][0]["text"]


class OpenAIProvider(LLMProvider):
    name = "openai"

    def __init__(self):
        self.key = os.environ["OPENAI_API_KEY"]
        self.model = os.environ.get("OPENAI_MODEL", "gpt-4o")
        self.base = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")

    def _complete(self, system, user, json_mode=False):
        body = {"model": self.model,
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": user}]}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        out = _post(f"{self.base}/chat/completions",
                    {"Authorization": f"Bearer {self.key}"}, body)
        return out["choices"][0]["message"]["content"]


class GeminiProvider(LLMProvider):
    name = "gemini"

    def __init__(self):
        self.key = os.environ["GEMINI_API_KEY"]
        # gemini-2.0-flash was retired and now 404s with "no longer
        # available" — an unset GEMINI_MODEL used to break every call.
        self.model = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")

    def _complete(self, system, user, json_mode=False):
        body = {
            "system_instruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {"maxOutputTokens": 2000},
        }
        if json_mode:
            body["generationConfig"]["responseMimeType"] = "application/json"
        out = _post(
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model}:generateContent",
            {"x-goog-api-key": self.key}, body)
        return out["candidates"][0]["content"]["parts"][0]["text"]


class AzureOpenAIProvider(OpenAIProvider):
    name = "azure"

    def __init__(self):
        self.key = os.environ["AZURE_OPENAI_API_KEY"]
        endpoint = os.environ["AZURE_OPENAI_ENDPOINT"].rstrip("/")
        deployment = os.environ["AZURE_OPENAI_DEPLOYMENT"]
        api_ver = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-06-01")
        self.url = (f"{endpoint}/openai/deployments/{deployment}"
                    f"/chat/completions?api-version={api_ver}")

    def _complete(self, system, user, json_mode=False):
        body = {"messages": [{"role": "system", "content": system},
                             {"role": "user", "content": user}]}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        out = _post(self.url, {"api-key": self.key}, body)
        return out["choices"][0]["message"]["content"]


_PROVIDERS = {"mock": MockProvider, "anthropic": AnthropicProvider,
              "openai": OpenAIProvider, "azure": AzureOpenAIProvider,
              "gemini": GeminiProvider}


def get_provider() -> LLMProvider:
    name = os.environ.get("LLM_PROVIDER", "mock").lower()
    try:
        return _PROVIDERS[name]()
    except KeyError:
        raise ValueError(f"Unknown LLM_PROVIDER '{name}'. "
                         f"Choose from {list(_PROVIDERS)}")
