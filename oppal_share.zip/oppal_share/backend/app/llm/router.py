"""Smart routing and automatic failover (Sprint B item 2).

WHAT THIS COUNTERS
------------------
Unity AI Gateway offers a central control plane for traffic splitting, load
balancing and automatic failover across model providers. OpPal had the registry
but none of the behaviour: ``get_provider()`` read one name from config and
instantiated it, with no retry, no fallback and no notion that a cheap
classification and a complex actuarial explanation might warrant different
models.

TWO SEPARATE CAPABILITIES, DELIBERATELY DECOUPLED
-------------------------------------------------
FAILOVER is about availability. If the primary provider is down, try the next
one. It is unconditionally safe: the alternative to a slightly different model
answering is no answer at all.

TIERED ROUTING is about cost. Sending a yes/no classification to Opus 5 wastes
roughly 5x what Haiku 4.5 costs for the same outcome. But this one is NOT
unconditionally safe, which is the point of the guard below.

THE GUARD, AND WHY IT EXISTS
----------------------------
A cheaper model produces different trust scores. Trust scores gate write-back
execution (``execution_trust_gate``) and are written into the immutable ledger.
So a routing decision made purely on cost silently changes governance outcomes:
an action that would have cleared the gate under Sonnet 5 might not under
Haiku 4.5, or — far worse — the reverse.

``TRUST_CRITICAL_TASKS`` is therefore enforced here, in code, not in
configuration: SQL generation, trust scoring, action proposal, policy
evaluation and compliance audit are never downgraded below the standard tier,
whatever the cost policy says. Cost optimization is allowed to make a system
cheaper. It is not allowed to make it differently governed.

Every routing decision is recorded on the meter and lands in the provenance
receipt, so an auditor can see which model produced a given number and whether
a downgrade was involved. That is why this work was sequenced after answer
provenance rather than before it.
"""
from __future__ import annotations

import logging
import os

log = logging.getLogger("oppal.llm.router")

# Ordered fallback chain. The first entry that both resolves and answers wins.
# `mock` is always last: it is the deterministic rules path, and reaching it
# means the platform degrades to non-LLM operation rather than failing.
DEFAULT_CHAIN = ("anthropic", "openai", "gemini", "mock")

# Task -> tier. Anything absent defaults to "standard", never to "cheap":
# an unclassified task is not a licence to downgrade it.
TASK_TIERS = {
    "intent_routing":     "cheap",
    "classification":     "cheap",
    "tagging":            "cheap",
    "summarization":      "cheap",
    "insight_narration":  "standard",
    "cohort_translation": "standard",
    "sql_generation":     "standard",
    "trust_scoring":      "standard",
    "action_proposal":    "standard",
    "policy_evaluation":  "deep",
    "compliance_audit":   "deep",
    "root_cause":         "deep",
}
DEFAULT_TIER = "standard"


class RoutingDecision(dict):
    """A plain dict, so it serializes into the provenance receipt untouched."""


def _chain() -> list:
    """Ordered providers to try.

    `mock` is TERMINAL, never a waypoint. If the operator configured mock as
    the primary they have deliberately chosen not to call an external API — for
    a PHI-bearing workload that is often a compliance decision, not a
    convenience. "Failing over" from mock to Anthropic would then ship data
    off-box against explicit intent and start billing, so a mock primary
    yields a single-entry chain. When a real provider is primary, mock remains
    last as the degradation floor: reaching it means answering from the
    deterministic rules path rather than not answering.
    """
    raw = os.environ.get("OPPAL_LLM_CHAIN", "")
    if raw.strip():
        return [p.strip() for p in raw.split(",") if p.strip()]
    primary = os.environ.get("LLM_PROVIDER", "mock").strip() or "mock"
    if primary == "mock":
        return ["mock"]
    rest = [p for p in DEFAULT_CHAIN if p not in (primary, "mock")]
    return [primary] + rest + ["mock"]


def tier_for(task: str | None) -> str:
    """Resolve a task to a tier, refusing to downgrade a governance task.

    The refusal is the entire point: a cost policy that lowers the tier of
    trust_scoring is not a cost policy, it is a change to how write-backs get
    approved.
    """
    from .base import TRUST_CRITICAL_TASKS
    requested = TASK_TIERS.get((task or "").strip().lower(), DEFAULT_TIER)
    if (task or "").strip().lower() in TRUST_CRITICAL_TASKS \
            and requested == "cheap":
        log.warning("refusing to downgrade trust-critical task '%s' to the "
                    "cheap tier; using '%s'", task, DEFAULT_TIER)
        return DEFAULT_TIER
    return requested


def plan(task: str | None = None) -> RoutingDecision:
    """Decide the tier, model and fallback order for a task — no I/O."""
    from .base import model_for_tier, TRUST_CRITICAL_TASKS
    tier = tier_for(task)
    return RoutingDecision({
        "task": task or "(unspecified)",
        "tier": tier,
        "model": model_for_tier(tier),
        "chain": _chain(),
        "downgrade_blocked": (task or "").strip().lower()
        in TRUST_CRITICAL_TASKS,
    })


# ---------------------------------------------------------------------------
def complete(system: str, user: str, *, task: str | None = None,
             json_mode: bool = False) -> dict:
    """Run a completion with tiered model selection and automatic failover.

    Returns {"text"|"json", "decision", "provider_used", "attempts"}. Never
    raises on provider failure — exhausting the chain lands on the mock
    provider, whose None return makes every agent take its deterministic path.
    """
    from .base import _PROVIDERS, MODEL_TIERS

    decision = plan(task)
    attempts, out, used = [], None, None

    for name in decision["chain"]:
        cls = _PROVIDERS.get(name)
        if cls is None:
            attempts.append({"provider": name, "ok": False,
                             "error": "not a registered provider"})
            continue
        try:
            provider = cls()
            # pin the tier's model on providers that expose one, so a routed
            # call is actually cheaper rather than merely labelled cheaper
            if hasattr(provider, "model") and name == "anthropic":
                provider.model = decision["model"]
            out = (provider.complete_json(system, user) if json_mode
                   else provider.complete(system, user))
            used = name
            attempts.append({"provider": name, "ok": True,
                             "model": getattr(provider, "model", "")})
            break
        except Exception as e:
            log.warning("provider '%s' failed (%s); failing over",
                        name, type(e).__name__)
            attempts.append({"provider": name, "ok": False,
                             "error": f"{type(e).__name__}: {str(e)[:80]}"})
            continue

    decision["provider_used"] = used
    decision["attempts"] = attempts
    decision["failed_over"] = bool(
        used and attempts and attempts[0].get("provider") != used)
    return {"json" if json_mode else "text": out, "decision": decision,
            "provider_used": used, "attempts": attempts}


def summary() -> dict:
    """Routing posture, for the Settings/Governance surface."""
    from .base import MODEL_TIERS, price_for, TRUST_CRITICAL_TASKS
    tiers = {}
    for tier, model in MODEL_TIERS.items():
        pin, pout = price_for("anthropic", model)
        tiers[tier] = {"model": model, "input_per_mtok": pin,
                       "output_per_mtok": pout}
    return {
        "chain": _chain(),
        "tiers": tiers,
        "task_tiers": dict(TASK_TIERS),
        "never_downgraded": sorted(TRUST_CRITICAL_TASKS),
        "policy": ("failover is unconditional; tiered routing never downgrades "
                   "a trust-critical task, because trust scores gate write-back "
                   "execution and are written to the immutable ledger"),
    }
