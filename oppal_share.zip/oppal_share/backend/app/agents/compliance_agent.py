"""Clinical Policy Agent — validates data pulled by the SQL agent
against CMS guidelines (Medicare Advantage program audit protocols,
Medicaid MCO certification). Produces pass/fail findings with the exact
rule, citation, observed value and threshold — the logic tree the
compliance officer inspects in the trust panel.
"""

POLICY_SYSTEM_PROMPT = """You are the Clinical Policy Agent for a US \
Healthcare Payer. You NEVER query data yourself; the Data/SQL Agent \
hands you observed universes and metrics. Your job is to validate them \
against CMS regulatory guidelines and return an auditable logic tree.

Authoritative rulebook (cite exactly):
- 42 CFR §422.2410: MA plans must maintain a Medical Loss Ratio >= 85%.
- 42 CFR §422.568: standard organization determinations within 14 \
calendar days (ODAG universe: medical denials).
- 42 CFR §423.568(b): standard Part D coverage determinations within \
72 hours (CDAG universe: PBM rejects).
- CMS Program Audit Protocol (CDAG), Universe Table 1: every reject \
code 75 (PA required) must generate a coverage-determination notice; \
sustained reject-rate spikes require a formulary-change impact analysis.
- 42 CFR §438.242: Medicaid MCO encounter data submitted within 30 days.
- 42 CFR §438.330: Medicaid quality strategy — HEDIS gap closure plans.

For each rule return: {rule_id, citation, requirement, observed, \
threshold, status: pass|fail|warning, remediation}.
Return STRICT JSON {findings: [...], summary}. Flag anything you cannot \
verify as 'warning' with the missing universe named — never guess."""

from ..data.db import run_query
from ..semantic.brain import get_brain


class ClinicalPolicyAgent:
    def __init__(self, llm):
        self.llm = llm

    def audit(self, question: str, lob_scope: list[str]) -> dict:
        """Coordinated audit: pull universes (Data/SQL agent territory),
        then validate each against the CMS rulebook."""
        lobs = "', '".join(lob_scope)
        universes = {}

        u1 = run_query(
            f"SELECT service_quarter, COUNT(*) AS denials FROM claims "
            f"WHERE status = 'Denied' AND lob IN ('{lobs}') "
            f"GROUP BY service_quarter ORDER BY service_quarter")
        universes["ODAG_denials"] = u1

        u2 = run_query(
            f"SELECT service_quarter, reject_code, COUNT(*) AS rejects "
            f"FROM pharmacy_claims WHERE status = 'Rejected' "
            f"AND lob IN ('{lobs}') "
            f"GROUP BY service_quarter, reject_code ORDER BY 1, 2")
        universes["CDAG_rejects"] = u2

        u3 = run_query(
            f"SELECT c.service_quarter, "
            f"ROUND(SUM(c.paid_amount) * 1.0 / SUM(m.monthly_premium * 3), 3) "
            f"AS mlr FROM claims c JOIN members m "
            f"ON c.member_id = m.member_id WHERE c.lob IN ('{lobs}') "
            f"GROUP BY c.service_quarter ORDER BY c.service_quarter")
        universes["MLR_by_quarter"] = u3

        u4 = run_query(
            f"SELECT lob, ROUND(AVG(CASE WHEN hedis_gap_count > 0 "
            f"THEN 1.0 ELSE 0 END), 3) AS gap_rate, "
            f"ROUND(AVG(raf_score), 3) AS avg_raf FROM members "
            f"WHERE lob IN ('{lobs}') GROUP BY lob")
        universes["HEDIS_RAF"] = u4

        findings = self._validate(universes, lob_scope)
        if self.llm:
            prompt = get_brain()["prompts"].get("policy",
                                                POLICY_SYSTEM_PROMPT)
            out = self.llm.complete_json(
                system=prompt,
                user=f"Question: {question}\nLOB scope: {lob_scope}\n"
                     f"Universes: {self._universes_for_llm(universes)}\n"
                     f"Deterministic findings (verify/extend): {findings}")
            if out and out.get("findings"):
                findings = out["findings"]
        return {"universes": universes, "findings": findings,
                "system_prompt_id": "clinical-policy-v2026.1"}

    @staticmethod
    def _universes_for_llm(universes):
        from .. import config
        if config.load()["privacy"].get("send_row_samples", True):
            return {k: v["rows"][:12] for k, v in universes.items()}
        return {k: f"[{v['row_count']} rows withheld — metadata-only mode]"
                for k, v in universes.items()}

    def _validate(self, universes: dict, lob_scope: list[dict]) -> list[dict]:
        """Executes the declarative rulebook from the Brain
        (policy_rules.md) against the pulled universes."""
        findings = []
        rules = get_brain().get("policy_rules", [])
        mlr_rows = universes["MLR_by_quarter"]["rows"]
        rej_rows = universes["CDAG_rejects"]["rows"]
        den_rows = universes["ODAG_denials"]["rows"]
        hedis_rows = universes["HEDIS_RAF"]["rows"]

        for r in rules:
            check = r.get("check", "")
            base = {"rule_id": r["rule_id"], "citation": r.get("citation", ""),
                    "requirement": r.get("requirement", ""),
                    "remediation": ""}
            if check == "mlr_floor" and mlr_rows:
                if r.get("applies_to") and r["applies_to"] not in lob_scope:
                    continue
                latest_q, latest = mlr_rows[-1][0], mlr_rows[-1][1] or 0
                thr = float(r.get("threshold", 0.85))
                ok = latest >= thr
                findings.append({**base,
                    "observed": f"MLR {latest:.1%} in {latest_q}",
                    "threshold": f">= {thr:.0%}",
                    "status": "pass" if ok else "fail",
                    "remediation": "" if ok else r.get("remediation", "")})
            elif check == "reject_spike" and rej_rows:
                code = str(r.get("code", "75"))
                mult = float(r.get("multiplier", 2))
                min_count = int(r.get("min_count", 50))
                latest_q = max(x[0] for x in rej_rows)
                cur = sum(x[2] for x in rej_rows
                          if x[0] == latest_q and str(x[1]) == code)
                prev_qs = sorted({x[0] for x in rej_rows})[:-1]
                base_counts = [sum(x[2] for x in rej_rows
                                   if x[0] == pq and str(x[1]) == code)
                               for pq in prev_qs] or [0]
                base_avg = sum(base_counts) / max(len(base_counts), 1)
                spike = cur > base_avg * mult and cur > min_count
                findings.append({**base,
                    "observed": f"{cur} code-{code} rejects in {latest_q} "
                                f"vs {base_avg:.0f}/quarter baseline",
                    "threshold": f"<= {mult:g}x trailing baseline",
                    "status": "fail" if spike else "pass",
                    "remediation": r.get("remediation", "") if spike else ""})
            elif check == "reject_volume_warning" and rej_rows:
                codes = [c.strip() for c in
                         str(r.get("codes", "")).split(",") if c.strip()]
                warn_above = int(r.get("warn_above", 200))
                latest_q = max(x[0] for x in rej_rows)
                n = sum(x[2] for x in rej_rows
                        if x[0] == latest_q and str(x[1]) in codes)
                warn = n > warn_above
                findings.append({**base,
                    "observed": f"{n} code-{'/'.join(codes)} rejects "
                                f"in {latest_q}",
                    "threshold": f"reviewed universe (warn > {warn_above})",
                    "status": "warning" if warn else "pass",
                    "remediation": r.get("remediation", "") if warn else ""})
            elif check == "universe_completeness" and den_rows:
                min_q = int(r.get("min_quarters", 8))
                ok = len(den_rows) >= min_q
                findings.append({**base,
                    "observed": f"{den_rows[-1][1]} denials in "
                                f"{den_rows[-1][0]} ({len(den_rows)} "
                                f"quarters populated)",
                    "threshold": f"universe populated for {min_q}+ quarters",
                    "status": "pass" if ok else "warning",
                    "remediation": "" if ok else r.get("remediation", "")})
            elif check == "medicaid_gap_rate":
                thr = float(r.get("threshold", 0.45))
                for lob, gap_rate, avg_raf in hedis_rows:
                    if lob != "Medicaid":
                        continue
                    ok = gap_rate < thr
                    findings.append({**base,
                        "observed": f"{gap_rate:.1%} of Medicaid members "
                                    f"have open gaps (avg RAF {avg_raf})",
                        "threshold": f"gap rate < {thr:.0%} with closure plan",
                        "status": "pass" if ok else "warning",
                        "remediation": "" if ok else r.get("remediation", "")})
        return findings
