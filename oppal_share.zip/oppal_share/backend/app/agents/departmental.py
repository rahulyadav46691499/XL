"""Departmental agent swarm (Phase 3).

Ten personas declared in the Context Brain (`agents.md`) and implemented here
on the Phase 0 agentic framework. Each agent:

  * is constructed from its Brain persona (role, triggers, tool allow-list) —
    the roster is never hardcoded;
  * runs a DETERMINISTIC detector (pure Python over the Phase 2 rules engine /
    root-cause analytics) so a swarm run is fast and cheap; the LLM is used
    only where a persona genuinely needs open-ended language;
  * reads exclusively through the MCP data service with the caller's
    ScopeContext (no agent can widen its own scope);
  * writes findings to the shared blackboard (``ctx.findings``) and a trust
    contribution to ``ctx.trust_components``;
  * degrades via ``framework.Agent.run`` — a failing agent never sinks a run.

A finding is a dict: {agent, kind, severity, headline, detail, evidence,
impact, case (optional case spec)}.
"""
from __future__ import annotations

import logging
import statistics

from ..analytics import root_cause, rules_engine
from ..mcp import data_service
from .framework import Agent, AgentContext

log = logging.getLogger("oppal.swarm")

SEV_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}


def _q(ctx: AgentContext, sql: str) -> dict:
    """Scoped read through the MCP layer (never a direct DB call)."""
    return data_service().run_legacy(sql, ctx.pipeline["scope"],
                                     purpose="swarm")


def _finding(agent, kind, severity, headline, detail="", evidence=None,
             impact=0.0, case=None) -> dict:
    return {"agent": agent, "kind": kind, "severity": severity,
            "headline": headline, "detail": detail,
            "evidence": evidence or {}, "impact": round(impact, 2),
            "case": case}


class DepartmentAgent(Agent):
    """Base for every persona: pulls its definition from the Brain roster."""

    def __init__(self, persona: dict, llm=None, registry=None):
        from .framework import ToolRegistry
        self.persona = persona
        self.name = persona["name"]
        self.prompt_key = persona["name"]
        self.tool_names = list(persona.get("tools", []))
        super().__init__(llm, registry or ToolRegistry())

    @property
    def department(self) -> str:
        return self.persona.get("department", "")

    def trust(self, ctx: AgentContext, value: float):
        ctx.trust_components[self.name] = round(value, 3)

    def act(self, ctx: AgentContext, **kw):
        name = self.persona.get("detector", "") or ""
        detector = getattr(self, name, None)
        if detector is None:
            # DECLARATIVE FALLBACK.
            #
            # Previously an unmapped persona returned [] and contributed no
            # trust: it appeared in the roster, was "activated" by the Sentry,
            # and did nothing. Silent, and worse than an error — a new
            # domain's swarm looked like it ran and simply found nothing,
            # which is indistinguishable from a clean estate.
            #
            # A persona can now declare its own detector in agents.md as SQL
            # plus a finding template, so a domain gets working agents (and,
            # crucially, CASES) with no new Python. If it declares neither a
            # known detector method nor a query, we say so loudly rather than
            # returning empty.
            if self.persona.get("query"):
                return self._declarative(ctx)
            log.warning("persona '%s' declares detector '%s' which does not "
                        "exist and no `query:` — it will find nothing",
                        self.name, name or "(none)")
            self.trust(ctx, 0.0)
            out = [_finding(
                self.name, "misconfigured", "medium",
                f"Agent '{self.name}' is not implemented",
                f"The Brain declares detector '{name or '(none)'}' for this "
                f"persona, but no such detector exists and no `query:` is "
                f"declared. Either add a `query:` block to agents.md or "
                f"remove the persona — an agent that cannot look at anything "
                f"should not appear to have looked.",
                {"persona": self.name, "declared_detector": name})]
            for f in out:
                ctx.findings.append(f)
            return out
        out = detector(ctx) or []
        for f in out:
            ctx.findings.append(f)
        return out

    # ------------------------------------------------------------------
    def _declarative(self, ctx: AgentContext):
        """Run a Brain-declared query and shape rows into findings.

        Fields read from the persona (all optional except `query`):

            query               scoped SQL; every column is available to the
                                templates below as {column}
            finding_kind        label for the finding (default: persona name)
            severity            static severity, or `column:<name>` to read it
            severity_threshold  with severity_column, rows at/above are
                                'critical', below are 'high'
            severity_column     numeric column driving severity
            headline            template, e.g. "Excursion on lot {lot_id}"
            detail              template
            impact_column       column carrying the dollar exposure
            min_impact          skip rows below this impact
            case_type           if present, EVERY emitted row also opens a
                                case of this type — this is what makes the
                                Cases tab work for a new domain
            case_subject_column column identifying the case subject
            case_pattern        pattern label for de-duplication
        """
        p = self.persona
        res = _q(ctx, " ".join(str(p["query"]).split()))
        if not res.get("ok"):
            self.trust(ctx, 0.5)
            log.warning("persona '%s' query failed: %s", self.name,
                        str(res.get("error") or res.get("abac"))[:120])
            return []
        cols = res.get("columns") or []
        rows = [dict(zip(cols, r)) for r in (res.get("rows") or [])]

        sev_static = str(p.get("severity", "") or "").strip()
        sev_col = str(p.get("severity_column", "") or "").strip()
        try:
            sev_thr = float(p.get("severity_threshold"))
        except (TypeError, ValueError):
            sev_thr = None
        imp_col = str(p.get("impact_column", "") or "").strip()
        try:
            min_imp = float(p.get("min_impact"))
        except (TypeError, ValueError):
            min_imp = None
        kind = str(p.get("finding_kind", "") or self.name)
        head_t = str(p.get("headline", "") or f"{self.name} finding")
        det_t = str(p.get("detail", "") or "")
        case_type = str(p.get("case_type", "") or "").strip()
        case_subj = str(p.get("case_subject_column", "") or "").strip()
        case_pat = str(p.get("case_pattern", "") or kind).strip()

        def fmt(tpl, row):
            try:
                return tpl.format(**row)
            except (KeyError, IndexError, ValueError):
                # A template naming a column the query does not return is a
                # Brain authoring error; show the raw template rather than
                # crashing the whole swarm run.
                return tpl

        findings = []
        for row in rows:
            impact = 0.0
            if imp_col and row.get(imp_col) is not None:
                try:
                    impact = float(row[imp_col])
                except (TypeError, ValueError):
                    impact = 0.0
            if min_imp is not None and impact < min_imp:
                continue
            sev = sev_static or "medium"
            if sev_col and sev_thr is not None and row.get(sev_col) is not None:
                try:
                    sev = ("critical" if float(row[sev_col]) >= sev_thr
                           else "high")
                except (TypeError, ValueError):
                    pass
            case = None
            if case_type:
                case = {"case_type": case_type,
                        "subject": str(row.get(case_subj) or "unknown"),
                        "pattern": case_pat,
                        "estimated_impact": impact,
                        "detail": fmt(det_t, row) if det_t else "",
                        "severity": sev}
            findings.append(_finding(
                self.name, kind, sev, fmt(head_t, row),
                fmt(det_t, row) if det_t else "", row,
                impact=impact, case=case))

        self.trust(ctx, 0.92 if findings else 0.88)
        for f in findings:
            ctx.findings.append(f)
        return findings


# ---------------------------------------------------------------------------
# Detectors (one method per Brain `detector:` value)
# ---------------------------------------------------------------------------
class SentryAgent(DepartmentAgent):
    """Triage: scan for live anomalies and pick the departments to activate."""

    def triage(self, ctx: AgentContext):
        findings = []
        # Cheap unprompted anomaly probe on the two payer headline series.
        # Hardcoded to claims/pharmacy_claims, and Sentry always runs, so a
        # non-payer domain used to get "Medical Cost spike" noise on every
        # swarm run -- wrong-domain findings with no error. Same class of bug
        # as app/data/quality.py's anomaly_overview(); same fix (skip a
        # metric whose table isn't governed by the active domain).
        from ..data.quality import _foreign_tables
        _metric_table = {"medical_cost": "claims",
                         "pbm_reject_rate": "pharmacy_claims"}
        _foreign = _foreign_tables()
        for metric, sql in (
            ("medical_cost",
             "SELECT service_quarter, SUM(allowed_amount) FROM claims "
             "GROUP BY service_quarter ORDER BY service_quarter"),
            ("pbm_reject_rate",
             "SELECT service_quarter, AVG(CASE WHEN status='Rejected' "
             "THEN 1.0 ELSE 0 END) FROM pharmacy_claims "
             "GROUP BY service_quarter ORDER BY service_quarter"),
        ):
            if _metric_table.get(metric) in _foreign:
                continue
            r = _q(ctx, sql)
            if not r["ok"] or len(r["rows"]) < 4:
                continue
            # detect_anomalies expects [(period, value), ...] and returns
            # dicts {period, pct_change, z_score, direction}
            series = [(row[0], row[1] or 0) for row in r["rows"]]
            values = dict(series)
            for a in root_cause.detect_anomalies(series):
                period = a["period"]
                findings.append(_finding(
                    self.name, "anomaly",
                    "critical" if abs(a["z_score"]) >= 2.5 else "high",
                    f"{metric.replace('_', ' ').title()} "
                    f"{a['direction']} in {period} "
                    f"({a['pct_change']:+.1f}%)",
                    f"Statistically significant {a['direction']} "
                    f"(z={a['z_score']}) detected in {period}.",
                    {"metric": metric, "period": period,
                     "value": round(values.get(period, 0), 2),
                     "z_score": a["z_score"],
                     "pct_change": a["pct_change"]}))
        self.trust(ctx, 0.95 if findings else 0.9)
        return findings


class MedicalEconomicsAgent(DepartmentAgent):
    def cost_drivers(self, ctx: AgentContext):
        findings = []
        r = _q(ctx, "SELECT service_quarter, SUM(allowed_amount) FROM claims "
                    "GROUP BY service_quarter ORDER BY service_quarter")
        if not r["ok"] or len(r["rows"]) < 2:
            self.trust(ctx, 0.6)
            return findings
        series = [(row[0], row[1] or 0) for row in r["rows"]]
        latest, prev = series[-1], series[-2]
        delta = latest[1] - prev[1]
        pct = (delta / prev[1] * 100) if prev[1] else 0
        sev = "high" if abs(pct) >= 15 else "medium" if abs(pct) >= 7 else "low"
        findings.append(_finding(
            self.name, "cost_trend", sev,
            f"Allowed cost {'up' if delta > 0 else 'down'} {abs(pct):.1f}% "
            f"in {latest[0]}",
            f"{latest[0]}: ${latest[1]:,.0f} vs {prev[0]}: ${prev[1]:,.0f}.",
            {"period": latest[0], "prev": prev[0], "pct_change": round(pct, 1)},
            impact=abs(delta)))
        # additive driver decomposition (deterministic)
        try:
            drivers = root_cause.decompose_additive(
                "medical_cost", latest[0], {}, None,
                ctx.pipeline["scope"].allowed_lobs)
            for d in drivers[:2]:
                findings.append(_finding(
                    self.name, "cost_driver", "medium",
                    f"{d['dimension']} = {d['value']} drove "
                    f"{d['contribution_pct']}% of the movement",
                    "Additive contribution analysis.", d,
                    impact=abs(d.get("delta", 0))))
        except Exception:
            log.debug("additive decomposition unavailable", exc_info=True)
        self.trust(ctx, 0.92)
        return findings


class PBMForensicsAgent(DepartmentAgent):
    def pbm_rejects(self, ctx: AgentContext):
        findings = []
        r = _q(ctx, "SELECT service_quarter, AVG(CASE WHEN status='Rejected' "
                    "THEN 1.0 ELSE 0 END) FROM pharmacy_claims "
                    "GROUP BY service_quarter ORDER BY service_quarter")
        if not r["ok"] or not r["rows"]:
            self.trust(ctx, 0.6)
            return findings
        period = r["rows"][-1][0]
        rate = r["rows"][-1][1] or 0
        try:
            drivers = root_cause.decompose_pbm_rejects(
                period, {}, ctx.pipeline["scope"].allowed_lobs)
        except Exception:
            drivers = []
        for d in drivers[:3]:
            code = d.get("reject_code") or d.get("value")
            findings.append(_finding(
                self.name, "pbm_reject", "high",
                f"NCPDP reject {code} driving rejects in {period}",
                d.get("meaning", "Reject-code decomposition."), d,
                impact=float(d.get("delta", 0) or 0)))
        if not drivers:
            findings.append(_finding(
                self.name, "pbm_reject", "low",
                f"Pharmacy reject rate {rate:.1%} in {period}",
                "No single reject code dominates.", {"period": period}))
        self.trust(ctx, 0.9)
        return findings


class ClinicalUMAgent(DepartmentAgent):
    def pa_triage(self, ctx: AgentContext):
        res = rules_engine.pa_triage(ctx.pipeline["scope"])
        s = res.get("summary", {})
        findings = []
        total = s.get("total", 0)
        if total:
            pended = s.get("pended", 0)
            auto = s.get("auto_approve_eligible", 0)
            sev = "high" if pended / total > 0.5 else "medium"
            findings.append(_finding(
                self.name, "pa_backlog", sev,
                f"{pended} of {total} prior-auth cases pended below the "
                f"{s.get('gate', 0.85):.0%} trust gate",
                f"{auto} case(s) meet criteria AND clear the gate for "
                f"auto-approval; the remainder require UM nurse review.",
                s))
        self.trust(ctx, 0.93 if total else 0.6)
        return findings


class FWASIUAgent(DepartmentAgent):
    def fwa_scan(self, ctx: AgentContext):
        res = rules_engine.fwa_scan(ctx.pipeline["scope"])
        findings = []
        for a in res.get("alerts", []):
            sev = "critical" if (a.get("z_score") or 0) >= 5 else "high"
            findings.append(_finding(
                self.name, "fwa", sev,
                f"{a['pattern'].replace('_', ' ').title()} — provider "
                f"{a['provider_id']}",
                a.get("detail", ""), a,
                impact=a.get("estimated_overpayment", 0),
                case={"case_type": "FWACase", "subject": a["provider_id"],
                      "pattern": a["pattern"],
                      "estimated_impact": a.get("estimated_overpayment", 0),
                      "detail": a.get("detail", ""), "severity": sev}))
        self.trust(ctx, 0.94 if findings else 0.88)
        return findings


class ComplianceAgent(DepartmentAgent):
    def regulatory_timeliness(self, ctx: AgentContext):
        res = rules_engine.determination_timeliness(ctx.pipeline["scope"])
        findings = []
        for u in res.get("universes", []):
            if u["breaches"]:
                sev = "critical" if u["compliance_pct"] < 90 else "high"
                findings.append(_finding(
                    self.name, "regulatory", sev,
                    f"{u['universe']}: {u['breaches']} timeliness breach(es) "
                    f"— {u['compliance_pct']}% compliant",
                    f"{u['citation']}. Breaching cases are listed for the "
                    f"auditor with notice evidence.", u,
                    case={"case_type": "CDAGCase", "subject": u["universe"],
                          "pattern": "timeliness_breach",
                          "estimated_impact": 0.0,
                          "detail": f"{u['breaches']} breaches "
                                    f"({u['compliance_pct']}% compliant)",
                          "severity": sev}))
        self.trust(ctx, 0.95 if findings else 0.9)
        return findings


class NetworkAgent(DepartmentAgent):
    def network_exposure(self, ctx: AgentContext):
        r = _q(ctx, "SELECT p.network_status, COUNT(*) AS n, "
                    "SUM(c.allowed_amount) AS spend FROM claims c "
                    "JOIN providers p ON p.provider_id = c.provider_id "
                    "GROUP BY p.network_status")
        findings = []
        if r["ok"] and r["rows"]:
            cols = r["columns"]
            rows = [dict(zip(cols, row)) for row in r["rows"]]
            total = sum(x["spend"] or 0 for x in rows) or 1
            oon = sum(x["spend"] or 0 for x in rows
                      if "out" in str(x["network_status"]).lower())
            pct = oon / total * 100
            sev = "high" if pct >= 20 else "medium" if pct >= 10 else "low"
            findings.append(_finding(
                self.name, "network_leakage", sev,
                f"Out-of-network spend is {pct:.1f}% of allowed",
                "Network leakage exposure by provider participation status.",
                {"oon_spend": round(oon, 2), "total_spend": round(total, 2),
                 "oon_pct": round(pct, 1)}, impact=oon))
        self.trust(ctx, 0.9)
        return findings


class QualityHEDISAgent(DepartmentAgent):
    def hedis_gaps(self, ctx: AgentContext):
        r = _q(ctx, "SELECT AVG(CASE WHEN hedis_gap_count > 0 THEN 1.0 ELSE 0 "
                    "END) AS gap_rate, SUM(hedis_gap_count) AS gaps, "
                    "COUNT(*) AS members FROM members")
        findings = []
        if r["ok"] and r["rows"]:
            d = dict(zip(r["columns"], r["rows"][0]))
            rate = d.get("gap_rate") or 0
            sev = "high" if rate >= 0.45 else "medium" if rate >= 0.3 else "low"
            findings.append(_finding(
                self.name, "hedis_gap", sev,
                f"{rate:.0%} of members have at least one open HEDIS gap",
                f"{int(d.get('gaps') or 0)} open gaps across "
                f"{int(d.get('members') or 0)} members — prioritize high-RAF "
                f"members for outreach.", d))
        self.trust(ctx, 0.9)
        return findings


class RiskHCCAgent(DepartmentAgent):
    def risk_profile(self, ctx: AgentContext):
        r = _q(ctx, "SELECT acg_risk_band, COUNT(*) AS n, AVG(raf_score) AS "
                    "raf, AVG(pmpm_cost) AS pmpm FROM members "
                    "WHERE acg_risk_band IS NOT NULL GROUP BY acg_risk_band "
                    "ORDER BY acg_risk_band DESC")
        findings = []
        if r["ok"] and r["rows"]:
            cols = r["columns"]
            rows = [dict(zip(cols, row)) for row in r["rows"]]
            top = rows[0]
            total = sum(x["n"] for x in rows) or 1
            share = top["n"] / total * 100
            findings.append(_finding(
                self.name, "risk_concentration",
                "high" if share >= 12 else "medium",
                f"{share:.1f}% of members sit in the highest ACG band "
                f"({top['acg_risk_band']})",
                f"Average RAF {top['raf']:.2f}, PMPM ${top['pmpm']:,.0f} in "
                f"that band.", {"bands": rows[:3]}))
        # MOOP / reinsurance exposure (Pillar 4)
        r2 = _q(ctx, "SELECT COUNT(*) FROM members WHERE moop_accum >= "
                     "moop_limit AND moop_limit > 0")
        if r2["ok"] and r2["rows"]:
            reached = r2["rows"][0][0] or 0
            if reached:
                findings.append(_finding(
                    self.name, "moop_reached", "medium",
                    f"{reached} member(s) have reached their MOOP limit",
                    "Further eligible costs accrue to the plan; check "
                    "reinsurance attachment.", {"members_at_moop": reached}))
        self.trust(ctx, 0.91)
        return findings


class PrescriptiveActionAgent(DepartmentAgent):
    """Turns findings into trust-scored proposals and persistent cases."""

    def propose_actions(self, ctx: AgentContext):
        from . import case_store
        from ..semantic.brain import get_brain
        settings = get_brain().get("swarm_settings", {})
        min_trust = float(settings.get("case_creation_min_trust", 0.6))
        scope = ctx.pipeline["scope"]
        run_trust = (statistics.mean(ctx.trust_components.values())
                     if ctx.trust_components else 0.0)
        actions, created = [], []
        for f in list(ctx.findings):
            spec = f.get("case")
            if not spec:
                continue
            if run_trust < min_trust:
                continue                       # below the case-creation floor
            # Stamp the case with the scope it was derived from:
            #   full scope        -> CROSS_LOB ("ALL")
            #   single LOB        -> that LOB
            #   multi-LOB subset  -> canonical "A|B" label
            # A creator must always be able to see its own case, so we never
            # label a non-full-scope user's case as cross-LOB.
            #
            # BUT: this used the RUNNER's own scope for every case, even a
            # single-incident finding (one shipment, one hub). A full-scope
            # analyst running the swarm made every case "ALL", which only
            # other full-scope viewers can see (_can_see) -- a narrower
            # analyst who legitimately owns that one hub saw nothing. If the
            # finding's own row carries the domain's declared scope column
            # (a persona query chose to select it), that row-level value is
            # the true scope of the incident and takes priority.
            lob = case_store.scope_label(scope)
            scope_col = (get_brain().get("governance") or {}).get(
                "scope_column")
            if scope_col:
                row_val = (f.get("evidence") or {}).get(scope_col)
                if row_val:
                    lob = str(row_val)
            case = case_store.upsert_case(
                case_type=spec["case_type"], lob=lob,
                subject=str(spec["subject"]), pattern=spec["pattern"],
                detail=spec.get("detail", ""),
                severity=spec.get("severity", "medium"),
                trust_score=round(run_trust, 3),
                estimated_impact=float(spec.get("estimated_impact", 0) or 0),
                evidence=f.get("evidence", {}), created_by=f["agent"])
            created.append(case["case_id"])
            actions.append(_finding(
                self.name, "action_proposed",
                spec.get("severity", "medium"),
                f"Case {case['case_id']} "
                f"{'opened' if case.get('created') else 'updated'} — "
                f"{spec['pattern'].replace('_', ' ')}",
                f"Proposed follow-up for {spec['subject']} "
                f"(trust {run_trust:.0%}). Approval & write-back are "
                f"human-in-the-loop (Phase 4).",
                {"case_id": case["case_id"], "status": case["status"],
                 "new": case.get("created", False)},
                impact=float(spec.get("estimated_impact", 0) or 0)))
        self.trust(ctx, 0.9 if actions else 0.85)
        ctx.pipeline["cases_created"] = created
        return actions


# ---------------------------------------------------------------------------
# Registry: Brain persona name -> implementation class
# ---------------------------------------------------------------------------
AGENT_CLASSES = {
    "sentry": SentryAgent,
    "medical_economics": MedicalEconomicsAgent,
    "pbm_forensics": PBMForensicsAgent,
    "clinical_um": ClinicalUMAgent,
    "fwa_siu": FWASIUAgent,
    "compliance": ComplianceAgent,
    "network": NetworkAgent,
    "quality_hedis": QualityHEDISAgent,
    "risk_hcc": RiskHCCAgent,
    "prescriptive_action": PrescriptiveActionAgent,
}


def build_agent(persona: dict, llm=None):
    cls = AGENT_CLASSES.get(persona["name"], DepartmentAgent)
    return cls(persona, llm)
