"""Persistent case store (Phase 3).

Promotes swarm findings into durable, de-duplicated case objects with a triage
lifecycle. Cases are LOB-stamped and only visible to a principal whose scope
covers the case's line of business (same ABAC contract as audiences).

Phase 3 covers create / dedupe / status + owner transitions and querying.
Write-back to the core-admin system (Facets/QNXT) and HITL approval remain
Phase 4 — this module deliberately performs no external writes.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import threading
import time
from datetime import datetime, timezone

log = logging.getLogger("oppal.cases")

CASE_DB = os.environ.get(
    "OPPAL_CASE_DB",
    os.path.join(os.path.dirname(os.path.dirname(__file__)), "data",
                 "cases.db"))

# lifecycle read from the Brain would be over-engineering for a fixed
# workflow; these are the states the ontology declares for FWACase.
STATES = ("open", "reviewing", "referred_siu", "closed")
_lock = threading.Lock()


def _con():
    os.makedirs(os.path.dirname(CASE_DB), exist_ok=True)
    con = sqlite3.connect(CASE_DB, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS cases (
            case_id TEXT PRIMARY KEY,
            case_type TEXT,          -- FWACase | PriorAuthCase | CDAGCase
            dedupe_key TEXT UNIQUE,
            lob TEXT,
            subject TEXT,            -- provider_id / member_id / universe
            pattern TEXT,
            severity TEXT,
            trust_score REAL,
            estimated_impact REAL,
            detail TEXT,
            evidence TEXT,           -- JSON
            status TEXT,
            owner TEXT,
            created_by TEXT,         -- agent name
            created_at TEXT,
            updated_at TEXT,
            occurrences INTEGER DEFAULT 1)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_cases_lob ON cases(lob)")
    con.execute("CREATE INDEX IF NOT EXISTS ix_cases_status ON cases(status)")
    return con


def _dedupe_key(case_type: str, lob: str, subject: str, pattern: str) -> str:
    raw = f"{case_type}|{lob}|{subject}|{pattern}".lower()
    return hashlib.sha256(raw.encode()).hexdigest()[:20]


def _audit(event: str, payload: dict):
    try:
        from ..trust.audit_ledger import _write
        _write({"ts": datetime.now(timezone.utc).isoformat(),
                "kind": "case", "event": event, **payload})
    except Exception:                                     # pragma: no cover
        log.debug("case audit failed", exc_info=True)


# ---------------------------------------------------------------------------
def upsert_case(*, case_type: str, lob: str, subject: str, pattern: str,
                detail: str = "", severity: str = "medium",
                trust_score: float = 0.0, estimated_impact: float = 0.0,
                evidence: dict | None = None,
                created_by: str = "swarm") -> dict:
    """Create a case, or bump an existing identical one (dedupe by
    type+lob+subject+pattern). Never duplicates across swarm runs."""
    key = _dedupe_key(case_type, lob, subject, pattern)
    now = datetime.now(timezone.utc).isoformat()
    with _lock:
        con = _con()
        try:
            row = con.execute("SELECT * FROM cases WHERE dedupe_key = ?",
                              (key,)).fetchone()
            if row:
                con.execute(
                    "UPDATE cases SET occurrences = occurrences + 1, "
                    "updated_at = ?, trust_score = ?, "
                    "estimated_impact = ?, detail = ? WHERE dedupe_key = ?",
                    (now, trust_score, estimated_impact, detail, key))
                con.commit()
                out = dict(con.execute(
                    "SELECT * FROM cases WHERE dedupe_key = ?",
                    (key,)).fetchone())
                out["created"] = False
                return out
            case_id = f"{case_type[:3].upper()}-{key[:8]}"
            con.execute(
                "INSERT INTO cases VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (case_id, case_type, key, lob, subject, pattern, severity,
                 trust_score, estimated_impact, detail,
                 json.dumps(evidence or {}), "open", "", created_by, now,
                 now, 1))
            con.commit()
            _audit("created", {"case_id": case_id, "case_type": case_type,
                               "lob": lob, "pattern": pattern,
                               "created_by": created_by,
                               "trust_score": trust_score})
            out = dict(con.execute("SELECT * FROM cases WHERE case_id = ?",
                                   (case_id,)).fetchone())
            out["created"] = True
            return out
        finally:
            con.close()


CROSS_LOB = "ALL"     # cases derived from the full governed universe
_SEP = "|"            # canonical multi-LOB label separator


def scope_label(scope) -> str:
    """Canonical LOB label for a case created under `scope`.

    full scope -> "ALL"; single LOB -> that LOB; multi-LOB subset -> "A|B"
    (sorted). Never labels a non-full-scope principal's case as cross-LOB, so
    a creator can always see its own case.
    """
    lobs = sorted(getattr(scope, "allowed_lobs", []) or [])
    if not lobs:
        return ""
    if getattr(scope, "is_full_scope", lambda: False)():
        return CROSS_LOB
    return lobs[0] if len(lobs) == 1 else _SEP.join(lobs)


def _label_lobs(label: str, scope) -> set:
    """The set of LOBs a case label represents (ALL = the whole universe)."""
    if label == CROSS_LOB:
        return set(getattr(scope, "full_lobs", []) or []) or {CROSS_LOB}
    return set(label.split(_SEP)) if label else set()


def _can_see(label: str, scope) -> bool:
    """ABAC: a case is visible when the LOBs it was derived from are a subset
    of the viewer's authorized scope (same contract as audiences)."""
    allowed = set(getattr(scope, "allowed_lobs", []) or [])
    if not allowed:
        return False
    if label == CROSS_LOB:
        return bool(getattr(scope, "is_full_scope", lambda: False)())
    case_lobs = _label_lobs(label, scope)
    return bool(case_lobs) and case_lobs <= allowed


def list_cases(scope, *, status: str | None = None,
               case_type: str | None = None) -> list:
    """LOB-scoped listing. A principal sees only cases whose originating scope
    is a subset of their own."""
    if not getattr(scope, "allowed_lobs", None):
        return []
    con = _con()
    try:
        q, args = "SELECT * FROM cases WHERE 1=1", []
        if status:
            q += " AND status = ?"
            args.append(status)
        if case_type:
            q += " AND case_type = ?"
            args.append(case_type)
        q += " ORDER BY estimated_impact DESC, created_at DESC"
        rows = [dict(r) for r in con.execute(q, args)]
    finally:
        con.close()
    return [c for c in rows if _can_see(c["lob"], scope)]


def get_case(case_id: str, scope) -> dict | None:
    con = _con()
    try:
        row = con.execute("SELECT * FROM cases WHERE case_id = ?",
                          (case_id,)).fetchone()
    finally:
        con.close()
    if not row:
        return None
    c = dict(row)
    return c if _can_see(c["lob"], scope) else None


def update_status(case_id: str, status: str, scope, *,
                  owner: str | None = None, actor: str = "") -> dict:
    """Triage transition. Refuses out-of-scope cases and unknown states."""
    if status not in STATES:
        raise ValueError(f"unknown status '{status}'")
    existing = get_case(case_id, scope)
    if not existing:
        raise PermissionError("case not found in your authorized scope")
    now = datetime.now(timezone.utc).isoformat()
    with _lock:
        con = _con()
        try:
            con.execute(
                "UPDATE cases SET status = ?, owner = COALESCE(?, owner), "
                "updated_at = ? WHERE case_id = ?",
                (status, owner, now, case_id))
            con.commit()
        finally:
            con.close()
    _audit("status_changed", {"case_id": case_id,
                              "from": existing["status"], "to": status,
                              "owner": owner, "actor": actor})
    out = dict(existing)
    out.update({"status": status, "owner": owner or existing["owner"],
                "updated_at": now})
    return out


def summary(scope) -> dict:
    cases = list_cases(scope)
    by_status: dict = {}
    by_type: dict = {}
    impact = 0.0
    for c in cases:
        by_status[c["status"]] = by_status.get(c["status"], 0) + 1
        by_type[c["case_type"]] = by_type.get(c["case_type"], 0) + 1
        impact += c["estimated_impact"] or 0
    return {"total": len(cases), "by_status": by_status, "by_type": by_type,
            "estimated_impact": round(impact, 2)}


def reset():
    """Test helper — clears the store."""
    with _lock:
        con = _con()
        try:
            con.execute("DELETE FROM cases")
            con.commit()
        finally:
            con.close()
