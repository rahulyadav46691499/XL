"""Swarm orchestrator (Phase 3) — Sentry-triaged conditional StateGraph.

Flow:
    sentry (always) → triage decides which departments are relevant
      → activated departmental agents run (2–4 typically), each writing
        findings to the shared blackboard
      → prescriptive_action (always) converts qualifying findings into
        persistent, de-duplicated cases
      → synthesis: rank findings, compute run trust, apply the hard gate

Design points:
  * The roster, triggers, tool allow-lists and settings come from the Context
    Brain (`agents.md`) — nothing about the swarm is hardcoded here.
  * Only relevant agents run (mid-market compute mandate): activation is the
    union of always-on agents and trigger/anomaly matches, capped by
    `max_active_agents`.
  * The whole run is expressed as a `framework.StateGraph`, so `describe()`
    renders the exact flow for a BA and the journey trace shows every step.
  * Every agent reads through the MCP data service with the caller's scope.
"""
from __future__ import annotations

import logging
import statistics
import time

from ..semantic.brain import get_brain
from .departmental import build_agent
from .framework import AgentContext, StateGraph

log = logging.getLogger("oppal.swarm")

SEV_RANK = {"critical": 3, "high": 2, "medium": 1, "low": 0}


def roster() -> dict:
    return get_brain().get("agents", {})


def settings() -> dict:
    return get_brain().get("swarm_settings", {})


# ---------------------------------------------------------------------------
def select_agents(question: str, sentry_findings: list | None = None) -> list:
    """Triage: which personas are relevant to this question / these anomalies?
    Returns persona dicts in priority order (always-on first by priority)."""
    q = (question or "").lower()
    people = roster()
    cfg = settings()
    max_active = int(cfg.get("max_active_agents", 4))
    chosen: dict = {}

    for name, p in people.items():
        if p.get("always_on"):
            chosen[name] = p

    # keyword triggers from the question. Matching is token-stem aware so
    # "billing anomalies" still matches the trigger "billing anomaly".
    def _matches(trigger: str, text: str) -> bool:
        if trigger in text:
            return True
        # compare on singular stems, all trigger words must appear
        words = [w.rstrip("s") for w in trigger.split() if w]
        return bool(words) and all(
            any(tok.rstrip("s") == w for tok in text.replace(",", " ").split())
            for w in words)

    # EXPLICIT INTENT OUTRANKS AMBIENT ANOMALIES: a question keyword match is
    # weighted an order of magnitude above an anomaly-driven suggestion, so a
    # user asking about upcoding always gets FWA/SIU even when unrelated
    # anomalies are live and the activation budget is tight.
    KEYWORD_WEIGHT, ANOMALY_WEIGHT = 10, 1
    scores: dict = {}

    def _bump(name, p, weight):
        if name in chosen:
            return
        cur = scores.get(name)
        scores[name] = (cur[0] + weight, p) if cur else (weight, p)

    for name, p in people.items():
        trig = [t for t in p.get("triggers", []) if t and t != "*"]
        hits = sum(1 for t in trig if _matches(t, q))
        if hits:
            _bump(name, p, hits * KEYWORD_WEIGHT)

    # anomaly-driven activation (Sentry's own findings steer the swarm)
    for f in (sentry_findings or []):
        metric = str((f.get("evidence") or {}).get("metric", "")).lower()
        for name, p in people.items():
            if any(t in metric for t in p.get("triggers", []) if t != "*"):
                _bump(name, p, ANOMALY_WEIGHT)

    scored = [(s, p["priority"], name, p) for name, (s, p) in scores.items()]
    scored.sort(key=lambda x: (-x[0], x[1]))
    # `max_active_agents` budgets INVESTIGATING departments. Always-on
    # infrastructure personas (sentry triage, prescriptive action) are not
    # charged against it — otherwise the effective cap silently drops and an
    # explicitly requested department can be crowded out.
    ALWAYS_ON_FREE = {"sentry", "prescriptive_action"}
    budget = max(max_active - len(
        [n for n, p in chosen.items() if n not in ALWAYS_ON_FREE]), 0)
    for _hits, _prio, name, p in scored:
        if budget <= 0:
            break
        if name not in chosen:
            chosen[name] = p
            budget -= 1

    return sorted(chosen.values(), key=lambda p: p["priority"])


# ---------------------------------------------------------------------------
def run_swarm(question: str, user: dict, *, llm=None) -> dict:
    """Execute a swarm investigation for `question` under the user's scope."""
    from ..mcp import scope_from_user
    t0 = time.time()
    scope = scope_from_user(user)
    ctx = AgentContext(user=user)
    ctx.pipeline["scope"] = scope
    ctx.pipeline["question"] = question

    if not scope.is_effective():
        return {"question": question, "activated": [], "findings": [],
                "cases_created": [], "trust": 0.0, "gate_passed": False,
                "summary": "No authorized line-of-business scope — the swarm "
                           "did not run.",
                "flow": [], "trace": [], "ms": 0}

    people = roster()
    graph = StateGraph("departmental_swarm")
    from ..security import agent_acl

    # --- node 1: Sentry (always on) ---------------------------------------
    sentry_persona = people.get("sentry")
    sentry_out: dict = {"findings": []}

    def _run_sentry(c: AgentContext):
        if not sentry_persona:
            return
        if not agent_acl.can_invoke_agent(user, "sentry"):
            return                       # no triage rights, no triage findings
        agent = build_agent(sentry_persona, llm)
        res = agent.run(c)
        sentry_out["findings"] = res.get("result") or []

    graph.add("sentry_triage", _run_sentry)

    # --- node 2: activation decision --------------------------------------
    # Sentry picks on RELEVANCE; the ACL then decides INVOCABILITY. An agent
    # the caller may not invoke is withheld and disclosed, not silently
    # dropped — see security/agent_acl.py for why auto-selection filters
    # while direct invocation refuses.
    activated: list = []
    withheld: list = []

    def _select(c: AgentContext):
        chosen = select_agents(question, sentry_out["findings"])
        allowed, denied = agent_acl.partition(user, chosen)
        withheld.extend(denied)
        activated.extend([p for p in allowed if p["name"] != "sentry"])
        c.pipeline["activated"] = [p["name"] for p in allowed]
        c.pipeline["withheld"] = [d["agent"] for d in denied]

    graph.add("select_departments", _select)

    # --- node 3: departmental agents (conditional) ------------------------
    def _run_departments(c: AgentContext):
        for persona in activated:
            if persona["name"] == "prescriptive_action":
                continue                      # runs last, after all findings
            build_agent(persona, llm).run(c)

    graph.add("departmental_agents", _run_departments)

    # --- node 4: prescriptive action / case creation ----------------------
    def _run_action(c: AgentContext):
        p = people.get("prescriptive_action")
        if p and agent_acl.can_invoke_agent(user, "prescriptive_action"):
            build_agent(p, llm).run(c)

    graph.add("prescriptive_action", _run_action,
              when=lambda c: bool(c.findings))

    graph.execute(ctx)

    # --- synthesis --------------------------------------------------------
    cfg = settings()
    gate = float(cfg.get("trust_gate", 0.85))
    trust = round(statistics.mean(ctx.trust_components.values()), 3) \
        if ctx.trust_components else 0.0
    findings = sorted(ctx.findings,
                      key=lambda f: (-SEV_RANK.get(f.get("severity", "low"), 0),
                                     -(f.get("impact") or 0)))
    top = findings[0] if findings else None
    agents_ran = sorted(set(f["agent"] for f in findings))
    summary = (f"{len(findings)} finding(s) from {len(agents_ran)} "
               f"department(s). Lead: {top['headline']}." if top
               else "No material findings for this question in your scope.")
    if withheld:
        summary += (f" {len(withheld)} relevant specialist(s) withheld — "
                    f"{', '.join(w['agent'] for w in withheld)} — "
                    f"not authorized for your role.")

    agent_acl.record_run(user, question,
                         ctx.pipeline.get("activated", []), withheld)
    return {
        "question": question,
        "activated": ctx.pipeline.get("activated", []),
        "withheld": withheld,
        "departments": [{"name": p["name"], "department": p.get("department"),
                         "role": p.get("role")} for p in activated],
        "findings": findings,
        "cases_created": ctx.pipeline.get("cases_created", []),
        "trust": trust,
        "gate": gate,
        "gate_passed": trust >= gate,
        "summary": summary,
        "flow": graph.describe(),
        "trace": ctx.trace,
        "trust_components": ctx.trust_components,
        "ms": round((time.time() - t0) * 1000, 1),
    }
