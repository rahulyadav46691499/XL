"""Multi-agent orchestrator — US Healthcare Payer/MCO.

Pipeline (every step audit-logged per request/user):
  0. RBAC/ABAC scope resolution + semantic cache probe
  1. Graph RAG grounding (benefit hierarchy + formulary multi-hop)
  2. Intent routing
  3a. Analytics path: SQL agent (LOB-scoped) -> validation gate ->
      root-cause (incl. PBM reject-code decomposition) -> viz -> insight
  3b. Compliance path: Data/SQL agent universes + Clinical Policy agent
      (CMS guideline validation) coordinated for audit readiness
  4. Trust scoring with compliance logic tree
  5. GRACEFUL DEGRADATION: trust < 85% or unresolved semantic hop ->
     refuse SQL output, enqueue to human review queue
"""
import re
import time

from ..semantic import graph as kg
from ..data.db import run_query
from ..mcp import data_service, scope_from_user
from ..analytics import root_cause, cohort_insights
from ..trust import scoring
from ..security.semantic_cache import CACHE
from ..llm.base import METER
from ..security import review_queue
from .intent_router import IntentRouter
from .sql_agent import SQLAgent
from .viz_agent import VizAgent
from .insight_agent import InsightAgent
from .compliance_agent import ClinicalPolicyAgent
from .cohort_agent import CohortAgent, compile_where

CREATE_COHORT_RE = re.compile(
    r"\b(create|build|define|make|save)\b.{0,40}\b(audience|cohort|segment|risk pool)\b",
    re.I)
HARD_GATE = 0.85          # below this: refuse + route to review queue


class Orchestrator:
    def __init__(self, llm):
        self.llm = llm
        self.router = IntentRouter(llm)
        self.sql_agent = SQLAgent(llm)
        self.viz_agent = VizAgent()
        self.insight_agent = InsightAgent(llm)
        self.policy_agent = ClinicalPolicyAgent(llm)
        self.cohort_agent = CohortAgent(llm)
        # rule-only twins for per-request "LLM assist off"
        self._rule_router = IntentRouter(None)
        self._rule_sql = SQLAgent(None)
        self._rule_insight = InsightAgent(None)

    # ------------------------------------------------------------------
    def handle(self, question, cohort_id=None, user=None, pipeline=None):
        """Public entry point. Thin wrapper whose only job is to guarantee
        that every answer — inline, compliance, cohort or degraded — carries
        its provenance receipt.

        _handle() returns from six different places. Attaching the receipt at
        each of them would work until someone added a seventh and it silently
        went un-attributed, so it is attached here, once.
        """
        from ..trust import provenance as _prov
        try:
            _prov.begin()
        except Exception:
            pass
        response = self._handle(question, cohort_id, user, pipeline)
        try:
            if isinstance(response, dict) and "provenance" not in response:
                receipt = _prov.last()
                if receipt:
                    response["provenance"] = receipt
        except Exception:
            pass       # provenance must never break the answer path
        return response

    def _handle(self, question, cohort_id=None, user=None, pipeline=None):
        pipeline = {"use_cache": True, "root_cause": True,
                    "llm_assist": True, "replay": False, **(pipeline or {})}
        if pipeline["replay"]:
            pipeline["llm_assist"] = False   # deterministic replays
        router = self.router if pipeline["llm_assist"] else self._rule_router
        sql_agent = (self.sql_agent if pipeline["llm_assist"]
                     else self._rule_sql)
        insight_agent = (self.insight_agent if pipeline["llm_assist"]
                         else self._rule_insight)
        user = user or {"user_id": "anonymous", "allowed_lobs": [],
                        "authorized": False}
        if not user.get("authorized") or not user.get("allowed_lobs"):
            return self._degraded(
                question, user, None, [],
                "User has no LOB authorizations (RBAC). Select an "
                "authorized analyst in Settings → Access.")

        if CREATE_COHORT_RE.search(question):
            return self.create_cohort(question, user=user)

        cohort = CohortAgent.get(cohort_id, user=user) if cohort_id else None
        if cohort_id and cohort is None:
            return self._degraded(
                question, user, None, [],
                "The requested audience is outside your authorized scope "
                "or no longer exists.")
        audit, t_start = [], time.time()
        METER.reset()
        allowed = user["allowed_lobs"]
        # Phase 1: all analytical reads go through the MCP Zero-Copy data
        # service, which refuses to execute without this scope.
        scope = scope_from_user(user)
        data = data_service()

        tok_prev = [0]

        def step(name, agent, detail, engine="internal"):
            tok_now = METER.tokens_in + METER.tokens_out
            audit.append({"step": name, "agent": agent, "detail": detail,
                          "engine": engine,
                          "tokens": tok_now - tok_prev[0],
                          "ms": round((time.time() - t_start) * 1000, 1)})
            tok_prev[0] = tok_now

        step("access_control", "rbac-abac",
             {"user": user["user_id"], "role": user.get("role"),
              "allowed_lobs": allowed,
              "attributes": user.get("attributes", {})}, engine="internal")

        grounding = kg.ground(question)
        step("semantic_grounding", "graph-rag (Context Brain)",
             {"matched_terms": grounding["matched_terms"],
              "graph_paths": grounding["graph_paths"][:12],
              "source_documents": grounding["source_documents"],
              "coverage": grounding["coverage"]}, engine="internal")

        intent = router.route(question, grounding)
        step("intent_routing", f"intent-router ({intent['source']})",
             {k: v for k, v in intent.items() if k != "extraction_trace"},
             engine="llm" if intent["source"] == "llm" else "internal")

        # RBAC: requested LOB outside scope -> refuse
        want_lob = (intent.get("filters") or {}).get("lob")
        if want_lob and want_lob not in allowed:
            return self._degraded(
                question, user, None, audit,
                f"'{want_lob}' is outside your authorized scope "
                f"({', '.join(allowed)}). Request access via your data "
                f"governance team.")

        # semantic cache probe
        cache_key = CACHE.key(grounding, intent, allowed, cohort_id)
        cached = CACHE.get(cache_key) if pipeline["use_cache"] else None
        if cached:
            cached["cache_hit"] = True
            saved = cached.get("usage", {})
            cached["usage"] = {**saved, "cache_hit": True,
                               "tokens_cached": saved.get("tokens_in", 0)
                               + saved.get("tokens_out", 0),
                               "tokens_in": 0, "tokens_out": 0,
                               "llm_calls": 0, "est_cost_usd": 0.0,
                               "latency_ms": round(
                                   (time.time() - t_start) * 1000, 1)}
            cached["audit"] = audit + [{"step": "semantic_cache",
                                        "agent": "cache",
                                        "detail": {"hit": True,
                                                   "key": cache_key[:24]},
                                        "engine": "cache", "tokens": 0,
                                        "ms": 0}]
            return cached

        if intent["intent"] == "compliance_audit":
            return self._compliance(question, user, grounding, intent,
                                    audit, step, cache_key)

        if cohort:
            step("cohort_scope", "cohort-agent",
                 {"cohort": cohort["name"], "where": cohort["where"]},
                 engine="internal")

        sql_out = sql_agent.generate(question, intent, grounding,
                                     cohort, allowed)
        step("sql_generation", f"sql-agent ({sql_out['source']})",
             {"sql": sql_out["sql"],
              "explanation": sql_out.get("explanation")},
             engine="llm" if sql_out["source"] == "llm" else "internal")

        result = data.run_legacy(sql_out["sql"], scope)
        # STRUCTURAL ABAC: LLM may ignore the RBAC prompt; the gate refuses
        # any out-of-scope SQL regardless of who authored it. Refusal ->
        # governed template (which is LOB-scoped by construction).
        if result.get("gate", {}).get("abac_refused"):
            step("abac_refused", "governance-gate",
                 {"reason": result["abac"]["reason"], "scope": allowed,
                  "action": "falling back to governed template"},
                 engine="internal")
            sql_out = self._rule_sql.generate(question, intent, grounding,
                                              cohort, allowed)
            result = data.run_legacy(sql_out["sql"], scope)
        # RESULT-SHAPE validation: LLM SQL can execute yet be malformed
        expected = intent.get("metric")
        shape_bad = (result["ok"] and sql_out["source"] == "llm"
                     and expected and expected not in result["columns"])
        if shape_bad:
            step("llm_sql_shape_rejected", "governance-gate",
                 {"expected_column": expected,
                  "got_columns": result["columns"],
                  "action": "falling back to governed template"},
                 engine="internal")
            sql_out = self._rule_sql.generate(question, intent, grounding,
                                              cohort, allowed)
            result = data.run_legacy(sql_out["sql"], scope)
        if not result["ok"] and sql_out["source"] == "llm":
            # LLM SQL failed a validation gate -> governed template retry
            step("llm_sql_rejected", "governance-gate",
                 {"gate": result["gate"],
                  "action": "falling back to governed template"},
                 engine="internal")
            sql_out = self._rule_sql.generate(question, intent, grounding,
                                              cohort, allowed)
            step("sql_generation", "sql-agent (template fallback)",
                 {"sql": sql_out["sql"]}, engine="internal")
            result = data.run_legacy(sql_out["sql"], scope)
        step("validation_and_execute", "query-executor",
             {"gate": result["gate"], "row_count": result.get("row_count", 0),
              "ms": result.get("ms")}, engine="data")

        analysis = {"anomalies": [], "drivers": []}
        if pipeline["root_cause"] and intent["intent"] in ("metric_trend",
                                                           "root_cause"):
            try:                     # stage guard: never sink the answer
                analysis = root_cause.analyze(
                    intent.get("metric", ""), result,
                    intent.get("filters", {}), cohort, allowed)
            except Exception as e:
                step("root_cause_skipped", "governance-gate",
                     {"error": f"{type(e).__name__}: {e}"},
                     engine="internal")
        step("root_cause_analysis", "insight-miner (z-score + mix-shift)",
             {"anomalies": analysis["anomalies"],
              "drivers": analysis["drivers"]}, engine="internal")

        trust = scoring.score(
            grounding, result["gate"], result, sql_out["source"],
            grounding["metrics"],
            logic_tree=self._logic_tree(grounding, intent, sql_out),
            point_lookup=intent["intent"] in ("formulary_lookup",
                                              "detail_lookup", "top_n",
                                              "breakdown"))
        step("trust_scoring", "trust-engine",
             {k: v for k, v in trust.items() if k != "logic_tree"},
             engine="internal")

        # ---- GRACEFUL DEGRADATION (hard gate) -------------------------
        if trust["score"] < HARD_GATE:
            return self._degraded(
                question, user, trust, audit,
                f"Trust score {trust['score']:.0%} is below the "
                f"{HARD_GATE:.0%} enterprise gate — the generated SQL was "
                f"withheld rather than risk an uncertain answer.",
                grounding)

        try:                         # stage guard
            artifacts = self.viz_agent.build(intent, result, analysis)
        except Exception as e:
            artifacts = [{"type": "grid", "title": "Underlying data",
                          "columns": result["columns"],
                          "rows": result["rows"], "collapsed": False}]
            step("viz_degraded", "governance-gate",
                 {"error": f"{type(e).__name__}: {e}"}, engine="internal")
        step("visualization", "viz-agent",
             {"artifacts": [a["type"] for a in artifacts]},
             engine="internal")
        insight = insight_agent.narrate(question, intent, result,
                                        analysis, grounding)
        step("insight_narration",
             f"insight-agent ({'llm' if self.llm and METER.llm_calls else 'rules'})",
             {"followups": insight.get("followups", [])},
             engine="llm" if (self.llm and
                              METER.tokens_in + METER.tokens_out
                              > tok_prev[0]) else "internal")

        usage = {**METER.snapshot(), "cache_hit": False,
                 "tokens_cached": 0,
                 "rows_scanned": result.get("row_count", 0),
                 "latency_ms": round((time.time() - t_start) * 1000, 1)}
        response = {
            "question": question,
            "usage": usage,
            "summary": (f"[Audience: {cohort['name']}] " if cohort else "")
                       + insight["summary"],
            "artifacts": artifacts,
            "followups": insight.get("followups", []),
            "analysis": analysis, "trust": trust, "audit": audit,
            "sql": sql_out["sql"], "cache_hit": False,
            "active_cohort": ({"id": cohort["id"], "name": cohort["name"]}
                              if cohort else None),
            "acting_user": {"user_id": user["user_id"],
                            "allowed_lobs": allowed},
            "grounding": {"matched_terms": grounding["matched_terms"],
                          "source_documents": grounding["source_documents"],
                          "metrics": {k: v["definition"] for k, v in
                                      grounding["metrics"].items()}},
        }
        response["pipeline"] = pipeline
        receipt = self._persist_audit(question, user, audit, trust,
                                      sql_out["sql"])
        if receipt:
            response["provenance"] = receipt
        # cache AFTER provenance is attached, so a cache hit replays the same
        # receipt rather than returning an answer with no attribution
        if pipeline["use_cache"]:
            CACHE.put(cache_key, response)
        return response

    # ------------------------------------------------------------------
    def _compliance(self, question, user, grounding, intent, audit, step,
                    cache_key):
        """Coordinated Data/SQL + Clinical Policy agent workflow."""
        allowed = user["allowed_lobs"]
        result = self.policy_agent.audit(question, allowed)
        step("universe_pull", "data-sql-agent",
             {u: {"rows": r["row_count"]} for u, r in
              result["universes"].items()}, engine="data")
        step("policy_validation",
             "clinical-policy-agent (Brain rulebook)",
             {"findings": result["findings"]},
             engine="llm" if self.llm else "internal")

        findings = result["findings"]
        n_fail = sum(1 for f in findings if f["status"] == "fail")
        n_warn = sum(1 for f in findings if f["status"] == "warning")

        artifacts = [{
            "type": "insights",
            "title": "CMS guideline validation — Clinical Policy Agent",
            "items": [
                ("⚠ " if f["status"] != "pass" else "✓ ")
                + f"[{f['rule_id']}] {f['requirement']} — {f['observed']} "
                  f"({f['citation']})"
                + (f" → {f['remediation']}" if f.get("remediation") else "")
                for f in findings]}]
        cdag = result["universes"]["CDAG_rejects"]
        if cdag["ok"] and cdag["rows"]:
            artifacts.append({"type": "grid",
                              "title": "CDAG universe — PBM rejects by code",
                              "columns": cdag["columns"], "rows": cdag["rows"],
                              "collapsed": False})
        mlr = result["universes"]["MLR_by_quarter"]
        if mlr["ok"] and mlr["rows"]:
            artifacts.append({
                "type": "chart", "chart_type": "line",
                "title": "MLR by quarter vs 85% floor (42 CFR §422.2410)",
                "x": "quarter", "series": ["mlr"], "format": "percent",
                "columns": ["quarter", "mlr"], "rows": mlr["rows"]})

        logic_tree = self._logic_tree(grounding, intent, None)
        logic_tree["policy_rules"] = [
            {"rule_id": f["rule_id"], "citation": f["citation"],
             "observed": f["observed"], "threshold": f["threshold"],
             "status": f["status"]} for f in findings]
        trust = scoring.score(
            grounding,
            {"read_only": True, "parses": True, "single_statement": True,
             "passed": True},
            {"ok": True, "row_count": len(findings)},
            "template", grounding["metrics"] or {"_": {"certified": True}},
            logic_tree=logic_tree)
        step("trust_scoring", "trust-engine",
             {"score": trust["score"], "findings_fail": n_fail},
             engine="internal")

        usage = {**METER.snapshot(), "cache_hit": False, "tokens_cached": 0,
                 "rows_scanned": sum(
                     r.get("row_count", 0)
                     for r in result["universes"].values()),
                 "latency_ms": 0}
        response = {
            "question": question,
            "usage": usage,
            "summary": (f"Audit readiness ({', '.join(allowed)}): "
                        f"{len(findings)} CMS checks — "
                        f"{len(findings) - n_fail - n_warn} pass, "
                        f"{n_warn} warnings, {n_fail} FAIL. "
                        + ("Primary exposure: code-75 paid-reject surge "
                           "from the 2026-04-01 GLP-1 formulary change."
                           if n_fail else "No failing controls detected.")),
            "artifacts": artifacts,
            "followups": ["Why did pharmacy rejects spike in 2026Q2?",
                          "Show mlr trend for Medicare Advantage",
                          "Show rejected pharmacy claims detail for reject code 75"],
            "analysis": {"anomalies": [], "drivers": []},
            "trust": trust, "audit": audit,
            "sql": "-- audit universes pulled by data/sql agent "
                   "(see agent trace)",
            "cache_hit": False, "active_cohort": None,
            "acting_user": {"user_id": user["user_id"],
                            "allowed_lobs": allowed},
            "grounding": {"matched_terms": grounding["matched_terms"],
                          "source_documents": grounding["source_documents"],
                          "metrics": {}},
        }
        CACHE.put(cache_key, response)
        self._persist_audit(question, user, audit, trust, None)
        return response

    # ------------------------------------------------------------------
    def _degraded(self, question, user, trust, audit, reason,
                  grounding=None):
        """Strict refusal + human-in-the-loop routing."""
        item = review_queue.enqueue(
            question, user.get("user_id", "anonymous"), reason, trust,
            (grounding or {}).get("matched_terms", []))
        audit = audit + [{"step": "graceful_degradation",
                          "agent": "governance-gate",
                          "detail": {"reason": reason,
                                     "review_ticket": item["id"]},
                          "engine": "internal", "tokens": 0, "ms": 0}]
        self._persist_audit(question, user, audit, trust, None)
        return {
            "question": question,
            "usage": {**METER.snapshot(), "cache_hit": False,
                      "tokens_cached": 0, "rows_scanned": 0,
                      "latency_ms": 0},
            "summary": ("⛔ I can't answer this confidently, so no SQL was "
                        f"generated. {reason} The request was routed to the "
                        f"human review queue (ticket #{item['id']}). Try "
                        "rephrasing with governed terms from the Semantic "
                        "Graph tab (e.g. 'MLR', 'pbm reject rate', "
                        "'claim severity')."),
            "artifacts": [], "followups": [
                "How is mlr trending?",
                "Why did pharmacy rejects spike in 2026Q2?",
                "Run a Medicare Advantage audit readiness check"],
            "analysis": {"anomalies": [], "drivers": []},
            "trust": trust, "audit": audit, "sql": "-- withheld",
            "degraded": True, "review_ticket": item["id"],
            "cache_hit": False, "active_cohort": None,
            "acting_user": {"user_id": user.get("user_id"),
                            "allowed_lobs": user.get("allowed_lobs", [])},
            "grounding": {"matched_terms":
                          (grounding or {}).get("matched_terms", []),
                          "source_documents": [], "metrics": {}},
        }

    # ------------------------------------------------------------------
    @staticmethod
    def _logic_tree(grounding, intent, sql_out):
        return {
            "entity_extraction":
                grounding.get("extraction_trace", [])
                + intent.get("extraction_trace", []),
            "source_documents": grounding.get("source_documents", []),
            "graph_paths": grounding.get("graph_paths", [])[:10],
            "sql_template": (sql_out or {}).get("explanation", ""),
        }

    @staticmethod
    def _persist_audit(question, user, audit, trust, sql):
        """Single choke point for every answer path — inline, cohort, and
        degraded all land here, so provenance is recorded once, here."""
        try:
            from ..trust.audit_ledger import log_agent_steps
            log_agent_steps("inline", user.get("user_id", "anonymous"),
                            question, audit, trust, sql)
        except Exception:
            pass   # audit persistence must never break the answer path
        try:
            # Recommendation 2: pin the model, prompt and governed-policy
            # version that produced this answer, so an auditor can ask
            # "is this still reproducible?" and get a field-level answer.
            from ..trust import provenance
            return provenance.record(question, user, trust, sql)
        except Exception:
            return None   # provenance must never break the answer path

    # ------------------------------------------------------------------
    def compare_cohorts(self, id_a, id_b, user=None):
        a, b = CohortAgent.get(id_a, user), CohortAgent.get(id_b, user)
        if not a or not b:
            return {"summary": "One of the audiences no longer exists.",
                    "artifacts": [], "followups": [], "trust": None,
                    "audit": [], "sql": "",
                    "grounding": {"matched_terms": [], "metrics": {}}}
        t0 = time.time()
        cmp = cohort_insights.compare(a, b)
        audit = [{"step": "cohort_comparison", "agent": "insight-miner",
                  "detail": {"a": a["name"], "b": b["name"],
                             "insights": cmp["insights"]},
                  "ms": round((time.time() - t0) * 1000, 1)}]
        return {
            "question": f"Compare audiences: {a['name']} vs {b['name']}",
            "summary": f"Comparative analysis of '{a['name']}' vs "
                       f"'{b['name']}'. "
                       + (cmp["insights"][0] if cmp["insights"] else ""),
            "artifacts": cmp["artifacts"],
            "followups": [f"Why is claim severity different between these audiences?",
                          "Show hedis gap rate by lob",
                          "Show raf score by lob"],
            "analysis": {"anomalies": [], "drivers": []},
            "trust": scoring.score({"coverage": 1.0},
                                   {"read_only": True, "parses": True,
                                    "single_statement": True, "passed": True},
                                   {"ok": True,
                                    "row_count": len(cmp["profiles"])},
                                   "template", {}),
            "audit": audit,
            "sql": f"-- A: WHERE {a['where']}\n-- B: WHERE {b['where']}",
            "active_cohort": None,
            "grounding": {"matched_terms": [a["name"], b["name"]],
                          "metrics": {}},
        }

    def create_cohort(self, question, name=None, user=None):
        audit, t0 = [], time.time()
        # parse() now returns VALIDATED filters plus whatever it refused, so
        # the predicate shown here, the profile computed below and the cohort
        # stored by create() are all the same thing. They previously were not:
        # this path compiled the raw parser output, so a hallucinated value
        # produced a predicate that matched nothing while create() quietly
        # saved a clean one.
        parsed = self.cohort_agent.parse(question)
        where, needs_m = compile_where(parsed["filters"], _validated=True)
        where = where or "1=1"
        rejected = parsed.get("rejected") or []
        audit.append({"step": "cohort_parsing",
                      "agent": f"cohort-agent ({parsed['source']})",
                      "detail": {"filters": parsed["filters"],
                                 "where": where,
                                 "rejected_filters": rejected},
                      "ms": round((time.time() - t0) * 1000, 1)})
        auto = cohort_insights.analyze(where, needs_m,
                                       name or parsed["name"])
        audit.append({"step": "auto_insights", "agent": "insight-miner",
                      "detail": {"n_insights": len(auto["insights"]),
                                 "lifts": auto["lifts"][:3]},
                      "ms": round((time.time() - t0) * 1000, 1)})
        cohort = self.cohort_agent.create(question, auto["profile"],
                                          parsed, name, user=user)
        artifacts = []
        if auto["insights"]:
            artifacts.append({"type": "insights",
                              "title": f"Auto-detected patterns — {cohort['name']}",
                              "items": auto["insights"]})
        if auto["lifts"]:
            artifacts.append({
                "type": "chart", "chart_type": "bar",
                "title": "What makes this risk pool different (lift vs book)",
                "x": "attribute", "series": ["lift"], "format": "number",
                "columns": ["attribute", "lift"],
                "rows": [[f"{l['dimension']}={l['value']}", l["lift"]]
                         for l in auto["lifts"]]})
        if auto["trend"].get("rows"):
            artifacts.append({
                "type": "chart", "chart_type": "line",
                "title": "Claim volume in this risk pool",
                "x": "quarter", "series": ["claim_count"],
                "format": "number",
                "columns": auto["trend"]["columns"],
                "rows": auto["trend"]["rows"]})
        gate_result = run_query(
            "SELECT COUNT(*) FROM claims c "
            + ("JOIN members m ON c.member_id = m.member_id "
               if needs_m else "") + f"WHERE {where}")
        # run_query()'s row_count is len(rows) — the number of RESULT ROWS,
        # not the COUNT(*) value. A COUNT(*) with no GROUP BY always returns
        # exactly one row, so gate_result["row_count"] is 1 whether the
        # audience matches 1 claim or 100,000. Feeding that straight into
        # the trust scorer pinned data_sufficiency at 0.5 for every cohort
        # ever created (n=1 is neither 0 nor >=3) and showed "Only 1 row(s)
        # returned" regardless of the true match size — reproduced: the
        # Medicare Advantage / GLP-1 cohort actually matches 1,068 claims,
        # not 1. Unwrap the real count from the returned row before scoring.
        n_claims = (gate_result["rows"][0][0]
                    if gate_result.get("ok") and gate_result.get("rows")
                    else 0)
        scoring_result = dict(gate_result, row_count=n_claims)
        trust = scoring.score(
            {"coverage": min(len(parsed["filters"]) * 0.34, 1.0)},
            gate_result["gate"], scoring_result,
            "template" if parsed["source"] == "rules" else "llm", {})
        audit.append({"step": "trust_scoring", "agent": "trust-engine",
                      "detail": {"score": trust["score"]},
                      "ms": round((time.time() - t0) * 1000, 1)})
        prof = auto["profile"]
        summary = (f"Risk pool '{cohort['name']}' saved "
                   f"({len(parsed['filters'])} filters). ")
        if not prof.get("empty"):
            summary += (f"It matches {prof['claims']:,} claims — "
                        f"{prof['share_of_book'] * 100:.1f}% of the book. "
                        f"Select it to scope your next questions.")
        else:
            summary += "No claims match — widen the definition."
        # Refusals belong in the SUMMARY, not only in a panel. A dropped
        # clause silently narrows or widens every number scoped to this
        # audience, so the person reading the answer has to see it.
        if rejected:
            summary += (f" ⚠ {len(rejected)} clause(s) were not applied: "
                        + "; ".join(r.get("reason", "") for r in rejected[:3]))
        return {"question": question, "summary": summary,
                "artifacts": artifacts, "followups": auto["suggestions"],
                "analysis": {"anomalies": auto["trend"].get("anomalies", []),
                             "drivers": []},
                "trust": trust, "audit": audit,
                "sql": f"-- audience predicate\nWHERE {where}",
                "cohort": cohort, "active_cohort": None,
                "grounding": {"matched_terms":
                              [f["field"] for f in parsed["filters"]],
                              "metrics": {}}}
