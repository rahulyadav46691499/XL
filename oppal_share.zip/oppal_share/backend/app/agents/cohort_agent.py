"""Audience Builder — payer RISK POOLS.

Plain English -> governed cohort over the claims book joined to member
risk attributes: RAF scores (CMS-HCC), HEDIS care gaps, dual
eligibility, LOB, diagnosis, cost thresholds. Patterns are auto-mined
on creation (severity, RAF, HEDIS vs book).
"""
import json
import os
import re
import time
import uuid

STORE_PATH = os.environ.get(
    "COHORT_STORE_PATH",
    os.path.join(os.path.dirname(__file__), "..", "data", "cohorts.json"))

from ..semantic.brain import get_brain

# Every lookup below accepts an optional `brain` override (a dict shaped like
# get_brain()'s return value). Phase 5's simulator passes its FORKED (deep
# copied) brain here so cohort resolution never touches the live singleton —
# see app/simulation/isolation.py. Default None preserves Phase 0-3 behavior
# exactly (falls back to the live get_brain()).


def _vals(dim, brain=None):
    return (brain or get_brain()).get("dim_values", {}).get(dim, [])


def _fields(brain=None):
    b = brain or get_brain()
    return b.get("cohort_fields", {}), b.get("cohort_member_fields", set())


def _rx_fields(brain=None):
    return (brain or get_brain()).get("cohort_rx_fields", set())


# Dimensions whose values come from a closed vocabulary in the Brain. A value
# outside it cannot match a single row, so accepting one produces a cohort
# that is silently, permanently empty.
_CLOSED_DIMS = ("lob", "region", "claim_type", "diagnosis_category",
                "drug_class", "status", "pharmacy_type", "age_band")

_QUARTER_RE = re.compile(r"^(20\d\d)\s*[-_ ]?\s*[Qq]\s*([1-4])$")
_QUARTER_REV = re.compile(r"^[Qq]\s*([1-4])\s*[-_ ]?\s*(20\d\d)$")


def normalize_quarter(v):
    """Any reasonable spelling of a quarter -> the canonical ``2026Q2``.

    The warehouse stores ``2026Q2``. A model that emits ``2024-Q2`` is
    especially dangerous here because SQLite string-compares it as TRUE
    against every real quarter ('Q' > '-'), so the filter looks like it
    works while meaning nothing. Returns None when it is not a quarter.
    """
    s = str(v).strip()
    m = _QUARTER_RE.match(s) or None
    if m:
        return f"{m.group(1)}Q{m.group(2)}"
    m = _QUARTER_REV.match(s)
    if m:
        return f"{m.group(2)}Q{m.group(1)}"
    return None


def _canonical_value(dim, value, brain=None):
    """Match a model-supplied value to the Brain's vocabulary.

    Case- and punctuation-insensitive, and tolerant of a near miss
    ('GLP1 agonist' -> 'GLP-1 Agonist'), because rejecting a value the user
    clearly meant is its own kind of wrong. Returns None if there is no
    defensible match.
    """
    allowed = _vals(dim, brain)
    if not allowed:
        return value                    # open vocabulary — nothing to check
    s = str(value).strip()
    norm = lambda x: re.sub(r"[^a-z0-9]", "", str(x).lower())
    for a in allowed:
        if s == a:
            return a
    for a in allowed:
        if norm(s) == norm(a):
            return a
    # containment, but only when unambiguous
    hits = [a for a in allowed if norm(s) and norm(s) in norm(a)]
    return hits[0] if len(hits) == 1 else None


def _did_you_mean(dim, value, brain=None):
    """Closest vocabulary entry to a rejected value, or None.

    Used only to MAKE A REJECTION ACTIONABLE — never to auto-correct. Quietly
    repairing a governance value is how 'Medicaid' becomes 'Medicare' and a
    number reaches a regulator scoped to the wrong population. The system
    should say what it thinks you meant and let you decide.
    """
    import difflib
    allowed = [str(a) for a in _vals(dim, brain)]
    if not allowed:
        return None
    norm = lambda x: re.sub(r"[^a-z0-9]", "", str(x).lower())
    scored = sorted(((difflib.SequenceMatcher(
        None, norm(value), norm(a)).ratio(), a) for a in allowed),
        reverse=True)
    best, second = scored[0], (scored[1] if len(scored) > 1 else (0.0, None))
    # Require a strong match that is also clearly better than the runner-up,
    # so we never nudge someone between two genuinely similar LOB names.
    if best[0] >= 0.85 and best[0] - second[0] >= 0.15:
        return best[1]
    return None


def validate_filters(filters, brain=None):
    """Return (accepted, rejected) — the governance gate for a cohort.

    Cohort predicates were compiled and SAVED straight from whatever the
    parser produced. With an LLM parser that meant a hallucinated value
    (claim_type = 'Pharmacy', which is not one of Inpatient/Outpatient/ER/
    Specialist Visit/Lab) or a mis-formatted quarter became a governed,
    reusable artifact that silently matched nothing. An audience that cannot
    match a row is not a narrow audience — it is a broken one, and the user
    deserves to be told which clause broke it rather than seeing an empty
    profile and guessing.
    """
    field_sql, _ = _fields(brain)
    accepted, rejected = [], []
    for f in (filters or []):
        if not isinstance(f, dict):
            rejected.append({"filter": f, "reason": "malformed filter"})
            continue
        field, op, val = f.get("field"), f.get("op", "="), f.get("value")
        if field not in field_sql:
            rejected.append({
                "filter": f, "field": field,
                "reason": f"'{field}' is not a cohort dimension in this "
                          f"domain's Brain"})
            continue
        if op not in ("=", "!=", ">", "<", ">=", "<="):
            rejected.append({"filter": f, "field": field,
                             "reason": f"unsupported operator '{op}'"})
            continue
        if field == "service_quarter":
            q = normalize_quarter(val)
            if not q:
                rejected.append({
                    "filter": f, "field": field,
                    "reason": f"'{val}' is not a quarter — expected a form "
                              f"like 2026Q2"})
                continue
            accepted.append({"field": field, "op": op, "value": q})
            continue
        if field in _CLOSED_DIMS and op in ("=", "!="):
            canon = _canonical_value(field, val, brain)
            if canon is None:
                allowed = _vals(field, brain)
                hint = _did_you_mean(field, val, brain)
                rejected.append({
                    "filter": f, "field": field, "did_you_mean": hint,
                    "reason": f"'{val}' is not a known {field}"
                              + (f" — did you mean '{hint}'?" if hint else "")
                              + (f" Valid values: {', '.join(map(str, allowed))}"
                                 if allowed else "")})
                continue
            accepted.append({"field": field, "op": op, "value": canon})
            continue
        if field in ("allowed_amount", "raf_score", "monthly_premium",
                     "hedis_gap_count", "fraud_flag", "dual_eligible"):
            try:
                num = float(val)
            except (TypeError, ValueError):
                rejected.append({"filter": f, "field": field,
                                 "reason": f"'{val}' is not numeric"})
                continue
            accepted.append({"field": field, "op": op,
                             "value": int(num) if num == int(num) else num})
            continue
        accepted.append({"field": field, "op": op, "value": val})
    return accepted, rejected

# resolved lazily from the Brain
FIELD_SQL = {}
MEMBER_FIELDS = set()

COHORT_SYSTEM_PROMPT = """Parse a plain-English RISK POOL definition for \
a US healthcare payer into JSON filters over ONLY these fields: {fields}.
Ops: =, !=, >, <, >=, <=.

CLOSED VOCABULARIES — use a value EXACTLY as listed or omit the filter:
  lob: {lobs}
  claim_type: {claim_types}
  diagnosis_category: {diags}
  drug_class: {drug_classes}
  region: {regions}

HARD RULES:
- NEVER invent a value that is not listed. 'Pharmacy' is NOT a claim_type; \
pharmacy is expressed with drug_class / formulary_tier.
- NEVER substitute a related concept for one you cannot express. A drug class \
is NOT a diagnosis_category: "GLP-1" means drug_class = 'GLP-1 Agonist', \
never diagnosis_category = 'Diabetes'. If a concept has no field, OMIT it.
- service_quarter values look like {quarter_example} — never '2024-Q2'. \
A month means its quarter ("since April 2026" => >= 2026Q2).
- Risk semantics: 'high risk' => raf_score > 1.2; 'dual eligible' => \
dual_eligible = 1; 'open care gaps'/'HEDIS gaps' => hedis_gap_count > 0.

Return {{"name": short-name, "filters": [{{"field","op","value"}}]}}"""


def _load():
    if os.path.exists(STORE_PATH):
        with open(STORE_PATH) as f:
            return json.load(f)
    return {}


def _save(store):
    os.makedirs(os.path.dirname(STORE_PATH), exist_ok=True)
    with open(STORE_PATH, "w") as f:
        json.dump(store, f, indent=1)


def _lit(v):
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def compile_where(filters, brain=None, _validated=False):
    """-> (SQL predicate for the CLAIMS base, needs_members_join)

    Pharmacy dimensions cannot be a column on the medical claims table, so a
    pharmacy clause is expressed as a correlated EXISTS over the member: "a
    claim belonging to a member who has a GLP-1 pharmacy claim". That is the
    semantics an analyst means by "Medicare Advantage members with GLP-1
    pharmacy claims", and it keeps the predicate a single string the SQL agent
    can drop into any medical query unchanged.

    VALIDATES ITS OWN INPUT. The first attempt at this fix put validation in
    ``create()`` only — but ``compile_where`` has four call sites, and the
    orchestrator's cohort path called it with the raw parser output. The
    result was a three-way split: the displayed predicate and the profile were
    built from unvalidated filters (so an audience matched nothing) while
    ``create()`` separately stored a clean one and reported the rejection.
    A guard on one call site is not a guard. Validation is idempotent, so
    revalidating clean filters costs nothing and makes the unsafe call
    impossible to write.
    """
    if not _validated:
        filters, _ = validate_filters(filters, brain)
    field_sql, member_fields = _fields(brain)
    rx_fields = _rx_fields(brain)
    parts, rx_parts, needs_m = [], [], False
    for f in filters:
        col = field_sql[f["field"]]
        v_sql = _lit(f["value"])
        if f["field"] in rx_fields:
            rx_parts.append(f"rx_c.{col.split('.', 1)[-1]} {f['op']} {v_sql}")
            continue
        if f["field"] in member_fields:
            needs_m = True
        parts.append(f"{col} {f['op']} {v_sql}")
    if rx_parts:
        parts.append(
            "EXISTS (SELECT 1 FROM pharmacy_claims rx_c "
            f"WHERE rx_c.member_id = c.member_id AND {' AND '.join(rx_parts)})")
    return " AND ".join(parts), needs_m


def compile_where_rx(filters, brain=None, _validated=False):
    """-> (SQL predicate for the PHARMACY base, needs_members_join)

    The mirror image: pharmacy columns apply directly, medical-only columns
    (claim_type, diagnosis_category, fraud_flag, provider) become an EXISTS
    over the member's medical claims. Shared columns — lob, region, status,
    service_quarter — exist on both tables and are applied in place, so an
    audience means the same thing whichever book is queried.

    Validates its own input for the same reason as ``compile_where``.
    """
    if not _validated:
        filters, _ = validate_filters(filters, brain)
    field_sql, member_fields = _fields(brain)
    rx_fields = _rx_fields(brain)
    shared = {"lob", "region", "status", "service_quarter"}
    parts, med_parts, needs_m = [], [], False
    for f in filters:
        name = f["field"]
        col = field_sql[name]
        v_sql = _lit(f["value"])
        if name in rx_fields or name in shared:
            parts.append(f"rx.{col.split('.', 1)[-1]} {f['op']} {v_sql}")
        elif name in member_fields:
            needs_m = True
            parts.append(f"{col} {f['op']} {v_sql}")
        else:
            med_parts.append(f"c_x.{col.split('.', 1)[-1]} {f['op']} {v_sql}")
    if med_parts:
        parts.append(
            "EXISTS (SELECT 1 FROM claims c_x "
            f"WHERE c_x.member_id = rx.member_id AND {' AND '.join(med_parts)})")
    return " AND ".join(parts), needs_m


def _latest_year(brain=None):
    """Newest year present in the warehouse's quarter vocabulary.

    "since April" with no year means the most recent April in the DATA, not
    the wall-clock year — a demo/analysis warehouse routinely ends in a past
    or future period, and defaulting to today's year yields an empty cohort.
    """
    qs = _vals("service_quarter", brain) or []
    years = [int(str(x)[:4]) for x in qs if str(x)[:4].isdigit()]
    if years:
        return max(years)
    try:
        from ..data.db import run_query
        r = run_query("SELECT MAX(service_quarter) FROM claims", scoped=False)
        v = (r.get("rows") or [[None]])[0][0]
        if v and str(v)[:4].isdigit():
            return int(str(v)[:4])
    except Exception:
        pass
    from datetime import date
    return date.today().year


def _money(text):
    m = re.search(r"\$?\s?([\d,]+(?:\.\d+)?)\s*(k|thousand|m|million)?", text)
    if not m:
        return None
    val = float(m.group(1).replace(",", ""))
    return val * {"k": 1e3, "thousand": 1e3, "m": 1e6,
                  "million": 1e6}.get(m.group(2), 1)


class CohortAgent:
    def __init__(self, llm):
        self.llm = llm

    def parse(self, prompt, brain=None):
        if self.llm:
            field_sql, _ = _fields(brain)
            sys_prompt = (brain or get_brain())["prompts"].get(
                "cohort", COHORT_SYSTEM_PROMPT)
            qs = _vals("service_quarter", brain)
            out = self.llm.complete_json(
                system=sys_prompt.format(
                    fields=list(field_sql), lobs=_vals("lob", brain),
                    diags=_vals("diagnosis_category", brain),
                    claim_types=_vals("claim_type", brain),
                    drug_classes=_vals("drug_class", brain),
                    regions=_vals("region", brain),
                    quarter_example=(qs[-1] if qs else "2026Q2")),
                user=prompt)
            if out and out.get("filters"):
                out["source"] = "llm"
                return self._validated(out, brain)
        return self._validated(self._rule_based(prompt, brain), brain)

    @staticmethod
    def _validated(parsed, brain=None):
        """Clean the parser's output at the SOURCE.

        Callers should never have to remember to validate. Returning
        already-clean filters plus the list of refusals means the orchestrator,
        the simulator and create() all see the same predicate — the earlier
        split, where the displayed WHERE and the computed profile used raw
        filters while the stored cohort used clean ones, was possible only
        because each caller validated (or forgot to) on its own.
        """
        clean, rejected = validate_filters(parsed.get("filters"), brain)
        parsed["filters"] = clean
        parsed["rejected"] = rejected
        return parsed

    def _rule_based(self, prompt, brain=None):
        q = prompt.lower()
        filters = []
        for v in _vals("lob", brain):
            if re.search(rf"\b{re.escape(v.lower())}\b", q):
                filters.append({"field": "lob", "op": "=", "value": v})
        for v in _vals("region", brain):
            if re.search(rf"\b{re.escape(v.lower())}\b", q):
                filters.append({"field": "region", "op": "=", "value": v})
        for v in _vals("claim_type", brain):
            if re.search(rf"\b{re.escape(v.lower())}\b", q):
                filters.append({"field": "claim_type", "op": "=", "value": v})
        for v in _vals("diagnosis_category", brain):
            if re.search(rf"\b{re.escape(v.lower())}\b", q):
                filters.append({"field": "diagnosis_category", "op": "=",
                                "value": v})
        if re.search(r"\bdiabetic", q) and not any(
                f["field"] == "diagnosis_category" for f in filters):
            filters.append({"field": "diagnosis_category", "op": "=",
                            "value": "Diabetes"})
        # risk semantics
        m = re.search(r"\braf\b[^.]*?(above|over|>\s*|greater than)\s*([\d.]+)", q)
        if m:
            filters.append({"field": "raf_score", "op": ">",
                            "value": float(m.group(2))})
        elif re.search(r"\bhigh[- ]risk\b|\bhigh raf\b", q):
            filters.append({"field": "raf_score", "op": ">", "value": 1.2})
        if re.search(r"\bdual[- ]eligible\b|\bduals\b", q):
            filters.append({"field": "dual_eligible", "op": "=", "value": 1})
        if re.search(r"\b(open |with )?(hedis|care|quality) gaps?\b", q):
            filters.append({"field": "hedis_gap_count", "op": ">",
                            "value": 0})
        if re.search(r"\bfraud|upcod", q):
            filters.append({"field": "fraud_flag", "op": "=", "value": 1})
        for status in ("Paid", "Denied", "Pending"):
            if re.search(rf"\b{status.lower()}\b", q):
                filters.append({"field": "status", "op": "=", "value": status})
        m = re.search(r"(?:claims?|costs?|allowed|amounts?)[^.]*?"
                      r"(over|above|greater than|more than|under|below|less than)"
                      r"([^,.]*)", q)
        if m:
            val = _money(m.group(2))
            if val:
                op = ">" if m.group(1) in ("over", "above", "greater than",
                                           "more than") else "<"
                filters.append({"field": "allowed_amount", "op": op,
                                "value": val})
        # drug class — a PHARMACY dimension. Previously unhandled, so "GLP-1
        # drug class" was silently dropped by the rules and substituted with a
        # diagnosis proxy by the LLM.
        for v in _vals("drug_class", brain):
            if re.search(rf"\b{re.escape(v.lower())}\b", q) or (
                    v.lower().startswith("glp-1")
                    and re.search(r"\bglp[- ]?1\b", q)):
                filters.append({"field": "drug_class", "op": "=", "value": v})
                break
        m = re.search(r"\btier\s*([1-5])\b", q)
        if m:
            filters.append({"field": "formulary_tier", "op": "=",
                            "value": int(m.group(1))})

        # Time. Explicit quarter first, then a bare month name ("since April"),
        # which analysts use constantly and which was being dropped entirely.
        m = re.search(r"\b(20\d\d)\s?q([1-4])\b", q)
        if m:
            filters.append({"field": "service_quarter", "op": "=",
                            "value": f"{m.group(1)}Q{m.group(2)}"})
        else:
            months = {"january": 1, "february": 2, "march": 3, "april": 4,
                      "may": 5, "june": 6, "july": 7, "august": 8,
                      "september": 9, "october": 10, "november": 11,
                      "december": 12}
            mm = re.search(
                r"\b(?:since|after|from)\s+(" + "|".join(months) + r")\b"
                r"(?:\s+\d{1,2})?(?:,?\s*(20\d\d))?", q)
            if mm:
                month = months[mm.group(1)]
                year = int(mm.group(2)) if mm.group(2) else _latest_year(brain)
                filters.append({"field": "service_quarter", "op": ">=",
                                "value": f"{year}Q{(month - 1) // 3 + 1}"})
        m = re.search(r"\b(pr-\d{3})\b", q)
        if m:
            filters.append({"field": "provider_id", "op": "=",
                            "value": m.group(1).upper()})
        # GENERIC value matching for any remaining cohort field the branches
        # above do not cover. The rules were an explicit list of payer field
        # names, so a domain whose audiences turn on `lead_source`, `channel`
        # or `funnel_stage` got them silently dropped — the audience was
        # created, but broader than the analyst asked for, which is the worst
        # way to be wrong about a population.
        #
        # Two guards keep this from changing any existing domain's behaviour
        # and from inventing predicates nobody asked for.
        #
        # 1. Dedupe on the resolved COLUMN, not the field name. Two field names
        #    legitimately point at one column when a domain declares a synonym
        #    (`region` as a second name for `market`, so the payer-shaped
        #    branches above still parse), and matching both produced
        #    `c.market = 'Southwest' AND c.market = 'Southwest'`.
        #
        # 2. Only match a value that is CODED or MULTI-WORD — it must contain a
        #    digit, a hyphen or a space. A bare common word is too ambiguous to
        #    pull out of free text: `funnel_stage` has the value 'Lead', so
        #    "leads from lead source LS-TELE-03" acquired a
        #    `funnel_stage = 'Lead'` predicate and silently returned a
        #    quarter of the population the analyst asked for. This also
        #    excludes the payer's `reject_code` values ('70', '75', '76'),
        #    which are the only dim_values field the branches above do not
        #    already handle — so no payer question changes.
        field_sql_all = _fields(brain)[0]
        _seen_cols = {field_sql_all[f["field"]] for f in filters
                      if f["field"] in field_sql_all}
        for field, column in field_sql_all.items():
            if column in _seen_cols:
                continue
            for v in _vals(field, brain):
                text = str(v).strip()
                if len(text) < 3 or not re.search(r"[\d\- ]", text):
                    continue
                if text.replace(".", "").isdigit():
                    continue
                if re.search(rf"(?<![\w-]){re.escape(text.lower())}"
                             rf"(?![\w-])", q):
                    filters.append({"field": field, "op": "=", "value": v})
                    _seen_cols.add(column)
                    break

        m = re.search(r"(?:named|called|call it)\s+['\"]?([\w -]+)['\"]?", q)
        name = m.group(1).strip().title() if m else " ".join(
            str(f["value"]) for f in filters[:3]) or "All Claims"
        return {"name": name, "filters": filters, "source": "rules"}

    def create(self, prompt, profile, parsed=None, name=None, user=None):
        parsed = parsed or self.parse(prompt)
        # VALIDATE before compiling. Whatever produced the filters — rules or
        # an LLM — anything that cannot possibly match a row is dropped here
        # and reported, rather than being frozen into a saved predicate.
        clean, rejected = validate_filters(parsed.get("filters"))
        where, needs_m = compile_where(clean)
        where_rx, needs_m_rx = compile_where_rx(clean)
        cohort = {"id": str(uuid.uuid4())[:8],
                  "name": name or parsed["name"], "prompt": prompt,
                  "filters": clean, "where": where or "1=1",
                  "where_rx": where_rx or "1=1",
                  "needs_members": needs_m or needs_m_rx,
                  "rejected_filters": rejected,
                  "parser": parsed["source"],
                  "created_at": time.strftime("%Y-%m-%d %H:%M"),
                  "owner": (user or {}).get("user_id"),
                  "owner_lobs": (user or {}).get("allowed_lobs", []),
                  "profile": profile}
        store = _load()
        store[cohort["id"]] = cohort
        _save(store)
        return cohort

    # ---- Visibility: OWNERSHIP first, then ABAC ------------------------
    # An audience is private to the analyst who defined it. The LOB check is
    # retained as an ADDITIONAL constraint (you must still be authorized for
    # the data the cohort spans), not as an alternative route in.
    #
    # Previously this method compared only LOB scopes, so two analysts holding
    # the same authorization saw — and could delete — each other's audiences.
    # A cohort definition is analytical work-in-progress and often encodes an
    # investigation someone has not published yet.
    @staticmethod
    def _visible(cohort, user):
        if user is None:                       # internal/full-trust caller
            return True
        owner = cohort.get("owner")
        uid = user.get("user_id")
        if owner and uid and owner != uid:
            return False                       # someone else's audience
        allowed = set(user.get("allowed_lobs", []))
        owner_lobs = set(cohort.get("owner_lobs") or [])
        if not owner_lobs:                     # legacy/unscoped
            from ..data.db import ALL_LOBS
            return allowed >= set(ALL_LOBS())
        return owner_lobs <= allowed

    @staticmethod
    def get(cohort_id, user=None):
        c = _load().get(cohort_id)
        if c and not CohortAgent._visible(c, user):
            return None
        return c

    @staticmethod
    def list_all(user=None):
        return sorted((c for c in _load().values()
                       if CohortAgent._visible(c, user)),
                      key=lambda c: c["created_at"], reverse=True)

    @staticmethod
    def delete(cohort_id, user=None):
        store = _load()
        c = store.get(cohort_id)
        if c and CohortAgent._visible(c, user):
            del store[cohort_id]
            _save(store)
            return True
        return False
