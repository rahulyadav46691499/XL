"""OpPal Agentic Framework — the spine every agent conforms to.

Design (LangGraph-style, dependency-free):
  Agent      — persona with a system prompt (Brain-overridable), a tool
               allow-list, RBAC scope, and a guarded run() contract
  Tool       — typed callable an agent may invoke (MCP query, graph
               ground, policy check, action proposal); every invocation
               is audit-logged with the agent identity
  AgentContext — immutable per-request state: user (RBAC), pipeline
               flags, trust accumulator, journey trace, token meter slice
  StateGraph — declarative node/edge runner: nodes are agents or pure
               functions, edges carry conditions; the swarm orchestrator
               (Phase 3) is expressed as a StateGraph, as is the Sentry
               loop and the HITL action lifecycle (Phase 4)

Guarantees enforced BY the framework (not by agent goodwill):
  * every LLM call goes through the PHI-guarded provider
  * every tool call is appended to the audit ledger (agent, tool, hash)
  * an agent can only see tools on its allow-list
  * trust contributions are recorded per node for the final gate
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class Tool:
    name: str
    description: str
    fn: Callable[..., Any]
    engine: str = "internal"          # internal | llm | data | cache | action

    def __call__(self, ctx: "AgentContext", **kwargs) -> Any:
        t0 = time.time()
        # Upgrade 2: the tool is a securable object in its own right. This is
        # not redundant with the agent-level check — agents.md is editable, so
        # a persona's `tools:` allow-list can be widened; gating the tool means
        # that cannot silently confer a write-adjacent capability.
        from ..security.agent_acl import assert_can_invoke_tool
        assert_can_invoke_tool(getattr(ctx, "user", {}) or {}, self.name)
        out = self.fn(**kwargs)
        ctx.trace.append({
            "step": f"tool:{self.name}", "agent": ctx.current_agent,
            "engine": self.engine, "tokens": 0,
            "ms": round((time.time() - t0) * 1000, 1),
            "detail": {"tool": self.name,
                       "args": {k: str(v)[:120] for k, v in kwargs.items()}},
        })
        return out


@dataclass
class AgentContext:
    user: dict                                    # RBAC context (never None)
    pipeline: dict = field(default_factory=dict)
    trace: list = field(default_factory=list)     # journey steps
    findings: list = field(default_factory=list)  # cross-agent blackboard
    trust_components: dict = field(default_factory=dict)
    current_agent: str = "orchestrator"

    @property
    def allowed_lobs(self) -> list:
        return self.user.get("allowed_lobs", [])


class Agent:
    """Base persona. Subclasses set name/prompt_key/tools and implement
    act(). The framework wraps act() with tracing + guardrails."""
    name: str = "agent"
    prompt_key: str = ""              # section in Brain prompts.md
    tool_names: list[str] = []

    def __init__(self, llm, registry: "ToolRegistry"):
        self.llm = llm                # already PHI-guarded provider or None
        self.tools = registry.subset(self.tool_names)

    def prompt(self) -> str:
        from ..semantic.brain import get_brain
        return get_brain()["prompts"].get(self.prompt_key, "")

    def run(self, ctx: AgentContext, **kwargs) -> dict:
        prev_agent = ctx.current_agent
        ctx.current_agent = self.name
        t0 = time.time()
        try:
            result = self.act(ctx, **kwargs)
            ctx.trace.append({"step": f"agent:{self.name}",
                              "agent": self.name,
                              "engine": "llm" if self.llm else "internal",
                              "tokens": 0,
                              "ms": round((time.time() - t0) * 1000, 1),
                              "detail": {"ok": True}})
            return {"agent": self.name, "ok": True, "result": result}
        except Exception as e:            # agents degrade, never crash runs
            ctx.trace.append({"step": f"agent:{self.name}:degraded",
                              "agent": self.name, "engine": "internal",
                              "tokens": 0, "ms": 0,
                              "detail": {"error": f"{type(e).__name__}: {e}"}})
            return {"agent": self.name, "ok": False,
                    "error": f"{type(e).__name__}: {e}"}
        finally:
            ctx.current_agent = prev_agent

    def act(self, ctx: AgentContext, **kwargs) -> Any:   # override
        raise NotImplementedError


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool):
        self._tools[tool.name] = tool

    def subset(self, names: list[str]) -> dict[str, Tool]:
        return {n: self._tools[n] for n in names if n in self._tools}


@dataclass
class Node:
    name: str
    run: Callable[[AgentContext], Any]      # agent.run or pure fn
    when: Optional[Callable[[AgentContext], bool]] = None


class StateGraph:
    """Minimal sequential/conditional graph runner. Phase 3 swarm and
    Phase 4 action lifecycle are declared as StateGraphs so the flow is
    inspectable by BAs (rendered in each phase's Architecture Flow)."""

    def __init__(self, name: str):
        self.name = name
        self.nodes: list[Node] = []

    def add(self, name, run, when=None) -> "StateGraph":
        self.nodes.append(Node(name, run, when))
        return self

    def execute(self, ctx: AgentContext) -> AgentContext:
        for node in self.nodes:
            if node.when and not node.when(ctx):
                continue
            node.run(ctx)
        return ctx

    def describe(self) -> list[str]:
        """Human-readable flow for design docs / UI."""
        return [f"{i + 1}. {n.name}" + (" [conditional]" if n.when else "")
                for i, n in enumerate(self.nodes)]
