"""Agent 4: Insight narration — payer domain (MLR, PBM, risk pools)."""


def _rows_for_llm(result):
    """ABAC data-minimization: when 'send_row_samples' is off, the LLM
    receives METADATA ONLY (schema + counts), never row values."""
    from .. import config
    if config.load()["privacy"].get("send_row_samples", True):
        return result.get("rows", [])[:12]
    return (f"[metadata-only mode: {result.get('row_count', 0)} rows "
            f"withheld from LLM]")


class InsightAgent:
    def __init__(self, llm):
        self.llm = llm

    def narrate(self, question, intent, result, analysis, grounding) -> dict:
        if self.llm:
            from ..semantic.brain import get_brain
            brain_prompt = get_brain()["prompts"].get("insight")
            out = self.llm.complete_json(
                system=brain_prompt or ("You are a healthcare PAYER analytics narrator "
                        "(MLR, PBM adjudication, risk adjustment). Given a "
                        "query result and anomaly/driver analysis, write a "
                        "crisp 2-3 sentence answer that leads with the "
                        "'why' — name NCPDP reject codes and formulary "
                        "changes explicitly when present. Then suggest 3 "
                        "follow-ups. Return JSON {summary, followups:[]}"),
                user=f"Q: {question}\nIntent: {intent}\nResult cols: "
                     f"{result.get('columns')}\nRows: {_rows_for_llm(result)}\n"
                     f"Analysis: {analysis}")
            if out:
                return out
        return self._rule_based(intent, result, analysis, grounding)

    def _rule_based(self, intent, result, analysis, grounding) -> dict:
        # Describe the value the SQL actually returned. A breakdown may select a
        # column other than the grounded metric (e.g. "which reject codes
        # spiked" returns reject_count, not pbm_reject_rate); narrating it as
        # the metric would mislabel the answer.
        metric_key = intent.get("metric", "metric")
        cols = result.get("columns", []) if isinstance(result, dict) else []
        if metric_key not in cols and len(cols) >= 2:
            value_col = next((c for c in cols[1:] if c != "claim_count"),
                             cols[-1])
        else:
            value_col = metric_key
        metric = value_col.replace("_", " ")
        parts, followups = [], []

        if intent["intent"] == "formulary_lookup" and result.get("rows"):
            for r in result["rows"]:
                name, rx, cls, tier, pa, step, doc = r[:7]
                parts.append(
                    f"{name} (RxNorm {rx}, {cls}) adjudicates at TIER {tier}"
                    + (", PRIOR AUTH required" if pa else "")
                    + (", step therapy" if step else "")
                    + f". Source: {doc}.")
            followups = ["Why did pharmacy rejects spike in 2026Q2?",
                         "Show pbm reject rate by drug class",
                         "Pharmacy cost trend for GLP-1 Agonist"]
            return {"summary": " ".join(parts), "followups": followups}

        if result.get("ok") and result["rows"]:
            n = result["row_count"]
            parts.append(f"Here is {metric} ({n} data points)"
                         + (f" filtered to {', '.join(f'{k}={v}' for k, v in intent.get('filters', {}).items())}"
                            if intent.get("filters") else "") + ".")
        else:
            parts.append("The query returned no data — try widening the filters.")

        for a in analysis.get("anomalies", [])[:2]:
            parts.append(
                f"⚠ Anomaly in {a['period']}: {metric} "
                f"{'jumped' if a['direction'] == 'spike' else 'fell'} "
                f"{abs(a['pct_change'])}% QoQ (z={a['z_score']}).")

        for d in analysis.get("drivers", [])[:3]:
            kind = d.get("kind")
            dim = d["dimension"].replace("_", " ")
            if kind == "pbm_reject":
                parts.append(
                    f"Adjudication driver — reject code {d['value']} "
                    f"({d['meaning']}): {d['rejects_prev']:,} → "
                    f"{d['rejects_cur']:,} rejects "
                    f"({d['contribution_pct']}% of the paid-reject increase "
                    f"in {d['period']}).")
                followups.append(
                    f"Show rejected pharmacy claims detail for reject code {d['value']}")
            elif kind == "pbm_reject_detail":
                parts.append(
                    f"Within code {d['within_code']}, {dim} = {d['value']} "
                    f"accounts for the bulk: {d['rejects_prev']:,} → "
                    f"{d['rejects_cur']:,} rejects — consistent with the "
                    f"2026-04-01 formulary change (GLP-1 tier 3→4 + new PA, "
                    f"Express Scripts NPF 2026 v2 §4.2).")
            elif kind == "mix_shift":
                bits = []
                if abs(d["within_change_pct"]) > 10:
                    bits.append(f"its own rate/severity moved "
                                f"{d['within_change_pct']:+.1f}%")
                if abs(d["mix_shift_pp"]) > 3:
                    bits.append(f"its share shifted {d['share_prev_pct']}% → "
                                f"{d['share_cur_pct']}%")
                parts.append(
                    f"Pinpointed: {dim} = {d['value']} explains "
                    f"{d['contribution_pct']}% of the move in {d['period']} — "
                    + " and ".join(bits) + ".")
            else:
                parts.append(
                    f"Driven primarily by {dim} = {d['value']}: "
                    f"+{d['delta']:,.0f} vs {d['vs']} "
                    f"({d['contribution_pct']}% of the increase).")

        if not followups:
            followups = [f"Break down {metric} by lob",
                         _peer_metric_question(metric),
                         "Run an audit readiness check"]
            followups = [f for f in followups if f]
        return {"summary": " ".join(parts), "followups": followups[:3]}


def _peer_metric_question(metric: str) -> str:
    """A second question drawn from THIS domain's Brain.

    The literal "Why did pharmacy rejects spike in 2026Q2?" used to sit here.
    It is payer domain knowledge in shared agent code, so every domain offered
    it: a Medicare Sales analyst asking about lead quality was invited to ask
    about pharmacy rejects, a table this domain does not have. Returns "" when
    the Brain has nothing else certified to offer, and the caller drops it.
    """
    try:
        from ..semantic.brain import get_brain
        want = str(metric).replace(" ", "_").lower()
        for mid, m in get_brain()["metrics"].items():
            if mid.lower() == want or not m.get("certified"):
                continue
            return f"How is {str(m.get('label') or mid).lower()} trending?"
    except Exception:                       # never break an answer over a chip
        pass
    return ""
