"""Agent 2: SQL generation — Brain-driven, RBAC-scoped.

Metric expressions, bases and dimension SQL all come from the Context
Brain (metrics.md / entities.md) — nothing domain-specific here.
"""
from ..semantic.brain import get_brain

# `brain=None` on every helper below preserves Phase 0-3 behavior (falls back
# to the live get_brain()); Phase 5's simulator passes its forked brain copy
# so governed SQL is built from the FORKED metrics/formulas, never the live
# singleton — see app/simulation/isolation.py.


def _metric_sql(brain=None):
    b = brain or get_brain()
    return {mid: (m["sql"], m["base"], m["needs_members"], m["average"])
            for mid, m in b["metrics"].items()}


def _dim_sql(brain=None):
    return (brain or get_brain())["dim_sql"]


def _cohort_pred(cohort, base, brain=None):
    """The cohort predicate written for THIS base table.

    A cohort used to be applied only to medical claims, so scoping a pharmacy
    question to an audience silently ignored the audience. Each base needs its
    own rendering: pharmacy columns are direct on the rx table and an EXISTS
    over the member on the claims side, and vice-versa. Cohorts saved before
    both forms existed are recompiled from their stored filters rather than
    being dropped (silently unscoped) or reused verbatim (invalid SQL, since
    the alias would not exist on the other table).
    """
    if base not in ("claims", "rx"):
        return ""
    key = "where" if base == "claims" else "where_rx"
    pred = (cohort or {}).get(key)
    if pred:
        return pred
    filters = (cohort or {}).get("filters")
    if not filters:
        return ""
    try:
        from .cohort_agent import compile_where, compile_where_rx
        fn = compile_where if base == "claims" else compile_where_rx
        return fn(filters, brain)[0]
    except Exception:
        return ""

SQL_SYSTEM_PROMPT = """You are the Data/SQL Agent for a US Healthcare \
Payer analytics system. Write ONE read-only SQLite SELECT.
{schema_hint}
SECURITY: you MUST scope every query with: {rbac_predicate}
Use ONLY these governed metric definitions:
{metric_defs}
{cohort_ctx}
Return STRICT JSON {{"sql": ..., "explanation": ...}}."""


class SQLAgent:
    def __init__(self, llm):
        self.llm = llm

    def generate(self, question, intent, grounding, cohort=None,
                 allowed_lobs=None, brain=None):
        if self.llm:
            metric_defs = "\n".join(
                f"- {k}: {v['definition']} formula: {v['formula']}"
                for k, v in grounding["metrics"].items())
            rbac = ("lob IN (" + ", ".join(f"'{l}'" for l in allowed_lobs)
                    + ")") if allowed_lobs else "1=1"
            # Sprint B item 3: describe only the intent-relevant neighbourhood.
            # A hardcoded full-schema sentence would put a customer's entire
            # 200-table warehouse in every prompt regardless of the question.
            space = (grounding or {}).get("space") or {}
            schema_hint = space.get("schema_hint") or (
                "Schema (benefit hierarchy): plans -> products -> "
                "benefit_packages -> members m -> claims c (medical) / "
                "pharmacy_claims rx (PBM); providers pr; formulary f "
                "(RxNorm -> tier/PA, source_doc).\nJoins: "
                + str(grounding.get("available_joins", "")))
            out = self.llm.complete_json(
                system=SQL_SYSTEM_PROMPT.format(
                    schema_hint=schema_hint,
                    rbac_predicate=rbac, metric_defs=metric_defs,
                    cohort_ctx=(f"Scope to audience: {cohort['where']}"
                                if cohort else "")),
                user=f"Question: {question}\nIntent: {intent}")
            if out and "sql" in out:
                out["source"] = "llm"
                return out
        return self._template(intent, grounding, cohort, allowed_lobs, brain)

    def _template(self, intent, grounding, cohort=None, allowed_lobs=None,
                  brain=None):
        METRIC_SQL = _metric_sql(brain)
        DIM_SQL = _dim_sql(brain)
        default_metric = next(iter(METRIC_SQL), "medical_cost")
        metric = intent.get("metric") or default_metric
        if metric not in METRIC_SQL:
            metric = default_metric
        expr, base, needs_members, is_avg = METRIC_SQL[metric]
        # group_by is used below as a dict key (dims_map.get(group_by, ...)).
        # It normally comes from IntentRouter, which now coerces LLM slots to
        # scalars — but this method is also reachable with a hand-built intent
        # (simulation/engine.py, departmental agents), so re-guard here too:
        # a list/dict slipping through raises "unhashable type" deep in a
        # dict.get() with no indication the real fault was upstream.
        group_by = intent.get("group_by")
        if isinstance(group_by, list):
            group_by = group_by[0] if group_by else None
        elif not isinstance(group_by, (str, type(None))):
            group_by = None
        filters = dict(intent.get("filters", {}))
        for _k, _v in list(filters.items()):
            if _k != "quarter_range" and isinstance(_v, list):
                filters[_k] = _v[0] if _v else None

        # ---- formulary lookup (RxNorm multi-hop) -----------------------
        if intent["intent"] == "formulary_lookup" and grounding.get("drugs"):
            rxnorms = ", ".join(str(d["rxnorm"]) for d in grounding["drugs"])
            sql = (f"SELECT drug_name, rxnorm_code, drug_class, tier, "
                   f"pa_required, step_therapy, source_doc FROM formulary "
                   f"WHERE rxnorm_code IN ({rxnorms})")
            return {"sql": sql, "explanation":
                    "Formulary resolution via RxNorm (graph multi-hop)",
                    "source": "template"}

        # ---- TABLE-DECLARED metrics: any table, and now GOVERNED ---------
        # This path serves two populations: auto-onboarded imported tables
        # (base: generic) and any domain whose metrics name their own table
        # rather than one of the payer bases.
        #
        # It used to skip the RBAC predicate entirely — the explanation string
        # said so out loud ("outside LOB governance"). That was tolerable when
        # it only served a read-only side table queried by a full-scope demo
        # user, and indefensible as the main analytic path for a whole domain:
        # every answer would bypass the one control the product is sold on.
        # The scope predicate is applied here whenever the table is declared
        # governed in the Brain, using the governance-declared scope column
        # rather than a literal `lob`.
        brain_now = brain or get_brain()
        mdef = brain_now["metrics"].get(metric, {})
        declared_table = (mdef.get("table") or "").strip()
        known_base = base in ("claims", "rx", "members")
        if declared_table and (base == "generic" or not known_base):
            t = declared_table
            tc = mdef.get("time_column", "")
            gdims = mdef.get("dims", [])
            dim = group_by if group_by in gdims else (gdims[0] if gdims else "")
            gov = brain_now.get("governance") or {}
            governed_tables = gov.get("governed_tables") or {}
            scope_col = (governed_tables.get(t)
                         or gov.get("scope_column") or "lob")
            is_governed = t in governed_tables
            conds = []
            for col, val in filters.items():
                if col in ("quarter_range", "service_quarter"):
                    continue
                if col in gdims:
                    safe = str(val).replace("'", "''")
                    conds.append(f"t.{col} = '{safe}'")
            # Scope is applied only to tables the Brain declares governed. An
            # ungoverned reference table has no scope column to filter on, and
            # inventing one would produce "no such column" rather than safety.
            if is_governed and allowed_lobs is not None:
                lobs = ", ".join(f"'{l}'" for l in allowed_lobs)
                conds.append(f"t.{scope_col} IN ({lobs})")
            where = ("WHERE " + " AND ".join(conds)) if conds else ""
            if intent["intent"] in ("metric_trend", "root_cause") and tc:
                sql = (f"SELECT t.{tc} AS period, {expr} AS {metric} "
                       f"FROM {t} t {where} GROUP BY t.{tc} ORDER BY period")
            elif dim:
                sql = (f"SELECT t.{dim} AS {dim}, {expr} AS {metric} "
                       f"FROM {t} t {where} GROUP BY t.{dim} ORDER BY 2 DESC")
            else:
                sql = f"SELECT {expr} AS {metric} FROM {t} t {where}"
            scope_note = ("scope-enforced on "
                          f"{t}.{scope_col}" if is_governed
                          else "ungoverned reference table")
            certified = mdef.get("certified")
            cert_note = "" if certified else "uncertified; "
            return {"sql": " ".join(sql.split()),
                    "explanation": f"Metric {metric} on table {t} "
                                   f"({cert_note}{scope_note})",
                    "source": "template"}

        # A metric that names an unknown base and declares NO table cannot be
        # compiled. Previously this fell through to `FROM claims c` and either
        # produced silently wrong SQL against the wrong table or raised a bare
        # KeyError on DIM_SQL[base] — both of which read as an engine bug
        # rather than what they are: an incomplete metric definition.
        if not known_base and base != "generic":
            return {"sql": "-- withheld",
                    "explanation": (f"Metric '{metric}' declares base "
                                    f"'{base}' but no `table:`. Add a table "
                                    f"to the metric in the Context Brain so "
                                    f"the query can be compiled."),
                    "source": "template", "error": "unresolvable_base"}

        # ---- member-base metrics: no time series, break down by LOB ----
        if base == "members":
            _gov = (brain or get_brain()).get("governance") or {}
            _scol = _gov.get("scope_column") or "lob"
            dims = DIM_SQL["members"]
            dim = dims.get(group_by or _scol, f"m2.{_scol}")
            where = self._where([], "m2", filters, allowed_lobs,
                                f"m2.{_scol}")
            sql = (f"SELECT {dim} AS {group_by or 'lob'}, {expr} AS {metric}, "
                   f"COUNT(m2.member_id) AS member_count "
                   f"FROM members m2 {where} GROUP BY {dim} ORDER BY 2 DESC")
            return {"sql": " ".join(sql.split()),
                    "explanation": f"Member risk-pool metric {metric}",
                    "source": "template"}

        # ---- pharmacy vs medical base -----------------------------------
        alias = "rx" if base == "rx" else "c"
        table = "pharmacy_claims rx" if base == "rx" else "claims c"
        dims_map = DIM_SQL[base]
        joins = [f"FROM {table}"]
        if needs_members or (cohort and cohort.get("needs_members")):
            joins.append(f"JOIN members m ON {alias}.member_id = m.member_id")
        if base == "claims" and (group_by == "provider"
                                 or "provider_id" in filters
                                 or intent["intent"] == "correlation"):
            joins.append("JOIN providers pr ON c.provider_id = pr.provider_id")

        conds = []
        if cohort:
            pred = _cohort_pred(cohort, base, brain)
            if pred:
                conds.append(f"({pred})")
        qrange = filters.pop("quarter_range", None)
        if qrange and len(qrange) == 2:
            conds.append(f"{alias}.service_quarter BETWEEN "
                         f"'{qrange[0]}' AND '{qrange[1]}'")
            filters.pop("service_quarter", None)
        if intent["intent"] in ("metric_trend", "root_cause"):
            filters = {k: v for k, v in filters.items()
                       if k != "service_quarter"}
        for col, val in filters.items():
            col_sql = dims_map.get(col) or {
                "provider_id": "c.provider_id",
                "service_quarter": f"{alias}.service_quarter"}.get(col) \
                or f"{alias}.{col}"
            if col == "claim_type" and base == "rx":
                continue
            conds.append(f"{col_sql} = '{val}'")
        _gov = (brain or get_brain()).get("governance") or {}
        _scol = _gov.get("scope_column") or "lob"
        where = self._where(conds, alias, {}, allowed_lobs,
                            f"{alias}.{_scol}")

        # "Which reject codes spiked?" — a breakdown BY reject_code needs the
        # volume of rejects per code, not the rate metric. Grouping the rate by
        # reject_code is degenerate: reject_code is only populated on rejected
        # rows, so every code shows rate 1.0 and the dominant NULL bucket is
        # non-rejected claims. Count rejects per code, excluding the NULL
        # (non-reject) bucket, ranked by volume.
        if base == "rx" and group_by == "reject_code":
            rej = (where + " AND rx.reject_code IS NOT NULL") if where \
                else "WHERE rx.reject_code IS NOT NULL"
            sql = (f"SELECT rx.reject_code AS reject_code, "
                   f"COUNT(rx.rx_claim_id) AS reject_count "
                   f"{' '.join(joins)} {rej} GROUP BY rx.reject_code "
                   f"ORDER BY reject_count DESC LIMIT 10")
            return {"sql": " ".join(sql.split()),
                    "explanation": "Reject volume by NCPDP reject code "
                                   "(rejected claims only, ranked by count)",
                    "source": "template"}

        count_col = f", COUNT({alias}.{'rx_claim_id' if base == 'rx' else 'claim_id'}) AS claim_count" \
            if is_avg else ""

        if intent["intent"] == "correlation":
            sql = (f"SELECT pr.name AS provider, COUNT(c.claim_id) AS claim_count, "
                   f"ROUND(AVG(c.allowed_amount), 0) AS claim_severity "
                   f"{' '.join(joins)} {where} GROUP BY pr.name "
                   f"HAVING COUNT(c.claim_id) >= 20")
            return {"sql": " ".join(sql.split()),
                    "explanation": "Provider volume vs severity",
                    "source": "template"}
        if intent["intent"] in ("metric_trend", "root_cause"):
            dims = [f"{alias}.service_quarter AS quarter"]
            grp, order = f"GROUP BY {alias}.service_quarter", "ORDER BY quarter"
        elif intent["intent"] == "top_n":
            # Default breakdown dimension is the domain's scope column, not a
            # literal `lob` — for a pharma domain that is distributor/region.
            dim = dims_map.get(group_by or _scol, f"{alias}.{_scol}")
            dims = [f"{dim} AS {group_by or _scol}"]
            grp, order = f"GROUP BY {dim}", "ORDER BY 2 DESC LIMIT 10"
        elif intent["intent"] == "breakdown" and group_by:
            dim = dims_map.get(group_by, f"{alias}.{group_by}")
            if "service_quarter" in intent.get("filters", {}):
                dims = [f"{dim} AS {group_by}"]
                grp, order = f"GROUP BY {dim}", "ORDER BY 2 DESC"
            else:
                dims = [f"{dim} AS {group_by}",
                        f"{alias}.service_quarter AS quarter"]
                grp = f"GROUP BY {dim}, {alias}.service_quarter"
                order = "ORDER BY quarter, 1"
        elif intent["intent"] == "detail_lookup":
            if base == "rx":
                sql = (f"SELECT rx.rx_claim_id, rx.service_date, rx.drug_name, "
                       f"rx.drug_class, rx.formulary_tier, rx.status, "
                       f"rx.reject_code, rx.plan_paid, rx.lob "
                       f"{' '.join(joins)} {where} "
                       f"ORDER BY rx.service_date DESC LIMIT 100")
            else:
                sql = (f"SELECT c.claim_id, c.service_date, c.lob, c.region, "
                       f"c.claim_type, c.diagnosis_category, c.status, "
                       f"c.denial_reason, c.allowed_amount, c.fraud_flag "
                       f"{' '.join(joins)} {where} "
                       f"ORDER BY c.allowed_amount DESC LIMIT 100")
            return {"sql": " ".join(sql.split()),
                    "explanation": "Claim-level detail", "source": "template"}
        else:
            dims = [f"{alias}.service_quarter AS quarter"]
            grp, order = f"GROUP BY {alias}.service_quarter", "ORDER BY quarter"

        sql = (f"SELECT {', '.join(dims)}, {expr} AS {metric}{count_col} "
               f"{' '.join(joins)} {where} {grp} {order}")
        return {"sql": " ".join(sql.split()),
                "explanation": f"Governed template for {metric} "
                               f"({intent['intent']}, base={base})",
                "source": "template"}

    @staticmethod
    def _where(conds, alias, filters, allowed_lobs, lob_col):
        conds = list(conds)
        if allowed_lobs is not None:
            lobs = ", ".join(f"'{l}'" for l in allowed_lobs)
            conds.append(f"{lob_col} IN ({lobs})")   # RBAC scope
        return ("WHERE " + " AND ".join(conds)) if conds else ""
