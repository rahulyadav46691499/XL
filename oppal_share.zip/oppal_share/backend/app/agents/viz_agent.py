"""Agent 3: Visualization — generative artifacts with anomaly markers."""

from ..semantic.brain import get_brain


def _fmt(metric):
    return get_brain()["metrics"].get(metric, {}).get("format", "number")


def recommend_chart(intent, cols, rows):
    """Analyze the result shape and pick the most readable chart.
    Returns (chart_type, reason)."""
    has_quarter = "quarter" in cols
    n = len(rows)
    metric = intent.get("metric", "")
    multi_dim = has_quarter and len(cols) >= 3 and cols[0] != "quarter"
    if intent["intent"] == "correlation":
        return "scatter", "two numeric measures — correlation reads best as a scatter"
    if multi_dim:
        n_series = len({r[0] for r in rows})
        n_quarters = len({r[cols.index("quarter")] for r in rows})
        if n_quarters <= 6 and n_series <= 5:
            return "bar", (f"{n_quarters} periods × {n_series} series — "
                           "grouped bars make side-by-side comparison easiest")
        return "multiline", (f"{n_quarters} periods × {n_series} series — "
                             "lines read best for longer trends")
    if has_quarter:
        return ("area" if metric.startswith(("medical_cost", "pharmacy_cost",
                                             "total_")) else "line"),             "single time series — line/area shows the trend cleanest"
    if n <= 6 and intent.get("wants_pie"):
        return "pie", "few categories as shares — pie works"
    if n <= 12:
        return "bar", f"{n} categories — bars compare magnitudes best"
    return "bar", "many categories — sorted bars remain scannable"


class VizAgent:
    def build(self, intent, result, analysis=None) -> list[dict]:
        if not result.get("ok") or not result["rows"]:
            return []
        cols, rows = result["columns"], result["rows"]
        metric = intent.get("metric", cols[-1])
        fmt = _fmt(metric)
        anomaly_periods = [a["period"] for a in
                           (analysis or {}).get("anomalies", [])]
        artifacts = []

        if intent["intent"] == "formulary_lookup":
            artifacts.append({"type": "grid", "title": "Formulary resolution",
                              "columns": cols, "rows": rows,
                              "collapsed": False})
            return artifacts
        recommended, reason = recommend_chart(intent, cols, rows)
        chosen = intent.get("wants_chart") or recommended
        mismatch = bool(intent.get("wants_chart")
                        and intent["wants_chart"] != recommended)

        def spec(extra):
            base = {"type": "chart", "chart_type": chosen,
                    "recommended_chart": recommended,
                    "recommendation_reason": reason,
                    "chart_mismatch": mismatch,
                    "format": fmt, "columns": cols, "rows": rows,
                    "anomaly_periods": anomaly_periods}
            base.update(extra)
            return base

        if intent["intent"] == "correlation":
            artifacts.append(spec({
                "chart_type": "scatter", "recommended_chart": "scatter",
                "chart_mismatch": False,
                "title": "Volume vs severity — each point is a provider",
                "x": "claim_count", "y": "claim_severity",
                "label": cols[0], "format": "currency"}))
        elif "quarter" in cols and len(cols) >= 3 and cols[0] != "quarter":
            # dim × quarter matrix (breakdown / range queries)
            artifacts.append(spec({
                "title": f"{metric.replace('_', ' ').title()} by "
                         f"{cols[0].replace('_', ' ')} per quarter",
                "x": "quarter", "series_dim": cols[0], "value": metric,
                "pivot": True}))
        elif intent["intent"] in ("metric_trend", "root_cause") and "quarter" in cols:
            artifacts.append(spec({
                "title": f"{metric.replace('_', ' ').title()} by Quarter",
                "x": "quarter", "series": [metric],
                "drilldown": {"dimension": "reject code"
                              if metric == "pbm_reject_rate" else "lob",
                              "prompt_template":
                              f"break down {metric} by "
                              + ("reject code" if metric == "pbm_reject_rate"
                                 else "lob") + " in {x}"}}))
        elif intent["intent"] in ("top_n", "breakdown") and cols:
            dim = cols[0]
            # The plotted series is the metric ONLY when the SQL actually
            # selected it. Some breakdowns return a different value column —
            # e.g. "which reject codes spiked" counts rejects per code
            # (reject_count), not the pbm_reject_rate. Labelling that chart
            # "Pbm Reject Rate" (and pointing the series at a non-existent
            # column) is wrong, so fall back to the real value column.
            value_col = metric if metric in cols else next(
                (c for c in cols[1:] if c != "claim_count"), cols[-1])
            vfmt = _fmt(value_col) if value_col in get_brain()["metrics"] \
                else "number"
            artifacts.append(spec({
                "format": vfmt,
                "title": f"{value_col.replace('_', ' ').title()} by {dim.replace('_', ' ')}",
                "x": dim, "series": [value_col], "colorful": True,
                "drilldown": {"dimension": "quarter",
                              "prompt_template": f"show {value_col} trend for {{x}}"}}))

        artifacts.append({
            "type": "grid", "title": "Underlying data",
            "columns": cols, "rows": rows, "format": fmt,
            "collapsed": intent["intent"] != "detail_lookup"})
        return artifacts
