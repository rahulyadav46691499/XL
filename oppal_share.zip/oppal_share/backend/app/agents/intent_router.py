"""Agent 1: Intent router — US Healthcare Payer/MCO domain.

Routes questions across the medical book, the PBM/pharmacy book, the
benefit hierarchy, and regulatory compliance workflows. Every slot
extraction is recorded with the exact regex used (compliance trace).
"""
import re

from ..semantic.brain import get_brain

INTENTS = ["metric_trend", "breakdown", "root_cause", "top_n",
           "correlation", "detail_lookup", "formulary_lookup",
           "compliance_audit", "general"]

def _vals(dim):
    return get_brain().get("dim_values", {}).get(dim, [])

GROUP_BY_KEYWORDS = {
    "lob": ["by lob", "by line of business", "per lob", "by plan",
            "for each plan", "each plan", "per plan", "for each lob",
            "across lobs", "by contract"],
    "region": ["by region", "across regions", "per region"],
    "claim_type": ["by claim type", "by type", "by place of service"],
    "diagnosis_category": ["by diagnosis", "by condition"],
    "provider": ["by provider", "per provider", "by npi"],
    "drug_class": ["by drug class", "by class", "by therapeutic class",
                   "by drug"],
    "reject_code": ["by reject code", "by reject", "per reject code"],
    "formulary_tier": ["by tier", "by formulary tier"],
    "status": ["by status"],
}

# Bare dimension NOUNS, for "which/what <noun>" phrasing that carries no "by".
# "Which reject codes spiked?" is a breakdown by reject_code even though the
# user never said "by reject code". Ordered longest-first so "reject code"
# wins over a stray "code". Only consulted when no explicit "by X" matched.
DIMENSION_NOUNS = [
    ("reject_code", ["reject code", "reject codes", "reject reason"]),
    ("drug_class", ["drug class", "drug classes", "therapeutic class"]),
    ("diagnosis_category", ["diagnosis", "condition", "diagnoses"]),
    ("formulary_tier", ["formulary tier", "tier"]),
    ("claim_type", ["claim type", "place of service"]),
    ("provider", ["provider", "providers", "npi"]),
    ("region", ["region", "regions"]),
    ("lob", ["line of business", "lines of business", "plan", "plans", "lob"]),
    ("status", ["status"]),
]

PHARMACY_HINTS = re.compile(
    r"\b(pharmacy|pbm|rx|drug|formulary|tier|reject|script|ozempic|glp-?1|"
    r"prior auth|ndc|rxnorm|specialty pharmacy)\b", re.I)
COMPLIANCE_HINTS = re.compile(
    r"\b(audit|certification|compliance|cms|odag|cdag|regulator|"
    r"readiness|42 cfr|program audit|universe)\b", re.I)

# Refactored system prompt (LLM path) -------------------------------------
ROUTER_SYSTEM_PROMPT = """You are the Intent Router for a US Healthcare \
Payer/MCO conversational analytics system operating over:
- MEDICAL book: claims joined through the benefit hierarchy \
(plans -> products -> benefit_packages -> members -> claims)
- PHARMACY/PBM book: pharmacy_claims with NCPDP adjudication \
(reject codes 70 = product not covered, 75 = prior authorization \
required, 76 = plan limitations exceeded) and a formulary keyed on RxNorm
- RISK & QUALITY: member RAF scores (CMS-HCC) and HEDIS care gaps
- COMPLIANCE: Medicare Advantage (ODAG/CDAG program audit) and Medicaid \
MCO certification workflows

Classify the user question and extract slots. Intents: {intents}.
Route to 'compliance_audit' when the user asks about audit readiness, \
CMS program audits, certification, or regulatory validation — this \
coordinates the Data/SQL agent (universe pulls) with the Clinical \
Policy agent (CMS guideline validation).
Route to 'formulary_lookup' for drug coverage/tier/PA questions.
Dimensions: lob, region, claim_type, diagnosis_category, provider, \
drug_class, reject_code, formulary_tier, status.
LOBs: {lobs}. Reject codes of interest: 70, 75, 76.
Quarter RANGES ("from 2025 Q1 to 2026 Q2") must be returned as \
filters.quarter_range = ["2025Q1","2026Q2"] — NEVER as a single \
service_quarter string. Chart preferences ("bar graph", "pie") go in \
"wants_chart": bar|line|pie|area|scatter.
Return STRICT JSON:
{{"intent": ..., "metric": ..., "group_by": ..., \
"filters": {{dim: value}}, "domain": "medical|pharmacy|member", \
"wants_chart": null, "time_grain": "quarter"}}
Grounded metrics available: {metrics}."""


KNOWN_DIMS = {"lob", "region", "claim_type", "diagnosis_category", "provider",
              "drug_class", "reject_code", "formulary_tier", "status"}


def brain_dims() -> set:
    """Every dimension the BRAIN knows about, not just the ones hardcoded here.

    GROUP_BY_KEYWORDS above covers the medical/PBM schema this router was
    written for. It cannot cover a dimension that did not exist when it was
    written — and auto-onboarded tables declare their own ``dims:`` in
    metrics.md. Symptom this fixes: a HEDIS metric declaring
    ``dims: region, age_band, measure_name`` answered "CBP gap rate by age
    band" with the REGION breakdown, because "by age band" matched nothing,
    group_by stayed None, and the question resolved to the identical intent as
    "what is the CBP gap rate?" — right down to the same semantic-cache key.
    The cache was faithfully returning the correct answer for the intent it
    was handed; the intent was wrong.

    Union of: the hardcoded set, every metric's declared dims, and the
    per-base dim_sql maps. Read at call time so a Brain edit takes effect on
    the next question with no deploy.
    """
    dims = set(KNOWN_DIMS)
    try:
        b = get_brain()
        for m in (b.get("metrics") or {}).values():
            for d in (m.get("dims") or []):
                d = str(d).strip()
                if d:
                    dims.add(d)
        for base_map in (b.get("dim_sql") or {}).values():
            dims.update(str(k) for k in (base_map or {}))
        # Vocabulary ALIASES for dimensions ("hub => dim:hub_id"). Without
        # these, a user must type the raw column name: "by hub" matched
        # nothing while "by hub id" worked, which is not how anyone speaks.
        dims.update(dim_aliases())
    except Exception:                                     # pragma: no cover
        pass
    return dims


def dim_aliases() -> dict:
    """Spoken label -> real column, from vocabulary.md `X => dim:col` lines.

    vocabulary.md already supported `term => metric:id`; the `dim:` form was
    accepted by the parser and then read by nobody, so declaring it looked
    like it worked and did nothing.
    """
    out = {}
    try:
        for term, target in (get_brain().get("synonyms") or {}).items():
            t = str(target).strip()
            if t.startswith("dim:"):
                col = t[4:].strip()
                if col:
                    out[str(term).strip().lower()] = col
    except Exception:                                     # pragma: no cover
        pass
    return out


def resolve_dim(label):
    """Map a matched dimension label to the real column name."""
    if not label:
        return label
    return dim_aliases().get(str(label).strip().lower(), label)


def _scalar(v):
    """Coerce an LLM slot to a single hashable value.

    The router prompt asks for group_by/filter values as scalars (the one
    documented exception is filters.quarter_range, a 2-element list). A
    model is free to ignore that and return ["provider"] instead of
    "provider" — Gemini does this in practice. Every downstream consumer
    (sql_agent's dims_map.get(group_by, ...)) uses the value as a dict
    key, so an un-coerced list surfaces as
    ``TypeError: unhashable type: 'list'`` deep in template SQL building,
    with no hint that the real fault was an unvalidated LLM slot. Coerce
    once, here, at the boundary where untrusted model output enters the
    pipeline.
    """
    if isinstance(v, list):
        return v[0] if v else None
    if isinstance(v, (dict, set)):
        return None
    return v


def _sanitize_llm_out(out: dict) -> dict:
    out["group_by"] = _scalar(out.get("group_by"))
    # Validate against the BRAIN's dimensions, not just the hardcoded set —
    # otherwise a model that correctly answers "age_band" for an onboarded
    # HEDIS metric gets its answer thrown away as unrecognised.
    out["group_by"] = resolve_dim(out.get("group_by"))
    if out["group_by"] is not None and out["group_by"] not in brain_dims():
        out["group_by"] = None
    filters = out.get("filters") or {}
    if not isinstance(filters, dict):
        filters = {}
    clean = {}
    for k, v in filters.items():
        if k == "quarter_range":
            clean[k] = v if isinstance(v, list) else _scalar(v)
        else:
            clean[k] = _scalar(v)
    out["filters"] = clean
    return out


class IntentRouter:
    def __init__(self, llm):
        self.llm = llm

    def route(self, question: str, grounding: dict) -> dict:
        if self.llm:
            prompt = get_brain()["prompts"].get("router",
                                                ROUTER_SYSTEM_PROMPT)
            out = self.llm.complete_json(
                system=prompt.format(
                    intents=INTENTS, lobs=_vals("lob"),
                    metrics=", ".join(grounding["metrics"].keys())),
                user=question)
            if out and out.get("intent") in INTENTS:
                out["source"] = "llm"
                out.setdefault("extraction_trace", [])
                out.setdefault("filters", {})
                return _sanitize_llm_out(out)
        return self._rule_based(question, grounding)

    def _rule_based(self, question: str, grounding: dict) -> dict:
        q = question.lower()
        trace = []

        def match(pattern, text=q):
            m = re.search(pattern, text)
            if m:
                trace.append({"entity": "slot", "regex": pattern,
                              "matched_text": m.group(0)})
            return m

        pharmacy = bool(PHARMACY_HINTS.search(q)) or any(
            m in grounding["metrics"]
            for m in ("pharmacy_cost", "pbm_reject_rate"))
        member_domain = any(v.get("base") == "members"
                            for v in grounding["metrics"].values())

        # Pick THE metric deterministically and by domain, not by arbitrary
        # dict/set order. A question can ground several metrics ("pharmacy
        # reject rate for members" grounds both pbm_reject_rate[rx] and
        # enrollment[members]); choosing next(iter(...)) made the answer depend
        # on hash-randomized ordering. Prefer the base that matches the
        # question's domain (pharmacy -> rx, otherwise member/claims), then
        # fall back to a stable alphabetical order.
        gm = grounding.get("metrics", {})
        if pharmacy:
            want = "rx"
        elif member_domain and any(
                w in q for w in ["member", "enrol", "raf", "risk score",
                                 "hedis", "dual", "risk adjust"]):
            want = "members"
        else:
            want = "claims"

        def _pick(metrics_dict):
            if not metrics_dict:
                return "pharmacy_cost" if pharmacy else "medical_cost"
            ranked = sorted(
                metrics_dict.items(),
                key=lambda kv: (0 if kv[1].get("base") == want else 1, kv[0]))
            return ranked[0][0]
        metric = _pick(gm)

        filters = {}
        for v in _vals("lob"):
            if match(rf"\b{re.escape(v.lower())}\b"):
                filters["lob"] = v
        for v in _vals("region"):
            if match(rf"\b{re.escape(v.lower())}\b"):
                filters["region"] = v
        for v in _vals("claim_type"):
            if not pharmacy and match(rf"\b{re.escape(v.lower())}\b"):
                filters["claim_type"] = v
        for v in _vals("diagnosis_category"):
            if match(rf"\b{re.escape(v.lower())}\b"):
                filters["diagnosis_category"] = v
        for v in _vals("drug_class"):
            if match(rf"\b{re.escape(v.lower())}\b"):
                filters["drug_class"] = v
        m = match(r"\breject code\s*(70|75|76)\b") or \
            match(r"\bcode\s*(70|75|76)\b")
        if m:
            filters["reject_code"] = m.group(1)
        m = match(r"\btier\s*([1-5])\b")
        if m:
            filters["formulary_tier"] = m.group(1)
        m = match(r"\b(pr-\d{3})\b")
        if m:
            filters["provider_id"] = m.group(1).upper()
        # quarter RANGE: "from 2025 Q1 to 2026 Q2", "between X and Y", "X to Y"
        qpat = r"(20\d\d)\s?q\s?([1-4])"
        mr = match(rf"(?:from|between|starting from)?\s*{qpat}\s*(?:to|and|through|-|until)\s*{qpat}")
        if mr:
            filters["quarter_range"] = [f"{mr.group(1)}Q{mr.group(2)}",
                                        f"{mr.group(3)}Q{mr.group(4)}"]
        else:
            m = match(r"\b(20\d\d)\s?q([1-4])\b")
            if m:
                filters["service_quarter"] = f"{m.group(1)}Q{m.group(2)}"

        # explicit chart preference
        wants_chart = None
        for ct, pats in {"bar": ["bar graph", "bar chart", "bars"],
                         "line": ["line graph", "line chart"],
                         "pie": ["pie chart", "pie graph", "donut"],
                         "area": ["area chart", "area graph"],
                         "scatter": ["scatter plot", "scatter chart"]}.items():
            if any(pt in q for pt in pats):
                wants_chart = ct
                trace.append({"entity": "chart_preference",
                              "regex": "|".join(pats), "matched_text": ct})

        group_by = None
        for dim, kws in GROUP_BY_KEYWORDS.items():
            if any(kw in q for kw in kws):
                group_by = dim

        # Then any dimension the BRAIN declares that the map above has never
        # heard of — "by age band" for a metric whose dims include age_band.
        # Longest label first so "by measure name" beats a stray "by measure".
        if group_by is None:
            for dim in sorted(brain_dims(), key=len, reverse=True):
                label = re.escape(dim.replace("_", " "))
                pat = rf"\b(?:by|per|across|for each)\s+{label}\b"
                if match(pat):
                    group_by = resolve_dim(dim)
                    trace.append({"entity": "group_by_brain_dim",
                                  "regex": pat, "matched_text": dim})
                    break

        # "which/what/list <dimension noun>" — a breakdown the user expressed
        # without the word "by". "Which reject codes spiked?" is a breakdown by
        # reject_code. Gated on an interrogative/breakdown cue so an incidental
        # noun (e.g. "reject" inside "reject rate") does not trigger it.
        if group_by is None and re.search(
                r"\b(which|what|list|breakdown|across|for each|per)\b", q):
            for dim, nouns in DIMENSION_NOUNS:
                if any(re.search(rf"\b{re.escape(n)}\b", q) for n in nouns):
                    group_by = dim
                    trace.append({"entity": "group_by_noun",
                                  "regex": "|".join(nouns), "matched_text": dim})
                    break

        if COMPLIANCE_HINTS.search(q):
            intent = "compliance_audit"
        elif grounding.get("drugs") and re.search(
                r"\b(tier|cover|formulary|prior auth|pa\b|why)", q):
            intent = "formulary_lookup"
        elif any(w in q for w in ["scatter", "correlation", "volume vs"]):
            intent = "correlation"
            group_by = group_by or "provider"
        elif any(w in q for w in ["why", "driver", "driven", "cause",
                                  "explain", "root", "reason"]):
            intent = "root_cause"
        elif any(w in q for w in ["top", "worst", "best", "highest",
                                  "lowest", "rank", "share", "mix",
                                  "distribution", "spike", "spiked", "jump",
                                  "jumped", "surge", "surged", "which"]):
            intent = "top_n"
            group_by = group_by or ("drug_class" if pharmacy else "lob")
        elif group_by:
            intent = "breakdown"
        elif any(w in q for w in ["list", "detail", "sample",
                                  "show me claims"]):
            intent = "detail_lookup"
        else:
            intent = "metric_trend"

        # range + "by X" phrasing means the user wants the matrix view
        if filters.get("quarter_range") and group_by \
                and intent in ("metric_trend", "root_cause", "top_n"):
            intent = "breakdown"
        # Report the domain of the metric we actually chose, not just whichever
        # domain happened to be grounded. "Pharmacy reject rate for members"
        # grounds enrollment[members] too, but we answer with pbm_reject_rate
        # (rx) — so the domain label must read "pharmacy", not "member".
        chosen_base = gm.get(metric, {}).get("base")
        domain = {"rx": "pharmacy", "members": "member"}.get(
            chosen_base, "pharmacy" if pharmacy else "medical")
        return {"intent": intent, "metric": metric, "group_by": group_by,
                "filters": filters,
                "domain": domain,
                "time_grain": "quarter",
                "wants_chart": wants_chart,
                "wants_pie": any(w in q for w in ["share", "mix",
                                                  "distribution", "pie"]),
                "extraction_trace": trace, "source": "rules"}
