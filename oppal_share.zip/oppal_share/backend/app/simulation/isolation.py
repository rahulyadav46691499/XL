"""Simulation sandbox isolation (Phase 5, TDD §1.1.1).

Five isolation invariants, and where each is actually enforced:

  1. Brain isolation      — ``fork_brain()`` returns a DEEP COPY of the live
     Brain. A simulation applies its ``ParameterOverride`` list to the copy
     only; there is no aliasing path back to the ``_brain`` singleton (deep
     copy, not a shallow reference) — verified by ``assert_forked`` below and
     by test A1/A2.
  2. Scope isolation      — this module never touches ``ScopeContext``; the
     caller's scope is threaded through unmodified by ``app/simulation/
     engine.py`` straight into ``DataAccessService.execute``.
  3. Data isolation       — enforced by the engine calling
     ``DataAccessService.execute(..., purpose="simulation")``; Zero-Copy /
     Zero-Persistence is unchanged (this module does not query anything).
  4. Write isolation      — nothing in this module (or in ``engine.py``) has
     a write path; the only production effect a simulation can ever have is
     REQ-5.5 promotion, which proposes a Phase-4 ``ActionRequest`` — it does
     not execute one.
  5. Concurrency isolation — every simulation gets its own ``run_id`` and its
     own forked dict; the engine passes the fork EXPLICITLY into every
     downstream call (cohort/SQL agents, formula lookups) rather than relying
     on any shared/global state, so two simulations running at once (or a
     simulation racing a live ``/api/ask``) never observe each other. The
     ``contextvar`` below is a secondary introspection/debugging aid, not the
     isolation mechanism itself — correctness never depends on it.
"""
from __future__ import annotations

import contextvars
import copy
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field

from ..semantic.brain import get_brain

#: introspection only (e.g. "what run is this thread currently inside,"
#: useful for logging) — NOT relied on for isolation correctness.
CURRENT_RUN_ID: contextvars.ContextVar = contextvars.ContextVar(
    "oppal_sim_run_id", default=None)

# Brain sections that must never be aliased between the fork and the live
# singleton — every simulation-relevant section, so identity checks (A1) are
# meaningful for the whole surface a simulation actually reads.
_FORK_CHECK_KEYS = ("metrics", "policy_rules", "simulation", "action_rules",
                    "governance", "dim_sql", "cohort_fields", "tables")


@dataclass
class Sandbox:
    run_id: str
    domain: str
    brain_fork: dict = field(repr=False)


def fork_brain(domain: str | None = None) -> dict:
    """A deep copy of the live Brain. Overrides are applied to THIS object
    only; mutating it can never reach ``get_brain()`` because a deep copy
    holds no shared mutable containers with the original."""
    live = get_brain()
    fork = copy.deepcopy(live)
    assert fork is not live, "fork_brain must not return the live singleton"
    for key in _FORK_CHECK_KEYS:
        if key in live:
            assert fork.get(key) is not live.get(key), (
                f"fork_brain aliases the live singleton's '{key}' section")
    return fork


def assert_forked(brain_fork: dict) -> None:
    """Callable independently by tests: proves a given fork is a true
    isolate of whatever the live Brain looks like RIGHT NOW."""
    live = get_brain()
    assert brain_fork is not live
    for key in _FORK_CHECK_KEYS:
        if key in live:
            assert brain_fork.get(key) is not live.get(key)


@contextmanager
def sandbox(domain: str | None = None):
    """``with isolation.sandbox() as sb:`` — forks the Brain, marks the
    current run_id for introspection, and unconditionally clears the
    contextvar on exit (success or failure). Yields a :class:`Sandbox` whose
    ``brain_fork`` the caller must thread explicitly into every downstream
    call; nothing here is discovered implicitly."""
    run_id = f"SIM-{uuid.uuid4().hex[:12]}"
    live_domain = domain or get_brain().get("domain_id", "")
    sb = Sandbox(run_id=run_id, domain=live_domain,
                brain_fork=fork_brain(live_domain))
    token = CURRENT_RUN_ID.set(run_id)
    try:
        yield sb
    finally:
        # close_sandbox: discard the fork reference and free the contextvar.
        # There is nothing to flush/persist — a simulation writes nothing.
        CURRENT_RUN_ID.reset(token)
        sb.brain_fork = None


__all__ = ["Sandbox", "fork_brain", "assert_forked", "sandbox",
           "CURRENT_RUN_ID"]
