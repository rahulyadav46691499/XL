"""Actuarial "What-If" Simulator engine (Phase 5).

Implements the TDD §1.1.2 step sequence: fork the Brain, resolve a baseline
cohort through the EXISTING cohort compiler (``agents.cohort_agent``,
brain-injected so it never touches the live singleton), run a baseline pass
and a simulated pass through the SAME Zero-Copy MCP path
(``DataAccessService.execute(..., purpose="simulation")``), score trust on
both, and return a ``SimulationResult``. Promotion (REQ-5.5) proposes a
Phase-4 ``ActionRequest`` — it never writes anything itself.

Design note on parameter overrides (read this before editing): a
``ParameterOverride`` addresses a DOTTED, numeric leaf inside the FORKED
Brain — either a real Brain parameter (e.g.
``simulation.admin_burden.pa_touch_minutes``, which changes the admin-burden
multiplier for this run only, exactly the same way editing simulation.md
would change it for every run — B3) or one of four *virtual* stress-percent
leaves this engine reads back after overrides are applied:
``metrics.mlr.stress_pct``, ``metrics.medical_cost.stress_pct``,
``metrics.pharmacy_cost.stress_pct`` and ``metrics.reject_count.stress_pct``.
Those four virtual leaf NAMES are the payer's; a domain that declares
``### simulator_bindings`` in simulation.md renames them to its own levers
(see ``_DEFAULT_BINDINGS`` and ``bindings()``), and the domain's own binding is
what a ``ParameterOverride`` must address.
Overrides may NEVER target a SQL-bearing field (``sql``, ``formula``,
``value_sql``, ``table``, ``time_column``) — that would be a code-injection
surface, not a what-if lever — and this is enforced independently of the
Pydantic contract's own governance/action-rule denylist (defense in depth,
mirroring the Phase 4 "engine + adapter both re-check" pattern).
"""
from __future__ import annotations

import logging
import os
import sqlite3
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutTimeout
from datetime import datetime, timezone
from decimal import ROUND_HALF_UP, Decimal

from .. import config
from ..agents.case_store import scope_label
from ..agents.cohort_agent import CohortAgent, compile_where
from ..mcp import data_service
from ..schemas.simulation import (MetricDelta, ParameterOverride,
                                  SimulationRequest, SimulationResult)
from ..trust import scoring
from . import isolation

log = logging.getLogger("oppal.simulation")

SIM_DB = os.environ.get(
    "OPPAL_SIM_DB",
    os.path.join(os.path.dirname(os.path.dirname(__file__)), "data",
                 "simulations.db"))
_lock = threading.Lock()
_EXECUTOR = ThreadPoolExecutor(max_workers=8, thread_name_prefix="oppal-sim")

# brain_path suffixes that can NEVER be an override target — mutating them
# would tamper with the query/formula text itself rather than a what-if lever.
_SQL_BEARING_SUFFIXES = ("sql", "formula", "value_sql", "table",
                         "time_column", "check", "rule_id")

# The payer's formula ids, kept as a module constant because external callers
# and tests import it. run_simulation() no longer reads it: the ids it requires
# are derived per domain from the simulator bindings below, and for the payer
# that derivation yields exactly this set.
REQUIRED_FORMULA_IDS = ("mlr", "net_dollar_impact", "admin_burden",
                        "affected_members", "medical_cost", "pharmacy_cost")

# ---------------------------------------------------------------------------
# SIMULATOR BINDINGS — the one payer-specific thing left in this engine.
#
# The delta model's SHAPE is already generic: a ratio reported in basis points,
# two cost legs whose reduction is the net dollar impact, a volume whose change
# becomes an operations burden, and a population count. What was payer-specific
# was the NAMES: four metric ids and three literal FROM clauses
# (`FROM claims c JOIN members m`, `FROM pharmacy_claims rx`,
# `FROM members m2`) hardcoded here. Under any other domain's Brain the
# simulator raised a named configuration error and the tab was dead.
#
# A domain now binds its own metrics and tables by declaring a
# `### simulator_bindings` section in simulation.md. Every key below is the
# PAYER value, used verbatim when the section is absent — so the payer and
# pharma paths are unchanged, byte for byte.
#
# `*_from` clauses carry the alias the bound metric's SQL and the compiled
# cohort predicate expect. `*_stress_key` is the virtual `metrics.<key>.
# stress_pct` leaf an override addresses; it is a separate key because the
# payer's volume lever is spelled `reject_count` while its volume metric is
# `pbm_reject_rate`.
_DEFAULT_BINDINGS = {
    "ratio_metric": "mlr",
    "ratio_formula": "mlr",
    "ratio_from": "FROM claims c JOIN members m ON c.member_id = m.member_id",
    "ratio_stress_key": "mlr",
    "cost_a_metric": "medical_cost",
    "cost_a_formula": "medical_cost",
    "cost_a_from": "FROM claims c",
    "cost_a_stress_key": "medical_cost",
    "cost_b_metric": "pharmacy_cost",
    "cost_b_formula": "pharmacy_cost",
    "cost_b_from": "FROM pharmacy_claims rx",
    "cost_b_scope_alias": "rx.lob",
    "cost_b_stress_key": "pharmacy_cost",
    "volume_metric": "pbm_reject_rate",
    "volume_formula": "admin_burden",
    "volume_from": "FROM pharmacy_claims rx",
    "volume_scope_alias": "rx.lob",
    "volume_stress_key": "reject_count",
    "population_formula": "affected_members",
    "population_sql": "COUNT(DISTINCT m2.member_id)",
    "population_from": "FROM members m2",
    "population_scope_alias": "m2.lob",
    "net_formula": "net_dollar_impact",
    "cohort_scope_alias": "c.lob",
}

# Keys whose value reaches the warehouse as SQL text. A Brain edit may rebind
# them — that is the whole point — but only to a table reference, never to
# something carrying a statement terminator or a comment, which would let a
# markdown edit smuggle SQL past the read-only gate rather than merely name a
# table for it.
_SQL_BEARING_BINDINGS = ("ratio_from", "cost_a_from", "cost_b_from",
                         "volume_from", "population_from", "population_sql")
_FORBIDDEN_IN_BINDING = (";", "--", "/*", "*/")


def bindings(brain: dict) -> dict:
    """Resolved simulator bindings: payer defaults <- simulation.md."""
    declared = (brain.get("simulation") or {}).get("simulator_bindings") or {}
    out = dict(_DEFAULT_BINDINGS)
    for key, value in declared.items():
        if key not in _DEFAULT_BINDINGS:
            continue                     # ignore prose bullets (definition, owner)
        text = " ".join(str(value).split())
        if not text:
            continue
        if key in _SQL_BEARING_BINDINGS and any(
                bad in text for bad in _FORBIDDEN_IN_BINDING):
            raise SimulationConfigError(
                f"simulator binding '{key}' contains a statement separator or "
                f"comment marker; it may name a table, not carry SQL")
        out[key] = text
    return out


def _required_formula_ids(b: dict) -> tuple:
    """The simulation.md formula ids this binding set needs declared."""
    return (b["ratio_formula"], b["cost_a_formula"], b["cost_b_formula"],
            b["volume_formula"], b["net_formula"], b["population_formula"])

# Aliases accepted in `SimulationRequest.metrics_requested`. The BRD/TDD's
# default vocabulary says "net_savings"; simulation.md declares the same
# quantity as `net_dollar_impact`. Mapping them here keeps the public request
# vocabulary stable without duplicating the Brain formula (audit finding S-2).
_METRIC_ALIASES = {"net_savings": "net_dollar_impact",
                   "affected_member_count": "affected_members",
                   "member_abrasion": "affected_members"}


def _metric_aliases(b: dict) -> dict:
    """Request vocabulary -> this domain's declared formula id.

    `SimulationRequest.metrics_requested` defaults, in the Pydantic schema, to
    the payer slot names — so a caller who asks for nothing in particular is
    asking for "mlr, net_savings, admin_burden, affected_members". Under a
    rebound Brain those ids are not declared and the request was refused as
    naming unknown metrics, which meant the Simulator could not be driven at
    all off-payer without the caller knowing the internal binding names.

    Extending the alias map is what this map already exists for: keeping the
    public request vocabulary stable without duplicating a Brain formula. For
    the payer every entry below is the identity, so nothing changes.
    """
    out = dict(_METRIC_ALIASES)
    out.update({
        "mlr": b["ratio_formula"],
        "medical_cost": b["cost_a_formula"],
        "pharmacy_cost": b["cost_b_formula"],
        "admin_burden": b["volume_formula"],
        "net_dollar_impact": b["net_formula"],
        "net_savings": b["net_formula"],
        "affected_members": b["population_formula"],
        "affected_member_count": b["population_formula"],
        "member_abrasion": b["population_formula"],
    })
    return out


class SimulationError(Exception):
    """Base for every simulator control-flow refusal."""


class SimulationConfigError(SimulationError):
    """A Brain formula id the simulator needs is missing. Fails closed —
    NEVER falls back to a hardcoded formula (NFR-1)."""


class SimulationTimeout(SimulationError):
    """A warehouse query exceeded the configured statement timeout."""


class SimulationScopeDenied(SimulationError):
    """The NL cohort named a line of business outside the caller's scope."""


# ---------------------------------------------------------------------------
def _con():
    os.makedirs(os.path.dirname(SIM_DB), exist_ok=True)
    con = sqlite3.connect(SIM_DB, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS simulations (
            run_id TEXT PRIMARY KEY, requested_by TEXT, lob TEXT,
            result_json TEXT, logic_tree_json TEXT, created_at TEXT)""")
    return con


def _save(run_id, requested_by, lob, result: SimulationResult, logic: dict):
    import json
    with _lock:
        con = _con()
        try:
            con.execute(
                "INSERT OR REPLACE INTO simulations VALUES (?,?,?,?,?,?)",
                (run_id, requested_by, lob, result.model_dump_json()
                 if hasattr(result, "model_dump_json")
                 else json.dumps(result.model_dump(), default=str),
                 json.dumps(logic, default=str),
                 datetime.now(timezone.utc).isoformat()))
            con.commit()
        finally:
            con.close()


def _load_row(run_id: str):
    con = _con()
    try:
        return con.execute("SELECT * FROM simulations WHERE run_id = ?",
                           (run_id,)).fetchone()
    finally:
        con.close()


def _audit(event: str, *, run_id: str, actor: str, extra: dict | None = None):
    try:
        from ..privacy.phi_guard import PHIGuard
        from ..trust.audit_ledger import _write
        rec = {"ts": datetime.now(timezone.utc).isoformat(),
               "kind": "simulation", "event": event, "run_id": run_id,
               "actor": actor}
        rec.update(PHIGuard(enabled=True).scrub_structure(extra or {}))
        _write(rec)
    except Exception:                                     # pragma: no cover
        log.debug("simulation audit failed", exc_info=True)


# ---------------------------------------------------------------------------
def _get_path(d: dict, path: str, default=None):
    node = d
    for part in path.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def _set_path(d: dict, path: str, value) -> None:
    parts = path.split(".")
    node = d
    for part in parts[:-1]:
        nxt = node.get(part)
        if not isinstance(nxt, dict):
            nxt = {}
            node[part] = nxt
        node = nxt
    node[parts[-1]] = value


def _assert_safe_override_target(path: str) -> None:
    """Defense in depth alongside ParameterOverride's own governance
    denylist: never let an override touch a SQL/formula-bearing field."""
    tail = path.rsplit(".", 1)[-1].lower()
    if tail in _SQL_BEARING_SUFFIXES:
        raise SimulationError(
            f"override target '{path}' would tamper with query/formula "
            f"text, not a what-if parameter; refused")


def _to_decimal(v) -> Decimal:
    try:
        return Decimal(str(v))
    except Exception:
        return Decimal(0)


def _apply_op(base: Decimal, op, value) -> Decimal:
    """`value` for DELTA_PCT/TIER_SHIFT is always a plain fraction (-0.05 ==
    -5%). If the target's current value is exactly zero there is nothing to
    take a percentage OF (e.g. a fresh stress-percent lever, or an untouched
    accumulator) — the override's intent is additive in that case: "move
    this lever by `value`", not "take value percent of nothing"."""
    from ..schemas.simulation import OverrideOp
    v = _to_decimal(value)
    if op == OverrideOp.SET:
        return v
    if op == OverrideOp.DELTA_ABS:
        return base + v
    if op in (OverrideOp.DELTA_PCT, OverrideOp.TIER_SHIFT):
        # TIER_SHIFT is modeled as an equivalent percentage stress — a full
        # formulary-tier engine is out of scope for this deliverable.
        if base == 0:
            return base + v
        return base * (Decimal(1) + v)
    return base


def _apply_overrides_to_fork(brain_fork: dict,
                             overrides: list[ParameterOverride]) -> None:
    for ov in overrides:
        _assert_safe_override_target(ov.brain_path)
        current_dec = _to_decimal(_get_path(brain_fork, ov.brain_path,
                                            default=0))
        new_val = _apply_op(current_dec, ov.op, ov.value)
        _set_path(brain_fork, ov.brain_path, new_val)


def _stress(brain_fork: dict, metric: str) -> Decimal:
    return _to_decimal(_get_path(brain_fork, f"metrics.{metric}.stress_pct",
                                 default=0))


# ---------------------------------------------------------------------------
def _run_query(sql: str, scope, timeout_s: int, run_id: str) -> tuple:
    """Execute one governed, already-scoped SELECT with a hard client-side
    deadline. Returns (QueryResult, elapsed_ms). On expiry raises
    SimulationTimeout and records a `sim_timeout` ledger entry — the query is
    never allowed to hang the caller (NFR-3 / §4.1)."""
    svc = data_service()
    fut = _EXECUTOR.submit(svc.execute, sql, scope, purpose="simulation")
    t0 = time.time()
    try:
        result = fut.result(timeout=timeout_s)
    except FutTimeout:
        fut.cancel()
        elapsed_ms = round((time.time() - t0) * 1000, 1)
        _audit("sim_timeout", run_id=run_id, actor=getattr(scope, "user_id",
                                                            ""),
               extra={"elapsed_ms": elapsed_ms, "timeout_s": timeout_s})
        err = SimulationTimeout(
            f"warehouse query exceeded the {timeout_s}s statement timeout")
        err.run_id = run_id
        err.elapsed_ms = elapsed_ms
        raise err
    return result, round((time.time() - t0) * 1000, 1)


def _aggregate(expr: str, from_sql: str, where: str, scope, timeout_s: int,
              run_id: str, *, want_presence: bool = False) -> tuple:
    """SELECT {expr} AS value {from_sql} WHERE {where} — a single-row
    aggregate. `expr` always comes from a governed metrics.md field; `where`
    always comes from compile_where()/the LOB predicate.

    Returns (Decimal value, elapsed_ms, truncated) or, with
    ``want_presence=True``, (value, elapsed_ms, truncated, present) where
    ``present`` is False when the warehouse returned NULL / no rows — i.e. the
    quantity is UNDEFINED rather than zero (D3: divide-by-zero MLR must be
    reported as n/a, never as 0 and never as inf).
    """
    sql = f"SELECT {expr} AS value {from_sql} WHERE {where}"
    result, ms = _run_query(sql, scope, timeout_s, run_id)
    if not result.ok:
        if result.refusal_reason:
            raise SimulationScopeDenied(result.refusal_reason)
        return (Decimal(0), ms, False, False) if want_presence \
            else (Decimal(0), ms, False)
    if not result.rows or result.rows[0][0] is None:
        return (Decimal(0), ms, result.truncated, False) if want_presence \
            else (Decimal(0), ms, result.truncated)
    value = _to_decimal(result.rows[0][0])
    return (value, ms, result.truncated, True) if want_presence \
        else (value, ms, result.truncated)


def _lob_predicate(alias_col: str, scope) -> str:
    lobs = ", ".join(f"'{l}'" for l in (scope.allowed_lobs or []))
    return f"{alias_col} IN ({lobs})" if lobs else "1=0"   # deny-by-default


# ---------------------------------------------------------------------------
def run_simulation(request: SimulationRequest, user: dict, scope) -> \
        SimulationResult:
    if not scope.is_effective():
        _audit("sim_scope_denied", run_id="(none)",
               actor=user.get("user_id", ""),
               extra={"reason": "no authorized scope"})
        raise SimulationScopeDenied("no authorized line-of-business scope")

    timeout_s = int(config.mcp_config().get("statement_timeout_seconds", 30))
    t0 = time.time()

    with isolation.sandbox() as sb:
        brain_fork = sb.brain_fork
        run_id = sb.run_id
        sim_formulas = brain_fork.get("simulation", {})
        bind = bindings(brain_fork)
        required_formulas = _required_formula_ids(bind)
        missing = [f for f in required_formulas if f not in sim_formulas]
        if missing:
            raise SimulationConfigError(
                f"missing Brain formula id(s) in simulation.md: "
                f"{', '.join(missing)}")
        # NFR-1 fail-closed: the burden formula's own leaf value must come from
        # the Brain too — no silent Python-side numeric fallback if an operator
        # edits simulation.md and drops this line.
        burden_unit_path = (f"simulation.{bind['volume_formula']}"
                            f".pa_touch_minutes")
        if _get_path(brain_fork, burden_unit_path) is None:
            raise SimulationConfigError(
                f"missing Brain leaf: {burden_unit_path}")

        # audit finding S-2: `metrics_requested` used to be accepted and then
        # silently ignored. Every requested id must resolve to a formula the
        # BRAIN declares — an unknown id fails closed (-> HTTP 422 naming it,
        # the same contract as a missing formula) instead of quietly returning
        # a different metric set than the caller asked for.
        aliases = _metric_aliases(bind)
        requested = [aliases.get(m, m)
                     for m in (request.metrics_requested or [])]
        unknown = [m for m in requested if m not in sim_formulas]
        if unknown:
            raise SimulationConfigError(
                f"unknown metric id(s) not declared in simulation.md: "
                f"{', '.join(sorted(set(unknown)))}")

        cohort_agent = CohortAgent(llm=None)
        parsed = cohort_agent.parse(request.baseline_query, brain=brain_fork)
        filters = parsed.get("filters", [])
        full_scope = scope.is_full_scope()
        for f in filters:
            if f.get("field") == "lob" and not full_scope and \
                    f.get("value") not in (scope.allowed_lobs or []):
                _audit("sim_scope_denied", run_id=run_id,
                       actor=user.get("user_id", ""),
                       extra={"lob": f.get("value")})
                raise SimulationScopeDenied(
                    f"'{f.get('value')}' is outside your authorized scope")
        cohort_where, needs_members = compile_where(filters, brain=brain_fork)
        cohort_where = cohort_where or "1=1"

        claims_where = (f"({cohort_where}) AND "
                        f"{_lob_predicate(bind['cohort_scope_alias'], scope)}")
        rx_where = _lob_predicate(bind["cost_b_scope_alias"], scope)
        volume_where = _lob_predicate(bind["volume_scope_alias"], scope)
        members_where = (
            f"({cohort_where}) AND "
            f"{_lob_predicate(bind['population_scope_alias'], scope)}") \
            if needs_members \
            else _lob_predicate(bind["population_scope_alias"], scope)

        # The delta model needs four metrics by id. WHICH four is a binding
        # (see _DEFAULT_BINDINGS); reaching for the payer's names directly
        # raised a bare KeyError under any other domain's Brain — a 500 with no
        # explanation, at the moment a user pressed "Run simulation". A missing
        # metric is a configuration fact, not a crash: name the ones that are
        # absent and say what the simulator needs.
        metrics_b = brain_fork["metrics"]
        _REQUIRED = (bind["ratio_metric"], bind["cost_a_metric"],
                     bind["cost_b_metric"], bind["volume_metric"])
        _missing = [m for m in _REQUIRED if m not in metrics_b]
        if _missing:
            raise SimulationConfigError(
                "The what-if simulator's delta model requires the metrics "
                + ", ".join(_REQUIRED)
                + f" — this Brain does not define: {', '.join(_missing)}. "
                "Either define them in metrics.md or rebind the simulator in "
                "simulation.md under '### simulator_bindings'; the simulator "
                "will not substitute a hardcoded formula for a missing "
                "declaration.")
        mlr_sql = metrics_b[bind["ratio_metric"]]["sql"]
        medical_sql = metrics_b[bind["cost_a_metric"]]["sql"]
        pharmacy_sql = metrics_b[bind["cost_b_metric"]]["sql"]
        reject_case = metrics_b[bind["volume_metric"]]["value_sql"]
        if not str(reject_case).strip():
            raise SimulationConfigError(
                f"metric '{bind['volume_metric']}' is bound as the "
                f"simulator's volume lever but declares no 'value_sql', so "
                f"there is no per-row expression to count")

        warehouse_ms = 0.0
        truncated = False

        # D3: a NULL aggregate means the denominator (earned premium) was zero
        # or the cohort was empty — MLR is genuinely undefined, NOT 0%. We
        # carry that distinction as `mlr_available=False` rather than letting a
        # meaningless 0 bps look like a real, spectacularly good loss ratio.
        baseline_mlr, ms, tr, mlr_present = _aggregate(
            mlr_sql, bind["ratio_from"], claims_where, scope, timeout_s,
            run_id, want_presence=True)
        mlr_available = mlr_present
        warehouse_ms += ms
        truncated = truncated or tr

        baseline_medical, ms, tr = _aggregate(
            medical_sql, bind["cost_a_from"], claims_where, scope, timeout_s,
            run_id)
        warehouse_ms += ms
        truncated = truncated or tr

        baseline_pharmacy, ms, tr = _aggregate(
            pharmacy_sql, bind["cost_b_from"], rx_where, scope,
            timeout_s, run_id)
        warehouse_ms += ms
        truncated = truncated or tr

        baseline_rejects, ms, tr = _aggregate(
            f"SUM({reject_case})", bind["volume_from"], volume_where,
            scope, timeout_s, run_id)
        warehouse_ms += ms
        truncated = truncated or tr

        baseline_members, ms, tr = _aggregate(
            bind["population_sql"], bind["population_from"], members_where,
            scope, timeout_s, run_id)
        warehouse_ms += ms
        truncated = truncated or tr

        # ---- apply overrides to the FORK only, then read the simulated
        # pass back from stress-percent leaves + any admin_burden override.
        _apply_overrides_to_fork(brain_fork, request.parameter_overrides)

        def _stressed(name, base):
            pct = _stress(brain_fork, name)      # a plain fraction: -0.05 == -5%
            return (base * (Decimal(1) + pct)).quantize(
                Decimal("0.0001"), rounding=ROUND_HALF_UP)

        simulated_mlr = _stressed(bind["ratio_stress_key"], baseline_mlr)
        simulated_medical = _stressed(bind["cost_a_stress_key"],
                                      baseline_medical)
        simulated_pharmacy = _stressed(bind["cost_b_stress_key"],
                                       baseline_pharmacy)
        simulated_rejects = max(Decimal(0),
                                _stressed(bind["volume_stress_key"],
                                          baseline_rejects))

        pa_touch_minutes = _to_decimal(_get_path(brain_fork,
                                                 burden_unit_path))
        rejects_delta = simulated_rejects - baseline_rejects
        admin_burden_delta = (rejects_delta * pa_touch_minutes).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP)

        net_dollar_impact = ((baseline_medical - simulated_medical) +
                             (baseline_pharmacy - simulated_pharmacy)
                             ).quantize(Decimal("0.01"),
                                        rounding=ROUND_HALF_UP)

        any_effect = (simulated_mlr != baseline_mlr or
                     simulated_medical != baseline_medical or
                     simulated_pharmacy != baseline_pharmacy or
                     simulated_rejects != baseline_rejects)
        affected_member_count = int(baseline_members) if any_effect else 0

        def _bps(ratio: Decimal) -> int:
            v = int((ratio * Decimal(10000)).to_integral_value(
                rounding=ROUND_HALF_UP))
            return max(0, v)

        baseline_mlr_bps = _bps(baseline_mlr)
        simulated_mlr_bps = _bps(simulated_mlr)
        mlr_delta_bps = simulated_mlr_bps - baseline_mlr_bps

        # audit finding S-1 (B1 traceability): EVERY MetricDelta emitted here
        # must correspond to a formula id declared in simulation.md and echoed
        # in `formula_ids_used` — previously medical_cost/pharmacy_cost were
        # reported with no declared formula, while net_dollar_impact and
        # affected_members were declared but never reported.
        all_metrics = [
            MetricDelta(metric=bind["ratio_formula"], baseline=baseline_mlr,
                       simulated=simulated_mlr,
                       delta=simulated_mlr - baseline_mlr, unit="bps",
                       direction=("favorable" if mlr_delta_bps <= 0
                                  else "adverse") if mlr_delta_bps != 0
                       else "neutral"),
            MetricDelta(metric=bind["cost_a_formula"],
                       baseline=baseline_medical,
                       simulated=simulated_medical,
                       delta=simulated_medical - baseline_medical,
                       unit="usd",
                       direction=("favorable"
                                  if simulated_medical <= baseline_medical
                                  else "adverse")),
            MetricDelta(metric=bind["cost_b_formula"],
                       baseline=baseline_pharmacy,
                       simulated=simulated_pharmacy,
                       delta=simulated_pharmacy - baseline_pharmacy,
                       unit="usd",
                       direction=("favorable"
                                  if simulated_pharmacy <= baseline_pharmacy
                                  else "adverse")),
            MetricDelta(metric=bind["volume_formula"],
                       baseline=baseline_rejects,
                       simulated=simulated_rejects, delta=rejects_delta,
                       unit="minutes",
                       direction=("favorable" if admin_burden_delta <= 0
                                  else "adverse")),
            MetricDelta(metric=bind["net_formula"],
                       baseline=Decimal(0), simulated=net_dollar_impact,
                       delta=net_dollar_impact, unit="usd",
                       direction=("favorable" if net_dollar_impact >= 0
                                  else "adverse")),
            MetricDelta(metric=bind["population_formula"],
                       baseline=Decimal(int(baseline_members)),
                       simulated=Decimal(affected_member_count),
                       delta=Decimal(affected_member_count), unit="count",
                       direction=("neutral" if affected_member_count == 0
                                  else "adverse")),
        ]
        # honour metrics_requested (validated above); an empty/absent list
        # means "everything the Brain declares".
        wanted = set(requested)
        metrics_out = [m for m in all_metrics
                       if not wanted or m.metric in wanted]
        formula_ids_used = [m.metric for m in metrics_out]

        grounding = {"coverage": 1.0 if filters else 0.6}
        gate_checks = {"read_only": True, "parses": True,
                       "single_statement": True}
        trust = scoring.score(
            grounding=grounding, gate=gate_checks,
            result={"ok": True, "row_count": int(baseline_members)},
            sql_source="template",
            metrics={k: metrics_b[k] for k in
                    (bind["ratio_metric"], bind["cost_a_metric"],
                     bind["cost_b_metric"])
                    if k in metrics_b})
        trust_score = trust["score"]
        trust_gate_passed = trust_score >= scoring.HARD_GATE

        lineage_ref = f"SIM-LOGIC-{run_id}"
        try:
            from ..privacy.phi_guard import PHIGuard
            scrubbed_query, _ = PHIGuard(enabled=True).scrub(
                request.baseline_query)
        except Exception:                                 # never block on it
            scrubbed_query = request.baseline_query
        logic_tree = {
            # NFR-2: the NL cohort text is PHI-scrubbed before it is ever
            # persisted — the logic tree is visible to any approver whose
            # scope covers this run, not just the requester (C3).
            "baseline_query": scrubbed_query,
            "parsed_filters": filters, "cohort_where": cohort_where,
            "overrides": [o.model_dump() for o in
                          request.parameter_overrides],
            "formula_ids_used": list(formula_ids_used),
            "formula_provenance": {fid: sim_formulas.get(fid, {})
                                   for fid in formula_ids_used},
            "mlr_available": mlr_available,
            "trust": trust, "lob_scope": list(scope.allowed_lobs or []),
        }

        # Recommendation 2: a simulation's trust score gates whether its
        # promoted action may execute, and the formulas it used live in
        # editable markdown — so the Brain version behind the projection is
        # governance-relevant and is pinned into the logic tree and ledger.
        try:
            from ..trust import provenance as _prov
            logic_tree["provenance"] = _prov.record(
                request.baseline_query, user, trust, sql=cohort_where,
                kind="simulation",
                extra={"run_id": run_id,
                       "formula_ids_used": sorted(formula_ids_used)})
        except Exception:                                 # never block a run
            pass

        elapsed_ms = round((time.time() - t0) * 1000, 1)
        result = SimulationResult(
            run_id=run_id, requested_by=user.get("user_id", ""),
            lob_scope=list(scope.allowed_lobs or []),
            baseline_mlr_bps=baseline_mlr_bps,
            simulated_mlr_bps=simulated_mlr_bps,
            mlr_delta_bps=mlr_delta_bps,
            net_dollar_impact=net_dollar_impact,
            admin_burden_delta=admin_burden_delta,
            affected_member_count=affected_member_count,
            metrics=metrics_out, trust_score=trust_score,
            trust_gate_passed=trust_gate_passed,
            formula_ids_used=list(formula_ids_used),
            mlr_available=mlr_available,
            lineage_ref=lineage_ref,
            created_at=datetime.now(timezone.utc).isoformat(),
            warehouse_ms=warehouse_ms, truncated=truncated)

        _save(run_id, user.get("user_id", ""), scope_label(scope), result,
             logic_tree)
        _audit("simulated", run_id=run_id, actor=user.get("user_id", ""),
              extra={"mlr_delta_bps": mlr_delta_bps,
                     "net_dollar_impact": str(net_dollar_impact),
                     "trust_score": trust_score, "elapsed_ms": elapsed_ms})
        return result


def _readable(row, scope) -> bool:
    """A simulation run is the requester's OWN what-if draft.

    ``requested_by`` was recorded but never enforced, so any principal with a
    matching LOB scope could read another analyst's unpublished scenario. A
    what-if is deliberative: seeing someone's abandoned "what if we cut this
    benefit" run is a real disclosure. Ownership is required; the LOB check is
    kept as an ADDITIONAL constraint, not an alternative.

    This does not weaken maker-checker: promotion (REQ-5.5) copies what an
    approver needs into the dual-control ActionRequest, and the approval path
    reads that request — never this table.
    """
    from ..agents.case_store import _can_see
    owner = row["requested_by"]
    uid = getattr(scope, "user_id", None)
    if owner and uid and owner != uid:
        return False
    return _can_see(row["lob"], scope)


def get_simulation(run_id: str, scope):
    row = _load_row(run_id)
    if not row or not _readable(row, scope):
        return None
    import json
    return SimulationResult(**json.loads(row["result_json"]))


def get_logic_tree(run_id: str, scope) -> dict | None:
    row = _load_row(run_id)
    if not row or not _readable(row, scope):
        return None
    import json
    return json.loads(row["logic_tree_json"])


def list_simulations(scope) -> list:
    con = _con()
    try:
        rows = con.execute(
            "SELECT * FROM simulations ORDER BY created_at DESC").fetchall()
    finally:
        con.close()
    import json
    out = []
    for r in rows:
        if _readable(r, scope):
            out.append(json.loads(r["result_json"]))
    return out


def formulas_for(scope=None) -> dict:
    """GET /api/sim/formulas — the exact Brain-declared formula/risk-factor
    provenance the sandbox UI shows to prove NFR-1 (§3.1)."""
    from ..semantic.brain import get_brain
    b = get_brain()
    return {"formulas": list(b.get("simulation", {}).values()),
           "risk_factors": [r for r in b.get("policy_rules", [])
                            if r.get("pillar") == "regulatory"]}


def promote(run_id: str, note: str, user: dict, scope):
    """REQ-5.5 — promotion NEVER executes anything; it proposes a Phase-4
    ActionRequest into the SAME dual-control queue as any other action
    (§5 B4). Severity is derived from the EXISTING MLR-85 regulatory rule
    (threshold read from the Brain, not a new literal) so a simulation that
    would breach the regulatory MLR floor is routed with elevated severity."""
    from ..actions import engine as action_engine
    from ..semantic.brain import get_brain

    result = get_simulation(run_id, scope)
    if not result:
        raise PermissionError("simulation not found in your authorized scope")

    brain = get_brain()
    mlr_floor = 0.85
    for r in brain.get("policy_rules", []):
        if r.get("check") == "mlr_floor":
            try:
                mlr_floor = float(r.get("threshold", mlr_floor))
            except (TypeError, ValueError):
                pass
    severity = "critical" if (result.simulated_mlr_bps / 10000.0) < mlr_floor \
        else ("high" if not result.trust_gate_passed else "medium")

    action = action_engine.propose(
        case_id="", action_type="simulation_promotion",
        target_object=result.run_id, lob=scope_label(scope),
        summary=(note or f"Promote simulation {result.run_id} "
                f"(MLR Δ {result.mlr_delta_bps} bps, "
                f"net ${result.net_dollar_impact})")[:500],
        estimated_financial_impact=abs(float(result.net_dollar_impact)),
        regulatory_severity=severity, trust_score=result.trust_score,
        compliance_logic={
            "simulation_run_id": result.run_id,
            "lineage_ref": result.lineage_ref,
            "mlr_floor_rule": "MLR-85", "mlr_floor_threshold": mlr_floor,
            "baseline_mlr_bps": result.baseline_mlr_bps,
            "simulated_mlr_bps": result.simulated_mlr_bps,
            "formula_ids_used": result.formula_ids_used},
        fields={"run_id": result.run_id,
               "net_dollar_impact": str(result.net_dollar_impact),
               "mlr_delta_bps": result.mlr_delta_bps},
        target_system="dry_run", proposer_user_id=user.get("user_id", ""))
    _audit("promoted", run_id=run_id, actor=user.get("user_id", ""),
          extra={"action_id": action.action_id})
    try:
        from ..notify.bus import emit
        from ..schemas.notify import NotificationEvent
        emit(NotificationEvent(
            event="sim_promoted", action_id=action.action_id,
            lob=action.lob,
            summary=f"Simulation {run_id} promoted to action "
                   f"{action.action_id}",
            severity="info"))
    except Exception:
        log.debug("notification emit failed for sim_promoted", exc_info=True)
    return action


def reset():
    """Test helper."""
    with _lock:
        con = _con()
        try:
            con.execute("DELETE FROM simulations")
            con.commit()
        finally:
            con.close()


__all__ = ["run_simulation", "get_simulation", "get_logic_tree",
           "list_simulations", "formulas_for", "promote", "reset",
           "SimulationError", "SimulationConfigError", "SimulationTimeout",
           "SimulationScopeDenied", "REQUIRED_FORMULA_IDS"]
