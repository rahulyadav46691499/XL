"""Phase 5 — Actuarial "What-If" Simulator.

Every simulation is a pure function of a frozen, forked Brain snapshot: it
never reads or writes the live Context Brain singleton, never writes to the
warehouse, and never persists anything except (optionally) a pinned workspace
artifact and a ledger "simulation" event. See ``isolation.py`` for the five
isolation invariants and ``engine.py`` for the baseline/simulated delta
computation.
"""
