"""ScopeEnforcer — the single authority for LOB isolation.

Reads the declarative governance rules from the Context Brain (never hardcodes
table names) and turns a :class:`ScopeContext` into either a pushed-down SQL
predicate (for warehouses) or a directive to build a physically-filtered data
plane (for the local reference engine). It also refuses any reference to an
excluded credential/RBAC table, at every scope.
"""
from __future__ import annotations

import logging
import re
from typing import Callable, Optional

from .models import ScopeContext, ScopeStrategy, ScopeViolation

log = logging.getLogger("oppal.mcp.scope")


class ScopeEnforcer:
    """Stateless w.r.t. requests; caches nothing that could leak across users.

    Governance is read fresh from the Brain so a steward editing governance.md
    changes enforcement with no code change or restart.
    """

    def __init__(self, governance_provider: Optional[Callable[[], dict]] = None):
        # Injected for testability (SOLID: depend on abstraction, not module).
        self._governance_provider = governance_provider or self._from_brain

    # -- governance access ---------------------------------------------------
    @staticmethod
    def _from_brain() -> dict:
        from ..semantic.brain import get_brain
        return get_brain().get("governance") or {}

    def rules(self) -> dict:
        g = self._governance_provider() or {}
        # defensive defaults so enforcement never silently disables
        g.setdefault("governed_tables", {})
        g.setdefault("transitive_tables", {})
        g.setdefault("excluded_tables", [])
        g.setdefault("ungoverned_tables", [])
        g.setdefault("scope_column", "lob")
        g.setdefault("require_scope_context", True)
        g.setdefault("deny_by_default", True)
        return g

    def strategy_for(self, connector_name: str) -> ScopeStrategy:
        g = self.rules()
        if connector_name in g.get("pushdown_capable", []):
            return ScopeStrategy.PREDICATE_PUSHDOWN
        return ScopeStrategy.PHYSICAL_SANDBOX

    # -- guards --------------------------------------------------------------
    def require_scope(self, scope: ScopeContext) -> None:
        """Deny by default: raise unless a usable scope is present."""
        g = self.rules()
        if not g.get("require_scope_context", True):
            return
        if scope is None or not isinstance(scope, ScopeContext):
            raise ScopeViolation("No scope context supplied — execution denied")
        if not scope.is_effective():
            raise ScopeViolation(
                f"Principal '{getattr(scope, 'user_id', '?')}' has no "
                f"authorized line-of-business scope — execution denied")

    # -- SQL normalization for the text guards -----------------------------
    @staticmethod
    def _normalize_for_guard(sql: str) -> str:
        """Return SQL prepared for the text guards below:

        * ``--`` line and ``/* */`` block comments removed (replaced by a
          space so they cannot glue tokens together, e.g.
          ``ds./*x*/claims`` -> ``ds. claims``);
        * single-quoted STRING-LITERAL contents blanked (kept as ``''``) so a
          keyword or table name that appears only inside a literal
          (``'drop table'``, ``'%grant exception%'``, ``'users'``) never
          triggers a false refusal.

        Double-quote and backtick spans are treated as IDENTIFIER quoting
        (not string literals) and are preserved, so a qualified/quoted table
        reference like ```proj`.`ds`.`claims``` is still detected.
        This is used only to evaluate the guards; the SQL actually executed
        keeps its original literals.
        """
        out, i, n = [], 0, len(sql)
        quote = None            # active quote char: ' (string) | " | ` (ident)
        while i < n:
            ch = sql[i]
            if quote:
                if ch == quote:
                    if i + 1 < n and sql[i + 1] == quote:      # doubled escape
                        if quote != "'":
                            out.append(ch)
                            out.append(ch)
                        i += 2
                        continue
                    out.append(ch)                             # closing quote
                    quote = None
                    i += 1
                    continue
                if quote != "'":                               # keep identifier
                    out.append(ch)
                i += 1                                         # drop string body
                continue
            if ch in ("'", '"', "`"):
                quote = ch
                out.append(ch)
                i += 1
                continue
            if ch == "-" and i + 1 < n and sql[i + 1] == "-":
                j = sql.find("\n", i)
                # removed entirely (not replaced by space) so a comment cannot
                # split an identifier to dodge a guard, e.g. us--x\ners->users
                if j == -1:
                    break
                i = j
                continue
            if ch == "/" and i + 1 < n and sql[i + 1] == "*":
                j = sql.find("*/", i + 2)
                if j == -1:
                    break
                i = j + 2
                continue
            out.append(ch)
            i += 1
        return "".join(out)

    # read-only / single-statement gate (applies on every strategy) ---------
    _DML_DDL = re.compile(
        r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|MERGE|GRANT|"
        r"REVOKE|ATTACH|REPLACE|CALL|COPY|EXPORT|LOAD)\b", re.I)

    def assert_read_only(self, sql: str) -> None:
        clean = self._normalize_for_guard(sql)
        if self._DML_DDL.search(clean):
            raise ScopeViolation("Only read-only SELECT queries are permitted")
        if clean.strip().rstrip(";").count(";") > 0:
            raise ScopeViolation("Multiple statements are not permitted")

    def assert_no_excluded(self, sql: str) -> None:
        """Refuse any reference to a credential/RBAC-directory table."""
        low = self._normalize_for_guard(sql).lower()
        for t in self.rules().get("excluded_tables", []):
            if re.search(rf"\b{re.escape(t.lower())}\b", low):
                raise ScopeViolation(
                    f"Query references excluded table '{t}' — refused")

    def assert_no_qualified_governed(self, sql: str) -> None:
        """On the pushdown path the governed CTEs shadow only BARE table
        names. A schema/project-qualified reference (``proj.ds.claims``,
        ``db.schema.claims``) would resolve to the physical, unfiltered table
        and dodge the CTE. For a scoped principal that is a scope escape, so
        any qualified reference to a governed/transitive table is refused.
        """
        g = self.rules()
        governed = set(g.get("governed_tables", {})) | set(
            g.get("transitive_tables", {}))
        low = self._normalize_for_guard(sql).lower()
        for t in governed:
            # <something> . <optional backtick/quote> table  → qualified ref
            if re.search(rf"[\w`\"\]\)]\s*\.\s*[`\"\[]?{re.escape(t.lower())}\b",
                         low):
                raise ScopeViolation(
                    f"Schema-qualified reference to governed table '{t}' is "
                    "not permitted for a scoped principal (would bypass the "
                    "LOB filter). Use the bare table name.")

    # -- predicate pushdown --------------------------------------------------
    def _lob_literals(self, scope: ScopeContext) -> str:
        return ", ".join("'" + str(l).replace("'", "''") + "'"
                         for l in scope.allowed_lobs) or "''"

    def _ordered_transitive(self, gov: dict) -> list:
        """Transitive tables in dependency order (parents before children)."""
        trans = gov["transitive_tables"]

        def depth(t, seen=()):
            if t in gov["governed_tables"] or t not in trans or t in seen:
                return 0
            return 1 + depth(trans[t]["parent_table"], seen + (t,))
        return sorted(trans.items(), key=lambda kv: depth(kv[0]))

    def build_pushdown_sql(self, sql: str, scope: ScopeContext,
                           qualify: Callable[[str], str]) -> str:
        """Prepend governed CTEs that shadow every base table with a
        LOB-filtered version, so unqualified references resolve to scoped
        data server-side. Full-scope principals get the query unchanged
        (still excluded-table guarded upstream).

        ``qualify`` maps a logical table name to the warehouse's fully
        qualified name (project.dataset.table, db.schema.table, …).
        """
        self.assert_no_excluded(sql)
        if scope.is_full_scope():
            return sql
        # a scoped principal may not schema-qualify a governed table (would
        # dodge the CTE shadow); refuse before building.
        self.assert_no_qualified_governed(sql)
        gov = self.rules()
        lobs = self._lob_literals(scope)
        col = gov["scope_column"]
        ctes = []
        for t, c in gov["governed_tables"].items():
            ctes.append(f"{t} AS (SELECT * FROM {qualify(t)} "
                        f"WHERE {c or col} IN ({lobs}))")
        for t, meta in self._ordered_transitive(gov):
            parent = meta["parent_table"]
            # reference the (already scoped) parent CTE by bare name
            ctes.append(
                f"{t} AS (SELECT * FROM {qualify(t)} WHERE {meta['key']} IN "
                f"(SELECT {meta['parent_key']} FROM {parent}))")
        for t in gov.get("ungoverned_tables", []):
            ctes.append(f"{t} AS (SELECT * FROM {qualify(t)})")
        if not ctes:
            return sql
        return "WITH " + ",\n     ".join(ctes) + "\n" + sql

    def scope_summary(self, scope: ScopeContext) -> dict:
        return {"user_id": scope.user_id, "role": scope.role,
                "allowed_lobs": list(scope.allowed_lobs),
                "full_scope": scope.is_full_scope()}
