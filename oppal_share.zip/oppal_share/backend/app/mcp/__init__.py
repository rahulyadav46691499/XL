"""OpPal MCP — Zero-Copy / Zero-Persistence data layer (Phase 1).

Public surface: build a ScopeContext for the principal, then read data only
through the DataAccessService. No query executes without a scope.
"""
from .models import (ConnectorInfo, ConnectorUnavailable, QueryResult,
                     QuerySpec, ScopeContext, ScopeStrategy, ScopeViolation,
                     WarehouseType)
from .registry import (DataAccessService, available_connectors,
                       create_connector, data_service, rebuild_service,
                       register, scope_from_user)
from .scope import ScopeEnforcer

__all__ = [
    "ScopeContext", "QuerySpec", "QueryResult", "ScopeStrategy",
    "WarehouseType", "ConnectorInfo", "ScopeViolation", "ConnectorUnavailable",
    "ScopeEnforcer", "DataAccessService", "data_service", "rebuild_service",
    "create_connector", "register", "available_connectors", "scope_from_user",
]
