"""Pydantic-compatibility layer.

OpPal models are authored as Pydantic v2 models — including the Phase 5/6
strict-boundary contracts (``ConfigDict(extra="forbid")``, ``field_validator``,
``model_validator``, ``frozen=True``, ``Decimal`` money fields, ``Literal``
discriminators). Pydantic is the intended production dependency; where it is
not installed (e.g. an air-gapped build sandbox with no PyPI egress), this
module provides a dependency-free shim implementing the subset of the v2 API
OpPal actually uses — typed fields (including ``Optional``/PEP 604 unions,
``list[X]`` element coercion, ``Literal``, ``Decimal``, nested models and
enums), ``Field`` constraints (``default_factory``, ``ge``/``le``,
``min_length``/``max_length``), ``ConfigDict`` (``extra``,
``str_strip_whitespace``, ``frozen``), ``field_validator``/``model_validator``,
``model_dump`` and ``model_validate``.

The import site is identical either way, so installing real pydantic later is
a transparent swap — every model below behaves the same, because the shim
mirrors the exact v2 semantics the models rely on, not a simplified subset of
them.
"""
from __future__ import annotations

try:                                    # ---- real pydantic when available ---
    from pydantic import (BaseModel, ConfigDict, Field,  # type: ignore  # noqa: F401
                          field_validator, model_validator)

    # NOT pydantic's ValidationError, deliberately. This module promises that
    # installing real pydantic is a transparent swap, and for this one name it
    # was not: the shim's ValidationError is a plain ValueError subclass that
    # app code RAISES with a message (`ActionRequest.assert_transition`), while
    # pydantic v2's takes `line_errors` and raises TypeError on a string — so
    # the action state machine refused illegal transitions without pydantic and
    # crashed with it. ValueError is the one type that satisfies both sides of
    # the contract: it is raisable with a message, and pydantic v2's own
    # ValidationError subclasses it, so the `except ValidationError` boundary
    # handlers still catch model-construction failures.
    # ponytail: this widens those handlers to any ValueError from the try block.
    # Each one wraps a single model construction, so the blast radius is one
    # statement; narrow it to a dedicated error type if a handler ever grows.
    ValidationError = ValueError
    PYDANTIC = True
except Exception:                       # ---- zero-dependency fallback -------
    PYDANTIC = False
    import enum
    import types
    import typing
    from decimal import Decimal, InvalidOperation

    class ValidationError(ValueError):
        """Raised when required fields are missing, mistyped, or a
        field/model validator rejects the value."""

    def ConfigDict(**kwargs):
        """Real pydantic returns a typed dict; a plain dict is sufficient
        here — only the keys OpPal's models set (``extra``, ``frozen``,
        ``str_strip_whitespace``, ``validate_assignment``) are consulted."""
        return dict(kwargs)

    # -- Field ---------------------------------------------------------------
    class _FieldInfo:
        __slots__ = ("default", "default_factory", "description", "ge", "le",
                     "min_length", "max_length")

        def __init__(self, default=..., *, default_factory=None,
                     description="", ge=None, le=None, min_length=None,
                     max_length=None):
            self.default = default
            self.default_factory = default_factory
            self.description = description
            self.ge = ge
            self.le = le
            self.min_length = min_length
            self.max_length = max_length

    def Field(default=..., *, default_factory=None, description="",
              ge=None, le=None, min_length=None, max_length=None):
        return _FieldInfo(default, default_factory=default_factory,
                          description=description, ge=ge, le=le,
                          min_length=min_length, max_length=max_length)

    # -- validators ------------------------------------------------------------
    class _FieldValidator:
        """Marker produced by ``field_validator(...)``; collected by the
        metaclass so the underlying (unbound) classmethod function can be
        invoked as ``func(cls, value)`` during construction."""
        __slots__ = ("fields", "func")

        def __init__(self, fields, func):
            self.fields, self.func = fields, func

    def field_validator(*fields, mode: str = "after"):
        def deco(fn):
            func = fn.__func__ if isinstance(fn, classmethod) else fn
            return _FieldValidator(fields, func)
        return deco

    class _ModelValidator:
        """Marker produced by ``model_validator(mode="after")``; the wrapped
        function is a plain instance method ``def f(self): ...``."""
        __slots__ = ("func", "mode")

        def __init__(self, func, mode):
            self.func, self.mode = func, mode

    def model_validator(*, mode: str = "after"):
        def deco(fn):
            func = fn.__func__ if isinstance(fn, classmethod) else fn
            return _ModelValidator(func, mode)
        return deco

    # -- type checking / coercion ---------------------------------------------
    _UNION_ORIGINS = (typing.Union, getattr(types, "UnionType", object()))

    def _check(name, value, typ):
        """Best-effort structural validation + coercion (not exhaustive
        generics, but covers every shape the Phase 0-6 models use)."""
        if typ is None or typ is typing.Any:
            return value
        origin = typing.get_origin(typ)
        if origin in _UNION_ORIGINS:             # Optional[X] / X | Y | ...
            args = [a for a in typing.get_args(typ) if a is not type(None)]
            if value is None:
                return value
            for a in args:                        # accept first matching arm
                try:
                    return _check(name, value, a)
                except ValidationError:
                    continue
            return value          # lenient fallback (matches prior behavior)
        if origin is typing.Literal:
            allowed = typing.get_args(typ)
            if value not in allowed:
                raise ValidationError(
                    f"{name}: {value!r} is not one of {allowed}")
            return value
        if origin in (list, typing.List):
            if not isinstance(value, (list, tuple)):
                raise ValidationError(f"{name}: expected list")
            elem_args = typing.get_args(typ)
            elem_t = elem_args[0] if elem_args else None
            if elem_t is None:
                return list(value)
            return [_check(f"{name}[{i}]", v, elem_t)
                    for i, v in enumerate(value)]
        if origin in (dict, typing.Dict):
            if not isinstance(value, dict):
                raise ValidationError(f"{name}: expected dict")
            return value
        if typ is Decimal:
            if isinstance(value, Decimal):
                return value
            try:
                return Decimal(str(value))
            except (InvalidOperation, ValueError, TypeError):
                raise ValidationError(
                    f"{name}: cannot parse Decimal from {value!r}")
        if isinstance(typ, type):
            if typ is float and isinstance(value, int) \
                    and not isinstance(value, bool):
                return float(value)
            if typ is int and isinstance(value, bool):
                raise ValidationError(f"{name}: expected int, got bool")
            if issubclass(typ, BaseModel):
                if isinstance(value, typ):
                    return value
                if isinstance(value, dict):
                    return typ(**value)
                raise ValidationError(
                    f"{name}: expected {typ.__name__} or dict, got "
                    f"{type(value).__name__}")
            if issubclass(typ, enum.Enum):
                if isinstance(value, typ):
                    return value
                try:                       # coerce a valid enum value (Pydantic-like)
                    return typ(value)
                except Exception:
                    raise ValidationError(
                        f"{name}: {value!r} is not a valid {typ.__name__}")
            if not isinstance(value, typ):
                raise ValidationError(
                    f"{name}: expected {typ.__name__}, got "
                    f"{type(value).__name__}")
        return value

    class _Meta(type):
        def __new__(mcs, name, bases, ns):
            cls = super().__new__(mcs, name, bases, ns)
            fields = {}
            validators: dict = {}
            model_validators: list = []
            for base in bases:                     # inherit parent fields
                fields.update(getattr(base, "__fields__", {}))
                for k, v in getattr(base, "__field_validators__", {}).items():
                    validators.setdefault(k, []).extend(v)
                model_validators.extend(
                    getattr(base, "__model_validators__", []))
            ann = ns.get("__annotations__", {})
            for fname, ftype in ann.items():
                if fname in ("model_config",):
                    continue
                default = ns.get(fname, ...)
                info = default if isinstance(default, _FieldInfo) \
                    else _FieldInfo(default)
                fields[fname] = (ftype, info)
            for attr_val in ns.values():
                if isinstance(attr_val, _FieldValidator):
                    for f in attr_val.fields:
                        validators.setdefault(f, []).append(attr_val.func)
                elif isinstance(attr_val, _ModelValidator):
                    model_validators.append(attr_val.func)
            cls.__fields__ = fields
            cls.__field_validators__ = validators
            cls.__model_validators__ = model_validators
            merged_cfg = {}
            for base in bases:
                merged_cfg.update(getattr(base, "__model_config__", {}) or {})
            merged_cfg.update(ns.get("model_config", {}) or {})
            cls.__model_config__ = merged_cfg
            # `from __future__ import annotations` stores annotations as
            # strings; resolve them to real types so type validation is not a
            # no-op. Best-effort: fall back to the string on failure.
            try:
                hints = typing.get_type_hints(cls)
                for fname, (ftype, info) in list(fields.items()):
                    if isinstance(ftype, str) and fname in hints:
                        fields[fname] = (hints[fname], info)
            except Exception:
                pass
            return cls

    class BaseModel(metaclass=_Meta):
        model_config: dict = {}

        def __init__(self, **data):
            cls = type(self)
            fields = cls.__fields__      # class dict (never shadowed)
            cfg = cls.__model_config__
            extra = set(data) - set(fields)
            if extra and cfg.get("extra", "forbid") != "ignore":
                raise ValidationError(f"unexpected fields: {sorted(extra)}")
            strip_ws = cfg.get("str_strip_whitespace", False)
            for fname, (ftype, info) in fields.items():
                if fname in data:
                    val = _check(fname, data[fname], ftype)
                elif info.default_factory is not None:
                    val = info.default_factory()
                elif info.default is not ...:
                    val = info.default
                else:
                    raise ValidationError(f"missing required field '{fname}'")
                if strip_ws and isinstance(val, str):
                    val = val.strip()
                if val is not None:
                    if info.ge is not None and val < info.ge:
                        raise ValidationError(
                            f"{fname}: must be >= {info.ge} (got {val!r})")
                    if info.le is not None and val > info.le:
                        raise ValidationError(
                            f"{fname}: must be <= {info.le} (got {val!r})")
                    if info.min_length is not None and hasattr(val, "__len__") \
                            and len(val) < info.min_length:
                        raise ValidationError(
                            f"{fname}: length must be >= {info.min_length}")
                    if info.max_length is not None and hasattr(val, "__len__") \
                            and len(val) > info.max_length:
                        raise ValidationError(
                            f"{fname}: length must be <= {info.max_length}")
                for vfunc in cls.__field_validators__.get(fname, []):
                    try:
                        val = vfunc(cls, val)
                    except ValidationError:
                        raise
                    except (ValueError, AssertionError) as e:
                        raise ValidationError(f"{fname}: {e}")
                object.__setattr__(self, fname, val)
            for mv in cls.__model_validators__:
                try:
                    mv(self)
                except ValidationError:
                    raise
                except (ValueError, AssertionError) as e:
                    raise ValidationError(str(e))
            # marks construction complete so validate_assignment only fires on
            # genuine post-init mutation, never on the __init__ writes above.
            object.__setattr__(self, "_initialized", True)
            if cfg.get("frozen"):
                object.__setattr__(self, "_frozen", True)

        def __setattr__(self, key, value):
            if getattr(self, "_frozen", False):
                raise ValidationError(
                    f"{type(self).__name__} is frozen; cannot set '{key}'")
            cls = type(self)
            cfg = cls.__model_config__
            # validate_assignment (TDD §2 global convention): re-run the same
            # type check, numeric/length constraints and field validators on
            # mutation that ran at construction. Without this, a model could be
            # constructed valid and then mutated into an invalid state — which
            # is exactly the server-authoritative hole the strict contracts
            # exist to close.
            if cfg.get("validate_assignment") and key in cls.__fields__ \
                    and getattr(self, "_initialized", False):
                ftype, info = cls.__fields__[key]
                value = _check(key, value, ftype)
                if cfg.get("str_strip_whitespace") and isinstance(value, str):
                    value = value.strip()
                if value is not None:
                    if info.ge is not None and value < info.ge:
                        raise ValidationError(
                            f"{key}: must be >= {info.ge} (got {value!r})")
                    if info.le is not None and value > info.le:
                        raise ValidationError(
                            f"{key}: must be <= {info.le} (got {value!r})")
                    if info.min_length is not None and \
                            hasattr(value, "__len__") and \
                            len(value) < info.min_length:
                        raise ValidationError(
                            f"{key}: length must be >= {info.min_length}")
                    if info.max_length is not None and \
                            hasattr(value, "__len__") and \
                            len(value) > info.max_length:
                        raise ValidationError(
                            f"{key}: length must be <= {info.max_length}")
                for vfunc in cls.__field_validators__.get(key, []):
                    try:
                        value = vfunc(cls, value)
                    except ValidationError:
                        raise
                    except (ValueError, AssertionError) as e:
                        raise ValidationError(f"{key}: {e}")
            object.__setattr__(self, key, value)

        def model_dump(self, exclude=None):
            import enum as _enum
            from decimal import Decimal as _Decimal
            exclude = exclude or set()

            def _ser(v):
                if isinstance(v, BaseModel):
                    return v.model_dump()
                if isinstance(v, _enum.Enum):
                    return v.value
                if isinstance(v, _Decimal):
                    return v
                if isinstance(v, (list, tuple)):
                    return [_ser(x) for x in v]
                if isinstance(v, dict):
                    return {k: _ser(x) for k, x in v.items()}
                return v

            out = {}
            for fname in type(self).__fields__:
                if fname in exclude:
                    continue
                out[fname] = _ser(getattr(self, fname))
            return out

        @classmethod
        def model_validate(cls, data):
            return cls(**data) if isinstance(data, dict) else data

        def __repr__(self):
            inner = ", ".join(f"{k}={getattr(self, k)!r}"
                              for k in self.__fields__)
            return f"{type(self).__name__}({inner})"


__all__ = ["BaseModel", "ConfigDict", "Field", "ValidationError",
           "field_validator", "model_validator", "PYDANTIC"]
