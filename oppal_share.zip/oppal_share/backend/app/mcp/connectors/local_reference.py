"""Local reference connector — the working, testable warehouse stand-in.

Uses the bundled SQLite dataset as if it were the client's warehouse so the
entire end-to-end flow (Graph-RAG grounding, agent swarm, analytics) runs
locally against mock payer data. Its scope strategy is ``physical_sandbox``:
each scoped query runs against a data plane that physically contains only the
caller's LOB rows (the Phase 0 mechanism, now governed by Brain rules).
"""
from __future__ import annotations

from ..base import BaseWarehouseConnector
from ..models import (CatalogColumn, CatalogTable, ConnectorInfo, QuerySpec,
                      ScopeContext)


class LocalReferenceConnector(BaseWarehouseConnector):
    warehouse_type = "local_reference"

    def _run(self, scoped_sql: str, spec: QuerySpec,
             scope: ScopeContext) -> dict:
        # Single execution primitive, reused so there is exactly one tested
        # sandbox implementation. Passing allowed_lobs triggers the physical
        # LOB plane for scoped users; full-scope principals read the pool.
        from ...data.db import run_query, ALL_LOBS
        full = scope.full_lobs or ALL_LOBS()
        out = run_query(scoped_sql, limit=spec.limit,
                        allowed_lobs=scope.allowed_lobs, full_lobs=full)
        if not out["ok"]:
            reason = (out.get("gate", {}) or {}).get("error") or "query failed"
            raise RuntimeError(reason)
        return {"columns": out["columns"], "rows": out["rows"],
                "bytes_processed": 0}

    def catalog(self, scope: ScopeContext) -> list:
        from ...semantic.brain import get_brain
        from ...data.db import ALL_LOBS  # noqa: F401 (keeps parity w/ warehouses)
        brain = get_brain()
        gov = brain.get("governance", {})
        governed = set(gov.get("governed_tables", {})) | set(
            gov.get("transitive_tables", {}))
        excluded = set(gov.get("excluded_tables", []))
        cols_by_tbl: dict = {}
        for col, _desc in brain.get("columns", {}).items():
            if "." in col:
                t, c = col.split(".", 1)
                cols_by_tbl.setdefault(t, []).append(c)
        out = []
        for tname in brain.get("tables", {}):
            if tname in excluded:
                continue
            out.append(CatalogTable(
                name=tname, governed=tname in governed,
                columns=[CatalogColumn(name=c)
                         for c in cols_by_tbl.get(tname, [])]))
        return out

    def healthcheck(self) -> ConnectorInfo:
        healthy = True
        detail = "SQLite reference engine (bundled payer dataset)"
        try:
            from ...data.db import ensure_db
            ensure_db()
        except Exception as e:                       # pragma: no cover
            healthy, detail = False, f"unavailable: {e}"
        return ConnectorInfo(
            name=self.name, warehouse_type=self.warehouse_type,
            strategy=self.strategy.value, healthy=healthy, available=True,
            zero_persistence=self._mcp.get("zero_persistence", True),
            detail=detail)
