"""Fake connector — deterministic, in-memory, for tests only.

Records the exact scoped SQL the base class handed it, so tests can assert that
(a) execution is refused without a scope, and (b) the LOB predicate/CTE was
applied before any adapter code ran. Never touches disk or network.
"""
from __future__ import annotations

from ..base import BaseWarehouseConnector
from ..models import CatalogTable, ConnectorInfo, QuerySpec, ScopeContext


class FakeWarehouseConnector(BaseWarehouseConnector):
    warehouse_type = "fake"

    def __init__(self, *a, rows=None, columns=None, **kw):
        super().__init__(*a, **kw)
        self.last_scoped_sql: str | None = None
        self.calls: list = []
        self._rows = rows if rows is not None else [[1]]
        self._columns = columns if columns is not None else ["n"]

    def _run(self, scoped_sql: str, spec: QuerySpec,
             scope: ScopeContext) -> dict:
        self.last_scoped_sql = scoped_sql
        self.calls.append({"sql": scoped_sql,
                           "allowed_lobs": list(scope.allowed_lobs)})
        return {"columns": self._columns, "rows": self._rows,
                "bytes_processed": 42}

    def catalog(self, scope: ScopeContext) -> list:
        return [CatalogTable(name="claims", governed=True)]

    def healthcheck(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name, warehouse_type=self.warehouse_type,
            strategy=self.strategy.value, healthy=True, available=True,
            detail="in-memory fake")
