"""Google BigQuery connector (first-class).

Zero-copy: the query runs inside BigQuery; OpPal streams result pages and never
copies the source tables. Zero-persistence: rows are held only for the request.
LOB isolation is applied as a server-side predicate pushdown (governed CTEs
built by the ScopeEnforcer) so BigQuery never returns out-of-scope rows.

The driver (``google-cloud-bigquery``) is optional: when it or credentials are
absent, execution raises ConnectorUnavailable and the base class returns a clean
error — while the scope pushdown and catalog remain fully exercised offline.
"""
from __future__ import annotations

import logging

from ..base import BaseWarehouseConnector
from ..models import (CatalogColumn, CatalogTable, ConnectorInfo,
                      ConnectorUnavailable, QuerySpec, ScopeContext)

log = logging.getLogger("oppal.mcp.bigquery")



def _spec_present(module: str) -> bool:
    """importlib.find_spec that never raises when a parent pkg is absent."""
    import importlib.util
    try:
        return importlib.util.find_spec(module) is not None
    except (ImportError, ModuleNotFoundError, ValueError):
        return False

class BigQueryConnector(BaseWarehouseConnector):
    warehouse_type = "bigquery"

    def _params(self) -> dict:
        return self.config.get("params", self.config) or {}

    def qualify(self, table: str) -> str:
        p = self._params()
        project = p.get("project_id", "")
        dataset = p.get("dataset", "")
        prefix = ".".join(x for x in (project, dataset) if x)
        return f"`{prefix}.{table}`" if prefix else f"`{table}`"

    # -- driver plumbing (import guarded; never a hard dependency) ----------
    def _client(self):
        try:
            from google.cloud import bigquery            # type: ignore
        except Exception as e:
            raise ConnectorUnavailable(
                "google-cloud-bigquery not installed") from e
        p = self._params()
        if not p.get("project_id"):
            raise ConnectorUnavailable("BigQuery project_id not configured")
        try:
            sa = p.get("service_account_json")
            if sa:
                return bigquery.Client.from_service_account_json(sa)
            return bigquery.Client(project=p["project_id"])
        except Exception as e:                            # pragma: no cover
            raise ConnectorUnavailable(f"BigQuery auth failed: {e}") from e

    def _run(self, scoped_sql: str, spec: QuerySpec,
             scope: ScopeContext) -> dict:
        client = self._client()          # raises ConnectorUnavailable cleanly
        from google.cloud import bigquery                 # type: ignore
        job_config = bigquery.QueryJobConfig(
            use_query_cache=True,
            maximum_bytes_billed=self._mcp.get("max_bytes_billed"))
        job = client.query(scoped_sql, job_config=job_config)
        it = job.result(page_size=self._mcp.get("page_size", 5000),
                        max_results=spec.limit)
        columns = [f.name for f in it.schema]
        rows = [[row[c] for c in columns] for row in it]  # streamed, not copied
        return {"columns": columns, "rows": rows,
                "bytes_processed": int(getattr(job, "total_bytes_processed",
                                               0) or 0)}

    def catalog(self, scope: ScopeContext) -> list:
        # Metadata only. Derived from the Brain so it is available even without
        # a live BigQuery connection; a live build would read INFORMATION_SCHEMA.
        from ...semantic.brain import get_brain
        brain = get_brain()
        gov = brain.get("governance", {})
        governed = set(gov.get("governed_tables", {})) | set(
            gov.get("transitive_tables", {}))
        excluded = set(gov.get("excluded_tables", []))
        return [CatalogTable(name=t, governed=t in governed, columns=[])
                for t in brain.get("tables", {}) if t not in excluded]

    def healthcheck(self) -> ConnectorInfo:
        available, detail = True, "BigQuery (predicate pushdown)"
        if not _spec_present("google.cloud.bigquery"):
            available = False
            detail = "driver google-cloud-bigquery not installed"
        elif not self._params().get("project_id"):
            available = False
            detail = "project_id not configured"
        return ConnectorInfo(
            name=self.name, warehouse_type=self.warehouse_type,
            strategy=self.strategy.value, healthy=available,
            available=available,
            zero_persistence=self._mcp.get("zero_persistence", True),
            detail=detail)
