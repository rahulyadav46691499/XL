"""Snowflake connector (typed adapter).

Predicate-pushdown scope, zero-copy (query runs in Snowflake), zero-persistence
(streamed via cursor). Driver ``snowflake-connector-python`` is optional; absent
it raises ConnectorUnavailable and the base returns a clean error, while scope
pushdown and catalog remain testable offline.
"""
from __future__ import annotations

from ..base import BaseWarehouseConnector
from ..models import (CatalogTable, ConnectorInfo, ConnectorUnavailable,
                      QuerySpec, ScopeContext)



def _spec_present(module: str) -> bool:
    """importlib.find_spec that never raises when a parent pkg is absent."""
    import importlib.util
    try:
        return importlib.util.find_spec(module) is not None
    except (ImportError, ModuleNotFoundError, ValueError):
        return False

class SnowflakeConnector(BaseWarehouseConnector):
    warehouse_type = "snowflake"

    def _params(self) -> dict:
        return self.config.get("params", self.config) or {}

    def qualify(self, table: str) -> str:
        p = self._params()
        parts = [p.get("database"), p.get("schema"), table]
        return ".".join(x for x in parts if x)

    def _connect(self):
        try:
            import snowflake.connector as sf              # type: ignore
        except Exception as e:
            raise ConnectorUnavailable(
                "snowflake-connector-python not installed") from e
        p = self._params()
        required = ("account", "user", "password", "warehouse", "database")
        missing = [k for k in required if not p.get(k)]
        if missing:
            raise ConnectorUnavailable(
                f"Snowflake config missing: {', '.join(missing)}")
        return sf.connect(
            account=p["account"], user=p["user"], password=p["password"],
            warehouse=p["warehouse"], database=p["database"],
            schema=p.get("schema"),
            network_timeout=self._mcp.get("statement_timeout_seconds", 60))

    def _run(self, scoped_sql: str, spec: QuerySpec,
             scope: ScopeContext) -> dict:
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(
                f"ALTER SESSION SET STATEMENT_TIMEOUT_IN_SECONDS = "
                f"{int(self._mcp.get('statement_timeout_seconds', 60))}")
            cur.execute(scoped_sql)
            columns = [c[0] for c in cur.description]
            fetched = cur.fetchmany(spec.limit) if spec.limit \
                else cur.fetchall()
            rows = [list(r) for r in fetched]
            return {"columns": columns, "rows": rows, "bytes_processed": 0}
        finally:
            conn.close()

    def catalog(self, scope: ScopeContext) -> list:
        from ...semantic.brain import get_brain
        brain = get_brain()
        gov = brain.get("governance", {})
        governed = set(gov.get("governed_tables", {})) | set(
            gov.get("transitive_tables", {}))
        excluded = set(gov.get("excluded_tables", []))
        return [CatalogTable(name=t, governed=t in governed)
                for t in brain.get("tables", {}) if t not in excluded]

    def healthcheck(self) -> ConnectorInfo:
        available = _spec_present("snowflake.connector")
        p = self._params()
        detail = "Snowflake (predicate pushdown)"
        if not available:
            detail = "driver snowflake-connector-python not installed"
        elif not p.get("account"):
            available, detail = False, "account not configured"
        return ConnectorInfo(
            name=self.name, warehouse_type=self.warehouse_type,
            strategy=self.strategy.value, healthy=available,
            available=available,
            zero_persistence=self._mcp.get("zero_persistence", True),
            detail=detail)
