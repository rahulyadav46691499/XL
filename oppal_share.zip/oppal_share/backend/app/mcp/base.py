"""BaseWarehouseConnector — the abstraction every data source conforms to.

Design guarantees (enforced by this base class, not by adapter goodwill):

  * DENY BY DEFAULT — ``execute`` refuses to run without an effective
    :class:`ScopeContext`. Subclasses cannot override ``execute`` (a runtime
    ``__init_subclass__`` guard forbids it), so no adapter can skip scoping.
  * SCOPE ALWAYS APPLIED — before any adapter code runs, the base class turns
    the request into a scoped form: a LOB-pushdown query (warehouses) or a
    physically-filtered data plane (local reference). Adapters only implement
    ``_run`` and are handed already-scoped SQL.
  * ZERO PERSISTENCE — result rows live only in memory for the request; the
    base class never writes them to disk and redacts them from logs.
  * OBSERVABLE — every execution is operationally logged and appended to the
    tamper-evident audit ledger with the principal and scope summary.

Adapters implement three abstract methods: ``_run``, ``catalog``,
``healthcheck``. Everything else is centralized here (SOLID: single place for
the cross-cutting policy; adapters stay small and decoupled).
"""
from __future__ import annotations

import abc
import logging
import time
from datetime import datetime, timezone

from .models import (ConnectorInfo, ConnectorUnavailable, QueryResult,
                     QuerySpec, ScopeContext, ScopeStrategy, ScopeViolation)
from .scope import ScopeEnforcer

log = logging.getLogger("oppal.mcp")
if not log.handlers:
    log.addHandler(logging.NullHandler())


class BaseWarehouseConnector(abc.ABC):
    warehouse_type: str = "abstract"

    # -- SOLID guard: execute() is final -----------------------------------
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Resolve execute() across the ENTIRE MRO (not just cls.__dict__): a
        # mixin placed before BaseWarehouseConnector could otherwise supply a
        # rogue execute and slip past a __dict__-only check.
        if cls.execute is not BaseWarehouseConnector.execute:
            raise TypeError(
                f"{cls.__name__} (or a base/mixin) overrides execute(); this "
                "is forbidden. Implement _run(). Scope enforcement lives in "
                "BaseWarehouseConnector.execute() by design.")

    def __init__(self, name: str, config: dict,
                 enforcer: ScopeEnforcer | None = None,
                 mcp_settings: dict | None = None):
        self.name = name
        self.config = config or {}
        self.enforcer = enforcer or ScopeEnforcer()
        self._mcp = mcp_settings or {}
        self.strategy = self.enforcer.strategy_for(name)

    # -- adapter hooks (the ONLY things subclasses implement) --------------
    @abc.abstractmethod
    def _run(self, scoped_sql: str, spec: QuerySpec,
             scope: ScopeContext) -> dict:
        """Execute already-scoped, read-only SQL. Return
        ``{"columns": list[str], "rows": list[list], "bytes_processed": int}``.
        Must NOT persist rows. Raise ConnectorUnavailable if not configured."""

    @abc.abstractmethod
    def catalog(self, scope: ScopeContext) -> list:
        """Schema metadata only (never data), honoring excluded tables."""

    @abc.abstractmethod
    def healthcheck(self) -> ConnectorInfo:
        ...

    def qualify(self, table: str) -> str:
        """Logical table name -> warehouse fully-qualified name. Overridden by
        cloud adapters; identity for engines that address tables bare."""
        return table

    # -- the single, final execution path ----------------------------------
    def execute(self, spec: QuerySpec, scope: ScopeContext) -> QueryResult:
        t0 = time.time()
        redact = self._mcp.get("redact_phi_in_logs", True)
        try:
            # 1) DENY BY DEFAULT — no scope, no execution.
            self.enforcer.require_scope(scope)
            # 2) Read-only, single-statement only (applies to EVERY strategy,
            #    including warehouse pushdown — no DML/DDL/multi-statement).
            self.enforcer.assert_read_only(spec.sql)
            # 3) Never expose credential / RBAC-directory tables.
            self.enforcer.assert_no_excluded(spec.sql)
            # 4) Apply scope BEFORE any adapter code sees the query.
            if self.strategy == ScopeStrategy.PREDICATE_PUSHDOWN:
                scoped_sql = self.enforcer.build_pushdown_sql(
                    spec.sql, scope, self.qualify)
            else:                       # physical sandbox engines
                scoped_sql = spec.sql
            log.info("mcp.execute start connector=%s strategy=%s scope=%s "
                     "purpose=%s", self.name, self.strategy.value,
                     self.enforcer.scope_summary(scope), spec.purpose)
            # 5) Row cap (zero-persistence safety; never stream unbounded).
            cap = self._mcp.get("max_result_rows")
            effective_limit = min(x for x in [spec.limit, cap]
                                  if x is not None) if (spec.limit or cap) \
                else None
            scoped_spec = QuerySpec(sql=scoped_sql, params=spec.params,
                                    limit=effective_limit, purpose=spec.purpose)
            # 5) Adapter runs already-scoped SQL.
            raw = self._run(scoped_sql, scoped_spec, scope)
            rows = raw.get("rows", [])
            truncated = False
            if cap is not None and len(rows) > cap:
                rows, truncated = rows[:cap], True
            result = QueryResult(
                ok=True, columns=raw.get("columns", []), rows=rows,
                row_count=len(rows), truncated=truncated,
                elapsed_ms=round((time.time() - t0) * 1000, 1),
                bytes_processed=int(raw.get("bytes_processed", 0)),
                connector=self.name, strategy=self.strategy.value,
                scope_applied=True, scoped_sql=scoped_sql)
            self._audit(scope, spec, result)
            log.info("mcp.execute ok connector=%s rows=%d ms=%.1f%s",
                     self.name, result.row_count, result.elapsed_ms,
                     " [rows redacted]" if redact else "")
            return result
        except ScopeViolation as e:
            log.warning("mcp.execute DENIED connector=%s reason=%s",
                        self.name, e)
            res = QueryResult(ok=False, connector=self.name,
                              strategy=self.strategy.value, scope_applied=False,
                              elapsed_ms=round((time.time() - t0) * 1000, 1),
                              refusal_reason=str(e))
            self._audit(scope, spec, res)
            return res
        except ConnectorUnavailable as e:
            log.error("mcp.execute unavailable connector=%s: %s", self.name, e)
            return QueryResult(ok=False, connector=self.name,
                               strategy=self.strategy.value,
                               elapsed_ms=round((time.time() - t0) * 1000, 1),
                               error=f"connector unavailable: {e}")
        except Exception as e:            # degrade, never crash the caller
            log.exception("mcp.execute error connector=%s", self.name)
            return QueryResult(ok=False, connector=self.name,
                               strategy=self.strategy.value,
                               elapsed_ms=round((time.time() - t0) * 1000, 1),
                               error=f"{type(e).__name__}: {e}")

    # -- audit hook ---------------------------------------------------------
    def _audit(self, scope: ScopeContext, spec: QuerySpec,
               result: QueryResult) -> None:
        try:
            from ..trust.audit_ledger import _write
            _write({
                "ts": datetime.now(timezone.utc).isoformat(),
                "kind": "mcp", "event": "query",
                "connector": self.name, "strategy": self.strategy.value,
                "user_id": getattr(scope, "user_id", None),
                "allowed_lobs": list(getattr(scope, "allowed_lobs", [])),
                "purpose": spec.purpose, "ok": result.ok,
                "row_count": result.row_count,
                "scope_applied": result.scope_applied,
                "refusal_reason": result.refusal_reason,
                # NB: no rows, no PHI, no raw SQL literals recorded here
            })
        except Exception:
            log.debug("audit hook failed (non-fatal)", exc_info=True)
