"""Typed contracts for the MCP Zero-Copy / Zero-Persistence data layer.

Every value that crosses the connector boundary is a validated model. The most
important is :class:`ScopeContext`: no connector will execute a query without
one, and the base connector enforces that natively (see ``base.py``).
"""
from __future__ import annotations

import enum
from typing import Any, Optional

from ._models_base import BaseModel, ConfigDict, Field


class WarehouseType(str, enum.Enum):
    LOCAL_REFERENCE = "local_reference"
    BIGQUERY = "bigquery"
    SNOWFLAKE = "snowflake"
    DATABRICKS = "databricks"
    FAKE = "fake"


class ScopeStrategy(str, enum.Enum):
    """How LOB isolation is applied for a given connector."""
    PREDICATE_PUSHDOWN = "predicate_pushdown"   # warehouse filters server-side
    PHYSICAL_SANDBOX = "physical_sandbox"       # data plane physically filtered


# ---------------------------------------------------------------------------
# Scope — the mandatory security context
# ---------------------------------------------------------------------------
class _Strict(BaseModel):
    """Boundary contract: an unknown field is an error, not a shrug.

    These models are the wire format between OpPal and a warehouse connector.
    A caller that misspells `allowed_lobs` should be told, not silently given
    an unscoped context — so `extra="forbid"` is declared here rather than
    inherited from whichever validation library happens to be installed.
    """
    model_config = ConfigDict(extra="forbid")


class ScopeContext(_Strict):
    """Immutable RBAC/ABAC context that MUST accompany every query.

    ``allowed_lobs`` is the authoritative list of line-of-business values the
    principal may read. ``full_lobs`` is the governed universe; when
    ``allowed_lobs`` covers it the principal is full-scope (unrestricted).
    """
    user_id: str
    role: Optional[str] = None
    allowed_lobs: list = Field(default_factory=list)
    full_lobs: list = Field(default_factory=list)
    attributes: dict = Field(default_factory=dict)
    authorized: bool = False

    def is_full_scope(self) -> bool:
        return bool(self.full_lobs) and set(self.allowed_lobs) >= set(
            self.full_lobs)

    def is_effective(self) -> bool:
        """A usable scope: authorized principal with at least one LOB."""
        return bool(self.authorized and self.allowed_lobs)


# ---------------------------------------------------------------------------
# Query request / result
# ---------------------------------------------------------------------------
class QuerySpec(_Strict):
    """A read-only analytical query to run against the warehouse."""
    sql: str
    params: dict = Field(default_factory=dict)
    limit: Optional[int] = None
    purpose: str = "analytics"          # audit annotation


class ColumnMeta(_Strict):
    name: str
    type: str = "unknown"


class QueryResult(_Strict):
    """Result of a scoped execution. Rows are held only in memory for the life
    of the request (zero-persistence); nothing here is written to disk."""
    ok: bool
    columns: list = Field(default_factory=list)          # list[str]
    rows: list = Field(default_factory=list)             # list[list]
    row_count: int = 0
    truncated: bool = False
    elapsed_ms: float = 0.0
    bytes_processed: int = 0
    connector: str = ""
    strategy: str = ""
    scope_applied: bool = False
    scoped_sql: str = ""                # the governed SQL actually executed
    error: Optional[str] = None
    refusal_reason: Optional[str] = None

    def to_legacy(self) -> dict:
        """Adapter to the Phase 0 ``run_query`` dict shape so existing agents
        consume MCP results unchanged (Liskov-friendly integration).

        The gate dict MUST carry the three named booleans the trust scorer
        reads — read_only, parses, single_statement. An earlier version emitted
        only {passed, abac_refused}; the scorer's gate.get('read_only', False)
        then defaulted all three to False on a perfectly valid query, capping
        validation_gates at 0.25 and every chat answer's trust at ~0.775 —
        below the 0.85 hard gate. The ScopeEnforcer already proves these before
        execution (it raises on a DML/DDL or multi-statement query), so a
        result that executed (ok=True) provably satisfied all three. On failure
        we report honestly from the refusal/error text rather than blanket-False,
        so the logic tree names what actually went wrong.
        """
        reason = (self.refusal_reason or self.error or "").lower()
        read_only = not ("read-only" in reason or "only read-only" in reason)
        single_statement = "multiple statements" not in reason
        # parses: a query that executed clearly parsed; on failure, only call it
        # a parse failure when the engine error actually looks like one
        parses = self.ok or not any(
            s in reason for s in ("syntax", "malformed", "no such column",
                                  "no such table", "unrecognized token"))
        return {
            "ok": self.ok, "columns": self.columns, "rows": self.rows,
            "row_count": self.row_count, "ms": self.elapsed_ms,
            "gate": {"passed": self.ok,
                     "read_only": read_only,
                     "parses": parses,
                     "single_statement": single_statement,
                     "abac_refused": bool(self.refusal_reason)},
            "abac": ({"ok": False, "reason": self.refusal_reason}
                     if self.refusal_reason else {"ok": True}),
        }


# ---------------------------------------------------------------------------
# Catalog (schema introspection — metadata only, never data)
# ---------------------------------------------------------------------------
class CatalogColumn(_Strict):
    name: str
    type: str = "unknown"


class CatalogTable(_Strict):
    name: str
    columns: list = Field(default_factory=list)          # list[CatalogColumn]
    governed: bool = False
    row_estimate: Optional[int] = None


class ConnectorInfo(_Strict):
    """Connector self-description for the UI / health surface."""
    name: str
    warehouse_type: str
    strategy: str
    healthy: bool = False
    zero_persistence: bool = True
    detail: str = ""
    available: bool = True             # driver present / reachable


class ScopeViolation(Exception):
    """Raised when execution is attempted without a valid scope, or a
    connector attempts to bypass scope application."""


class ConnectorUnavailable(Exception):
    """Raised when a warehouse driver/credentials are not configured."""
