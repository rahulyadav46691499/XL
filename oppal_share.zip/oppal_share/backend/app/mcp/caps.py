"""CAPS binding resolver (Phase 2, Pillar 1).

Turns the ontology's ``caps_bindings`` (Facets / QNXT / HealthEdge / Eldorado)
into runnable binding SELECTs that project a client's standard CAPS staging
views into OpPal's ontology attributes — no bespoke ETL. The client provides
read-only staging views; OpPal binds to them declaratively.

The active vendor comes from config/env (OPPAL_CAPS_VENDOR), never hardcoded.
For the local reference engine (which has no schemas), dotted staging view
names in the spec are mapped to the bundled demo views (``stg_x.v_y`` ->
``stg_x__v_y``) so the whole path runs end-to-end offline.
"""
from __future__ import annotations

import logging
from typing import Optional

from .. import config
from ..semantic import ontology

log = logging.getLogger("oppal.mcp.caps")


def active_vendor() -> str:
    import os
    env = os.environ.get("OPPAL_CAPS_VENDOR")
    if env:
        return env
    return config.load().get("data", {}).get("caps_vendor", "facets")


class CAPSBinder:
    """Resolves ontology objects to a vendor's staging views + column maps."""

    def __init__(self, vendor: Optional[str] = None, *, local_demo: bool = False):
        self.vendor = vendor or active_vendor()
        self.local_demo = local_demo
        self.binding = ontology.caps_binding(self.vendor)

    def available(self) -> bool:
        return bool(self.binding.get("objects"))

    def _view_name(self, view: str) -> str:
        # local reference engine has no schemas: stg_facets.v_member ->
        # stg_facets__v_member (the bundled demo view).
        return view.replace(".", "__") if self.local_demo else view

    def object_binding(self, object_type: str) -> Optional[dict]:
        return (self.binding.get("objects") or {}).get(object_type)

    def binding_sql(self, object_type: str,
                    attributes: Optional[list] = None) -> str:
        """SELECT <source_col> AS <ontology_attr>, ... FROM <staging_view>.
        Projects the CAPS staging layout into ontology attribute names."""
        ob = self.object_binding(object_type)
        if not ob:
            raise KeyError(
                f"no {self.vendor} binding for object '{object_type}'")
        col_map = ob.get("column_map", {})
        if attributes:
            col_map = {a: c for a, c in col_map.items() if a in attributes}
        if not col_map:
            raise ValueError(f"no mapped columns for '{object_type}'")
        cols = ", ".join(f"{src} AS {attr}" for attr, src in col_map.items())
        return f"SELECT {cols} FROM {self._view_name(ob['view'])}"

    def coverage(self) -> dict:
        """How completely each ontology object is mapped for this vendor —
        surfaced to the BA so gaps in a client's staging layer are visible."""
        out = {}
        otypes = ontology.object_types()
        for oname, ob in (self.binding.get("objects") or {}).items():
            declared = set((otypes.get(oname, {}).get("attributes") or {}))
            mapped = set(ob.get("column_map", {}))
            out[oname] = {
                "view": ob["view"], "mapped": sorted(mapped),
                "unmapped": sorted(declared - mapped),
                "coverage_pct": round(100 * len(mapped & declared)
                                      / max(len(declared), 1), 1)}
        return out


def describe() -> dict:
    """Vendor list + per-vendor object coverage for the CAPS UI surface."""
    vendors = ontology.caps_vendors()
    active = active_vendor()
    return {
        "active_vendor": active,
        "vendors": vendors,
        "coverage": {v: CAPSBinder(v).coverage() for v in vendors},
    }
