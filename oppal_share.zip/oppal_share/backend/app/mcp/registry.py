"""Connector registry & data-access service.

SOLID: the registry is open for extension (register a new adapter) and closed
for modification (no core edits to add a warehouse). The DataAccessService is
the single front door the rest of OpPal uses to read data — and it will not
issue a query without a :class:`ScopeContext`.
"""
from __future__ import annotations

import logging
from typing import Optional, Type

from .. import config
from .base import BaseWarehouseConnector
from .connectors.bigquery import BigQueryConnector
from .connectors.databricks import DatabricksConnector
from .connectors.fake import FakeWarehouseConnector
from .connectors.local_reference import LocalReferenceConnector
from .connectors.snowflake import SnowflakeConnector
from .models import ConnectorInfo, QueryResult, QuerySpec, ScopeContext
from .scope import ScopeEnforcer

log = logging.getLogger("oppal.mcp.registry")

_REGISTRY: dict = {
    "local_reference": LocalReferenceConnector,
    "sqlite_demo": LocalReferenceConnector,     # settings alias
    "bigquery": BigQueryConnector,
    "snowflake": SnowflakeConnector,
    "databricks": DatabricksConnector,
    "fake": FakeWarehouseConnector,
}


def register(name: str, cls: Type[BaseWarehouseConnector]) -> None:
    if not issubclass(cls, BaseWarehouseConnector):
        raise TypeError("connector must subclass BaseWarehouseConnector")
    # Defense in depth: reject any class whose execute() is not the base's
    # (belt-and-suspenders alongside the __init_subclass__ guard).
    if cls.execute is not BaseWarehouseConnector.execute:
        raise TypeError(f"{cls.__name__} overrides execute(); refused")
    _REGISTRY[name] = cls


def available_connectors() -> list:
    return sorted(_REGISTRY.keys())


def create_connector(name: str, *, connector_config: Optional[dict] = None,
                     enforcer: Optional[ScopeEnforcer] = None,
                     mcp_settings: Optional[dict] = None
                     ) -> BaseWarehouseConnector:
    cls = _REGISTRY.get(name)
    if cls is None:
        raise KeyError(f"unknown connector '{name}'")
    return cls(name, connector_config or {}, enforcer or ScopeEnforcer(),
               mcp_settings or config.mcp_config())


class DataAccessService:
    """The only path the analytical layer uses to read data. Deny-by-default:
    every call requires a ScopeContext; the connector enforces it natively."""

    def __init__(self, connector: Optional[BaseWarehouseConnector] = None):
        self._connector = connector or self._from_config()

    @staticmethod
    def _from_config() -> BaseWarehouseConnector:
        mcp = config.mcp_config()
        name = mcp.get("active_connector", "local_reference")
        settings = config.load().get("data", {})
        conn_cfg = {"params": settings.get("params", {})}
        try:
            return create_connector(name, connector_config=conn_cfg,
                                    mcp_settings=mcp)
        except Exception:
            log.exception("failed to build connector '%s'; "
                          "falling back to local_reference", name)
            return create_connector("local_reference", mcp_settings=mcp)

    @property
    def connector(self) -> BaseWarehouseConnector:
        return self._connector

    # -- primary API --------------------------------------------------------
    def execute(self, sql: str, scope: ScopeContext, *,
                limit: Optional[int] = None,
                purpose: str = "analytics") -> QueryResult:
        return self._connector.execute(
            QuerySpec(sql=sql, limit=limit, purpose=purpose), scope)

    def run_legacy(self, sql: str, scope: ScopeContext, *,
                   limit: Optional[int] = None,
                   purpose: str = "analytics") -> dict:
        """Return the Phase 0 ``run_query`` dict shape for drop-in use by the
        existing agents (keeps the orchestrator decoupled from MCP types)."""
        return self.execute(sql, scope, limit=limit, purpose=purpose).to_legacy()

    def catalog(self, scope: ScopeContext) -> list:
        return self._connector.catalog(scope)

    def health(self) -> ConnectorInfo:
        return self._connector.healthcheck()


# module-level default service (rebuilt on settings change)
_service: Optional[DataAccessService] = None


def data_service() -> DataAccessService:
    global _service
    if _service is None:
        _service = DataAccessService()
    return _service


def rebuild_service() -> DataAccessService:
    global _service
    _service = DataAccessService()
    return _service


def scope_from_user(user: dict) -> ScopeContext:
    """Map a Phase 0 RBAC user context into a typed ScopeContext."""
    from ..data.db import ALL_LOBS
    try:
        full = ALL_LOBS()
    except Exception:
        full = []
    return ScopeContext(
        user_id=user.get("user_id", "anonymous"),
        role=user.get("role"),
        allowed_lobs=list(user.get("allowed_lobs", [])),
        full_lobs=full,
        attributes=user.get("attributes", {}),
        authorized=bool(user.get("authorized")))
