"""Built-in ``ai_*`` functions, callable from SQL — Databricks-style.

DESIGN RULE, and the reason this file is shaped the way it is: **deterministic
first, model second.** Each function has a real local implementation that
runs air-gapped, costs nothing, and returns the same answer every time. A
language model is consulted only when one is configured, and even then:

  * PHI is scrubbed before the call and re-identified after (GuardedProvider)
  * results are cached per DISTINCT input, because a column of 31,000 claims
    contains far fewer distinct denial reasons than rows
  * a hard per-statement call budget applies — ``MAX_LLM_CALLS``
  * exceeding it degrades to the deterministic path rather than billing on

That last point is the one that matters in a warehouse. ``ai_classify(col)``
over a claims table is a per-row invocation; without a cap, one careless
SELECT is a five-figure bill and 31,000 rows of claim text leaving the
building. Databricks users hit exactly this. Here the ceiling is structural.

Determinism also protects the trust model: a value produced by a model is
tagged as inferred, never presented as governed warehouse data.
"""
from __future__ import annotations

import json
import logging
import math
import re
import threading

log = logging.getLogger("oppal.ai")

# Per-statement ceiling on model calls. Deliberately low: these functions are
# for enriching a result set a human is about to read, not for batch scoring a
# warehouse. Batch work belongs in a governed pipeline with a budget approval.
MAX_LLM_CALLS = 50
# Demo/sample mode: the ceiling applied once a human has explicitly confirmed
# they want a model-backed function to run over a column.
SAMPLE_LLM_CALLS = 20
MAX_TEXT = 4000

# Which functions CAN escalate to a model, and which can never. Only the first
# group needs a confirmation prompt — asking someone to approve ai_mask, which
# is pure local redaction, would train them to click through the dialog that
# actually matters.
MODEL_BACKED = {"ai_gen", "ai_translate", "ai_classify", "ai_extract",
                "ai_summarize", "ai_query"}
ALWAYS_LOCAL = {"ai_analyze_sentiment", "ai_mask", "ai_similarity",
                "ai_fix_grammar", "ai_forecast"}

_AI_CALL_RE = re.compile(r"\b(ai_[a-z_]+)\s*\(", re.I)

_state = threading.local()
_cache_lock = threading.Lock()
_CACHE: dict = {}          # (fn, args-key) -> value, per process


def reset_budget(limit: int | None = None):
    """Start a NEW statement's model budget.

    Must be called per statement. It previously existed but was never invoked
    outside tests, which meant the counter accumulated for the lifetime of a
    worker thread: the ceiling still bounded spend, but after ~50 calls that
    thread degraded to deterministic silently and forever. A budget nobody
    resets is a fuse, not a limit.
    """
    _state.calls = 0
    _state.limit = MAX_LLM_CALLS if limit is None else max(0, int(limit))


def _limit() -> int:
    return getattr(_state, "limit", MAX_LLM_CALLS)


def _budget_left() -> int:
    return max(0, _limit() - getattr(_state, "calls", 0))


def _spend():
    _state.calls = getattr(_state, "calls", 0) + 1


def stats() -> dict:
    return {"llm_calls_used": getattr(_state, "calls", 0),
            "llm_calls_max": _limit(),
            "cache_entries": len(_CACHE)}


def functions_used(sql: str) -> set:
    """Every ai_* referenced in a SQL string."""
    return {m.group(1).lower() for m in _AI_CALL_RE.finditer(str(sql or ""))}


def model_backed_used(sql: str) -> set:
    """Only those that could actually reach a model (and so cost money)."""
    return functions_used(sql) & MODEL_BACKED


# --------------------------------------------------------------- model access
def _provider():
    """A PHI-guarded provider, or None when offline/mock.

    MockProvider returns None for every completion, so treating "no usable
    model" and "mock" identically keeps the offline path honest instead of
    producing empty strings that look like answers.
    """
    try:
        from ..llm.base import get_provider, MockProvider
        from ..privacy.phi_guard import PHIGuard, GuardedProvider
        from .. import config
        p = get_provider()
        if p is None or isinstance(p, MockProvider):
            return None
        privacy = (config.load() or {}).get("privacy") or {}
        if privacy.get("phi_protection", True):
            return GuardedProvider(p, PHIGuard(True))
        return p
    except Exception:
        return None


def _ask(fn: str, system: str, user: str, cache_key):
    """One budgeted, cached, PHI-guarded completion. None on any failure."""
    ck = (fn, cache_key)
    with _cache_lock:
        if ck in _CACHE:
            return _CACHE[ck]
    if _budget_left() <= 0:
        return None
    p = _provider()
    if p is None:
        return None
    try:
        _spend()
        out = p.complete(system=system, user=str(user)[:MAX_TEXT])
    except Exception as e:                    # budget/kill-switch/transport
        log.debug("ai fn %s degraded to deterministic: %s", fn, e)
        return None
    if out:
        out = out.strip()
        with _cache_lock:
            _CACHE[ck] = out
    return out or None


# --------------------------------------------------------------- sentiment
# Small, auditable payer-flavoured lexicon. A reviewer can read it and predict
# the output, which is the whole advantage over a black box on this task.
_POS = {"approved", "approve", "resolved", "satisfied", "paid", "covered",
        "improved", "success", "successful", "thank", "thanks", "helpful",
        "good", "great", "excellent", "clear", "fast", "prompt", "accurate"}
_NEG = {"denied", "deny", "denial", "rejected", "reject", "delay", "delayed",
        "late", "error", "wrong", "incorrect", "complaint", "frustrated",
        "frustrating", "angry", "unacceptable", "escalate", "escalated",
        "appeal", "dispute", "confusing", "unclear", "failed", "failure",
        "missing", "unresolved", "overpaid", "underpaid", "abuse", "fraud"}
_NEGATORS = {"not", "no", "never", "without", "cannot", "cant", "didnt",
             "wasnt", "isnt", "wont"}


def ai_analyze_sentiment(text) -> str:
    """-> 'positive' | 'negative' | 'neutral' | 'mixed'."""
    s = re.sub(r"[^a-z0-9' ]+", " ", str(text or "").lower())
    words = [w for w in s.split() if w]
    if not words:
        return "neutral"
    pos = neg = 0
    for i, w in enumerate(words):
        flip = i > 0 and words[i - 1].replace("'", "") in _NEGATORS
        if w in _POS:
            neg += 1 if flip else 0
            pos += 0 if flip else 1
        elif w in _NEG:
            pos += 1 if flip else 0
            neg += 0 if flip else 1
    if pos and neg:
        ratio = pos / (pos + neg)
        if 0.4 <= ratio <= 0.6:
            return "mixed"
    if pos > neg:
        return "positive"
    if neg > pos:
        return "negative"
    return "neutral"


# --------------------------------------------------------------- classify
def ai_classify(text, labels) -> str:
    """Assign ``text`` to the closest of ``labels`` (comma string or list).

    Deterministic scoring uses the vector similarity module, so the label set
    can be arbitrary and no model is needed. A configured model is used only
    when the deterministic winner is weak or tied — the case where lexical
    overlap genuinely cannot decide.
    """
    from . import vectors
    labs = ([str(x) for x in labels] if isinstance(labels, (list, tuple))
            else [x.strip() for x in str(labels or "").split(",") if x.strip()])
    if not labs:
        return ""
    t = str(text or "")
    if not t.strip():
        return labs[0]
    scored = sorted(((vectors.similarity(t, l), l) for l in labs), reverse=True)
    top, runner = scored[0], (scored[1] if len(scored) > 1 else (0.0, None))
    if top[0] >= 0.25 and (top[0] - runner[0]) >= 0.05:
        return top[1]
    out = _ask("classify",
               "Choose EXACTLY ONE label. Reply with the label only, verbatim.",
               f"Labels: {', '.join(labs)}\n\nText: {t}",
               cache_key=(t[:200], tuple(labs)))
    if out:
        for l in labs:                      # never invent a label
            if l.lower() == out.strip().lower():
                return l
        for l in labs:
            if l.lower() in out.lower():
                return l
    return top[1]


# --------------------------------------------------------------- extract
_PATTERNS = {
    "claim_id": r"\b[Cc]-?\d{6,}\b",
    "member_id": r"\b[Mm]-?\d{5,}\b",
    "provider_id": r"\b[Pp][Rr]-?\d{3,}\b",
    "npi": r"\b\d{10}\b",
    "amount": r"\$\s?[\d,]+(?:\.\d{2})?",
    "date": r"\b\d{4}-\d{2}-\d{2}\b",
    "quarter": r"\b20\d\d\s?[Qq][1-4]\b",
    "reject_code": r"\b(?:reject(?:\s+code)?\s*)(\d{2,3})\b",
    "cpt": r"\b\d{5}\b",
    "icd10": r"\b[A-TV-Z]\d{2}(?:\.\d{1,4})?\b",
    "percent": r"\b\d{1,3}(?:\.\d+)?\s?%",
}


def ai_extract(text, fields=None) -> dict:
    """Pull named entities out of free text -> dict (SQL sees JSON).

    Regex-first because payer identifiers are STRUCTURED — claim ids, NPIs,
    CPT/ICD-10 codes, reject codes. A model is slower, costlier and less
    reliable than a pattern for exactly this shape of data.
    """
    t = str(text or "")
    want = ([str(x) for x in fields] if isinstance(fields, (list, tuple))
            else [x.strip() for x in str(fields or "").split(",") if x.strip()]
            or list(_PATTERNS))
    out = {}
    for f in want:
        pat = _PATTERNS.get(f)
        if not pat:
            continue
        found = re.findall(pat, t)
        if found:
            out[f] = found[0] if len(found) == 1 else found
    missing = [f for f in want if f not in out and f not in _PATTERNS]
    if missing and t.strip():
        got = _ask("extract",
                   "Extract the requested fields from the text. Reply with a "
                   "single JSON object. Use null when a field is absent. "
                   "Invent nothing.",
                   f"Fields: {', '.join(missing)}\n\nText: {t}",
                   cache_key=(t[:200], tuple(missing)))
        if got:
            try:
                parsed = json.loads(re.sub(r"^```(?:json)?|```$", "",
                                           got.strip(), flags=re.M))
                if isinstance(parsed, dict):
                    for k, v in parsed.items():
                        if v not in (None, "", []):
                            out[k] = v
            except (ValueError, TypeError):
                pass
    return out


# --------------------------------------------------------------- mask
def ai_mask(text) -> str:
    """Redact PHI/PII. Deterministic by construction.

    Reuses the shipped PHIGuard rather than a second, divergent redactor: a
    masking function that disagrees with the guard protecting LLM calls is a
    compliance liability, not a feature.
    """
    try:
        from ..privacy.phi_guard import PHIGuard
        scrubbed, _ = PHIGuard(True).scrub(str(text or ""))
        return scrubbed
    except Exception:
        return re.sub(r"\b\d{3}-\d{2}-\d{4}\b", "[REDACTED]", str(text or ""))


# --------------------------------------------------------------- summarize
_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")


def ai_summarize(text, max_sentences: int = 2) -> str:
    """EXTRACTIVE summary: the highest-signal sentences, verbatim.

    Extractive, not generative, on purpose. Every word returned appears in the
    source, so a summary of a clinical note or appeal letter cannot introduce
    a claim the record does not make. A model is used only for genuinely long
    text where sentence ranking reads poorly.
    """
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    if not t:
        return ""
    sents = [s.strip() for s in _SENT_SPLIT.split(t) if s.strip()]
    n = max(1, int(max_sentences or 2))
    if len(sents) <= n:
        return t[:MAX_TEXT]
    stop = {"the", "a", "an", "and", "or", "of", "to", "in", "for", "on",
            "is", "was", "were", "be", "with", "that", "this", "it", "as",
            "at", "by", "from"}
    words = [w for w in re.findall(r"[a-z0-9]+", t.lower()) if w not in stop]
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    scored = []
    for i, s in enumerate(sents):
        sw = [w for w in re.findall(r"[a-z0-9]+", s.lower()) if w not in stop]
        if not sw:
            continue
        # Mean term salience, with a mild lead bias: the first sentences of a
        # note or letter usually carry the point.
        score = sum(freq.get(w, 0) for w in sw) / len(sw)
        scored.append((score * (1.15 if i == 0 else 1.0), i, s))
    if len(t) > 1200:
        out = _ask("summarize",
                   f"Summarise in at most {n} sentences. Use only facts "
                   f"present in the text. No preamble.",
                   t, cache_key=(t[:300], n))
        if out:
            return out[:MAX_TEXT]
    top = sorted(sorted(scored, reverse=True)[:n], key=lambda x: x[1])
    return " ".join(s for _, _, s in top)


# --------------------------------------------------------------- grammar
_FIXES = [
    (r"\s+([,.;:!?])", r"\1"), (r"([,;:])(?=\S)", r"\1 "),
    # Space after sentence-ending punctuation, but ONLY between two letters.
    # A blunt rule here would corrupt the data it is meant to tidy: '1.5',
    # 'C-0012345', 'CO-50' and 'A41.9' must all survive untouched.
    (r"(?<=[a-zA-Z])([.!?])(?=[A-Za-z])", r"\1 "),
    (r"\s{2,}", " "), (r"\bi\b", "I"), (r"\bteh\b", "the"),
    (r"\brecieve(d?)\b", r"receive\1"), (r"\boccured\b", "occurred"),
    (r"\bseperate\b", "separate"), (r"\bdefinately\b", "definitely"),
    (r"\bacommodate\b", "accommodate"), (r"\bcliam\b", "claim"),
    (r"\bmemeber\b", "member"), (r"\bprovder\b", "provider"),
]


def ai_fix_grammar(text) -> str:
    """Conservative mechanical cleanup, then capitalise sentences.

    Intentionally timid: silently rewriting a clinician's or an appeals
    reviewer's wording is a documentation-integrity problem. Spacing,
    punctuation and a short list of common misspellings only.
    """
    s = str(text or "")
    if not s.strip():
        return s
    for pat, rep in _FIXES:
        s = re.sub(pat, rep, s, flags=re.I if pat.startswith(r"\b") else 0)
    s = re.sub(r"(^|[.!?]\s+)([a-z])",
               lambda m: m.group(1) + m.group(2).upper(), s)
    return s.strip()


# --------------------------------------------------------------- gen/translate
_NO_MODEL = "[no model configured — ai_gen requires an LLM provider]"


def ai_gen(prompt) -> str:
    """Free-form generation. Genuinely impossible without a model, so this
    says so rather than returning something that looks like an answer."""
    out = _ask("gen", "You are a concise analyst. Answer in plain prose.",
               str(prompt or ""), cache_key=str(prompt or "")[:300])
    return out or _NO_MODEL


def ai_translate(text, target_language="Spanish") -> str:
    out = _ask("translate",
               f"Translate into {target_language}. Return only the "
               f"translation, preserving numbers, codes and identifiers.",
               str(text or ""), cache_key=(str(text or "")[:300],
                                           str(target_language)))
    return out or (f"[no model configured — cannot translate to "
                   f"{target_language}]")


# --------------------------------------------------------------- similarity
def ai_similarity(a, b) -> float:
    from . import vectors
    return vectors.similarity(a, b)


# --------------------------------------------------------------- query
def ai_query(question, user=None) -> str:
    """Natural-language question -> the governed engine's own answer summary.

    Routed through the SAME orchestrator as the chat tab, so grounding, the
    read-only gate, LOB scoping and trust scoring all still apply. This is
    deliberately not a shortcut around governance; if the engine would
    withhold an answer in chat, it withholds it here.
    """
    try:
        from ..agents.orchestrator import Orchestrator
        from ..llm.base import get_provider
        u = user or {"user_id": "ai_query", "authorized": False,
                     "allowed_lobs": []}
        res = Orchestrator(get_provider()).handle(str(question or ""), user=u)
        return (res.get("summary") or "")[:MAX_TEXT]
    except Exception as e:
        log.debug("ai_query failed: %s", e)
        return "[ai_query unavailable]"


# --------------------------------------------------------------- forecast
def ai_forecast(series, horizon: int = 4) -> dict:
    """Time-series forecast. DETERMINISTIC STATISTICS, never a model.

    A model must not be allowed to invent a number that someone prices a
    benefit on. See analytics/timeseries.py for the method and its residuals.
    """
    from ..analytics import timeseries
    return timeseries.forecast(series, horizon)


# --------------------------------------------------------------- catalogue
CATALOGUE = [
    {"name": "ai_analyze_sentiment", "returns": "string",
     "args": "(text)", "engine": "deterministic",
     "about": "positive | negative | neutral | mixed, from an auditable "
              "payer lexicon with negation handling"},
    {"name": "ai_classify", "returns": "string", "args": "(text, labels)",
     "engine": "deterministic + model on ties",
     "about": "assigns text to one of your labels; never invents a label"},
    {"name": "ai_extract", "returns": "struct", "args": "(text, fields)",
     "engine": "deterministic",
     "about": "pulls claim/member/provider ids, NPI, CPT, ICD-10, amounts, "
              "dates, reject codes"},
    {"name": "ai_fix_grammar", "returns": "string", "args": "(text)",
     "engine": "deterministic",
     "about": "conservative spacing/punctuation/spelling cleanup only"},
    {"name": "ai_gen", "returns": "string", "args": "(prompt)",
     "engine": "model required",
     "about": "free-form generation; states plainly when no model is set"},
    {"name": "ai_mask", "returns": "string", "args": "(text)",
     "engine": "deterministic",
     "about": "PHI/PII redaction via the same guard that protects LLM calls"},
    {"name": "ai_query", "returns": "string", "args": "(question)",
     "engine": "governed engine",
     "about": "asks the governed orchestrator; grounding, gates and trust "
              "scoring all still apply"},
    {"name": "ai_similarity", "returns": "float", "args": "(a, b)",
     "engine": "deterministic",
     "about": "cosine similarity on character n-grams, 0..1"},
    {"name": "ai_summarize", "returns": "string",
     "args": "(text, max_sentences)", "engine": "deterministic",
     "about": "EXTRACTIVE — every word appears in the source, so it cannot "
              "introduce a claim the record does not make"},
    {"name": "ai_translate", "returns": "string",
     "args": "(text, target_language)", "engine": "model required",
     "about": "translation, preserving codes and identifiers"},
    {"name": "ai_forecast", "returns": "struct", "args": "(series, horizon)",
     "engine": "deterministic statistics",
     "about": "trend + seasonal forecast with prediction intervals; a model "
              "never produces the numbers"},
]


# --------------------------------------------------------------- SQL binding
def preflight(sql: str, row_estimate: int | None = None) -> dict:
    """Decide whether a statement needs human confirmation before running.

    Returns ``{"needs_confirmation": bool, ...}``. The caller refuses the
    statement and surfaces this to the user rather than quietly executing.

    IMPORTANT — why the ceiling is the model-call BUDGET and not a row LIMIT.
    A LIMIT does not bound how many times SQLite evaluates a scalar function:
    measured on this warehouse, ``SELECT ai_x(col) FROM claims ORDER BY amount
    DESC LIMIT 20`` evaluated the function 179 times, because the projection
    is computed while sorting. Enforcing "20 rows" with a LIMIT would be
    theatre. The budget counts actual model invocations, so it holds no matter
    what shape the query takes; the LIMIT is only there to keep the returned
    table small enough to read.
    """
    fns = sorted(model_backed_used(sql))
    local = sorted(functions_used(sql) - MODEL_BACKED)
    if not fns:
        return {"needs_confirmation": False, "model_backed": [],
                "local_only": local}
    return {
        "needs_confirmation": True,
        "model_backed": fns,
        "local_only": local,
        "row_estimate": row_estimate,
        "sample_rows": SAMPLE_LLM_CALLS,
        "max_model_calls_if_confirmed": SAMPLE_LLM_CALLS,
        "headline": (f"{', '.join(fns)} can call a language model once per row."),
        "detail": (
            f"On a table of {row_estimate:,} rows that is up to {row_estimate:,} "
            f"model calls, and the column text would leave this environment "
            f"once per call."
            if row_estimate else
            "Each row can trigger a model call, and the column text would "
            "leave this environment once per call."),
        "if_confirmed": (
            f"Demo mode runs a SAMPLE: at most {SAMPLE_LLM_CALLS} model calls "
            f"and {SAMPLE_LLM_CALLS} rows returned. Remaining rows fall back "
            f"to the deterministic implementation and are labelled as such."),
        "phi_note": ("Text is PHI-scrubbed before any call and results are "
                     "cached per distinct value, so repeats cost nothing."),
    }


def _j(v):
    """Struct-returning functions hand SQL a JSON string."""
    return json.dumps(v, default=str)


def register_sql_functions(con) -> int:
    """Register every ai_* as a SQLite scalar function on ``con``.

    Called for POOLED and for scoped single-use connections, because the
    read-only validation pass and the execution pass use different
    connections — a function registered on only one of them fails at
    EXPLAIN time with a confusing "no such function".
    """
    fns = [
        ("ai_analyze_sentiment", 1, lambda t: ai_analyze_sentiment(t)),
        ("ai_classify", 2, lambda t, l: ai_classify(t, l)),
        ("ai_extract", 1, lambda t: _j(ai_extract(t))),
        ("ai_extract", 2, lambda t, f: _j(ai_extract(t, f))),
        ("ai_fix_grammar", 1, lambda t: ai_fix_grammar(t)),
        ("ai_gen", 1, lambda p: ai_gen(p)),
        ("ai_mask", 1, lambda t: ai_mask(t)),
        ("ai_query", 1, lambda q: ai_query(q)),
        ("ai_similarity", 2, lambda a, b: ai_similarity(a, b)),
        ("ai_summarize", 1, lambda t: ai_summarize(t)),
        ("ai_summarize", 2, lambda t, n: ai_summarize(t, n)),
        ("ai_translate", 1, lambda t: ai_translate(t)),
        ("ai_translate", 2, lambda t, l: ai_translate(t, l)),
    ]
    added = 0
    for name, argc, fn in fns:
        try:
            con.create_function(name, argc, fn)
            added += 1
        except Exception as e:              # never break query execution
            log.debug("could not register %s/%d: %s", name, argc, e)
    try:
        con.create_aggregate("mkt", 1, _MKT)
        added += 1
    except Exception as e:
        log.debug("could not register mkt: %s", e)
    return added


class _MKT:
    """Mean Kinetic Temperature over a raw IoT series. SQL aggregate.

        MKT = (dH/R) / -ln( (1/n) * SUM( exp(-dH / (R * T_i)) ) )

    T_i in KELVIN. The exponent divides by (R * T_i) — a spec draft wrote it
    as -dH/R * T_i, which multiplies and yields nonsense. Cold chain is the
    one number a Quality lead rechecks by hand.

    An aggregate, not a precomputed column, so the metric stays declarative
    and the arithmetic is visible in the SQL log.
    """
    DH = 83144.0          # J/mol, ICH Q1A convention
    R = 8.314             # J/(mol K)

    def __init__(self):
        self.n = 0
        self.acc = 0.0

    def step(self, celsius):
        if celsius is None:
            return
        try:
            kelvin = float(celsius) + 273.15
        except (TypeError, ValueError):
            return
        if kelvin <= 0:
            return
        self.n += 1
        self.acc += math.exp(-self.DH / (self.R * kelvin))

    def finalize(self):
        if not self.n or self.acc <= 0:
            return None
        return round(self.DH / self.R / -math.log(self.acc / self.n) - 273.15, 2)


__all__ = ["ai_analyze_sentiment", "ai_classify", "ai_extract",
           "ai_fix_grammar", "ai_gen", "ai_mask", "ai_query",
           "ai_similarity", "ai_summarize", "ai_translate", "ai_forecast",
           "register_sql_functions", "CATALOGUE", "_MKT", "reset_budget", "stats",
           "MAX_LLM_CALLS", "SAMPLE_LLM_CALLS", "MODEL_BACKED", "ALWAYS_LOCAL",
           "functions_used", "model_backed_used", "preflight"]
