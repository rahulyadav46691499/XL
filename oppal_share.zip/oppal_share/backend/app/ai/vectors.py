"""Vector search over warehouse text — local, deterministic, stdlib only.

WHAT THIS IS, PLAINLY: character n-gram TF-IDF with cosine similarity. It
finds text that is *lexically* close — misspellings, morphology, word order,
partial tokens ("ozempic" ~ "Ozempic 0.5mg pen", "cardiolgy" ~ "Cardiology").

WHAT IT IS NOT: neural embeddings. It does not know that "GLP-1" relates to
"weight loss" unless the characters overlap. Calling that "semantic search"
would be the kind of overclaim this product exists to avoid, so the API
reports its own method and the UI says so.

Why this instead of an embedding API: it runs air-gapped, costs nothing,
never sends claim text off-box, and returns the same ranking every time —
which matters when a search result becomes part of an audit trail. An
embedding backend can be added behind the same interface later; the index
format already carries a ``method`` field so a mixed estate stays honest
about which index answered.
"""
from __future__ import annotations

import math
import re
import threading
from collections import Counter

NGRAM = 3            # trigrams: robust to typos without exploding the space
MAX_DOCS = 20000     # bounded memory; the UI paginates well before this
MIN_SCORE = 0.02     # below this, a "match" is noise

_lock = threading.Lock()
_INDEXES: dict = {}          # name -> index dict


def _norm(text) -> str:
    s = str(text or "").lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", s)).strip()


def _grams(text: str) -> Counter:
    """Character trigrams over space-padded words, plus whole words.

    Words are kept as their own features so an exact term match outranks a
    coincidental character overlap; trigrams supply the typo tolerance.
    """
    s = _norm(text)
    if not s:
        return Counter()
    feats = []
    for word in s.split(" "):
        if not word:
            continue
        feats.append("w:" + word)
        padded = f" {word} "
        for i in range(len(padded) - NGRAM + 1):
            feats.append(padded[i:i + NGRAM])
    return Counter(feats)


def _tf_weights(counts: Counter) -> dict:
    """Sub-linear term frequency — a term repeated 20x is not 20x as relevant."""
    return {t: 1.0 + math.log(c) for t, c in counts.items()}


def build_index(name: str, docs, method: str = "char_tfidf") -> dict:
    """Index ``docs`` = iterable of (id, text, meta).

    Stores L2-normalised sparse vectors so search is a dot product.
    """
    rows, df = [], Counter()
    for doc in docs:
        if len(rows) >= MAX_DOCS:
            break
        did, text, meta = (list(doc) + [None, None])[:3]
        counts = _grams(text)
        if not counts:
            continue
        rows.append({"id": did, "text": str(text), "meta": meta or {},
                     "tf": _tf_weights(counts)})
        for t in counts:
            df[t] += 1

    n = len(rows)
    idf = {t: math.log((n + 1) / (c + 1)) + 1.0 for t, c in df.items()}
    for r in rows:
        vec = {t: w * idf.get(t, 1.0) for t, w in r["tf"].items()}
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        r["vec"] = {t: v / norm for t, v in vec.items()}
        del r["tf"]

    index = {"name": name, "method": method, "n_docs": n, "idf": idf,
             "rows": rows, "ngram": NGRAM,
             "note": ("character n-gram TF-IDF — lexical/morphological "
                      "similarity, not neural embeddings")}
    with _lock:
        _INDEXES[name] = index
    return {"name": name, "n_docs": n, "method": method,
            "note": index["note"]}


def _query_vec(text: str, idf: dict) -> dict:
    counts = _grams(text)
    if not counts:
        return {}
    vec = {t: w * idf.get(t, 1.0) for t, w in _tf_weights(counts).items()}
    norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
    return {t: v / norm for t, v in vec.items()}


def search(name: str, query: str, k: int = 10,
           min_score: float = MIN_SCORE) -> dict:
    with _lock:
        index = _INDEXES.get(name)
    if not index:
        return {"ok": False, "reason": f"no index named '{name}' — build it first",
                "hits": []}
    qv = _query_vec(query, index["idf"])
    if not qv:
        return {"ok": True, "hits": [], "method": index["method"],
                "note": "the query had no indexable characters"}
    hits = []
    for r in index["rows"]:
        v = r["vec"]
        # Iterate the SHORTER side of the dot product — queries are tiny.
        small, big = (qv, v) if len(qv) <= len(v) else (v, qv)
        score = 0.0
        for t, w in small.items():
            other = big.get(t)
            if other:
                score += w * other
        if score >= min_score:
            hits.append({"id": r["id"], "score": round(score, 4),
                         "text": r["text"][:400], "meta": r["meta"]})
    hits.sort(key=lambda h: (-h["score"], str(h["id"])))   # stable ties
    return {"ok": True, "hits": hits[:max(1, min(int(k or 10), 100))],
            "method": index["method"], "n_docs": index["n_docs"],
            "note": index["note"]}


def similarity(a, b) -> float:
    """Cosine similarity of two strings, 0..1. Deterministic and symmetric.

    Self-contained (its own local IDF of the pair) so ``ai_similarity`` works
    as a SQL scalar function without a prebuilt index.
    """
    ca, cb = _grams(a), _grams(b)
    if not ca or not cb:
        return 0.0
    df = Counter()
    for t in set(ca) | set(cb):
        df[t] = (1 if t in ca else 0) + (1 if t in cb else 0)
    idf = {t: math.log(3 / (c + 1)) + 1.0 for t, c in df.items()}
    va = {t: w * idf[t] for t, w in _tf_weights(ca).items()}
    vb = {t: w * idf[t] for t, w in _tf_weights(cb).items()}
    na = math.sqrt(sum(v * v for v in va.values())) or 1.0
    nb = math.sqrt(sum(v * v for v in vb.values())) or 1.0
    dot = sum(v * vb.get(t, 0.0) for t, v in va.items())
    return round(max(0.0, min(1.0, dot / (na * nb))), 4)


def index_names() -> list:
    with _lock:
        return sorted(_INDEXES)


def index_info(name: str) -> dict:
    with _lock:
        i = _INDEXES.get(name)
    if not i:
        return {}
    return {"name": i["name"], "method": i["method"], "n_docs": i["n_docs"],
            "note": i["note"], "vocab": len(i["idf"])}


def reset():
    with _lock:
        _INDEXES.clear()


__all__ = ["build_index", "search", "similarity", "index_names", "index_info",
           "reset", "MIN_SCORE"]
