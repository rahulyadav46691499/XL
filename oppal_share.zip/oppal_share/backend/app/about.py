"""The About payload — "which build is this, running on what?".

Deliberately NOT written inline in the FastAPI route. Two reasons:

  1. Testability. FastAPI is an optional dependency in some environments
     (the regression suite runs without it), so anything defined inside
     ``main.py`` cannot be exercised by a test that does not import the
     whole web layer. Route handlers should be thin.
  2. Honesty. Every field below except the declared version is INTROSPECTED
     from the running system — the Brain's fingerprint, its metric count,
     the audit ledger's height and verification state. A hand-maintained
     "about" blob drifts; this one cannot, because there is nothing to
     maintain.

Each block degrades to a placeholder rather than raising: an About panel
with a gap in it is far better than one that 500s and leaves an operator
unable to identify the build they are debugging.
"""
from __future__ import annotations

from .version import (BUILD_DATE, CODENAME, RELEASE_NOTE, VERSION,
                      version_string)


def snapshot(llm_provider: str = "mock") -> dict:
    info = {
        "version": VERSION,
        "codename": CODENAME,
        "build_date": BUILD_DATE,
        "release_note": RELEASE_NOTE,
        "version_string": version_string(),
        "llm_provider": llm_provider or "mock",
    }

    try:
        from .semantic import brain as brain_loader
        info["brain_domain"] = brain_loader.active_domain()
        b = brain_loader.get_brain()
        info["brain_metrics"] = len(b.get("metrics", {}) or {})
        info["brain_policy_rules"] = len(b.get("policy_rules", {}) or {})
        info["brain_certified_metrics"] = sum(
            1 for m in (b.get("metrics", {}) or {}).values()
            if m.get("certified"))
    except Exception:
        info["brain_domain"] = "unavailable"

    try:
        # The key is 'brain_version' (e.g. 'sha256:864c5247…'). Guessing at
        # 'fingerprint' here returned an empty string that the panel happily
        # rendered as a blank row — a reminder that a defensive `.get()` with
        # a fallback can hide a wrong key rather than surface it.
        from .trust.provenance import brain_fingerprint
        fp = brain_fingerprint() or {}
        info["brain_fingerprint"] = str(fp.get("brain_version") or "")
        info["brain_files_hashed"] = len(fp.get("files") or {})
    except Exception:
        info["brain_fingerprint"] = ""

    try:
        from .trust import ledger_v2
        chain = ledger_v2.verify_chain()
        info["ledger_blocks"] = chain.checked
        info["ledger_head"] = str(chain.head_hash or "")[:16]
        info["ledger_verified"] = bool(chain.ok)
    except Exception:
        info["ledger_verified"] = None

    return info


__all__ = ["snapshot"]
