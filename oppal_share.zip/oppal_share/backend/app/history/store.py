"""Server-side chat history — per user, durable, and owner-scoped.

WHY THIS EXISTS
    History used to live in browser localStorage. That had two problems. It
    vanished on logout (the destructive wipe removed in v14.7.2), and even
    once that was fixed it never followed anyone to a second machine: an
    analyst who asked a question on a laptop could not find it on a desktop,
    and clearing the browser cache destroyed it permanently.

OWNERSHIP IS SERVER-DERIVED, ALWAYS
    Every function here takes the ``user_id`` of the AUTHENTICATED principal,
    resolved by the endpoint from the bearer token. It is never read from a
    request body or a query string. This is the same rule the workspace,
    cohort and review-queue stores follow, and it is the rule that the
    cross-user isolation suite exists to police: a store that accepts a
    caller-supplied owner is a store with no owner at all.

PHI AT REST — A DELIBERATE, BOUNDED DECISION
    A question is free text, and free text in a payer setting can carry PHI
    ("why was claim C-0012345 denied for member M-004217?"). Moving history
    to the server therefore creates a new PHI-at-rest surface that did not
    exist when it lived in one person's browser. Three things bound it:

      1. Owner scoping. There is no cross-user read path in this module at
         all — not for compliance officers, not for admins. ``list_for_user``
         filters on the authenticated id and nothing else. History is the
         one store with no privileged reader, because the operational need
         that would justify one (audit) is already served by the audit ledger,
         which stores its copy PHI-scrubbed.
      2. Retention. ``MAX_ENTRIES_PER_USER`` caps each user's history and the
         oldest entries are dropped on write, so the surface is bounded
         rather than unbounded-and-growing.
      3. Deletion. ``clear`` and ``delete_entry`` give the owner a real,
         immediate erase — which is more than the browser version offered
         once a cache was synced.

    The alternative — scrubbing questions before storage — was rejected on
    purpose: the entire point of history is to re-ask the question, and a
    tokenised question is not re-askable. That trade-off is recorded here so
    a reviewer can disagree with it knowingly rather than discover it.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
from datetime import datetime, timezone

log = logging.getLogger("oppal.history")

HISTORY_DB = os.environ.get(
    "OPPAL_HISTORY_DB",
    os.path.join(os.path.dirname(os.path.dirname(__file__)), "data",
                 "chat_history.db"))

# Retention cap per user. Mirrors the review queue's 200-item bound: enough
# for months of real use, small enough that the PHI surface cannot grow
# without limit. Configurable for deployments with a stricter policy.
MAX_ENTRIES_PER_USER = int(os.environ.get("OPPAL_HISTORY_MAX", "200"))

# A single conversation may accumulate many questions; cap it too so one
# long-running chat cannot consume the whole allowance.
MAX_QUESTIONS_PER_ENTRY = 100

_lock = threading.Lock()


def _con():
    os.makedirs(os.path.dirname(HISTORY_DB), exist_ok=True)
    con = sqlite3.connect(HISTORY_DB, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS chat_history (
            chat_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            title   TEXT,
            qs_json TEXT,
            ts      INTEGER,
            updated_at TEXT,
            PRIMARY KEY (chat_id, user_id))""")
    # Composite PK on (chat_id, user_id) rather than chat_id alone: chat ids
    # are generated client-side from Date.now(), so two users can collide on
    # one. Keying on the pair means a collision can never let one user's
    # write land on another's row.
    con.execute("CREATE INDEX IF NOT EXISTS ix_hist_user "
                "ON chat_history(user_id, ts DESC)")
    con.commit()
    return con


def _row(r) -> dict:
    d = dict(r)
    return {"id": d["chat_id"], "title": d["title"] or "",
            "qs": json.loads(d["qs_json"] or "[]"), "ts": d["ts"] or 0}


def list_for_user(user_id: str) -> list[dict]:
    """This user's history, newest first. No cross-user path exists."""
    if not user_id:
        return []
    con = _con()
    try:
        rows = con.execute(
            "SELECT * FROM chat_history WHERE user_id = ? "
            "ORDER BY ts DESC, updated_at DESC LIMIT ?",
            (user_id, MAX_ENTRIES_PER_USER)).fetchall()
        return [_row(r) for r in rows]
    finally:
        con.close()


def append_turn(user_id: str, chat_id: str, question: str,
                title: str = "") -> dict:
    """Record one question against a chat, creating the chat if new.

    Upsert rather than insert: the UI clubs every question in a session under
    one history entry, so a second question must extend the existing row, not
    open a new one.
    """
    if not user_id or not chat_id:
        return {"ok": False, "error": "missing principal or chat id"}
    q = (question or "").strip()
    if not q:
        return {"ok": False, "error": "empty question"}
    now = datetime.now(timezone.utc)
    with _lock:
        con = _con()
        try:
            row = con.execute(
                "SELECT * FROM chat_history WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id)).fetchone()
            if row:
                qs = json.loads(row["qs_json"] or "[]")
                qs.append(q)
                qs = qs[-MAX_QUESTIONS_PER_ENTRY:]
                con.execute(
                    "UPDATE chat_history SET qs_json = ?, title = ?, ts = ?, "
                    "updated_at = ? WHERE chat_id = ? AND user_id = ?",
                    (json.dumps(qs), title or row["title"] or q[:48],
                     int(now.timestamp() * 1000), now.isoformat(),
                     chat_id, user_id))
            else:
                con.execute(
                    "INSERT INTO chat_history (chat_id, user_id, title, "
                    "qs_json, ts, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (chat_id, user_id, title or q[:48], json.dumps([q]),
                     int(now.timestamp() * 1000), now.isoformat()))
            # Enforce retention on write, so the cap holds without a sweeper.
            con.execute(
                "DELETE FROM chat_history WHERE user_id = ? AND chat_id NOT IN "
                "(SELECT chat_id FROM chat_history WHERE user_id = ? "
                " ORDER BY ts DESC, updated_at DESC LIMIT ?)",
                (user_id, user_id, MAX_ENTRIES_PER_USER))
            con.commit()
        finally:
            con.close()
    return {"ok": True}


def import_entries(user_id: str, entries: list) -> dict:
    """One-time migration of a browser's localStorage history.

    Additive and idempotent: an entry whose chat_id this user already has is
    skipped rather than merged, so re-running the migration (a second tab, a
    refresh mid-flight) cannot duplicate or clobber anything.
    """
    if not user_id or not isinstance(entries, list):
        return {"ok": False, "imported": 0}
    imported = 0
    with _lock:
        con = _con()
        try:
            have = {r["chat_id"] for r in con.execute(
                "SELECT chat_id FROM chat_history WHERE user_id = ?",
                (user_id,))}
            now = datetime.now(timezone.utc).isoformat()
            for e in entries[:MAX_ENTRIES_PER_USER]:
                if not isinstance(e, dict):
                    continue
                cid = str(e.get("id") or "").strip()
                if not cid or cid in have:
                    continue
                qs = e.get("qs") or ([e.get("q")] if e.get("q") else [])
                qs = [str(x) for x in qs if x][:MAX_QUESTIONS_PER_ENTRY]
                if not qs:
                    continue
                con.execute(
                    "INSERT INTO chat_history (chat_id, user_id, title, "
                    "qs_json, ts, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (cid, user_id, str(e.get("title") or qs[0])[:120],
                     json.dumps(qs), int(e.get("ts") or 0), now))
                have.add(cid)
                imported += 1
            con.commit()
        finally:
            con.close()
    return {"ok": True, "imported": imported}


def delete_entry(user_id: str, chat_id: str) -> dict:
    """Delete ONE of this user's entries. The user_id predicate is not
    optional — without it this becomes a delete-anyone's-history endpoint."""
    if not user_id or not chat_id:
        return {"ok": False, "deleted": 0}
    with _lock:
        con = _con()
        try:
            cur = con.execute(
                "DELETE FROM chat_history WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id))
            con.commit()
            return {"ok": True, "deleted": cur.rowcount}
        finally:
            con.close()


def clear(user_id: str) -> dict:
    """Erase all of this user's history. Owner-initiated only."""
    if not user_id:
        return {"ok": False, "deleted": 0}
    with _lock:
        con = _con()
        try:
            cur = con.execute(
                "DELETE FROM chat_history WHERE user_id = ?", (user_id,))
            con.commit()
            return {"ok": True, "deleted": cur.rowcount}
        finally:
            con.close()


def summary(user_id: str) -> dict:
    con = _con()
    try:
        r = con.execute(
            "SELECT COUNT(*) AS n FROM chat_history WHERE user_id = ?",
            (user_id,)).fetchone()
        return {"entries": r["n"] if r else 0,
                "cap": MAX_ENTRIES_PER_USER}
    finally:
        con.close()


def reset():
    """Test/demo helper. Drops the whole store."""
    with _lock:
        con = _con()
        try:
            con.execute("DELETE FROM chat_history")
            con.commit()
        finally:
            con.close()
