# Compliance Guardrails

Three runnable rules plus the action-governance triple. Every threshold is a
bullet on the rule, and every rule that feeds the Pillars dashboard declares a
`query:` the rules engine executes against the caller's scoped data plane.

Rules that need data this domain does not yet have — rapid-disenrolment
recovery, election-period validity, agent appointment and certification
currency — are deliberately absent rather than declared and dead. A declared
check with no data fails closed and reports itself as unimplemented, which is
correct behaviour but a poor dashboard. Add them with the Tier-2 tables.

### MA-DSNP-ELIGIBILITY
- citation: 42 CFR §422.52(a); CMS Medicare Managed Care Manual ch. 2
- requirement: A Dual Eligible Special Needs Plan may enrol only a beneficiary entitled to Medicaid. An enrolment in a D-SNP product without dual eligibility is a mis-enrolment and must be remediated by eligibility redetermination or disenrollment.
- check: dsnp_eligibility
- pillar: regulatory
- max_exception_rate: 0.05
- breach_action: fail
- headline: {region} — {exceptions} of {dsnp_enrolments} D-SNP enrolments lack Medicaid entitlement ({exception_rate} vs 5% ceiling), {exposure_usd} USD annualised premium at risk
- query: SELECT t.region, SUM(t.dsnp_eligibility_exception) AS exceptions, SUM(CASE WHEN t.product_type = 'D-SNP' THEN 1 ELSE 0 END) AS dsnp_enrolments, ROUND(SUM(t.dsnp_eligibility_exception) * 1.0 / NULLIF(SUM(CASE WHEN t.product_type = 'D-SNP' THEN 1 ELSE 0 END), 0), 4) AS exception_rate, ROUND(SUM(CASE WHEN t.dsnp_eligibility_exception = 1 THEN t.monthly_premium * 12 ELSE 0 END), 0) AS exposure_usd FROM medicare_sales_monthly t GROUP BY t.region HAVING exceptions > 0 ORDER BY exceptions DESC
- remediation: Run Medicaid eligibility redetermination on the affected members. Where entitlement cannot be established, disenroll to a compatible non-SNP product and reverse the risk-adjustment submission. Refer the originating broker for commission review.

### MA-BROKER-COMP-FMV
- citation: 42 CFR §422.2274(b) — compensation may not exceed the fair market value CMS publishes for the plan year
- requirement: Compensation per enrolled life may not exceed the fair-market-value cap for the plan year. Any broker-quarter above the cap is an exception requiring compensation review before further payment.
- check: broker_compensation_cap
- pillar: fwa
- fmv_cap_usd: 100
- calibration_note: 100 USD is a DEMO-CALIBRATED threshold, not the CMS figure. The underlying dataset is relabelled employer-group commission, so the real CMS per-enrollee cap would never trigger against it. Set fmv_cap_usd to the published CMS plan-year value AND update the literal in the query below when real Medicare broker data replaces it — the two must be changed together.
- breach_action: fail
- headline: Broker {broker_id} — {commission_per_life} USD per enrolled life in {sale_quarter} ({region}), above the {fmv_cap_usd} USD cap on {enrolled_lives} lives
- query: SELECT t.broker_id, t.sale_quarter, t.region, t.enrolled_lives, ROUND(t.commission_paid, 0) AS commission_paid, ROUND(t.commission_paid * 1.0 / NULLIF(t.enrolled_lives, 0), 2) AS commission_per_life FROM broker_performance_quarterly t WHERE t.enrolled_lives > 0 AND t.commission_paid * 1.0 / NULLIF(t.enrolled_lives, 0) > 100 ORDER BY commission_per_life DESC
- remediation: Hold further commission payment to the broker, reconcile the paid amount against the plan-year cap, and open a recovery action for the excess.

### MA-CLAWBACK-CONCENTRATION
- citation: 42 CFR §422.2274(d) — compensation recovery on rapid disenrollment; internal SIU distribution policy
- requirement: A broker whose commission clawback rate is more than twice the book rate, on a meaningful payment volume, is referred for distribution-integrity review. The rule self-calibrates against the book rather than a fixed rate, so it stays meaningful as volume grows.
- check: clawback_concentration
- pillar: fwa
- rate_multiple: 2.0
- min_payments: 10
- breach_action: warn
- headline: Broker {broker_id} — clawback rate {clawback_rate} on {payments} payments, {rate_multiple}x the {book_rate} book rate, {exposure_usd} USD exposed
- query: SELECT t.broker_id, SUM(t.clawback_count) AS clawbacks, SUM(t.comm_count) AS payments, ROUND(SUM(t.clawback_count) * 1.0 / NULLIF(SUM(t.comm_count), 0), 4) AS clawback_rate, ROUND(SUM(t.clawback_exposure), 0) AS exposure_usd, (SELECT ROUND(SUM(b.clawback_count) * 1.0 / NULLIF(SUM(b.comm_count), 0), 4) FROM broker_performance_quarterly b) AS book_rate FROM broker_performance_quarterly t GROUP BY t.broker_id HAVING payments >= 10 AND clawback_rate > 2.0 * book_rate ORDER BY exposure_usd DESC
- remediation: Sample the broker's recent enrolments for rapid disenrollment and misrepresentation, verify appointment and certification currency, and open a recovery action for confirmed leakage.

### ACTION-DUAL-CONTROL-25K
- citation: Medicare Sales delegation of authority
- requirement: A write-back with an estimated impact of $25,000 or more requires two distinct approvers. Disenrollment, commission recovery and risk-adjustment reversal are always dual control regardless of amount, because each is externally visible to CMS or to a beneficiary.
- check: action_dual_control
- financial_impact_threshold: 25000
- regulatory_severity_triggers: critical, high
- dual_control_action_types: member_disenrollment, eligibility_redetermination, commission_recovery, broker_suspension, risk_adjustment_reversal, compensating
- self_approval_allowed: false
- always_dual_control: false

### ACTION-TRUST-GATE
- citation: Internal AI governance standard
- requirement: No Medicare Sales write-back executes below the enterprise trust gate. A beneficiary-facing action taken on a low-confidence analysis is a beneficiary-harm event, not a data-quality event.
- check: action_trust_gate
- execution_trust_gate: 0.85

### ACTION-APPROVER-ROLES
- citation: Medicare Sales delegation of authority; 42 CFR §422.2272 oversight obligation
- requirement: Approvers must hold a sales compliance or compliance officer role. A sales or distribution analyst may propose but never approve — the person carrying the growth target does not sign off on the compliance remedy.
- check: action_approver_roles
- approver_roles: sales_compliance_officer, compliance_officer

### ACTION-COMPENSATION
- citation: Internal reversal policy
- requirement: A reversal is itself a dual-control action; the original ledger entry is never edited. A disenrollment that is itself reversed must cite the original entry.
- check: action_compensation
- modes: void, reinstate
- min_reason_chars: 12
