# Simulation Formulas

What-if formulas for the Medicare Sales remediation and growth levers. The
delta engine looks up a formula id here and holds no arithmetic literal of its
own — a missing id raises SimulationConfigError rather than falling back to a
hardcoded number.

### eligibility_remediation_net
- label: Net Recovery from Eligibility Remediation
- definition: Premium and risk-revenue protected by remediating D-SNP eligibility exceptions, after redetermination cost and the share of members whose Medicaid entitlement is successfully established.
- formula: exceptions * annual_premium_per_member * (1 - redetermination_success_rate) - exceptions * redetermination_cost_per_member
- redetermination_success_rate: 0.35
- redetermination_cost_per_member: 85
- owner: Sales Compliance

### disenrollment_membership_impact
- label: Membership Impact of Remediation Disenrollment
- definition: Net membership lost if unresolved exceptions are disenrolled, offset by the share retained on a compatible non-SNP product.
- formula: exceptions * (1 - redetermination_success_rate) * (1 - non_snp_retention_rate)
- non_snp_retention_rate: 0.55
- redetermination_success_rate: 0.35
- owner: Medicare Sales Analytics

### commission_recovery_net
- label: Net Commission Recovery
- definition: Recoverable commission above the fair-market-value cap, after recovery cost and expected broker dispute leakage.
- formula: excess_commission * (1 - dispute_rate) - recovery_cost
- dispute_rate: 0.18
- recovery_cost: 4500
- owner: Sales Compensation

### broker_reallocation_lift
- label: Enrolment Lift from Broker Reallocation
- definition: Enrolments expected if lead volume is moved from an outlier broker to the compliant peer median, at the peer conversion rate.
- formula: reallocated_lives * peer_conversion_rate * (1 - ramp_loss)
- peer_conversion_rate: 0.42
- ramp_loss: 0.15
- owner: Distribution Leadership

### acquisition_cost_per_enrolment
- label: Acquisition Cost per Effectuated Enrolment
- definition: Fully loaded acquisition cost per enrolment, used to price any growth lever against the premium it buys.
- formula: (commission_paid + campaign_spend) / effectuated_enrolments
- campaign_spend: 0
- campaign_spend_note: Zero until the Tier-2 marketing_campaigns table lands. With no campaign spend in the warehouse, this formula currently reports commission-only cost — do not present it as fully loaded CAC.
- owner: Finance
