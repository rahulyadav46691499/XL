# Entities, Columns & Joins

The two curated tables are the analytic surface. They are built by
`app/data/medicare_sales_curated.sql` from the warehouse tables listed below,
and they exist because the metric compiler emits single-table SQL — the joins
happen once, at curation time, not per query.

## Tables

### medicare_sales_monthly
Curated enrolment book: one row per enrolled member, stamped with its
enrolment month, product, contract, PBP, region, risk band, dual status and
the D-SNP eligibility exception flag. The primary analytic table.

### broker_performance_quarterly
Curated distribution book: one row per broker per quarter per region, carrying
premium sold, enrolled lives, commission paid, commission count and clawback
count/exposure. Built from the imported group_sales, broker_commissions and
broker_groups datasets.

### members
Source enrolment roster: MBI, package, LOB, region, age band, dual status, RAF
score, premium and effective date. Curated into medicare_sales_monthly.

### plans
Line-of-business plan carrying the CMS contract number (H1234 for the MA book).

### products
Marketed product under a plan. `product_type` is HMO, PPO or D-SNP — the field
the eligibility rule turns on.

### benefit_packages
Plan Benefit Package including cost share and formulary linkage.

### group_sales
Imported broker sales transactions: premium sold per group per quarter.

### broker_commissions
Imported broker commission payments, carrying the clawback flag.

### broker_groups
Imported employer-group dimension: segment, region, enrolled lives.

## Columns

- medicare_sales_monthly.effective_month: Enrolment month, YYYY-MM. The time axis for every sales trend.
- medicare_sales_monthly.effective_date: Exact enrolment effective date.
- medicare_sales_monthly.lob: Line of business. The governed scope column.
- medicare_sales_monthly.region: Sales region — Midwest, Northeast, Southeast, Southwest, West.
- medicare_sales_monthly.cohort: Dual Eligible / Non-Dual. Cut on dual status because the seeded MA book is entirely age band 65+.
- medicare_sales_monthly.cms_contract: CMS contract number, H1234 for the MA book.
- medicare_sales_monthly.product_type: HMO, PPO or D-SNP. D-SNP carries the §422.52 eligibility condition.
- medicare_sales_monthly.pbp: Plan Benefit Package name.
- medicare_sales_monthly.risk_band: ACG risk band 1-Healthy through 4-High.
- medicare_sales_monthly.dual_eligible: 1 = entitled to Medicaid. The precondition for D-SNP enrolment.
- medicare_sales_monthly.monthly_premium: Member monthly premium revenue.
- medicare_sales_monthly.raf_score: CMS-HCC Risk Adjustment Factor at enrolment.
- medicare_sales_monthly.dsnp_eligibility_exception: 1 = enrolled in a D-SNP without dual eligibility. A 42 CFR §422.52(a) mis-enrolment.
- broker_performance_quarterly.broker_id: Selling broker or agency identifier.
- broker_performance_quarterly.sale_quarter: Sales quarter, e.g. 2025Q1. The distribution time axis.
- broker_performance_quarterly.premium_sold: Premium written by the broker in the quarter.
- broker_performance_quarterly.enrolled_lives: Lives enrolled behind that premium.
- broker_performance_quarterly.commission_paid: Commission paid to the broker in the quarter.
- broker_performance_quarterly.comm_count: Number of commission payments, the denominator for clawback rate.
- broker_performance_quarterly.clawback_count: Commission payments flagged for clawback.
- broker_performance_quarterly.clawback_exposure: Dollar value of commissions flagged for clawback.

## Joins

Curation-time joins, materialised by medicare_sales_curated.sql. Declared here
so the semantic graph can show the lineage of the curated tables.

- members.package_id = benefit_packages.package_id
- benefit_packages.product_id = products.product_id
- products.plan_id = plans.plan_id
- group_sales.group_id = broker_groups.group_id
- broker_commissions.broker_id = group_sales.broker_id

## Dimensions (medicare_sales_monthly)

- region: medicare_sales_monthly.region
- product_type: medicare_sales_monthly.product_type
- cohort: medicare_sales_monthly.cohort
- cms_contract: medicare_sales_monthly.cms_contract
- pbp: medicare_sales_monthly.pbp
- risk_band: medicare_sales_monthly.risk_band
- effective_month: medicare_sales_monthly.effective_month

## Dimensions (broker_performance_quarterly)

- broker_id: broker_performance_quarterly.broker_id
- region: broker_performance_quarterly.region
- sale_quarter: broker_performance_quarterly.sale_quarter

## Analysis Dimensions (medicare_sales_monthly)

- region, product_type, cohort, risk_band, pbp

## Analysis Dimensions (broker_performance_quarterly)

- broker_id, region

## Cohort Fields

Audience predicates. Unmarked fields resolve against the curated enrolment
table, which is the base for every audience in this domain.

- region: medicare_sales_monthly.region
- product_type: medicare_sales_monthly.product_type
- cohort: medicare_sales_monthly.cohort
- risk_band: medicare_sales_monthly.risk_band
- dual_eligible: medicare_sales_monthly.dual_eligible
- cms_contract: medicare_sales_monthly.cms_contract
