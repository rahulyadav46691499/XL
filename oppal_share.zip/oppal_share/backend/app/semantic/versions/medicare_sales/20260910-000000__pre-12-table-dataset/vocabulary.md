# Vocabulary

Business language a Medicare Sales user actually types, mapped onto governed
nodes. A question that matches nothing here grounds poorly, scores below the
trust gate and is refused rather than guessed at — so breadth here is what
makes the domain usable.

## Terms

- enrolments => metric:effectuated_enrolments
- enrollments => metric:effectuated_enrolments
- effectuated enrolments => metric:effectuated_enrolments
- effectuated enrollments => metric:effectuated_enrolments
- sales volume => metric:effectuated_enrolments
- new members => metric:effectuated_enrolments
- membership => metric:effectuated_enrolments
- membership growth => metric:effectuated_enrolments
- enrolment premium => metric:enrolment_premium
- premium revenue => metric:enrolment_premium
- revenue per enrolment => metric:revenue_per_enrolment
- revenue per enrollment => metric:revenue_per_enrolment
- premium per member => metric:revenue_per_enrolment
- raf at enrolment => metric:avg_raf_at_enrolment
- average raf => metric:avg_raf_at_enrolment
- risk score => metric:avg_raf_at_enrolment
- dsnp mix => metric:dsnp_mix
- d-snp mix => metric:dsnp_mix
- dsnp share => metric:dsnp_mix
- product mix => metric:dsnp_mix
- dual mix => metric:dual_eligible_mix
- dual eligible share => metric:dual_eligible_mix
- dual share => metric:dual_eligible_mix
- dsnp exceptions => metric:dsnp_eligibility_exceptions
- d-snp exceptions => metric:dsnp_eligibility_exceptions
- eligibility exceptions => metric:dsnp_eligibility_exceptions
- enrolment exceptions => metric:dsnp_eligibility_exceptions
- enrollment exceptions => metric:dsnp_eligibility_exceptions
- mis-enrolment => metric:dsnp_eligibility_exceptions
- misenrollment => metric:dsnp_eligibility_exceptions
- ineligible dsnp => metric:dsnp_eligibility_exceptions
- exception rate => metric:dsnp_exception_rate
- dsnp exception rate => metric:dsnp_exception_rate
- enrolment exception rate => metric:dsnp_exception_rate
- eligibility exception rate => metric:dsnp_exception_rate
- enrolment reconciliation => metric:dsnp_exception_rate
- premium exposure => metric:exception_premium_exposure
- premium at risk => metric:exception_premium_exposure
- recovery exposure => metric:exception_premium_exposure
- premium sold => metric:premium_sold
- written premium => metric:premium_sold
- broker production => metric:premium_sold
- commission => metric:commission_paid
- commission paid => metric:commission_paid
- commissions => metric:commission_paid
- commission per life => metric:commission_per_life
- commission per enrolment => metric:commission_per_life
- commission per member => metric:commission_per_life
- compensation per enrolment => metric:commission_per_life
- fmv => metric:commission_per_life
- fair market value => metric:commission_per_life
- acquisition cost => metric:acquisition_cost_ratio
- acquisition cost ratio => metric:acquisition_cost_ratio
- cost per enrolment => metric:acquisition_cost_ratio
- cac => metric:acquisition_cost_ratio
- sales economics => metric:acquisition_cost_ratio
- clawback => metric:clawback_rate
- clawback rate => metric:clawback_rate
- chargeback rate => metric:clawback_rate
- rapid disenrollment => metric:clawback_rate
- rapid disenrolment => metric:clawback_rate
- clawback exposure => metric:clawback_exposure
- overpayment => metric:clawback_exposure
- commission recovery => metric:clawback_exposure
- incentive leakage => metric:clawback_exposure

## Dimensions

- region => dim:region
- market => dim:region
- territory => dim:region
- sales region => dim:region
- product => dim:product_type
- product type => dim:product_type
- plan type => dim:product_type
- dsnp => dim:product_type
- hmo => dim:product_type
- ppo => dim:product_type
- contract => dim:cms_contract
- cms contract => dim:cms_contract
- h contract => dim:cms_contract
- pbp => dim:pbp
- plan benefit package => dim:pbp
- benefit package => dim:pbp
- cohort => dim:cohort
- segment => dim:cohort
- dual status => dim:cohort
- risk band => dim:risk_band
- acuity => dim:risk_band
- broker => dim:broker_id
- agent => dim:broker_id
- agency => dim:broker_id
- producer => dim:broker_id
- channel => dim:broker_id
- distribution => dim:broker_id
- quarter => dim:sale_quarter
- sales quarter => dim:sale_quarter
- month => dim:effective_month
- enrolment month => dim:effective_month
