# Departmental Agent Swarm

Five personas. None has a Python class — each declares its detector as SQL plus
a finding template, executed by the base DepartmentAgent. A persona with a
`case_type` also opens a de-duplicated case, which is what populates the Cases
tab without an engine change.

## sentry
- department: Medicare Sales Command
- role: Triage the question and decide which departmental agents to activate.
- triggers: *
- pillars: all
- tools: anomaly_scan, metric_trend
- detector: triage
- priority: 0
- always_on: true
- model_tier: cheap
- required_permission: agent_invoke_triage

## enrolment_integrity
- department: Sales Compliance
- role: Detect enrolments that breach a plan-eligibility condition, principally D-SNP enrolment without Medicaid entitlement under 42 CFR §422.52(a).
- triggers: dsnp, d-snp, eligibility, exception, mis-enrolment, misenrollment, reconciliation, enrolment integrity, enrollment integrity, dual, ineligible, special needs
- pillars: regulatory
- tools: policy_check, metric_trend
- detector: brain_query
- priority: 10
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_compliance
- finding_kind: dsnp_eligibility_exception
- severity_column: exception_rate
- severity_threshold: 0.25
- impact_column: exposure_usd
- min_impact: 1
- headline: {region} — {exceptions} D-SNP enrolments without Medicaid entitlement ({exception_rate} exception rate)
- detail: {exceptions} of {dsnp_enrolments} D-SNP enrolments in {region} carry dual_eligible = 0. 42 CFR §422.52(a) permits D-SNP enrolment only for a beneficiary entitled to Medicaid, so each is a mis-enrolment. Annualised premium at risk {exposure_usd} USD. Remediate by eligibility redetermination; where entitlement cannot be established, disenroll to a compatible non-SNP product and reverse the risk-adjustment submission.
- case_type: EnrolmentExceptionCase
- case_subject_column: region
- case_pattern: dsnp_eligibility
- query: SELECT t.region, SUM(t.dsnp_eligibility_exception) AS exceptions, SUM(CASE WHEN t.product_type = 'D-SNP' THEN 1 ELSE 0 END) AS dsnp_enrolments, ROUND(SUM(t.dsnp_eligibility_exception) * 1.0 / NULLIF(SUM(CASE WHEN t.product_type = 'D-SNP' THEN 1 ELSE 0 END), 0), 4) AS exception_rate, ROUND(SUM(CASE WHEN t.dsnp_eligibility_exception = 1 THEN t.monthly_premium * 12 ELSE 0 END), 0) AS exposure_usd FROM medicare_sales_monthly t GROUP BY t.region HAVING exceptions > 0 ORDER BY exposure_usd DESC

## broker_compensation
- department: Sales Compensation
- role: Test broker compensation per enrolled life against the plan-year fair-market-value cap in 42 CFR §422.2274(b).
- triggers: commission, compensation, fmv, fair market value, broker pay, agent pay, cap, per life, overpayment, incentive
- pillars: fwa
- tools: policy_check
- detector: brain_query
- priority: 20
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_fwa
- finding_kind: broker_compensation_exception
- severity: high
- impact_column: commission_paid
- headline: Broker {broker_id} — {commission_per_life} USD per life in {sale_quarter}, above the FMV cap
- detail: Broker {broker_id} was paid {commission_paid} USD on {enrolled_lives} enrolled lives in {sale_quarter} ({region}), or {commission_per_life} USD per life. 42 CFR §422.2274(b) caps compensation at the fair market value CMS publishes for the plan year. Hold further payment and reconcile the excess.
- case_type: BrokerCompensationCase
- case_subject_column: broker_id
- case_pattern: fmv_breach
- query: SELECT t.broker_id, t.sale_quarter, t.region, t.enrolled_lives, ROUND(t.commission_paid, 0) AS commission_paid, ROUND(t.commission_paid * 1.0 / NULLIF(t.enrolled_lives, 0), 2) AS commission_per_life FROM broker_performance_quarterly t WHERE t.enrolled_lives > 0 AND t.commission_paid * 1.0 / NULLIF(t.enrolled_lives, 0) > 100 ORDER BY commission_per_life DESC

## commission_recovery
- department: Distribution Integrity
- role: Identify brokers whose commission clawback rate is a peer outlier against the book, as a proxy for rapid-disenrollment recovery exposure.
- triggers: clawback, chargeback, recovery, rapid disenrollment, rapid disenrolment, leakage, persistency, retention, integrity
- pillars: fwa
- tools: policy_check, metric_trend
- detector: brain_query
- priority: 30
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_fwa
- finding_kind: clawback_concentration
- severity: medium
- impact_column: exposure_usd
- min_impact: 1000
- headline: Broker {broker_id} — clawback rate {clawback_rate} against a {book_rate} book rate
- detail: Broker {broker_id} recorded {clawbacks} clawbacks across {payments} commission payments, a rate of {clawback_rate} against the book rate of {book_rate}. Exposure {exposure_usd} USD. Sample recent enrolments for rapid disenrollment and misrepresentation, and verify appointment and certification currency.
- case_type: DistributionIntegrityCase
- case_subject_column: broker_id
- case_pattern: clawback_outlier
- query: SELECT t.broker_id, SUM(t.clawback_count) AS clawbacks, SUM(t.comm_count) AS payments, ROUND(SUM(t.clawback_count) * 1.0 / NULLIF(SUM(t.comm_count), 0), 4) AS clawback_rate, ROUND(SUM(t.clawback_exposure), 0) AS exposure_usd, (SELECT ROUND(SUM(b.clawback_count) * 1.0 / NULLIF(SUM(b.comm_count), 0), 4) FROM broker_performance_quarterly b) AS book_rate FROM broker_performance_quarterly t GROUP BY t.broker_id HAVING payments >= 10 AND clawback_rate > 2.0 * book_rate ORDER BY exposure_usd DESC

## sales_performance
- department: Sales & Distribution Leadership
- role: Surface regions whose enrolment mix or premium yield diverges from the book, so leadership sees where the growth is coming from and at what quality.
- triggers: pace, sales pace, growth, membership growth, mix, product mix, performance, scorecard, region, market, yield, premium
- pillars: regulatory
- tools: metric_trend, anomaly_scan
- detector: brain_query
- priority: 40
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: sales_mix_divergence
- severity: medium
- impact_column: annualised_premium
- headline: {region} — {enrolments} enrolments, {dsnp_share} D-SNP share, {avg_premium} USD average premium
- detail: {region} wrote {enrolments} enrolments at an average premium of {avg_premium} USD and an average RAF of {avg_raf}. D-SNP share {dsnp_share}, dual share {dual_share}. Annualised premium {annualised_premium} USD. Compare against the book to judge whether the region is buying growth with mix.
- query: SELECT t.region, COUNT(t.member_id) AS enrolments, ROUND(AVG(t.monthly_premium), 2) AS avg_premium, ROUND(AVG(t.raf_score), 3) AS avg_raf, ROUND(AVG(CASE WHEN t.product_type = 'D-SNP' THEN 1.0 ELSE 0 END), 4) AS dsnp_share, ROUND(AVG(t.dual_eligible), 4) AS dual_share, ROUND(SUM(t.monthly_premium) * 12, 0) AS annualised_premium FROM medicare_sales_monthly t GROUP BY t.region ORDER BY annualised_premium DESC

## Swarm Settings

- max_active_agents: 4
- min_active_agents: 1
- trust_gate: 0.85
- case_creation_min_trust: 0.60
