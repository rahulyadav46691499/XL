# Reference Data

## Source Documents

- 42 CFR §422.52: Eligibility to elect an MA plan, including the Medicaid entitlement condition for a Dual Eligible Special Needs Plan
- 42 CFR §422.2274: Agent, broker and third-party marketing organisation requirements — compensation limits, training, testing and oversight
- 42 CFR §422.2272: Licensure, appointment and reporting obligations for agents and brokers
- 42 CFR §422.60: Election process and coordinated election periods
- 42 CFR §422.62: Election periods — AEP, OEP, ICEP and special election periods
- 42 CFR §422.74: Disenrollment by the MA organisation
- CMS Medicare Communications and Marketing Guidelines: marketing, sales event and beneficiary contact rules
- CMS MA/Part D Monthly Enrollment by CPSC: the external benchmark for market penetration

## Dimension Values

- region: Midwest, Northeast, Southeast, Southwest, West
- product_type: HMO, PPO, D-SNP
- cohort: Dual Eligible, Non-Dual
- risk_band: 1-Healthy, 2-Low, 3-Moderate, 4-High
- cms_contract: H1234
- lob: Medicare Advantage

## Election Periods

Declared for vocabulary and narration. The seeded book carries no election
period signal — effective dates are spread uniformly across days of the month
rather than clustering on the 1st — so AEP/OEP reporting requires the Tier-2
application table rather than a derivation from enrolment dates.

- AEP: Annual Election Period, 15 October to 7 December, effective 1 January
- OEP: Medicare Advantage Open Enrollment Period, 1 January to 31 March
- ICEP: Initial Coverage Election Period, around Medicare entitlement
- SEP: Special Election Period, on a qualifying life or plan event
