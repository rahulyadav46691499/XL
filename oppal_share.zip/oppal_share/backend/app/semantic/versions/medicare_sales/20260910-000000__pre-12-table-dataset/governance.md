# Data Governance & Scoping Rules

Declarative RBAC/ABAC data-scoping rules read by the MCP Zero-Copy layer's
ScopeEnforcer. Scope is the line of business, the same as the payer domain — a
Medicare Sales analyst sees the Medicare Advantage book and nothing else.

## Scope Column

- lob

## Governed Tables

Both curated tables carry `lob` directly and are scoped on it. Note that
`broker_performance_quarterly` carries a stamped LOB value rather than a
sourced one (see the fidelity note in medicare_sales_curated.sql) — it is
declared governed deliberately, because an unscoped sales table would bypass
the platform's primary control.

- medicare_sales_monthly: lob
- broker_performance_quarterly: lob
- members: lob
- plans: lob

## Transitive Tables

The product hierarchy carries no LOB of its own; it is scoped by joining up to
the plan.

- products: plan_id -> plans.plan_id
- benefit_packages: product_id -> products.product_id

## Excluded Tables

Credential, identity and RBAC-directory tables. Never exposed to an analytical
query at any scope.

- users
- roles
- role_lob_access
- user_attributes

## Ungoverned Tables

Imported source datasets for the distribution book. They carry no LOB column
and no PHI — only broker, employer-group and commission facts. They are
available at every scope as lineage for the curated table; analysts should
query `broker_performance_quarterly` instead.

- group_sales
- broker_commissions
- broker_groups

## Role Aliases

This deployment's Medicare Sales role vocabulary, mapped onto known capability
classes. An alias grants a class; it cannot invent a permission.

- sales_compliance_officer: compliance_officer
- sales_ops_analyst: ma_analyst
- distribution_analyst: ma_analyst
- marketing_analyst: ma_analyst

## Scope Strategy

- predicate_pushdown_capable: bigquery, snowflake, databricks, redshift, postgres
- physical_sandbox: local_reference, sqlite_demo

## Enforcement

- deny_by_default: true
- require_scope_context: true
- forbid_unscoped_execution: true
