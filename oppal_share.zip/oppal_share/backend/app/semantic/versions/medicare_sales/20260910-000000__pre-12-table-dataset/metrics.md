# Governed Metrics

Every metric names its own table, so the compiler resolves it without a payer
base. `base:` is deliberately NOT one of claims/rx/members — those route to the
payer code paths, and `base: members` in particular has no time axis, which
would make monthly sales trends impossible. Tables declared governed in
governance.md get the LOB scope predicate injected automatically; the alias is
always `t`.

Numbers quoted in definitions are measured against the seeded book at the
Medicare Advantage scope (1,952 members, enrolment months 2024-07 to 2025-01).

## Enrolment & portfolio

### effectuated_enrolments
- label: Effectuated Enrolments
- definition: Count of enrolled members with an effective date in the period. The headline sales volume KPI.
- formula: COUNT(member_id)
- sql: COUNT(t.member_id)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, product_type, cohort, cms_contract, pbp, risk_band
- format: number
- depends: medicare_sales_monthly.member_id
- owner: Medicare Sales Analytics
- certified: true

### enrolment_premium
- label: Enrolment Premium
- definition: Total monthly premium revenue attached to enrolments in the period.
- formula: SUM(monthly_premium)
- sql: ROUND(SUM(t.monthly_premium), 0)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, product_type, cohort, cms_contract, pbp, risk_band
- format: currency
- depends: medicare_sales_monthly.monthly_premium
- owner: Finance
- certified: true

### revenue_per_enrolment
- label: Revenue per Enrolment
- definition: Average monthly premium per effectuated enrolment. The sales-economics denominator.
- formula: AVG(monthly_premium)
- sql: ROUND(AVG(t.monthly_premium), 2)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, product_type, cohort, cms_contract, pbp, risk_band
- average: true
- format: currency
- depends: medicare_sales_monthly.monthly_premium
- owner: Finance
- certified: true

### avg_raf_at_enrolment
- label: Average RAF at Enrolment
- definition: Mean CMS-HCC risk score of the enrolling cohort. Rising RAF with flat premium signals adverse selection in the sales mix.
- formula: AVG(raf_score)
- sql: ROUND(AVG(t.raf_score), 3)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, product_type, cohort, risk_band
- average: true
- format: number
- depends: medicare_sales_monthly.raf_score
- owner: Actuarial
- certified: true

## Product mix

### dsnp_mix
- label: D-SNP Share of Enrolments
- definition: Share of enrolments landing in a Dual Eligible Special Needs Plan. Roughly 50% of the seeded MA book.
- formula: AVG(CASE WHEN product_type = 'D-SNP' THEN 1 ELSE 0 END)
- sql: ROUND(AVG(CASE WHEN t.product_type = 'D-SNP' THEN 1.0 ELSE 0 END), 4)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, cohort, cms_contract, risk_band
- average: true
- format: percent
- depends: medicare_sales_monthly.product_type
- owner: Medicare Sales Analytics
- certified: true

### dual_eligible_mix
- label: Dual Eligible Share
- definition: Share of enrolments entitled to Medicaid. 744 of 1,952 in the seeded MA book.
- formula: AVG(dual_eligible)
- sql: ROUND(AVG(t.dual_eligible), 4)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, product_type, cms_contract, risk_band
- average: true
- format: percent
- depends: medicare_sales_monthly.dual_eligible
- owner: Medicare Sales Analytics
- certified: true

## Enrolment integrity

### dsnp_eligibility_exceptions
- label: D-SNP Eligibility Exceptions
- definition: Members enrolled in a D-SNP without Medicaid entitlement. 42 CFR §422.52(a) permits D-SNP enrolment only for a dual-eligible beneficiary, so each row is a mis-enrolment. 223 in the seeded MA book.
- formula: SUM(dsnp_eligibility_exception)
- sql: SUM(t.dsnp_eligibility_exception)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, cms_contract, pbp, risk_band, cohort
- format: number
- depends: medicare_sales_monthly.dsnp_eligibility_exception
- owner: Sales Compliance
- certified: true

### dsnp_exception_rate
- label: D-SNP Eligibility Exception Rate
- definition: Non-dual enrolments as a share of all D-SNP enrolments. The enrolment-integrity KPI. 23.1% book-wide; 30.5% in the Northeast against 17.4% in the West.
- formula: SUM(dsnp_eligibility_exception) / COUNT(D-SNP enrolments)
- sql: ROUND(SUM(t.dsnp_eligibility_exception) * 1.0 / NULLIF(SUM(CASE WHEN t.product_type = 'D-SNP' THEN 1 ELSE 0 END), 0), 4)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, cms_contract, pbp, risk_band
- average: true
- format: percent
- depends: medicare_sales_monthly.dsnp_eligibility_exception, medicare_sales_monthly.product_type
- owner: Sales Compliance
- certified: true

### exception_premium_exposure
- label: Premium Exposure on Exceptions
- definition: Annualised premium attached to D-SNP eligibility exceptions — the revenue subject to CMS recovery if the enrolments are unwound. $2.75M book-wide.
- formula: SUM(monthly_premium * 12) WHERE exception
- sql: ROUND(SUM(CASE WHEN t.dsnp_eligibility_exception = 1 THEN t.monthly_premium * 12 ELSE 0 END), 0)
- base: enrolment
- table: medicare_sales_monthly
- time_column: effective_month
- dims: region, cms_contract, pbp
- format: currency
- depends: medicare_sales_monthly.dsnp_eligibility_exception, medicare_sales_monthly.monthly_premium
- owner: Finance
- certified: true

## Distribution & compensation

### premium_sold
- label: Premium Sold
- definition: Premium written by the distribution channel in the quarter.
- formula: SUM(premium_sold)
- sql: ROUND(SUM(t.premium_sold), 0)
- base: distribution
- table: broker_performance_quarterly
- time_column: sale_quarter
- dims: broker_id, region
- format: currency
- depends: broker_performance_quarterly.premium_sold
- owner: Distribution Leadership
- certified: true

### commission_paid
- label: Commission Paid
- definition: Total broker commission paid in the quarter.
- formula: SUM(commission_paid)
- sql: ROUND(SUM(t.commission_paid), 0)
- base: distribution
- table: broker_performance_quarterly
- time_column: sale_quarter
- dims: broker_id, region
- format: currency
- depends: broker_performance_quarterly.commission_paid
- owner: Sales Compensation
- certified: true

### commission_per_life
- label: Commission per Enrolled Life
- definition: Commission paid divided by enrolled lives. The measure tested against the CMS fair-market-value compensation cap in 42 CFR §422.2274.
- formula: SUM(commission_paid) / SUM(enrolled_lives)
- sql: ROUND(SUM(t.commission_paid) * 1.0 / NULLIF(SUM(t.enrolled_lives), 0), 2)
- base: distribution
- table: broker_performance_quarterly
- time_column: sale_quarter
- dims: broker_id, region
- average: true
- format: currency
- depends: broker_performance_quarterly.commission_paid, broker_performance_quarterly.enrolled_lives
- owner: Sales Compensation
- certified: true

### acquisition_cost_ratio
- label: Acquisition Cost Ratio
- definition: Commission paid as a share of premium sold. The sales-economics efficiency KPI.
- formula: SUM(commission_paid) / SUM(premium_sold)
- sql: ROUND(SUM(t.commission_paid) * 1.0 / NULLIF(SUM(t.premium_sold), 0), 4)
- base: distribution
- table: broker_performance_quarterly
- time_column: sale_quarter
- dims: broker_id, region
- average: true
- format: percent
- depends: broker_performance_quarterly.commission_paid, broker_performance_quarterly.premium_sold
- owner: Finance
- certified: true

### clawback_rate
- label: Commission Clawback Rate
- definition: Share of commission payments flagged for clawback. A proxy for rapid-disenrolment recovery under 42 CFR §422.2274(d) until the Tier-2 enrolment-span table lands.
- formula: SUM(clawback_count) / SUM(comm_count)
- sql: ROUND(SUM(t.clawback_count) * 1.0 / NULLIF(SUM(t.comm_count), 0), 4)
- base: distribution
- table: broker_performance_quarterly
- time_column: sale_quarter
- dims: broker_id, region
- average: true
- format: percent
- depends: broker_performance_quarterly.clawback_count, broker_performance_quarterly.comm_count
- owner: Sales Compensation
- certified: true

### clawback_exposure
- label: Clawback Exposure
- definition: Dollar value of commission flagged for recovery.
- formula: SUM(clawback_exposure)
- sql: ROUND(SUM(t.clawback_exposure), 0)
- base: distribution
- table: broker_performance_quarterly
- time_column: sale_quarter
- dims: broker_id, region
- format: currency
- depends: broker_performance_quarterly.clawback_exposure
- owner: Sales Compensation
- certified: true
