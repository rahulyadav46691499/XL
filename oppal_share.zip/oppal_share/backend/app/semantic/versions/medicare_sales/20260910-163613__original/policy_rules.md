# Compliance Guardrails

Twelve runnable rules across three pillars, plus the action-governance quartet.
Every threshold is a bullet on the rule and every rule that feeds the Pillars
dashboard declares a `query:` the rules engine executes against the caller's
scoped data plane — one generic handler, no bespoke Python per rule.

Each query returns ONLY breaching rows, so the Pillars breach count is a real
count rather than a row count. Every query also selects `lob`, so a finding is
stamped with the scope of the incident rather than the scope of whoever ran it.

## Regulatory

### CMS-AGENT-CERT-2274
- citation: 42 CFR §422.2274(b); 42 CFR §422.2272 — licensure, appointment and annual training
- requirement: An agent or broker must hold a current AHIP certification, a valid state licence and an active carrier appointment on the date an application is written. An application written on a lapsed credential is a marketing violation and the enrolment is subject to CMS review.
- check: agent_certification_currency
- pillar: regulatory
- max_breach_count: 0
- breach_action: fail
- headline: Agent {agent_id} — {applications} application(s) written after the {cert_type} expired on {expiry_date} ({lob}, {market})
- query: SELECT a.lob, a.market, a.agent_id, c.cert_type, c.expiry_date, COUNT(DISTINCT a.application_id) AS applications, MIN(a.application_date) AS first_application, MAX(a.application_date) AS last_application FROM applications a JOIN agent_certifications c ON c.agent_id = a.agent_id WHERE c.cert_type IN ('AHIP', 'State License') AND c.expiry_date IS NOT NULL AND c.expiry_date < a.application_date GROUP BY a.lob, a.market, a.agent_id, c.cert_type, c.expiry_date ORDER BY applications DESC
- remediation: Suspend the agent from writing new business until the credential is reinstated. Re-verify every application in the affected window, disclose to the CMS account manager where an enrolment is affected, and hold commission on the affected applications pending review.

### CMS-SOA-2264
- citation: 42 CFR §422.2264 — Scope of Appointment must be documented and obtained before a personal marketing appointment
- requirement: A Scope of Appointment must be on file for every application, and must be signed at least 48 hours before the marketing appointment except where the beneficiary walks in or the appointment falls inside the last four days of a valid election period.
- check: soa_documentation
- pillar: regulatory
- min_hours_before_appointment: 48
- breach_action: fail
- headline: {lob} / {market} — {breaches} application(s) with no Scope of Appointment on file or signed inside the {min_hours} hour window
- min_hours: 48
- query: SELECT a.lob, a.market, COUNT(*) AS breaches, SUM(CASE WHEN a.soa_on_file = 0 THEN 1 ELSE 0 END) AS missing_soa, SUM(CASE WHEN a.soa_on_file = 1 AND a.soa_signed_date IS NOT NULL AND a.appointment_date IS NOT NULL AND (julianday(a.appointment_date) - julianday(a.soa_signed_date)) < 2.0 THEN 1 ELSE 0 END) AS short_notice FROM applications a WHERE a.soa_on_file = 0 OR (a.soa_signed_date IS NOT NULL AND a.appointment_date IS NOT NULL AND (julianday(a.appointment_date) - julianday(a.soa_signed_date)) < 2.0) GROUP BY a.lob, a.market ORDER BY breaches DESC
- remediation: Re-document the Scope of Appointment where the beneficiary is contactable, record the walk-in or election-period exception where one applies, and retrain the writing agents. Report the residual population in the annual marketing compliance attestation.

### CMS-COMP-CAP-2274E
- citation: 42 CFR §422.2274(e) — compensation may not exceed the fair market value CMS publishes for the plan year
- requirement: An initial-year commission may not exceed the CMS fair-market-value cap carried on the payment record. Any payment above the cap is an exception requiring compensation review before further payment to that agent.
- check: compensation_cap
- pillar: regulatory
- breach_action: fail
- headline: Agent {agent_id} — {payments} initial payment(s) above the FMV cap in {comm_quarter}, {excess_usd} USD over ({lob})
- query: SELECT t.lob, t.agent_id, t.agency_id, t.comm_quarter, COUNT(*) AS payments, ROUND(SUM(t.commission_paid - t.fmv_cap), 2) AS excess_usd, ROUND(MAX(t.commission_paid), 2) AS largest_payment, ROUND(MAX(t.fmv_cap), 2) AS cap FROM agent_commissions t WHERE t.comm_type = 'Initial' AND t.fmv_cap > 0 AND t.commission_paid > t.fmv_cap GROUP BY t.lob, t.agent_id, t.agency_id, t.comm_quarter ORDER BY excess_usd DESC
- remediation: Hold further payment to the agent, reconcile the paid amount against the published plan-year cap and open a commission recovery action for the excess. Where the agency received an override on the same enrolment, reconcile that too.

### CMS-RAPID-DISENROLL-RECOUP
- citation: 42 CFR §422.2274(d) — full compensation recovery when a beneficiary disenrolls within the first three months
- requirement: Compensation must be recouped in full when a beneficiary disenrolls within 90 days of the effective date. A rapid disenrolment with no recoupment flagged is an unrecovered payment.
- check: rapid_disenrollment_recoupment
- pillar: regulatory
- recoupment_window_days: 90
- breach_action: fail
- headline: Agent {agent_id} — {payments} payment(s) on rapid disenrolments with no recoupment raised, {unrecouped_usd} USD ({lob}, {channel})
- query: SELECT c.lob, c.channel, c.agent_id, c.agency_id, COUNT(*) AS payments, ROUND(SUM(c.commission_paid + c.bonus_paid + c.override_paid), 2) AS unrecouped_usd, MIN(e.disenroll_days) AS fastest_disenroll_days FROM agent_commissions c JOIN enrollments e ON e.enrollment_id = c.enrollment_id WHERE e.rapid_disenroll_flag = 1 AND c.recoupment_due_flag = 0 GROUP BY c.lob, c.channel, c.agent_id, c.agency_id ORDER BY unrecouped_usd DESC
- remediation: Raise the recoupment against the agent's next commission statement, reconcile the enrolment span with the CMS monthly membership report, and review the enrolment for misrepresentation before writing the recovery off.

### CMS-CTM-THRESHOLD
- citation: CMS Complaints Tracking Module; CMS Medicare Communications and Marketing Guidelines
- requirement: CMS Complaints Tracking Module contacts per 1,000 customer interactions must stay below the plan's internal escalation threshold. A market above the threshold is escalated to the compliance committee regardless of the absolute count.
- check: ctm_complaint_threshold
- pillar: regulatory
- max_ctm_per_1000: 20
- breach_action: warn
- headline: {lob} / {market} — {ctm_per_1000} CTM contacts per 1,000 interactions ({ctm_contacts} of {interactions}), above the {max_per_1000} threshold
- max_per_1000: 20
- query: SELECT t.lob, t.market, COUNT(*) AS interactions, SUM(t.ctm_flag) AS ctm_contacts, ROUND(SUM(t.ctm_flag) * 1000.0 / NULLIF(COUNT(*), 0), 1) AS ctm_per_1000, SUM(t.escalated_flag) AS escalated FROM interactions t GROUP BY t.lob, t.market HAVING ctm_contacts > 0 AND ctm_per_1000 > 20 ORDER BY ctm_per_1000 DESC
- remediation: Pull the underlying complaint categories, identify the selling agent and channel behind each contact, and open a marketing-conduct review where a single agent or lead source recurs.

### ENR-TAT-DECISION
- citation: 42 CFR §422.60; CMS enrolment processing guidance — a completed election must be processed inside the plan's stated window
- requirement: An application decision must be reached inside the declared processing window. An application-quarter whose mean turnaround exceeds the window, or which carries decisions beyond it, is an enrolment-operations exception.
- check: enrollment_turnaround
- pillar: regulatory
- max_turnaround_hours: 168
- breach_action: warn
- headline: {lob} / {market} — {breaches} decision(s) beyond the {max_hours} hour window in {application_quarter}, worst {worst_hours} hours
- max_hours: 168
- query: SELECT t.lob, t.market, t.application_quarter, COUNT(*) AS breaches, ROUND(MAX(t.turnaround_hours), 1) AS worst_hours, ROUND(AVG(t.turnaround_hours), 1) AS mean_hours FROM applications t WHERE t.turnaround_hours > 168 GROUP BY t.lob, t.market, t.application_quarter ORDER BY worst_hours DESC
- remediation: Work the backlog oldest-first, confirm whether any affected beneficiary experienced a coverage gap, and staff the enrolment queue against the pace the quarter actually requires.

## Fraud, waste & abuse

### SALES-EFFECTUATION-Z
- citation: Internal SIU distribution policy; 42 CFR §422.2274 oversight obligation
- requirement: An agent whose approval-to-effectuation rate sits materially below the book, on a meaningful enrolment volume, is referred for distribution-integrity review — the pattern of an enrolment written and credited that never becomes a real member.
- check: effectuation_outlier
- pillar: fwa
- min_enrollments: 15
- effectuation_floor: 0.85
- z_threshold: 3.0
- breach_action: fail
- headline: Agent {agent_id} — {effectuation_rate} effectuation on {enrollments} enrolments against a {book_rate} book rate ({lob})
- query: SELECT t.lob, t.agent_id, t.agency_id, COUNT(*) AS enrollments, SUM(t.effectuated_flag) AS effectuated, ROUND(AVG(t.effectuated_flag), 4) AS effectuation_rate, (SELECT ROUND(AVG(b.effectuated_flag), 4) FROM enrollments b) AS book_rate FROM enrollments t GROUP BY t.lob, t.agent_id, t.agency_id HAVING enrollments >= 15 AND effectuation_rate < 0.85 ORDER BY effectuation_rate ASC
- remediation: Sample the agent's non-effectuated applications for beneficiary contact, confirm each application was genuinely requested, hold further commission and open a recovery action for compensation already paid on enrolments that never effectuated.

### SALES-BONUS-EXCEPTION
- citation: 42 CFR §422.2274(e); internal compensation policy
- requirement: No initial commission, override or bonus may remain paid against an enrolment that never effectuated. Every such payment is an overpayment and must be recovered.
- check: bonus_exception
- pillar: fwa
- breach_action: fail
- headline: Agent {agent_id} — {payments} payment(s) on enrolments that never effectuated, {overpaid_usd} USD ({lob}, {channel})
- query: SELECT c.lob, c.channel, c.agent_id, c.agency_id, COUNT(*) AS payments, ROUND(SUM(c.commission_paid + c.bonus_paid + c.override_paid), 2) AS overpaid_usd, GROUP_CONCAT(DISTINCT c.comm_type) AS payment_types FROM agent_commissions c JOIN enrollments e ON e.enrollment_id = c.enrollment_id WHERE e.effectuated_flag = 0 AND (c.commission_paid + c.bonus_paid + c.override_paid) > 0 GROUP BY c.lob, c.channel, c.agent_id, c.agency_id ORDER BY overpaid_usd DESC
- remediation: Recover the payment through the next commission statement under dual control, and reconcile the enrolment against the CMS monthly membership report to confirm the enrolment never took effect.

## Sales performance

### LEAD-QUALITY-FLOOR
- citation: Internal lead-vendor performance standard; marketing procurement policy
- requirement: A lead source must sustain a qualified-lead rate at or above the declared floor on a meaningful volume. A source below the floor is buying volume the sales force cannot convert, and the spend is recoverable under the vendor agreement.
- check: lead_quality_floor
- pillar: sales_performance
- min_leads: 30
- qualified_rate_floor: 0.40
- breach_action: fail
- headline: Lead source {lead_source} — {qualified_rate} qualified-lead rate on {leads} leads in {market} {lead_quarter} ({cost_per_qualified} USD per qualified lead, floor {floor})
- floor: 0.40
- query: SELECT t.lob, t.market, t.lead_source, t.lead_quarter, COUNT(*) AS leads, SUM(t.qualified_flag) AS qualified, ROUND(AVG(t.qualified_flag), 4) AS qualified_rate, ROUND(SUM(t.cost_allocated), 0) AS cost_usd, ROUND(SUM(t.cost_allocated) * 1.0 / NULLIF(SUM(t.qualified_flag), 0), 2) AS cost_per_qualified FROM leads t GROUP BY t.lob, t.market, t.lead_source, t.lead_quarter HAVING leads >= 30 AND qualified_rate < 0.40 ORDER BY qualified_rate ASC
- remediation: Pause the source, invoke the quality clause in the vendor agreement, reallocate the budget to sources holding the floor, and re-baseline the market's pace-to-goal for the reduced qualified-lead supply.

### LEAD-SLA-FOLLOWUP
- citation: Internal sales-operations service standard
- requirement: Outreach activity must land inside its follow-up SLA at or above the declared floor. Follow-up compliance below the floor means qualified leads are ageing out of the funnel before anyone works them.
- check: lead_followup_sla
- pillar: sales_performance
- min_activities: 200
- sla_compliance_floor: 0.50
- breach_action: warn
- headline: {lob} / {activity_type} — {sla_compliance} of {activities} outreach activities inside SLA, floor {floor}
- floor: 0.50
- query: SELECT l.lob, a.activity_type, COUNT(*) AS activities, ROUND(AVG(a.followed_up_within_sla), 4) AS sla_compliance FROM lead_activities a JOIN leads l ON l.lead_id = a.lead_id WHERE a.sla_due_date IS NOT NULL GROUP BY l.lob, a.activity_type HAVING activities >= 200 AND sla_compliance < 0.50 ORDER BY sla_compliance ASC
- remediation: Re-sequence the outreach queue so first contact is worked before re-attempts, size the required headcount against the actual attempt volume, and hold team leads to the SLA in the weekly pace review.

### CAC-CEILING
- citation: Internal acquisition-economics standard; finance delegation of authority
- requirement: Cost per effectuated enrolment must stay at or below the declared acquisition ceiling. A market above the ceiling is buying enrolments for more than they are worth over their expected life.
- check: acquisition_cost_ceiling
- pillar: sales_performance
- min_leads: 50
- cac_ceiling_usd: 100
- breach_action: warn
- headline: {lob} / {market} — {cost_per_enrollment} USD per effectuated enrolment on {leads} leads, above the {ceiling} USD ceiling
- ceiling: 100
- query: SELECT t.lob, t.market, COUNT(*) AS leads, SUM(CASE WHEN t.funnel_stage = 'Effectuated' THEN 1 ELSE 0 END) AS effectuated, ROUND(SUM(t.cost_allocated), 0) AS cost_usd, ROUND(SUM(t.cost_allocated) * 1.0 / NULLIF(SUM(CASE WHEN t.funnel_stage = 'Effectuated' THEN 1 ELSE 0 END), 0), 2) AS cost_per_enrollment FROM leads t GROUP BY t.lob, t.market HAVING leads >= 50 AND cost_per_enrollment > 100 ORDER BY cost_per_enrollment DESC
- remediation: Shift budget toward the channels and lead sources holding the ceiling, review the vendor mix in the affected market, and re-forecast the market's enrolment target against the affordable lead supply.

### RETENTION-FLOOR
- citation: Internal persistency standard; 42 CFR §422.2274(d) recovery obligation
- requirement: Twelve-month persistency must stay at or above the declared floor by channel and market. A channel below the floor is generating enrolments that do not persist, and the compensation paid on them is recoverable.
- check: retention_floor
- pillar: sales_performance
- min_enrollments: 20
- retention_floor: 0.70
- breach_action: fail
- headline: {channel} channel in {market} — {retention_rate} 12-month retention on {enrollments} enrolments ({rapid_disenroll_rate} rapid disenrolment), floor {floor} ({lob})
- floor: 0.70
- query: SELECT t.lob, t.channel, t.market, COUNT(*) AS enrollments, ROUND(AVG(t.retained_12mo_flag), 4) AS retention_rate, ROUND(AVG(t.rapid_disenroll_flag), 4) AS rapid_disenroll_rate, ROUND(AVG(t.cancel_before_effective_flag), 4) AS cancel_rate, ROUND(SUM(t.annual_premium), 0) AS premium_at_risk FROM enrollments t GROUP BY t.lob, t.channel, t.market HAVING enrollments >= 20 AND retention_rate < 0.70 ORDER BY retention_rate ASC
- remediation: Audit the channel's recent sales for misrepresentation and benefit-mismatch, verify appointment and certification currency for the agents involved, raise the outstanding recoupments, and re-weight lead allocation toward channels holding the floor.

## Action governance

### ACT-DUAL-CONTROL
- citation: Medicare Sales delegation of authority
- requirement: A write-back with an estimated impact of $10,000 or more requires two distinct approvers. Commission recovery, agent suspension, lead-source suspension, campaign pause and any compensating reversal are always dual control regardless of amount, because each is externally visible to CMS, to an agent's livelihood or to a beneficiary.
- check: action_dual_control
- financial_impact_threshold: 10000
- regulatory_severity_triggers: critical, high
- dual_control_action_types: commission_recovery, agent_suspension, lead_source_suspension, campaign_pause, enrollment_reconciliation, agent_remediation, compensating
- self_approval_allowed: false

### ACT-TRUST-GATE
- citation: Internal AI governance standard
- requirement: No Medicare Sales write-back executes below the enterprise trust gate. An action taken against an agent's compensation or a beneficiary's enrolment on a low-confidence analysis is a harm event, not a data-quality event.
- check: action_trust_gate
- execution_trust_gate: 0.85

### ACT-APPROVER-ROLES
- citation: Medicare Sales delegation of authority; 42 CFR §422.2272 oversight obligation
- requirement: Approvers must hold a sales compliance or compliance officer role. A sales, distribution or marketing analyst may propose but never approve — the person carrying the growth target does not sign off on the compliance remedy.
- check: action_approver_roles
- approver_roles: sales_compliance_officer, compliance_officer

### ACT-COMPENSATION
- citation: Internal reversal policy
- requirement: A reversal is itself a dual-control action and the original ledger entry is never edited. A commission recovery that is later walked back must cite the original entry.
- check: action_compensation
- modes: void, reinstate
- min_reason_chars: 12
