# Reference Data

## Source Documents

- 42 CFR §422.2264: Marketing and beneficiary contact requirements, including the Scope of Appointment
- 42 CFR §422.2274: Agent, broker and third-party marketing organisation requirements — compensation limits, training, testing and oversight
- 42 CFR §422.2274(b): Compensation may not exceed the fair market value CMS publishes for the plan year
- 42 CFR §422.2274(d): Compensation recovery when a beneficiary disenrolls within the first three months of enrolment
- 42 CFR §422.2272: Licensure, appointment and reporting obligations for agents and brokers
- 42 CFR §422.60: Election process and coordinated election periods
- 42 CFR §422.62: Election periods — AEP, OEP, ICEP and special election periods
- 42 CFR §422.52: Eligibility to elect an MA plan, including the Medicaid entitlement condition for a Dual Eligible Special Needs Plan
- 42 CFR §422.74: Disenrollment by the MA organisation
- CMS Medicare Communications and Marketing Guidelines: marketing, sales event and beneficiary contact rules
- CMS Complaints Tracking Module: the beneficiary complaint channel behind the CTM rate
- CMS MA/Part D Monthly Enrollment by CPSC: the external benchmark for market penetration

## External Files

Sources the platform does not hold and that arrive as files rather than as
warehouse tables. Listed here so the Data tab importer has a documented,
governed destination rather than being a one-off spreadsheet exercise.

- cms_market_enrollment: CMS monthly MA and Part D enrolment by organisation, contract, plan, state and county. Ships as demo/data/cms_market_enrollment.csv, 900 rows, imported through the Data tab. Backs market penetration and competitor benchmarking. plan_type is blank on 149 rows (16.6%), concentrated in contracts H3390, S5678 and E7712 — the Data Quality missing-value target.

## Dimension Values

- lob: Medicare Advantage, Medicaid, Commercial, ACA Exchange
- market: Midwest, Northeast, Southeast, Southwest, West
- region: Midwest, Northeast, Southeast, Southwest, West
- state: TX, NY, CA, FL, AZ, GA, MI, OH, NJ, WA, PA, IL
- channel: Broker, Direct, Telesales, DTC, Agency, Web
- lead_source: LS-BRK-01, LS-WEB-01, LS-WEB-02, LS-TELE-01, LS-TELE-02, LS-TELE-03, LS-DTC-01, LS-DTC-02, LS-AGY-01, LS-AGEIN-01
- cohort: Age-In, New-to-Medicare, Existing Member, Retention-Risk
- age_band: <65, 65-69, 70-74, 75-79, 80-84, 85+
- funnel_stage: Lead, Contacted, Application, Approved, Enrolled, Effectuated, Lost
- plan_type: MA, MAPD, PDP, D-SNP, C-SNP, Group MA, ACA
- enrollment_period: AEP, OEP, SEP, ICEP
- application_status: Submitted, Approved, Denied, Withdrawn
- enrollment_status: Effectuated, Cancelled, Disenrolled, Active
- reconciliation_status: Reconciled, Exception, Cancelled
- comm_type: Initial, Renewal, Override, Bonus
- clawback_status: Recovered, Pending, Not Recovered
- agent_type: Captive, Independent, FMO, Vendor
- cert_type: AHIP, State License, Carrier Appointment, Product Training
- cert_status: Active, Expired, Lapsed, Pending
- interaction_type: Sales Call, Service, Complaint, Grievance, CTM
- interaction_channel: Inbound, Outbound, Chat, IVR
- activity_type: Call, Email, SMS, Mail, Appointment, Follow-up
- activity_outcome: Connected, No Answer, Voicemail, Declined, Appointment Set

## Election Periods

The election-period calendar the funnel is reported against. `aep_flag` on
`leads` and `enrollment_period` on `applications` carry the real signal, so
AEP and OEP reporting is a filter rather than a derivation from dates.

- AEP: Annual Election Period, 15 October to 7 December, effective 1 January
- OEP: Medicare Advantage Open Enrollment Period, 1 January to 31 March
- ICEP: Initial Coverage Election Period, around Medicare entitlement
- SEP: Special Election Period, on a qualifying life or plan event

## Reject Codes

Not applicable to this domain. The equivalent exception vocabulary is
`applications.denial_reason`, `enrollments.cancel_reason` and
`agent_commissions.clawback_reason`, each a free-text business reason rather
than a coded standard, so no code table is declared here.
