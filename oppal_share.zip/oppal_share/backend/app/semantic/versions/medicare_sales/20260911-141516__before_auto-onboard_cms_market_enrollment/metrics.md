# Governed Metrics

Named directly from §5 of the Medicare Sales Reporting & Analytics Engineering
document, so the semantic layer speaks the business's own vocabulary.

Every metric names its own `table:`, because the metric compiler emits
single-table SQL (`SELECT <sql> FROM <table> t`) and resolves no joins. `base:`
is deliberately never one of claims / rx / members — those route to the payer
code paths.

Tables declared governed in governance.md get the LOB scope predicate injected
automatically; the alias is always `t`.

Figures quoted in definitions are measured against the loaded dataset at full
scope (3,000 leads, 1,050 applications, 944 enrolments, 1,203 commission
payments, lead quarters 2025Q4 to 2026Q4).

## Sales & portfolio performance

### effectuated_enrollments
- label: Effectuated Enrolments
- definition: Count of enrolments that effectuated in the period. The headline sales-volume KPI. 889 of 944 in the loaded book.
- formula: COUNT(enrollment_id) WHERE effectuated_flag = 1
- sql: SUM(CASE WHEN t.effectuated_flag = 1 THEN 1 ELSE 0 END)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, contract_id, agent_id, agency_id, status
- format: number
- depends: enrollments.effectuated_flag
- owner: Medicare Sales Analytics
- certified: true

### net_membership_growth
- label: Net Membership Growth
- definition: Effectuated enrolments less disenrolments and pre-effective cancellations — the net change in membership the period actually delivered.
- formula: SUM(effectuated) - SUM(disenrolled) - SUM(cancelled before effective)
- sql: SUM(CASE WHEN t.effectuated_flag = 1 THEN 1 ELSE 0 END) - SUM(CASE WHEN t.status = 'Disenrolled' THEN 1 ELSE 0 END) - SUM(t.cancel_before_effective_flag)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, contract_id, agent_id
- format: number
- depends: enrollments.effectuated_flag, enrollments.status, enrollments.cancel_before_effective_flag
- owner: Medicare Sales Analytics
- certified: true

### enrollment_premium
- label: Enrolment Premium
- definition: Annualised premium written on effectuated enrolments in the period.
- formula: SUM(annual_premium) WHERE effectuated
- sql: ROUND(SUM(CASE WHEN t.effectuated_flag = 1 THEN t.annual_premium ELSE 0 END), 0)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, contract_id, agent_id
- format: currency
- depends: enrollments.annual_premium, enrollments.effectuated_flag
- owner: Finance
- certified: true

### revenue_per_enrollment
- label: Revenue per Enrolment
- definition: Average revenue attributed to an effectuated enrolment. The sales-economics numerator.
- formula: AVG(revenue_per_enrollment) WHERE effectuated
- sql: ROUND(AVG(CASE WHEN t.effectuated_flag = 1 THEN t.revenue_per_enrollment END), 2)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, contract_id
- average: true
- format: currency
- depends: enrollments.revenue_per_enrollment
- owner: Finance
- certified: true

### sales_to_goal_pct
- label: Sales to Goal
- definition: Enrolment quota attainment. Declared on sales_targets, which carries the quota; compare against effectuated_enrollments for the numerator.
- formula: SUM(target_enrollments) as the denominator of attainment
- sql: SUM(t.target_enrollments)
- base: target
- table: sales_targets
- time_column: target_quarter
- dims: agent_id, market, channel
- format: number
- depends: sales_targets.target_enrollments
- owner: Sales & Distribution Leadership
- certified: true

### daily_sales_pace
- label: Required Daily Sales Pace
- definition: Enrolments per selling day needed to reach quota. Compared against the achieved pace to produce the pace-to-goal gap.
- formula: AVG(required_daily_pace)
- sql: ROUND(AVG(t.required_daily_pace), 2)
- base: target
- table: sales_targets
- time_column: target_quarter
- dims: agent_id, market, channel
- average: true
- format: number
- depends: sales_targets.required_daily_pace
- owner: Sales & Distribution Leadership
- certified: true

## Lead & campaign effectiveness

### qualified_lead_rate
- label: Qualified Lead Rate
- definition: Share of leads that passed qualification. 65.9% book-wide; 24.2% for lead source LS-TELE-03 in the Southwest during AEP 2026Q4 against 63.6% for its peer source in the same market and quarter.
- formula: AVG(qualified_flag)
- sql: ROUND(AVG(t.qualified_flag), 4)
- base: lead
- table: leads
- time_column: lead_quarter
- dims: market, channel, lead_source, campaign_id, cohort, state
- average: true
- format: percent
- depends: leads.qualified_flag
- owner: Marketing & Growth
- certified: true

### lead_to_contact_rate
- label: Lead-to-Contact Conversion
- definition: Share of leads that reached a first successful contact. The top-of-funnel workability measure.
- formula: AVG(first_contact_date IS NOT NULL)
- sql: ROUND(AVG(CASE WHEN t.first_contact_date IS NOT NULL THEN 1.0 ELSE 0 END), 4)
- base: lead
- table: leads
- time_column: lead_quarter
- dims: market, channel, lead_source, campaign_id, cohort
- average: true
- format: percent
- depends: leads.first_contact_date
- owner: Sales Operations
- certified: true

### lead_to_enrollment_rate
- label: Lead-to-Enrolment Conversion
- definition: Share of leads that reached the Effectuated funnel stage. The end-to-end acquisition conversion KPI.
- formula: AVG(funnel_stage = 'Effectuated')
- sql: ROUND(AVG(CASE WHEN t.funnel_stage = 'Effectuated' THEN 1.0 ELSE 0 END), 4)
- base: lead
- table: leads
- time_column: lead_quarter
- dims: market, channel, lead_source, campaign_id, cohort, state
- average: true
- format: percent
- depends: leads.funnel_stage
- owner: Marketing & Growth
- certified: true

### cost_per_qualified_lead
- label: Cost per Qualified Lead
- definition: Allocated acquisition cost divided by qualified leads. $104.32 for LS-TELE-03 in the Southwest during AEP 2026Q4 against a $38.35 prior-quarter average for the same source and market.
- formula: SUM(cost_allocated) / SUM(qualified_flag)
- sql: ROUND(SUM(t.cost_allocated) * 1.0 / NULLIF(SUM(t.qualified_flag), 0), 2)
- base: lead
- table: leads
- time_column: lead_quarter
- dims: market, channel, lead_source, campaign_id, cohort
- average: true
- format: currency
- depends: leads.cost_allocated, leads.qualified_flag
- owner: Marketing & Growth
- certified: true

### cost_per_effectuated_enrollment
- label: Cost per Effectuated Enrolment
- definition: Allocated acquisition cost divided by leads that reached effectuation. The customer-acquisition-cost KPI tested against the acquisition ceiling.
- formula: SUM(cost_allocated) / COUNT(funnel_stage = 'Effectuated')
- sql: ROUND(SUM(t.cost_allocated) * 1.0 / NULLIF(SUM(CASE WHEN t.funnel_stage = 'Effectuated' THEN 1 ELSE 0 END), 0), 2)
- base: lead
- table: leads
- time_column: lead_quarter
- dims: market, channel, lead_source, campaign_id, cohort
- average: true
- format: currency
- depends: leads.cost_allocated, leads.funnel_stage
- owner: Finance
- certified: true

### campaign_response_rate
- label: Campaign Response Rate
- definition: Responses divided by impressions delivered. Declared on campaigns, which is ungoverned reference data — campaign spend is a marketing fact, not a member fact, so it is visible at every scope by design.
- formula: SUM(responses) / SUM(impressions)
- sql: ROUND(SUM(t.responses) * 1.0 / NULLIF(SUM(t.impressions), 0), 6)
- base: campaign
- table: campaigns
- time_column: campaign_quarter
- dims: channel, lead_source, market, target_cohort
- average: true
- format: percent
- depends: campaigns.responses, campaigns.impressions
- owner: Marketing & Growth
- certified: true

### campaign_spend
- label: Campaign Spend
- definition: Marketing spend in the period. The numerator of fully loaded acquisition economics.
- formula: SUM(spend)
- sql: ROUND(SUM(t.spend), 0)
- base: campaign
- table: campaigns
- time_column: campaign_quarter
- dims: channel, lead_source, market, target_cohort
- format: currency
- depends: campaigns.spend
- owner: Marketing & Growth
- certified: true

## Agent, broker & channel performance

### agent_conversion_rate
- label: Agent & Broker Conversion Rate
- definition: Share of an agent's approved enrolments that effectuated. Book-wide 94.2%; agent AG-0027 sits at 70.7% on 41 enrolments, a leave-one-out peer z of -4.01.
- formula: AVG(effectuated_flag)
- sql: ROUND(AVG(t.effectuated_flag), 4)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: agent_id, agency_id, market, channel, plan_type
- average: true
- format: percent
- depends: enrollments.effectuated_flag
- owner: Distribution Leadership
- certified: true

### agent_persistency_rate
- label: Agent & Broker Persistency
- definition: Share of an agent's enrolments still enrolled at 12 months. The quality-of-sale measure behind compensation.
- formula: AVG(retained_12mo_flag)
- sql: ROUND(AVG(t.retained_12mo_flag), 4)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: agent_id, agency_id, market, channel, plan_type
- average: true
- format: percent
- depends: enrollments.retained_12mo_flag
- owner: Distribution Leadership
- certified: true

### channel_cost_per_enrollment
- label: Channel Cost per Enrolment
- definition: Total compensation paid divided by the payments made, by channel. The distribution-economics comparison across Broker, Direct, Telesales, DTC, Agency and Web.
- formula: SUM(commission_paid + override_paid + bonus_paid) / COUNT(commission_id)
- sql: ROUND(SUM(t.commission_paid + t.override_paid + t.bonus_paid) * 1.0 / NULLIF(COUNT(t.commission_id), 0), 2)
- base: commission
- table: agent_commissions
- time_column: comm_quarter
- dims: channel, market, agent_id, agency_id, comm_type
- average: true
- format: currency
- depends: agent_commissions.commission_paid, agent_commissions.override_paid, agent_commissions.bonus_paid
- owner: Sales Compensation
- certified: true

### commission_paid
- label: Commission Paid
- definition: Total compensation paid in the period, including overrides and bonuses.
- formula: SUM(commission_paid + override_paid + bonus_paid)
- sql: ROUND(SUM(t.commission_paid + t.override_paid + t.bonus_paid), 2)
- base: commission
- table: agent_commissions
- time_column: comm_quarter
- dims: agent_id, agency_id, market, channel, comm_type
- format: currency
- depends: agent_commissions.commission_paid
- owner: Sales Compensation
- certified: true

### clawback_exposure
- label: Unrecovered Clawback Exposure
- definition: Dollar value of compensation where recoupment is due and the status is still Not Recovered. $18,307.05 across 36 payments in the loaded book.
- formula: SUM(clawback_amount) WHERE recoupment due AND not recovered
- sql: ROUND(SUM(CASE WHEN t.recoupment_due_flag = 1 AND t.clawback_status = 'Not Recovered' THEN t.clawback_amount ELSE 0 END), 2)
- base: commission
- table: agent_commissions
- time_column: comm_quarter
- dims: agent_id, agency_id, market, channel, clawback_status
- format: currency
- depends: agent_commissions.clawback_amount, agent_commissions.recoupment_due_flag, agent_commissions.clawback_status
- owner: Sales Compensation
- certified: true

### lead_followup_compliance
- label: Lead Follow-up Compliance
- definition: Share of outreach activities that landed inside their follow-up SLA. Declared on lead_activities, which is scoped transitively through its lead.
- formula: AVG(followed_up_within_sla)
- sql: ROUND(AVG(t.followed_up_within_sla), 4)
- base: activity
- table: lead_activities
- time_column: activity_date
- dims: activity_type, outcome, agent_id
- average: true
- format: percent
- depends: lead_activities.followed_up_within_sla
- owner: Sales Operations
- certified: true

## Enrolment & retention performance

### application_approval_rate
- label: Application Approval Rate
- definition: Share of applications approved. 89.9% book-wide.
- formula: AVG(status = 'Approved')
- sql: ROUND(AVG(CASE WHEN t.status = 'Approved' THEN 1.0 ELSE 0 END), 4)
- base: application
- table: applications
- time_column: application_quarter
- dims: market, plan_type, enrollment_period, contract_id, state
- average: true
- format: percent
- depends: applications.status
- owner: Enrolment Operations
- certified: true

### approval_to_effectuation_rate
- label: Approval-to-Effectuation Conversion
- definition: Share of approved enrolments that effectuated. The ghost-enrolment detector; 94.2% book-wide.
- formula: AVG(effectuated_flag)
- sql: ROUND(AVG(t.effectuated_flag), 4)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, agent_id, contract_id
- average: true
- format: percent
- depends: enrollments.effectuated_flag
- owner: Enrolment Operations
- certified: true

### enrollment_turnaround_hours
- label: Enrolment Turnaround Hours
- definition: Mean hours from application submission to decision, against the CMS processing window.
- formula: AVG(turnaround_hours)
- sql: ROUND(AVG(t.turnaround_hours), 1)
- base: application
- table: applications
- time_column: application_quarter
- dims: market, plan_type, enrollment_period, submission_channel, contract_id
- average: true
- format: number
- depends: applications.turnaround_hours
- owner: Enrolment Operations
- certified: true

### cancellation_before_effective_rate
- label: Cancellation Before Effective Date
- definition: Share of enrolments cancelled before coverage began. 4.6% book-wide; 6.2% in the Broker channel in the Northeast.
- formula: AVG(cancel_before_effective_flag)
- sql: ROUND(AVG(t.cancel_before_effective_flag), 4)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, agent_id, agency_id
- average: true
- format: percent
- depends: enrollments.cancel_before_effective_flag
- owner: Enrolment Operations
- certified: true

### rapid_disenrollment_rate
- label: Rapid Disenrolment Rate
- definition: Share of enrolments that disenrolled within 90 days. Triggers compensation recoupment under 42 CFR §422.2274(d). 5.5% book-wide; 25.0% in the Broker channel in the Northeast.
- formula: AVG(rapid_disenroll_flag)
- sql: ROUND(AVG(t.rapid_disenroll_flag), 4)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, agent_id, agency_id, contract_id
- average: true
- format: percent
- depends: enrollments.rapid_disenroll_flag
- owner: Enrolment Operations
- certified: true

### member_retention_rate
- label: Member Retention Rate
- definition: Share of enrolments still enrolled at 12 months. The persistency KPI. 83.8% book-wide; 64.6% in the Broker channel in the Northeast.
- formula: AVG(retained_12mo_flag)
- sql: ROUND(AVG(t.retained_12mo_flag), 4)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, agent_id, agency_id, contract_id
- average: true
- format: percent
- depends: enrollments.retained_12mo_flag
- owner: Enrolment Operations
- certified: true

### enrollment_reconciliation_rate
- label: Enrolment Reconciliation Rate
- definition: Share of enrolments reconciled cleanly against CMS. The remainder are Exception or Cancelled and sit in the reconciliation queue.
- formula: AVG(reconciliation_status = 'Reconciled')
- sql: ROUND(AVG(CASE WHEN t.reconciliation_status = 'Reconciled' THEN 1.0 ELSE 0 END), 4)
- base: enrollment
- table: enrollments
- time_column: enrollment_quarter
- dims: market, channel, plan_type, contract_id, status
- average: true
- format: percent
- depends: enrollments.reconciliation_status
- owner: Enrolment Operations
- certified: true

## Simulator metrics

The four metrics the what-if simulator's delta model binds to (see
`simulation.md` → `simulator_bindings`). They are separate declarations, not
duplicates, because the simulator composes its own FROM clause and the SQL
must carry ITS alias — `c` for the cohort base, `cm` for compensation, `en`
for enrolments — whereas every governed metric above is compiled as
`FROM <table> t`. Declaring them apart keeps both compilers honest instead of
making one metric mean two different things depending on who reads it.

They are marked `certified: false`: they exist to drive a model, not to be
quoted as a reported figure. The certified equivalents above are the ones a
report cites.

### sim_lead_loss_ratio
- label: Lead Loss Ratio (simulator)
- definition: Share of leads that ended at funnel stage Lost. The simulator's ratio slot; reported in basis points. Lower is better, matching the polarity the delta engine's favourable/adverse direction assumes.
- formula: COUNT(leads at stage Lost) / COUNT(leads)
- sql: ROUND(SUM(CASE WHEN c.funnel_stage = 'Lost' THEN 1.0 ELSE 0 END) * 1.0 / NULLIF(COUNT(c.lead_id), 0), 4)
- base: simulator
- format: percent
- value_sql: CASE WHEN c.funnel_stage = 'Lost' THEN 1.0 ELSE 0 END
- depends: leads.funnel_stage
- owner: Marketing & Growth
- certified: false

### sim_acquisition_cost
- label: Allocated Acquisition Cost (simulator)
- definition: Acquisition cost allocated to the leads in the baseline audience. The simulator's first cost leg.
- formula: SUM(cost_allocated)
- sql: ROUND(SUM(c.cost_allocated), 0)
- base: simulator
- format: currency
- depends: leads.cost_allocated
- owner: Finance
- certified: false

### sim_commission_cost
- label: Compensation Cost (simulator)
- definition: Commission, override and bonus paid in the caller's scope. The simulator's second cost leg.
- formula: SUM(commission_paid + override_paid + bonus_paid)
- sql: ROUND(SUM(cm.commission_paid + cm.override_paid + cm.bonus_paid), 0)
- base: simulator
- format: currency
- depends: agent_commissions.commission_paid
- owner: Sales Compensation
- certified: false

### sim_cancellation_count
- label: Cancellations Before Effective Date (simulator)
- definition: Enrolments cancelled before coverage began. The simulator's volume slot; the burden formula converts the count into minutes of enrolment-operations rework.
- formula: COUNT(cancel_before_effective_flag = 1)
- sql: SUM(CASE WHEN en.cancel_before_effective_flag = 1 THEN 1.0 ELSE 0 END)
- base: simulator
- format: number
- value_sql: CASE WHEN en.cancel_before_effective_flag = 1 THEN 1.0 ELSE 0 END
- depends: enrollments.cancel_before_effective_flag
- owner: Enrolment Operations
- certified: false

## Beneficiary experience

### ctm_complaint_rate
- label: CTM Complaint Rate
- definition: Share of customer interactions logged as a CMS Complaints Tracking Module contact. The beneficiary-harm early-warning signal.
- formula: AVG(ctm_flag)
- sql: ROUND(AVG(t.ctm_flag), 4)
- base: interaction
- table: interactions
- time_column: interaction_quarter
- dims: market, channel, interaction_type, complaint_category
- average: true
- format: percent
- depends: interactions.ctm_flag
- owner: Sales Compliance
- certified: true
