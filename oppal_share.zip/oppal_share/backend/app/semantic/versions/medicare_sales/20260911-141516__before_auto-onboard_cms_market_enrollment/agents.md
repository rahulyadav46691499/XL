# Departmental Agent Swarm

Eight personas, one per department in the reporting document's §6 persona table.
None has a Python class: each declares its detector as SQL plus a finding
template, executed by the base `DepartmentAgent`. A persona with a `case_type`
also opens a de-duplicated case, which is what populates the Cases tab without
an engine change.

Every persona declares `required_permission`. An agent the code has never heard
of otherwise resolves to the most restrictive default and is withheld from
every analyst who needs it — the declaration is what makes the roster usable,
and `security/agent_acl.py` still refuses any declaration that would widen a
permission the code pins.

Every detector query selects `lob`, so a case is stamped with the scope of the
incident rather than the scope of whoever ran the swarm.

`prescriptive_action` is not optional. It is the only component that calls
`case_store.upsert_case()`, so a roster without it produces findings that never
become cases and a permanently empty Cases tab.

## sentry
- department: Sales Command
- role: Triage the question and decide which departmental agents to activate.
- triggers: *
- pillars: all
- tools: anomaly_scan, metric_trend
- detector: triage
- priority: 0
- always_on: true
- model_tier: cheap
- required_permission: agent_invoke_triage

## lead_quality
- department: Marketing & Growth
- role: Detect lead sources whose qualified-lead rate has collapsed against the floor, and price the wasted acquisition spend.
- triggers: lead quality, lead source, qualified lead, qualification, vendor, lead vendor, campaign, marketing, aep, acquisition, cost per lead, lead dumping, lead volume
- pillars: sales_performance
- tools: metric_trend, anomaly_scan
- detector: brain_query
- priority: 10
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: lead_quality_collapse
- severity_column: cost_per_qualified
- severity_threshold: 80
- impact_column: cost_usd
- min_impact: 500
- headline: Lead source {lead_source} — {qualified_rate} qualified-lead rate in {market} {lead_quarter}, {cost_per_qualified} USD per qualified lead against a {peer_cost_per_qualified} USD peer rate
- detail: {lead_source} delivered {leads} leads into {market} in {lead_quarter} and only {qualified} qualified ({qualified_rate}). Cost per qualified lead is {cost_per_qualified} USD against {peer_cost_per_qualified} USD across every other source in the same market and quarter, on {cost_usd} USD of allocated spend. Only {effectuated} of these leads reached effectuation. Pause the source, invoke the quality clause in the vendor agreement and reallocate the budget to sources holding the 0.40 floor.
- case_type: LeadQualityCase
- case_subject_column: lead_source
- case_pattern: lead_quality_collapse
- query: SELECT t.lob, t.market, t.lead_source, t.lead_quarter, COUNT(*) AS leads, SUM(t.qualified_flag) AS qualified, ROUND(AVG(t.qualified_flag), 4) AS qualified_rate, SUM(CASE WHEN t.funnel_stage = 'Effectuated' THEN 1 ELSE 0 END) AS effectuated, ROUND(SUM(t.cost_allocated), 0) AS cost_usd, ROUND(SUM(t.cost_allocated) * 1.0 / NULLIF(SUM(t.qualified_flag), 0), 2) AS cost_per_qualified, (SELECT ROUND(SUM(p.cost_allocated) * 1.0 / NULLIF(SUM(p.qualified_flag), 0), 2) FROM leads p WHERE p.market = t.market AND p.lead_quarter = t.lead_quarter AND p.lead_source <> t.lead_source) AS peer_cost_per_qualified FROM leads t GROUP BY t.lob, t.market, t.lead_source, t.lead_quarter HAVING leads >= 30 AND qualified_rate < 0.40 ORDER BY cost_usd DESC

## funnel_ops
- department: Sales Operations
- role: Surface funnel fallout — qualified leads that never left the top of the funnel — and the follow-up SLA misses behind them.
- triggers: funnel, fallout, conversion, lead ageing, lead aging, backlog, follow up, followup, sla, first contact, stalled, contact rate, pipeline
- pillars: sales_performance
- tools: metric_trend, anomaly_scan
- detector: brain_query
- priority: 20
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: funnel_fallout
- severity_column: stall_rate
- severity_threshold: 0.45
- impact_column: stalled_cost_usd
- min_impact: 1000
- headline: {market} — {stalled} of {qualified} qualified leads never left the top of the funnel ({stall_rate}), {stalled_cost_usd} USD of spend stranded ({lob})
- detail: {market} qualified {qualified} leads and {stalled} of them are still at funnel stage Lead ({stall_rate}), stranding {stalled_cost_usd} USD of allocated acquisition spend. Mean days to first contact is {mean_days_to_contact} across the market. Re-sequence the outreach queue so first contact is worked before re-attempts, and size the required headcount against the actual attempt volume rather than the lead count.
- case_type: FunnelCase
- case_subject_column: market
- case_pattern: funnel_fallout
- query: SELECT t.lob, t.market, SUM(t.qualified_flag) AS qualified, SUM(CASE WHEN t.qualified_flag = 1 AND t.funnel_stage = 'Lead' THEN 1 ELSE 0 END) AS stalled, ROUND(SUM(CASE WHEN t.qualified_flag = 1 AND t.funnel_stage = 'Lead' THEN 1.0 ELSE 0 END) / NULLIF(SUM(t.qualified_flag), 0), 4) AS stall_rate, ROUND(SUM(CASE WHEN t.qualified_flag = 1 AND t.funnel_stage = 'Lead' THEN t.cost_allocated ELSE 0 END), 0) AS stalled_cost_usd, ROUND(AVG(t.days_to_first_contact), 1) AS mean_days_to_contact FROM leads t GROUP BY t.lob, t.market HAVING qualified >= 40 AND stall_rate > 0.30 ORDER BY stalled_cost_usd DESC

## agent_performance
- department: Distribution
- role: Identify agents and brokers whose effectuation or twelve-month persistency is a peer outlier against the book.
- triggers: agent, broker, agent performance, broker performance, producer, effectuation, conversion rate, persistency, retention, outlier, scorecard, distribution, agency, fmo
- pillars: fwa
- tools: metric_trend, anomaly_scan
- detector: brain_query
- priority: 30
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: agent_effectuation_outlier
- severity_column: shortfall
- severity_threshold: 0.15
- impact_column: premium_at_risk
- min_impact: 1000
- headline: Agent {agent_id} — {effectuation_rate} effectuation and {retention_rate} persistency on {enrollments} enrolments against a {book_rate} book rate ({lob})
- detail: Agent {agent_id} of agency {agency_id} effectuated {effectuated} of {enrollments} approved enrolments ({effectuation_rate}) against a book rate of {book_rate}, a shortfall of {shortfall}. Twelve-month persistency is {retention_rate}. {premium_at_risk} USD of annualised premium sits behind the enrolments that did not effectuate. Sample the non-effectuated applications for beneficiary contact and confirm each was genuinely requested before treating this as a servicing problem.
- case_type: AgentCase
- case_subject_column: agent_id
- case_pattern: agent_effectuation_outlier
- query: SELECT t.lob, t.agent_id, t.agency_id, COUNT(*) AS enrollments, SUM(t.effectuated_flag) AS effectuated, ROUND(AVG(t.effectuated_flag), 4) AS effectuation_rate, ROUND(AVG(t.retained_12mo_flag), 4) AS retention_rate, (SELECT ROUND(AVG(b.effectuated_flag), 4) FROM enrollments b) AS book_rate, ROUND((SELECT AVG(b.effectuated_flag) FROM enrollments b) - AVG(t.effectuated_flag), 4) AS shortfall, ROUND(SUM(CASE WHEN t.effectuated_flag = 0 THEN t.annual_premium ELSE 0 END), 0) AS premium_at_risk FROM enrollments t GROUP BY t.lob, t.agent_id, t.agency_id HAVING enrollments >= 15 AND effectuation_rate < 0.85 ORDER BY shortfall DESC

## enrollment_ops
- department: Enrolment Operations
- role: Detect enrolment cohorts failing to effectuate, cancelling before the effective date, or sitting unreconciled against CMS.
- triggers: enrolment, enrollment, effectuation, cancellation, cancel, reconciliation, exception, disenrolment, disenrollment, rapid disenrolment, turnaround, application status, retention floor, channel retention
- pillars: regulatory
- tools: metric_trend, policy_check
- detector: brain_query
- priority: 40
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: retention_leakage
- severity_column: rapid_disenroll_rate
- severity_threshold: 0.20
- impact_column: premium_at_risk
- min_impact: 2000
- headline: {channel} channel in {market} — {retention_rate} 12-month retention, {rapid_disenroll_rate} rapid disenrolment on {enrollments} enrolments ({lob})
- detail: The {channel} channel in {market} retained {retention_rate} of {enrollments} enrolments at twelve months, against a book rate of {book_retention}. Rapid disenrolment is {rapid_disenroll_rate} and cancellation before the effective date {cancel_rate}, with {reconciliation_exceptions} enrolment(s) still unreconciled. {premium_at_risk} USD of annualised premium is attached to the enrolments that did not persist. Audit the channel's recent sales for benefit mismatch and misrepresentation, and raise the outstanding recoupments under 42 CFR 422.2274(d).
- case_type: EnrollmentCase
- case_subject_column: channel
- case_pattern: retention_leakage
- query: SELECT t.lob, t.channel, t.market, COUNT(*) AS enrollments, ROUND(AVG(t.retained_12mo_flag), 4) AS retention_rate, ROUND(AVG(t.rapid_disenroll_flag), 4) AS rapid_disenroll_rate, ROUND(AVG(t.cancel_before_effective_flag), 4) AS cancel_rate, SUM(CASE WHEN t.reconciliation_status = 'Exception' THEN 1 ELSE 0 END) AS reconciliation_exceptions, ROUND(SUM(CASE WHEN t.retained_12mo_flag = 0 THEN t.annual_premium ELSE 0 END), 0) AS premium_at_risk, (SELECT ROUND(AVG(b.retained_12mo_flag), 4) FROM enrollments b) AS book_retention FROM enrollments t GROUP BY t.lob, t.channel, t.market HAVING enrollments >= 20 AND retention_rate < 0.70 ORDER BY premium_at_risk DESC

## compensation_siu
- department: Finance & SIU
- role: Find compensation paid against enrolments that never effectuated, payments above the CMS fair-market-value cap, and clawbacks never recovered.
- triggers: commission, compensation, overpayment, clawback, recoupment, fmv, fair market value, cap, bonus, override, siu, leakage, incentive, agent pay, broker pay
- pillars: fwa
- tools: policy_check, metric_trend
- detector: brain_query
- priority: 25
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_fwa
- finding_kind: compensation_overpayment
- severity_column: overpaid_usd
- severity_threshold: 2000
- impact_column: overpaid_usd
- min_impact: 250
- headline: Agent {agent_id} — {overpaid_usd} USD paid on {payments} enrolment(s) that never effectuated ({lob})
- detail: Agent {agent_id} of agency {agency_id} holds {overpaid_usd} USD across {payments} payment(s) of type {payment_types} against enrolments that never effectuated, plus {unrecovered_clawback_usd} USD of clawback still at status Not Recovered. 42 CFR 422.2274(e) permits no compensation on an enrolment that did not take effect, so the full amount is recoverable. Recover through the next commission statement under dual control and reconcile against the CMS monthly membership report.
- case_type: CompensationCase
- case_subject_column: agent_id
- case_pattern: compensation_overpayment
- query: SELECT c.lob, c.agent_id, c.agency_id, COUNT(*) AS payments, ROUND(SUM(c.commission_paid + c.bonus_paid + c.override_paid), 2) AS overpaid_usd, GROUP_CONCAT(DISTINCT c.comm_type) AS payment_types, (SELECT ROUND(COALESCE(SUM(k.clawback_amount), 0), 2) FROM agent_commissions k WHERE k.agent_id = c.agent_id AND k.recoupment_due_flag = 1 AND k.clawback_status = 'Not Recovered') AS unrecovered_clawback_usd FROM agent_commissions c JOIN enrollments e ON e.enrollment_id = c.enrollment_id WHERE e.effectuated_flag = 0 AND (c.commission_paid + c.bonus_paid + c.override_paid) > 0 GROUP BY c.lob, c.agent_id, c.agency_id ORDER BY overpaid_usd DESC

## sales_compliance
- department: Compliance
- role: Test marketing and licensing conduct — applications written on a lapsed AHIP or state licence, which is the breach CMS audits first.
- triggers: compliance, certification, cert, ahip, licence, license, appointment, soa, scope of appointment, marketing, ctm, complaint, grievance, audit, regulatory, 422.2274
- pillars: regulatory
- tools: policy_check
- detector: brain_query
- priority: 15
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_compliance
- finding_kind: certification_lapse
- severity: critical
- impact_column: premium_written
- min_impact: 0
- min_applications: 3
- headline: Agent {agent_id} — {applications} application(s) written after the {cert_type} expired on {expiry_date} ({lob}, {market})
- detail: Agent {agent_id} wrote {applications} application(s) between {first_application} and {last_application}, after their {cert_type} expired on {expiry_date}. 42 CFR 422.2274(b) requires a current certification, a valid state licence and an active carrier appointment on the date an application is written, and 42 CFR 422.2272 makes the plan responsible for verifying it. {premium_written} USD of annualised premium was written in the affected window. Suspend the agent from new business until the credential is reinstated, re-verify every affected application and hold commission pending review.
- case_type: CertificationCase
- case_subject_column: agent_id
- case_pattern: certification_lapse
- query: SELECT a.lob, a.market, a.agent_id, c.cert_type, c.expiry_date, COUNT(DISTINCT a.application_id) AS applications, MIN(a.application_date) AS first_application, MAX(a.application_date) AS last_application, ROUND(COALESCE(SUM(DISTINCT e.annual_premium), 0), 0) AS premium_written FROM applications a JOIN agent_certifications c ON c.agent_id = a.agent_id LEFT JOIN enrollments e ON e.application_id = a.application_id WHERE c.cert_type IN ('AHIP', 'State License') AND c.expiry_date IS NOT NULL AND c.expiry_date < a.application_date GROUP BY a.lob, a.market, a.agent_id, c.cert_type, c.expiry_date HAVING applications >= 3 ORDER BY applications DESC

## prescriptive_action
- department: Sales Operations
- role: Convert qualifying findings into persistent, de-duplicated cases and propose the follow-up action. Approval and write-back stay human-in-the-loop.
- triggers: *
- pillars: all
- tools: propose_action
- detector: propose_actions
- priority: 90
- always_on: true
- model_tier: writeback
- required_permission: agent_invoke_prescriptive

## Swarm Settings

- max_active_agents: 4
- min_active_agents: 1
- trust_gate: 0.85
- case_creation_min_trust: 0.60
