# Entities, Columns & Joins

Eleven tables, one per grain, each earning its place by backing a governed
metric, a policy rule or an agent detector. They are loaded verbatim from the
supplied dataset by `demo/data/make_medicare_sales_dataset.py`.

Every governed metric compiles to single-table SQL (`SELECT ... FROM <table> t`),
so each metric names its own table and no curation layer is needed — the
denormalised funnel columns (`lob`, `market`, `state`, `county`, `channel`,
`contract_id`, `plan_id`) are carried down from parent to child in the dataset
itself and cannot disagree.

A twelfth table, `cms_market_enrollment`, is the external CMS monthly enrolment
file. It is NOT part of the loaded warehouse: it arrives through the Data tab
importer (see reference.md → External Files) and is catalogued as `imported`
like any other onboarded source.

## Tables

### leads
Top of the funnel: one prospect. Carries the acquisition attributes (campaign,
lead source, channel, vendor), the qualification decision and score, the AEP
flag, the customer cohort, the assigned agent, first-contact timing and the
funnel stage reached. 3,000 rows.

### lead_activities
One outreach or disposition event against a lead — call, email, SMS, mail,
appointment or follow-up — with attempt number, outcome, duration and whether
the follow-up landed inside its SLA. The lead-follow-up compliance grain.
10,339 rows.

### applications
One MA / MAPD / PDP / D-SNP / C-SNP application. Carries the enrolment period
(AEP, OEP, SEP, ICEP), the Scope of Appointment evidence, the submission
channel, the decision, the turnaround in hours and any denial reason. 1,050 rows.

### enrollments
One approved enrolment and its downstream outcome: effectuation, cancellation
before the effective date, disenrolment timing, rapid-disenrolment flag,
12-month retention, premium and reconciliation status. The revenue grain.
944 rows.

### agent_commissions
One compensation payment: initial, renewal, override or bonus, with the CMS
fair-market-value cap that applied, the recoupment flag and the clawback
amount, reason and status. 1,203 rows.

### interactions
Call-centre and service activity, including complaints, grievances and CTM
(Complaints Tracking Module) contacts, with resolution timing and escalation.
800 rows.

### sales_targets
Quota and goal plan: target enrolments, target premium, target retention rate,
selling days, required daily pace and acquisition budget per agent per quarter.
240 rows.

### sales_agents
The agent and broker directory: NPN, agency, agent type (Captive, Independent,
FMO, Vendor), channel, market, sales team, hire and termination dates, status
and productive hours. Reference data, legitimately cross-LOB. 60 rows.

### agent_certifications
AHIP, state licence, carrier appointment and product training, with completion,
effective and expiry dates, status and continuing-education credits. Drives the
Regulatory pillar. 180 rows.

### campaigns
Marketing campaigns and spend: channel, vendor, lead source, target cohort,
spend, impressions, responses, leads generated and attribution model. 12 rows.

### plan_benefit_packages
Contract / plan / PBP reference: plan year, plan name, plan type, Star rating,
premium, MOOP, Part D inclusion, SNP type and service-area states. 24 rows.

## Columns

- leads.lead_id: Lead identifier, LD-nnnnnn. Primary key of the funnel.
- leads.lob: Line of business. The governed scope column.
- leads.market: Sales market — Midwest, Northeast, Southeast, Southwest, West.
- leads.state: Two-letter state of the prospect.
- leads.county: County of the prospect, for CMS county-level benchmarking.
- leads.campaign_id: Marketing campaign that sourced the lead.
- leads.lead_source: Vendor or channel lead source code, e.g. LS-TELE-03. The lead-quality unit of analysis.
- leads.channel: Distribution channel — Broker, Direct, Telesales, DTC, Agency, Web.
- leads.vendor_id: Lead vendor behind the source, where the source is purchased.
- leads.lead_created_date: Date the lead entered the funnel.
- leads.lead_quarter: Lead creation quarter, e.g. 2026Q4. The acquisition time axis.
- leads.aep_flag: 1 = created during the Annual Election Period.
- leads.cohort: Customer cohort — Age-In, New-to-Medicare, Existing Member, Retention-Risk.
- leads.age_band: Age band of the prospect.
- leads.dual_eligible: 1 = entitled to Medicaid. The precondition for D-SNP enrolment.
- leads.lis_eligible: 1 = eligible for the Part D Low Income Subsidy.
- leads.qualified_flag: 1 = the lead passed qualification. Numerator of qualified-lead rate.
- leads.qualification_score: Model qualification score, 0-1. Tested against the auto-qualify gate.
- leads.assigned_agent_id: Agent the lead was routed to.
- leads.first_contact_date: Date of first successful contact, blank if never contacted.
- leads.days_to_first_contact: Days from creation to first contact. The SLA measure.
- leads.funnel_stage: Stage reached — Lead, Contacted, Application, Approved, Enrolled, Effectuated, Lost.
- leads.disposition: Working disposition of the lead.
- leads.lost_reason: Why a Lost lead was lost. Blank on 18.7% of Lost leads — the Data Quality scan target.
- leads.duplicate_flag: 1 = identified as a duplicate of another lead.
- leads.cost_allocated: Acquisition cost attributed to the lead. Denominator of cost per qualified lead.
- lead_activities.activity_id: Activity identifier.
- lead_activities.lead_id: Lead the activity is against. The transitive scope key.
- lead_activities.activity_type: Call, Email, SMS, Mail, Appointment or Follow-up.
- lead_activities.attempt_number: Sequential outreach attempt against the lead.
- lead_activities.outcome: Connected, No Answer, Voicemail, Declined or Appointment Set.
- lead_activities.sla_due_date: Date the follow-up was due.
- lead_activities.followed_up_within_sla: 1 = the follow-up landed inside the SLA.
- applications.application_id: Application identifier, AP-nnnnn.
- applications.lead_id: Lead the application came from.
- applications.agent_id: Writing agent or broker.
- applications.contract_id: CMS contract number, e.g. H2201.
- applications.plan_id: CMS plan identifier under the contract.
- applications.pbp_id: Plan Benefit Package identifier.
- applications.plan_type: MA, MAPD, PDP, D-SNP, C-SNP, Group MA or ACA.
- applications.application_date: Date the application was submitted. The date certification currency is tested against.
- applications.application_quarter: Application quarter. The enrolment-operations time axis.
- applications.enrollment_period: AEP, OEP, SEP or ICEP.
- applications.submission_channel: How the application reached the plan.
- applications.soa_on_file: 1 = a Scope of Appointment is on file. 42 CFR §422.2264.
- applications.soa_signed_date: Date the Scope of Appointment was signed.
- applications.appointment_date: Date of the sales appointment. Must be at least 48h after the SOA signature.
- applications.status: Submitted, Approved, Denied or Withdrawn.
- applications.decision_date: Date the plan decided.
- applications.turnaround_hours: Hours from submission to decision. The processing-window measure.
- applications.denial_reason: Why an application was denied.
- applications.verification_call_completed: 1 = the outbound verification call was completed.
- enrollments.enrollment_id: Enrolment identifier, EN-nnnnn.
- enrollments.application_id: Application the enrolment came from.
- enrollments.agent_id: Agent credited with the enrolment.
- enrollments.agency_id: Agency or FMO the agent sells under.
- enrollments.channel: Distribution channel that produced the enrolment.
- enrollments.effective_date: Coverage effective date.
- enrollments.enrollment_quarter: Enrolment quarter. The sales-volume time axis.
- enrollments.effectuated_flag: 1 = the enrolment effectuated. Numerator of approval-to-effectuation.
- enrollments.effectuation_date: Date the enrolment effectuated.
- enrollments.cancel_before_effective_flag: 1 = cancelled before the effective date.
- enrollments.cancel_reason: Why the enrolment was cancelled.
- enrollments.disenroll_date: Date of disenrolment, blank if still enrolled.
- enrollments.disenroll_days: Days from effective date to disenrolment.
- enrollments.rapid_disenroll_flag: 1 = disenrolled within 90 days. Triggers commission recoupment under 42 CFR §422.2274(d).
- enrollments.status: Effectuated, Cancelled, Disenrolled or Active.
- enrollments.retained_12mo_flag: 1 = still enrolled at 12 months. The persistency numerator.
- enrollments.annual_premium: Annualised premium on the enrolment.
- enrollments.monthly_premium: Monthly premium on the enrolment.
- enrollments.revenue_per_enrollment: Revenue attributed to the enrolment.
- enrollments.reconciliation_status: Reconciled, Exception or Cancelled — the CMS reconciliation outcome.
- agent_commissions.commission_id: Commission payment identifier, CB-nnnnn.
- agent_commissions.enrollment_id: Enrolment the payment is against.
- agent_commissions.comm_quarter: Payment quarter. The compensation time axis.
- agent_commissions.comm_type: Initial, Renewal, Override or Bonus.
- agent_commissions.commission_paid: Commission paid on the enrolment.
- agent_commissions.fmv_cap: The CMS fair-market-value cap that applied for the plan year.
- agent_commissions.override_paid: Override paid to the upline agency or FMO.
- agent_commissions.bonus_paid: Bonus paid on the enrolment.
- agent_commissions.recoupment_due_flag: 1 = recoupment is due, normally on rapid disenrolment.
- agent_commissions.clawback_amount: Dollar value subject to clawback.
- agent_commissions.clawback_reason: Why the clawback arose.
- agent_commissions.clawback_status: Recovered, Pending or Not Recovered. The leakage measure.
- interactions.interaction_id: Interaction identifier.
- interactions.interaction_quarter: Interaction quarter.
- interactions.channel: Inbound, Outbound, Chat or IVR.
- interactions.interaction_type: Sales Call, Service, Complaint, Grievance or CTM.
- interactions.complaint_category: Category of the complaint or grievance.
- interactions.ctm_flag: 1 = a CMS Complaints Tracking Module contact.
- interactions.resolved_flag: 1 = the interaction was resolved.
- interactions.resolution_hours: Hours to resolution.
- interactions.escalated_flag: 1 = the interaction was escalated.
- sales_targets.target_quarter: Quarter the quota applies to.
- sales_targets.target_enrollments: Enrolment quota for the agent-quarter.
- sales_targets.target_premium: Premium quota for the agent-quarter.
- sales_targets.target_retention_rate: Retention rate the agent is held to.
- sales_targets.selling_days: Selling days available in the quarter.
- sales_targets.required_daily_pace: Enrolments per selling day needed to hit quota.
- sales_targets.acquisition_budget: Acquisition budget for the agent-quarter. The CAC ceiling denominator.
- sales_agents.agent_id: Agent identifier, AG-nnnn.
- sales_agents.agent_name: Agent or broker name.
- sales_agents.npn: National Producer Number.
- sales_agents.agent_type: Captive, Independent, FMO or Vendor.
- sales_agents.sales_team: Sales team the agent belongs to.
- sales_agents.status: Active, Terminated or Suspended.
- sales_agents.productive_hours_quarter: Productive selling hours in the quarter. Denominator of sales per productive hour.
- agent_certifications.cert_id: Certification record identifier.
- agent_certifications.cert_type: AHIP, State License, Carrier Appointment or Product Training.
- agent_certifications.plan_year: Plan year the certification covers.
- agent_certifications.completion_date: Date the certification was completed.
- agent_certifications.effective_date: Date the certification became effective.
- agent_certifications.expiry_date: Date the certification expires. Compared against application_date.
- agent_certifications.status: Active, Expired, Lapsed or Pending.
- agent_certifications.carrier_appointed: 1 = appointed by the carrier.
- agent_certifications.ce_credits_completed: Continuing-education credits completed.
- agent_certifications.ce_credits_required: Continuing-education credits required.
- campaigns.campaign_id: Campaign identifier.
- campaigns.campaign_name: Campaign name.
- campaigns.lead_source: Lead source code the campaign feeds.
- campaigns.campaign_quarter: Campaign quarter.
- campaigns.target_cohort: Cohort the campaign targets.
- campaigns.spend: Campaign spend. Numerator of cost per qualified lead.
- campaigns.impressions: Impressions delivered.
- campaigns.responses: Responses received. Numerator of campaign response rate.
- campaigns.leads_generated: Leads the campaign generated.
- campaigns.attribution_model: Attribution model applied to the campaign.
- plan_benefit_packages.pbp_id: Plan Benefit Package identifier. Primary key.
- plan_benefit_packages.plan_name: Marketed plan name.
- plan_benefit_packages.star_rating: CMS Star rating for the plan year.
- plan_benefit_packages.premium: Member premium for the package.
- plan_benefit_packages.moop: Maximum out-of-pocket for the package.
- plan_benefit_packages.part_d_included: 1 = Part D is included.
- plan_benefit_packages.snp_type: Special Needs Plan type, where applicable.
- plan_benefit_packages.service_area_states: States in the service area.

## Joins

The funnel spine plus its reference dimensions. Every one of these resolves
with zero orphans, asserted by the dataset loader's self-check.

- lead_activities.lead_id = leads.lead_id
- applications.lead_id = leads.lead_id
- enrollments.application_id = applications.application_id
- agent_commissions.enrollment_id = enrollments.enrollment_id
- applications.agent_id = sales_agents.agent_id
- enrollments.agent_id = sales_agents.agent_id
- agent_certifications.agent_id = sales_agents.agent_id
- leads.campaign_id = campaigns.campaign_id
- leads.assigned_agent_id = sales_agents.agent_id
- enrollments.pbp_id = plan_benefit_packages.pbp_id
- interactions.lead_id = leads.lead_id
- sales_targets.agent_id = sales_agents.agent_id

## Dimensions (leads)

- market: leads.market
- state: leads.state
- channel: leads.channel
- lead_source: leads.lead_source
- campaign_id: leads.campaign_id
- cohort: leads.cohort
- age_band: leads.age_band
- funnel_stage: leads.funnel_stage
- lead_quarter: leads.lead_quarter

## Dimensions (applications)

- market: applications.market
- state: applications.state
- plan_type: applications.plan_type
- contract_id: applications.contract_id
- enrollment_period: applications.enrollment_period
- status: applications.status
- application_quarter: applications.application_quarter

## Dimensions (enrollments)

- market: enrollments.market
- state: enrollments.state
- channel: enrollments.channel
- plan_type: enrollments.plan_type
- contract_id: enrollments.contract_id
- agent_id: enrollments.agent_id
- agency_id: enrollments.agency_id
- status: enrollments.status
- enrollment_quarter: enrollments.enrollment_quarter

## Dimensions (agent_commissions)

- agent_id: agent_commissions.agent_id
- agency_id: agent_commissions.agency_id
- market: agent_commissions.market
- channel: agent_commissions.channel
- comm_type: agent_commissions.comm_type
- clawback_status: agent_commissions.clawback_status
- comm_quarter: agent_commissions.comm_quarter

## Dimensions (interactions)

- market: interactions.market
- channel: interactions.channel
- interaction_type: interactions.interaction_type
- complaint_category: interactions.complaint_category
- interaction_quarter: interactions.interaction_quarter

## Dimensions (sales_targets)

- agent_id: sales_targets.agent_id
- market: sales_targets.market
- channel: sales_targets.channel
- target_quarter: sales_targets.target_quarter

## Analysis Dimensions (leads)

- market, channel, lead_source, cohort, funnel_stage, state

## Analysis Dimensions (applications)

- market, plan_type, enrollment_period, status, contract_id

## Analysis Dimensions (enrollments)

- market, channel, plan_type, agent_id, status, contract_id

## Analysis Dimensions (agent_commissions)

- agent_id, market, channel, comm_type, clawback_status

## Analysis Dimensions (interactions)

- market, channel, interaction_type, complaint_category

## Cohort Base

The base table every audience predicate is compiled against, plus the
domain-neutral facts the Audiences tab profiles. Declaring this section is what
makes the tab work off-payer: without it, `analytics/cohort_insights` falls back
to its payer strings (`FROM claims c JOIN members m`, a severity/RAF/HEDIS stat
set) and an audience defined on `leads` produces no profile at all.

Only quantities this domain genuinely has are declared. There is deliberately
no mapping of, say, `duplicate_flag` onto the payer's "fraud referral rate"
slot — a duplicate lead is a data-integrity signal, not a fraud referral, and
reporting it under a fraud label would be an overclaim.

- from: FROM leads c
- time_column: lead_quarter
- count_label: leads
- measure_sql: ROUND(SUM(c.cost_allocated), 0)
- measure_label: allocated acquisition cost
- lift_dims: lob, market, channel, lead_source, funnel_stage, cohort

## Cohort Fields

Audience predicates, all resolving against `leads` — the single base table
declared above. Every acquisition, qualification and funnel-stage population is
expressible from here.

Each value is the column as the compiled predicate must SPELL it — the base
table's ALIAS, `c`, not the table name. A predicate is a single string dropped
into `SELECT ... FROM leads c WHERE <predicate>`, and `leads.market` does not
resolve once the table carries an alias. This matches the payer pack, which
declares `c.lob` and `m.raf_score` for the same reason.

`region` is declared as a second name for the market column. The shared
rule-based cohort parser recognises `lob` and `region` by name when it reads
plain English, so declaring the alias is what lets "Southwest leads" parse
without a domain-specific parser. `market` is the domain's own term and both
resolve to the same column.

`lob` is declared first and deliberately. It is the scope column, and the
Simulator refuses a baseline whose parsed filters name a line of business
outside the caller's scope — a check that can only fire if `lob` is an
expressible cohort field. Omit it and a cross-book baseline is silently
accepted and merely returns nothing.

- lob: c.lob
- market: c.market
- region: c.market
- state: c.state
- channel: c.channel
- lead_source: c.lead_source
- campaign_id: c.campaign_id
- cohort: c.cohort
- age_band: c.age_band
- funnel_stage: c.funnel_stage
- qualified_flag: c.qualified_flag
- qualification_score: c.qualification_score
- dual_eligible: c.dual_eligible
- lis_eligible: c.lis_eligible
- aep_flag: c.aep_flag
- duplicate_flag: c.duplicate_flag
- assigned_agent_id: c.assigned_agent_id
