# CMS Policy Rulebook (Clinical Policy Agent)

### MLR-85
- citation: 42 CFR §422.2410
- requirement: MA Medical Loss Ratio >= 85%
- check: mlr_floor
- metric: mlr
- threshold: 0.85
- applies_to: Medicare Advantage
- remediation: File MLR remittance analysis; review benefit richness and premium adequacy for the contract.

### CDAG-PA-75
- citation: CMS Program Audit Protocol (CDAG), Universe Table 1; 42 CFR §423.568(b)
- requirement: Every reject 75 (PA required) generates a coverage determination within 72h; spikes require formulary-change impact analysis
- check: reject_spike
- metric: pbm_reject_rate
- code: 75
- multiplier: 2
- min_count: 50
- remediation: Reconcile code-75 universe against coverage-determination log; validate member notices for the 2026-04-01 formulary change (GLP-1 tier move, Express Scripts NPF 2026 v2 §4.2).

### CDAG-REJ-7076
- citation: CMS Program Audit Protocol (CDAG), Universe Table 2
- requirement: Non-formulary (70) and plan-limit (76) rejects require transition-fill review for new enrollees
- check: reject_volume_warning
- metric: pbm_reject_rate
- codes: 70, 76
- warn_above: 200
- remediation: Sample transition-fill compliance for affected members.

### ODAG-U1
- citation: 42 CFR §422.568
- requirement: Standard organization determinations within 14 days; denial universe complete per quarter
- check: universe_completeness
- metric: denial_rate
- min_quarters: 8
- remediation: Backfill missing quarters before audit submission.

### MCD-QS-01
- citation: 42 CFR §438.330
- requirement: Medicaid quality strategy — documented HEDIS gap-closure program
- check: medicaid_gap_rate
- metric: hedis_gap_rate
- threshold: 0.45
- remediation: Prioritize outreach for high-RAF members with gaps (use the Audience Builder risk pools).

## Regulatory Reporting Compliance (mid-market pillar boilerplate)

### CDAG-TAT-568
- citation: 42 CFR §423.568(b)
- requirement: Standard Part D coverage determinations decided and notified within 72 hours (expedited within 24 hours); every case appears in the CDAG universe with received/decision timestamps.
- check: determination_timeliness
- pillar: regulatory
- universe: CDAG_CD
- standard_hours: 72
- expedited_hours: 24
- breach_action: fail
- remediation: Generate the CDAG_CD universe, compute timeliness_hours per case, and list breaches for the auditor with member-notice evidence. Auto-log pass/fail to the hash-chained ledger.

### ODAG-TAT-568
- citation: 42 CFR §422.568 / §422.572
- requirement: Standard organization determinations within 14 calendar days; expedited within 72 hours.
- check: determination_timeliness
- pillar: regulatory
- universe: ODAG_OD
- standard_hours: 336
- expedited_hours: 72
- breach_action: fail
- remediation: Generate the ODAG_OD universe; flag cases exceeding the standard; confirm effectuation timestamps.

## Utilization Management / Claims Triage (mid-market pillar boilerplate)

### UM-INTERQUAL-PA
- citation: InterQual Level of Care Criteria 2026; CMS NCD/LCD where applicable
- requirement: Elective inpatient and high-cost outpatient services require prior authorization screened against InterQual criteria before approval; auto-approve only when criteria are unambiguously met AND answer trust >= the hard gate.
- check: pa_triage
- pillar: claims_triage
- guideline_source: InterQual
- auto_approve_trust: 0.85
- pended_on_ambiguity: true
- applies_to_claim_types: Inpatient, Specialist Visit
- remediation: Route ambiguous or below-gate cases to a UM nurse review queue; never auto-deny on model output alone.

### UM-RX-PA-75
- citation: NCPDP reject 75; plan formulary PA rules
- requirement: Pharmacy reject-75 (PA required) must trigger an electronic PA workflow; step-therapy and tier rules read from the formulary node.
- check: pa_triage
- pillar: claims_triage
- guideline_source: formulary
- reject_code: 75
- remediation: Open PA case, attach formulary tier/step-therapy evidence, enforce 72h coverage-determination clock (see CDAG-TAT-568).

## FWA / Overpayment Detection (mid-market pillar boilerplate)

### FWA-EM-UPCODE
- citation: CMS E/M documentation guidelines; OIG work plan (E/M upcoding)
- requirement: Flag providers whose share of high-level E/M codes (99204/99205/99214/99215) is a statistical outlier versus specialty peers.
- check: upcoding_zscore
- pillar: fwa
- dimension: em_level
- high_em_codes: 99205, 99215
- peer_group: specialty
- z_threshold: 3.0
- min_claims: 30
- remediation: Surface an FWACase with peer-relative z-score and estimated overpayment; route to SIU when z >= threshold and volume material.

### FWA-UNBUNDLE
- citation: NCCI Procedure-to-Procedure edits (CMS)
- requirement: Flag claims that bill component procedures separately when an NCCI bundle exists (unbundling) absent a valid modifier.
- check: unbundling_edit
- pillar: fwa
- edit_source: NCCI_PTP
- remediation: List offending claim/provider pairs with the violated NCCI edit; estimate recoverable overpayment.

## Action Governance (Phase 4 — HITL write-back controls)

Read by the action engine. Editing this section changes approval behaviour with
no code change: thresholds, severity triggers and approver roles are all
declarative.

### ACT-DUAL-CONTROL
- citation: Internal financial control standard; SOC 2 CC6.3 (segregation of duties)
- requirement: Actions whose estimated financial impact meets or exceeds the threshold, or whose regulatory severity is a trigger severity, require maker-checker dual control — two DISTINCT approvers. The proposer may never approve.
- check: action_dual_control
- pillar: regulatory
- financial_impact_threshold: 10000
- regulatory_severity_triggers: critical, high
- dual_control_action_types: claim_adjustment, overpayment_recovery, auth_override, universe_resubmission, compensating
- self_approval_allowed: false
- remediation: Route to a second authorized approver; record both signatures in the audit ledger.

### ACT-COMPENSATION
- citation: Internal financial control standard; SOC 2 CC6.3 (segregation of duties) — Phase 6 amendment (rollback/compensating actions)
- requirement: Reversing an executed action (credit or void) is itself a dual-control action. It is never an edit to the original ledger entry — the original block remains and a new, append-only compensating block cryptographically references it (original record_hash and payload_hash). A single approver may never void or credit a write-back.
- check: action_compensation
- pillar: regulatory
- always_dual_control: true
- remediation: Route the compensation through the same maker-checker queue as any other action; both signatures and the cryptographic backlink are written to the audit ledger.

### NOTIFY-TRIGGERS
- citation: OpPal governance standard — Phase 6 amendment (notification event bus, Limitation 3)
- requirement: The platform must notify an administrator/compliance channel the moment an action requires a second approver, the moment a compensation completes, and the moment the audit-ledger hash chain is found broken. Missing/unconfigured channels degrade to a logged no-op — they never block the underlying workflow.
- check: notify_triggers
- pillar: regulatory
- events: pending_second_approval, compensated, chain_broken, sim_promoted
- remediation: Configure a Slack webhook or SMTP relay in Settings; until then, notifications are recorded to the audit ledger only.

### ACT-TRUST-GATE
- citation: OpPal governance standard (trust-gated automation)
- requirement: No action may execute unless its trust score meets the hard gate. Below the gate the execution path is refused regardless of approvals.
- check: action_trust_gate
- pillar: regulatory
- execution_trust_gate: 0.85
- remediation: Raise trust by certifying the underlying metrics/evidence, or handle the case manually outside automated write-back.

### ACT-APPROVER-ROLES
- citation: RBAC policy
- requirement: Only these roles may approve a write-back action.
- check: action_approver_roles
- pillar: regulatory
- approver_roles: compliance_officer
- remediation: Request approval from an authorized compliance officer.

### FWA-PHANTOM-HOURS
- citation: SIU billing-integrity heuristics
- requirement: Flag rendering providers whose summed service_units imply more than 24 billable hours in a single service day (impossible-day / phantom hours).
- check: impossible_day
- pillar: fwa
- max_daily_hours: 24
- remediation: Surface provider/day with implied hours and contributing claims for SIU review.
