# Entities & Relationships

## Tables

### plans
Line-of-business plan (MA H-contract, Medicaid MCO, ...)

### products
Marketed product under a plan (HMO/PPO/D-SNP)

### benefit_packages
Benefit package incl. formulary and cost share

### members
Enrolled member: RAF score, HEDIS gaps, MBI, dual status

### claims
Medical claims (institutional + professional)

### pharmacy_claims
PBM claims incl. NCPDP paid/reject adjudication

### formulary
Formulary: RxNorm -> tier/PA, sourced from PBM document

### providers
Rendering providers with NPI


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results_2
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results_3
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### medicaid_coding_worksheet
Auto-onboarded imported table (900 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### hedis_measure_results
Auto-onboarded imported table (9110 rows) [auto-onboarded]


### evil_name_drop
Auto-onboarded imported table (3 rows) [auto-onboarded]


## Columns

- plans.lob: Line of business: Medicare Advantage / Medicaid / Commercial / ACA Exchange
- plans.cms_contract: CMS contract number (H1234 for MA)
- members.raf_score: CMS-HCC Risk Adjustment Factor score
- members.hedis_gap_count: Open HEDIS care gaps (CDC, BCS, COL...)
- members.dual_eligible: Dual Medicare/Medicaid eligibility
- members.mbi: Medicare Beneficiary Identifier (PHI)
- members.monthly_premium: Member monthly premium revenue
- claims.allowed_amount: Contracted allowed amount — governed default for medical 'cost'
- claims.paid_amount: Plan-paid amount (0 if denied/pending)
- claims.status: Paid / Denied / Pending
- claims.denial_reason: CARC denial reason (CO-50, CO-197, PR-204...)
- claims.fraud_flag: SIU referral flag (upcoding, phantom billing)
- claims.service_quarter: Incurred quarter, e.g. 2026Q2
- pharmacy_claims.plan_paid: PBM plan-paid amount
- pharmacy_claims.status: Paid / Rejected (NCPDP adjudication)
- pharmacy_claims.reject_code: NCPDP reject: 70 not covered, 75 PA required, 76 plan limits exceeded
- pharmacy_claims.formulary_tier: Adjudicated formulary tier 1-5
- pharmacy_claims.drug_class: Therapeutic class (GLP-1 Agonist, Statin...)
- pharmacy_claims.rxnorm_code: RxNorm concept identifier
- formulary.tier: Assigned tier per the PBM benefit document
- formulary.pa_required: Prior authorization required flag
- formulary.source_doc: Authoritative source benefit document
- providers.npi: National Provider Identifier (PHI-adjacent)

- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results_2.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_2.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_2.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_2.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_2.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_2.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results_3.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results_3.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results_3.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results_3.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results_3.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results_3.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- medicaid_coding_worksheet.worksheet_id: text column (900 distinct) [auto-onboarded]
- medicaid_coding_worksheet.member_id: text column (731 distinct) [auto-onboarded]
- medicaid_coding_worksheet.provider_id: text column (60 distinct) [auto-onboarded]
- medicaid_coding_worksheet.review_date: text column (168 distinct) [auto-onboarded]
- medicaid_coding_worksheet.condition_category: text column (6 distinct) [auto-onboarded]
- medicaid_coding_worksheet.coding_confirmed: text column (2 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- hedis_measure_results.member_id: text column (1952 distinct) [auto-onboarded]
- hedis_measure_results.measure_code: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.measure_name: text column (7 distinct) [auto-onboarded]
- hedis_measure_results.gap_open: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.numerator_compliant: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.outreach_attempts: numeric column (4 distinct) [auto-onboarded]
- hedis_measure_results.star_weight: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.measurement_year: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.denominator_eligible: numeric column (1 distinct) [auto-onboarded]
- hedis_measure_results.region: text column (5 distinct) [auto-onboarded]
- hedis_measure_results.age_band: text column (1 distinct) [auto-onboarded]
- hedis_measure_results.dual_eligible: numeric column (2 distinct) [auto-onboarded]
- hedis_measure_results.last_service_date: text column (144 distinct) [auto-onboarded]
- evil_name_drop.member_id: text column (3 distinct) [auto-onboarded]
- evil_name_drop.paid_amount: Amount true
- evil_name_drop.notes: text column (3 distinct) [auto-onboarded]

## Joins

- members.package_id = benefit_packages.package_id
- claims.member_id = members.member_id
- claims.provider_id = providers.provider_id
- pharmacy_claims.member_id = members.member_id
- pharmacy_claims.rxnorm_code = formulary.rxnorm_code
- products.plan_id = plans.plan_id
- benefit_packages.product_id = products.product_id


- hedis_measure_results.region = providers.region

- hedis_measure_results.member_id = members.member_id

- hedis_measure_results.region = members.region

- hedis_measure_results.member_id = claims.member_id

- hedis_measure_results.region = claims.region

- hedis_measure_results.member_id = pharmacy_claims.member_id

- hedis_measure_results_2.region = providers.region

- hedis_measure_results_2.member_id = members.member_id

- hedis_measure_results_2.region = members.region

- hedis_measure_results_2.member_id = claims.member_id

- hedis_measure_results_2.region = claims.region

- hedis_measure_results_2.member_id = pharmacy_claims.member_id

- hedis_measure_results_3.region = providers.region

- hedis_measure_results_3.member_id = members.member_id

- hedis_measure_results_3.region = members.region

- hedis_measure_results_3.member_id = claims.member_id

- hedis_measure_results_3.region = claims.region

- hedis_measure_results_3.member_id = pharmacy_claims.member_id

- medicaid_coding_worksheet.provider_id = providers.provider_id

- medicaid_coding_worksheet.member_id = members.member_id

- medicaid_coding_worksheet.member_id = claims.member_id

- medicaid_coding_worksheet.provider_id = claims.provider_id

- medicaid_coding_worksheet.member_id = pharmacy_claims.member_id

- medicaid_coding_worksheet.member_id = prior_auth.member_id

## Dimensions (claims)

- region: c.region
- lob: c.lob
- claim_type: c.claim_type
- diagnosis_category: c.diagnosis_category
- provider: pr.name
- status: c.status
- quarter: c.service_quarter


## Dimensions (rx)

- region: rx.region
- lob: rx.lob
- drug_class: rx.drug_class
- reject_code: rx.reject_code
- formulary_tier: rx.formulary_tier
- pharmacy_type: rx.pharmacy_type
- quarter: rx.service_quarter


## Dimensions (members)

- region: m2.region
- lob: m2.lob


## Analysis Dimensions (claims)
- lob, region, claim_type, diagnosis_category

## Analysis Dimensions (rx)
- reject_code, drug_class, formulary_tier, lob, pharmacy_type


## Cohort Fields

- region: c.region
- lob: c.lob
- claim_type: c.claim_type
- diagnosis_category: c.diagnosis_category
- status: c.status
- fraud_flag: c.fraud_flag
- allowed_amount: c.allowed_amount
- service_quarter: c.service_quarter
- provider_id: c.provider_id
- raf_score: m.raf_score [member]
- dual_eligible: m.dual_eligible [member]
- hedis_gap_count: m.hedis_gap_count [member]
- age_band: m.age_band [member]
- monthly_premium: m.monthly_premium [member]
- drug_class: rx.drug_class [rx]
- formulary_tier: rx.formulary_tier [rx]
- pharmacy_type: rx.pharmacy_type [rx]
- reject_code: rx.reject_code [rx]
- drug_name: rx.drug_name [rx]
