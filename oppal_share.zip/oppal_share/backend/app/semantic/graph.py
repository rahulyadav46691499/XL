"""Graph RAG semantic layer — built ENTIRELY from the Context Brain.

No domain knowledge lives here: tables, columns, joins, metrics,
vocabulary, drugs and source documents are parsed from the editable
Markdown files under brain/domains/<active>/ and assembled into the
knowledge graph at startup and on every Brain reload.
"""
import re


class DiGraph:
    def __init__(self):
        self.nodes = {}
        self.adj = {}

    def add_node(self, nid, **attrs):
        self.nodes.setdefault(nid, {}).update(attrs)

    def add_edge(self, src, dst, **attrs):
        self.add_node(src)
        self.add_node(dst)
        self.adj.setdefault(src, []).append((dst, attrs))

    def out_edges(self, node):
        return [(node, dst, attrs) for dst, attrs in self.adj.get(node, [])]

    def edges(self):
        return [(s, d, a) for s, lst in self.adj.items() for d, a in lst]

    def number_of_nodes(self):
        return len(self.nodes)

    def number_of_edges(self):
        return sum(len(v) for v in self.adj.values())


G = DiGraph()
METRICS: dict = {}
SYNONYMS: dict = {}
DRUG_INDEX: dict = {}     # synonym -> drug node id
GRAPH_META: dict = {"last_rebuild": None, "rebuild_count": 0}


def rebuild(brain: dict):
    """Assemble the knowledge graph from parsed Brain markdown."""
    global G, METRICS, SYNONYMS, DRUG_INDEX
    g = DiGraph()

    for t, desc in brain["tables"].items():
        g.add_node(t, ntype="table", description=desc)
    for col, desc in brain["columns"].items():
        g.add_node(col, ntype="column", description=desc)
        if "." in col:
            g.add_edge(col.split(".")[0], col, rel="HAS_COLUMN")
    for join in brain["joins"]:
        if "=" in join:
            left = join.split("=")[0].strip()
            right = join.split("=")[1].strip()
            g.add_edge(left.split(".")[0], right.split(".")[0],
                       rel="JOINS_ON", on=join)

    metrics = {}
    for mid, m in brain["metrics"].items():
        metrics[mid] = m
        g.add_node(f"metric:{mid}", ntype="metric", **m)
        for dep in m["depends"]:
            g.add_edge(f"metric:{mid}", dep, rel="DERIVED_FROM")

    # Documents live in their own `doc:` namespace. Without it a source
    # document's id ("42 CFR §422.2264", "CMS Complaints Tracking Module")
    # sits in the same flat id space as tables and columns, so the Medicare
    # Sales pack's twelve regulations rendered as twelve extra TABLES in the
    # graph's Tables column, and ground()'s `n.startswith("doc:")` filter -
    # which is how a question reports what it is grounded in - never matched,
    # leaving source_documents permanently empty for this domain.
    docs = {d: f"doc:{d}" for d in brain["documents"]}
    for doc_id, desc in brain["documents"].items():
        g.add_node(docs[doc_id], ntype="document", description=desc)

    drug_index = {}
    for d in brain["drugs"]:
        nid = f"drug:{re.sub(r'[^a-z0-9]+', '_', d['name'].lower())[:24]}"
        g.add_node(nid, ntype="drug",
                   description=f"{d['name']} — RxNorm {d['rxnorm']}, "
                               f"{d['drug_class']}",
                   rxnorm=d["rxnorm"], drug_class=d["drug_class"])
        tier_node = f"tier:{d['tier']}"
        g.add_node(tier_node, ntype="tier",
                   description=f"Formulary tier {d['tier']}"
                   + (" + prior authorization" if d["pa"] else ""))
        g.add_edge(nid, tier_node, rel="RESOLVES_TO")
        for doc_id in brain["documents"]:
            g.add_edge(tier_node, docs[doc_id], rel="SOURCED_FROM")
        for syn in d["synonyms"]:
            drug_index[syn] = nid

    # policy rules as first-class, searchable graph nodes
    for r in brain.get("policy_rules", []):
        nid = f"policy:{r['rule_id']}"
        thr = r.get("threshold") or r.get("multiplier") or             r.get("warn_above") or r.get("min_quarters") or ""
        g.add_node(nid, ntype="policy",
                   description=f"{r.get('requirement', '')} "
                               f"[threshold: {thr}] ({r.get('citation', '')})",
                   threshold=str(thr), citation=r.get("citation", ""),
                   check=r.get("check", ""))
        if r.get("metric") and f"metric:{r['metric']}" :
            g.add_edge(nid, f"metric:{r['metric']}", rel="GOVERNS")
        # A rule's citation names the documents it rests on. Only the drug
        # loop above ever edged a document, so in a domain with no drugs -
        # Medicare Sales, Retail Banking - every document node was an orphan:
        # drawn, unreachable, and invisible to ground(). The metric edge is
        # what ground() can actually walk (it follows OUT-edges only, and
        # GOVERNS points policy -> metric, away from the seed), so it is what
        # puts "42 CFR §422.2274(e)" in front of the analyst asking about
        # commission recovery.
        cite = r.get("citation", "")
        for doc_id, doc_nid in docs.items():
            if doc_id not in cite:
                continue
            g.add_edge(nid, doc_nid, rel="SOURCED_FROM")
            if r.get("metric"):
                g.add_edge(f"metric:{r['metric']}", doc_nid, rel="SOURCED_FROM")

    synonyms = dict(brain["synonyms"])
    for syn, nid in drug_index.items():
        synonyms[syn] = nid          # reference.md is authoritative for drugs
    for term, target in synonyms.items():
        g.add_node(f"term:{term}", ntype="term")
        g.add_edge(f"term:{term}", target, rel="SYNONYM_OF")

    import time as _t
    G, METRICS, SYNONYMS, DRUG_INDEX = g, metrics, synonyms, drug_index
    GRAPH_META["last_rebuild"] = _t.strftime("%Y-%m-%d %H:%M:%S")
    GRAPH_META["rebuild_count"] += 1


def _ensure():
    if not G.nodes:
        from ..semantic.brain import get_brain
        rebuild(get_brain())


STOPWORDS = {"the", "and", "for", "what", "how", "show", "was", "why",
             "are", "did", "our", "this", "that", "with", "last", "over",
             "give", "tell", "is", "in", "by", "on", "of", "to"}


def ground(question: str, max_hops: int = 3) -> dict:
    _ensure()
    q = question.lower().replace("_", " ")
    matched_terms, seeds, extraction = [], set(), []
    for term, target in SYNONYMS.items():
        # plural-tolerant: 'member count' matches 'member counts' etc.
        pattern = rf"\b{re.escape(term)}s?\b"
        if re.search(pattern, q):
            matched_terms.append(term)
            seeds.add(target)
            extraction.append({"entity": target, "regex": pattern,
                               "matched_text": term})

    paths, context_nodes = [], set(seeds)
    for seed in seeds:
        frontier = {seed}
        for _ in range(max_hops):
            nxt = set()
            for node in frontier:
                for _, dst, ed in G.out_edges(node):
                    if dst not in context_nodes:
                        nxt.add(dst)
                        context_nodes.add(dst)
                        paths.append(f"{node} -[{ed['rel']}]-> {dst}")
            frontier = nxt
            if not frontier:
                break

    # NOTE: context_nodes is a SET, so iterating it directly gave a
    # per-process (hash-randomized) order. Downstream, the router picks THE
    # metric via next(iter(metrics)), so that randomness meant the same
    # question could resolve to a different metric on different runs — e.g. a
    # pharmacy reject-rate question landing on 'enrollment' one run and
    # 'pbm_reject_rate' the next. Sorting makes grounding deterministic; the
    # router then picks the domain-appropriate metric (see intent_router).
    metrics = {mid: METRICS[mid] for mid in sorted(
               n.split(":", 1)[1] for n in context_nodes
               if n.startswith("metric:") and n.split(":", 1)[1] in METRICS)}
    drugs = [G.nodes[n] | {"id": n} for n in context_nodes
             if n.startswith("drug:") and G.nodes[n].get("rxnorm")]
    sources = [G.nodes[n].get("description", n) for n in context_nodes
               if n.startswith("doc:")]
    joins = [d["on"] for _, _, d in G.edges() if d.get("rel") == "JOINS_ON"]
    tokens = [t for t in re.findall(r"[a-z0-9]{2,}", q)
              if t not in STOPWORDS]
    coverage = (len(matched_terms) / max(len(tokens), 1)) if tokens else 0.0
    coverage = min(coverage * 1.8, 1.0)
    if metrics or drugs:     # resolved hop -> floor for the trust gate
        coverage = max(coverage, 0.8)

    # Intent-scoped sub-graph (Sprint B item 3). `available_joins` used to be
    # every join in the graph regardless of the question; it is now scoped to
    # the relevant neighbourhood, with `all_joins` retained for anything that
    # genuinely needs the whole picture. Falls back to the full set whenever
    # pruning is not provably safe — see semantic/subgraph.py.
    _partial = {"matched_terms": matched_terms, "metrics": metrics,
                "drugs": drugs, "extraction_trace": extraction,
                "context_nodes": sorted(context_nodes)}
    try:
        from . import subgraph as _sg
        space = _sg.space_for(question, _partial)
        scoped_joins = space["joins"] or joins
    except Exception:                                  # never break grounding
        space, scoped_joins = None, joins

    return {"matched_terms": matched_terms, "metrics": metrics,
            "drugs": drugs, "source_documents": sources,
            "extraction_trace": extraction,
            "context_nodes": sorted(context_nodes),
            "space": space, "all_joins": joins,
            "graph_paths": paths, "available_joins": scoped_joins,
            "coverage": round(coverage, 2)}


def export_graph(include_unmapped: bool = False) -> dict:
    """include_unmapped=True overlays ALL physical columns from the
    database schema (PRAGMA) that are NOT curated in the Brain — shown
    dimmed in the UI. The default view is intentionally curated: the
    semantic graph is a governed meaning layer, not a data dictionary."""
    _ensure()
    unmapped = []
    if include_unmapped:
        try:
            import sqlite3
            from ..data.generate import DB_PATH
            con = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
            for t in [n for n, a in G.nodes.items()
                      if a.get("ntype") == "table"]:
                for r in con.execute(f"PRAGMA table_info({t})"):
                    col = f"{t}.{r[1]}"
                    if col not in G.nodes:
                        unmapped.append({
                            "id": col, "ntype": "column", "label": col,
                            "description": f"physical column ({r[2]}) — "
                                           "not curated in the Brain",
                            "formula": "", "owner": "", "threshold": "",
                            "citation": "", "certified": False,
                            "unmapped": True, "table": t})
            con.close()
        except Exception:
            pass
    nodes = []
    for nid, attrs in G.nodes.items():
        label = nid.split(":", 1)[-1] if ":" in nid else nid
        nodes.append({"id": nid, "ntype": attrs.get("ntype", "other"),
                      "label": label,
                      "description": attrs.get("definition")
                                     or attrs.get("description") or "",
                      "formula": attrs.get("formula", ""),
                      "owner": attrs.get("owner", ""),
                      "threshold": attrs.get("threshold", ""),
                      "citation": attrs.get("citation", ""),
                      "certified": attrs.get("certified", False)})
    edges = [{"source": s, "target": d, "rel": a.get("rel", ""),
              "on": a.get("on", "")} for s, d, a in G.edges()]
    for u in unmapped:
        nodes.append(u)
        edges.append({"source": u["table"], "target": u["id"],
                      "rel": "HAS_COLUMN", "on": ""})
    return {"nodes": nodes, "edges": edges, "meta": dict(GRAPH_META)}


def graph_summary() -> dict:
    _ensure()
    return {"nodes": G.number_of_nodes(), "edges": G.number_of_edges(),
            "metrics": list(METRICS)}
