# FinOps / LLM Cost Governance (Phase 6 — REQ-6.4–6.6)

Read by `app/finops/telemetry.py` via `get_brain()["finops"]`. This file makes
the FinOps *policy* declarative (NFR-1): the cost formula, the savings model,
the latency percentile and the budget thresholds all live here, not in Python.

Model **prices** deliberately remain in `app/llm/base.PRICING_PER_M` — the TDD
names that dict as the single existing pricing anchor, and duplicating rates
here would create two sources of truth that could silently disagree. This file
governs *how* those rates are turned into reported figures; `PRICING_PER_M`
governs *what* a token costs. `FinOpsTelemetry.price_in_per_m` /
`price_out_per_m` echo the rate actually used, so every reported cost is
traceable to its source rate.

### cost_model
- label: LLM spend for a token bucket
- expr: (tokens_in * price_in_per_m + tokens_out * price_out_per_m) / 1000000
- price_source: app/llm/base.PRICING_PER_M
- arithmetic: decimal
- quantize: 0.000001
- rounding: ROUND_HALF_UP

### cache_savings
- label: Spend avoided by the semantic cache
- expr: cache_hits * avg_cost_per_call
- avg_cost_per_call_expr: global_cost_usd / llm_calls
- cold_cache_value: 0
- source: app/security/semantic_cache.CACHE.stats()

### latency_percentile
- label: Reported tail latency
- percentile: 95
- source: usage ledger latency_ms
- min_samples: 2

### reconciliation
- label: Invariants the widget relies on
- rule: session_tokens_in <= global_tokens_in
- rule2: session_tokens_out <= global_tokens_out
- rule3: session_cost_usd <= global_cost_usd
- enforcement: FinOpsTelemetry model_validator (fails closed)

### budget_thresholds
- label: Spend guardrails — the warn levels are advisory, the hard levels are enforced
- session_warn_usd: 1.00
- session_critical_usd: 5.00
- global_warn_usd: 50.00
- session_hard_usd: 25.00
- global_hard_usd: 250.00
- enforcement: app/finops/enforcement.py refuses the model call at or above a hard cap; it never silently truncates context, because a cheap answer that reports success is worse than a refusal. Deterministic agent paths continue to work, so the platform degrades to rules-based operation rather than going offline.
- kill_switch: Operated from Settings or the OPPAL_LLM_KILL_SWITCH environment variable. The switch MECHANISM is deliberately in code, not here — a kill switch that can be disabled by editing the file it polices is not a kill switch. Raising these limits is a business decision and belongs in this file; disabling enforcement is not.
- remediation: Review cache hit rate and prompt sizes; route exploratory workloads to the cheap tier (Haiku 4.5) in Settings; raise the cap here if the workload is legitimate.
