# Departmental Agent Swarm

Declarative roster for the Phase 3 swarm. The Sentry agent triages each
question and activates ONLY the agents whose triggers match, so a typical run
uses 2–4 agents instead of all ten (mid-market compute mandate). Everything
here — personas, triggers, tool allow-lists, priority — is read by the
orchestrator; no roster is hardcoded in Python.

Field reference:
- `department`   business owner of the persona
- `triggers`     comma-separated keywords/intents that activate the agent
- `pillars`      which mid-market pillars the agent serves
- `tools`        tool allow-list (framework enforces; agent cannot exceed it)
- `detector`     deterministic function the agent runs (no LLM required)
- `priority`     lower runs first; synthesis order
- `always_on`    true = runs on every swarm invocation

## sentry
- department: Operations Command
- role: Triage the question and current anomalies; decide which departmental agents to activate.
- triggers: *
- pillars: all
- tools: anomaly_scan, metric_trend
- detector: triage
- priority: 0
- always_on: true

## medical_economics
- department: Medical Economics
- role: Explain cost/utilization movement — trend, mix shift, additive drivers, PMPM.
- triggers: cost, spend, mlr, pmpm, utilization, trend, severity, allowed, paid, medical
- pillars: risk_analytics
- tools: metric_trend, root_cause_additive, root_cause_average
- detector: cost_drivers
- priority: 10
- always_on: false

## pbm_forensics
- department: Pharmacy / PBM
- role: Decompose NCPDP paid-reject behaviour (70/75/76) and formulary-change impact.
- triggers: pharmacy, rx, pbm, reject, formulary, drug, tier, ncpdp, glp-1, prior auth drug
- pillars: claims_triage
- tools: pbm_reject_decomposition, metric_trend
- detector: pbm_rejects
- priority: 20
- always_on: false

## network
- department: Network Management
- role: Provider network composition, leakage and out-of-network exposure.
- triggers: provider, network, leakage, out-of-network, specialty, referral
- pillars: fwa
- tools: network_scan
- detector: network_exposure
- priority: 30
- always_on: false

## clinical_um
- department: Utilization Management
- role: Prior-authorization and InterQual/CMS guideline triage with the trust gate.
- triggers: prior auth, authorization, um, interqual, medical necessity, pended, approval, denial
- pillars: claims_triage
- tools: pa_triage
- detector: pa_triage
- priority: 25
- always_on: false

## quality_hedis
- department: Quality / Stars
- role: HEDIS gap closure and Stars measure exposure.
- triggers: hedis, gap, quality, stars, measure, screening, adherence
- pillars: risk_analytics
- tools: quality_scan
- detector: hedis_gaps
- priority: 35
- always_on: false

## risk_hcc
- department: Risk Adjustment
- role: RAF/HCC accuracy, ACG risk bands, suspected undocumented conditions.
- triggers: raf, hcc, risk score, risk adjustment, acg, coding accuracy, suspect
- pillars: risk_analytics
- tools: risk_scan
- detector: risk_profile
- priority: 35
- always_on: false

## fwa_siu
- department: FWA / SIU
- role: Fraud, waste and abuse detection — upcoding, unbundling, impossible-day, overpayment.
- triggers: fraud, fwa, siu, abuse, upcoding, unbundling, overpayment, phantom, billing anomaly, waste
- pillars: fwa
- tools: fwa_scan
- detector: fwa_scan
- priority: 30
- always_on: false

## compliance
- department: Compliance / Regulatory
- role: CMS/state audit readiness — CDAG/ODAG universes, 42 CFR timeliness, MLR floor.
- triggers: compliance, audit, cms, cdag, odag, universe, 42 cfr, timeliness, regulatory, mlr
- pillars: regulatory
- tools: determination_timeliness, policy_check
- detector: regulatory_timeliness
- priority: 40
- always_on: false

## prescriptive_action
- department: Operations
- role: Convert findings into proposed, trust-scored actions and persistent cases.
- triggers: *
- pillars: all
- tools: propose_action
- detector: propose_actions
- priority: 90
- always_on: true

## Swarm Settings

- max_active_agents: 4
- min_active_agents: 1
- trust_gate: 0.85
- case_creation_min_trust: 0.60
- example_question: Are there billing anomalies or upcoding from any provider?
