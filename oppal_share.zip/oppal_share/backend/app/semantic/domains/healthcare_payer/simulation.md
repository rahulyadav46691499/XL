# Actuarial Simulation Formulas (Phase 5 — What-If Simulator)

Read by `app/simulation/engine.py` via `get_brain()["simulation"]`. Editing a
formula here changes what a simulation computes with **no code change** — the
delta engine looks up a formula id from this file for every number it reports;
it contains no arithmetic literals of its own. If a formula id the engine
needs is missing, the simulation fails closed with `SimulationConfigError`
rather than falling back to a hardcoded calculation.

### mlr
- label: Medical Loss Ratio (simulated vs baseline)
- source_metric: mlr
- basis: reuses the governed mlr metric sql (metrics.md) for both passes
- basis_points_expr: (simulated_mlr - baseline_mlr) * 10000
- direction_favorable: decrease
- floor_rule_ref: MLR-85

### net_dollar_impact
- label: Net Dollar Impact
- expr: (baseline_medical_cost - simulated_medical_cost) + (baseline_pharmacy_cost - simulated_pharmacy_cost)
- direction_favorable: increase
- unit: usd

### medical_cost
- label: Medical Spend (simulated vs baseline)
- source_metric: medical_cost
- basis: reuses the governed medical_cost metric sql (metrics.md) for both passes
- direction_favorable: decrease
- unit: usd

### pharmacy_cost
- label: Pharmacy Spend (simulated vs baseline)
- source_metric: pharmacy_cost
- basis: reuses the governed pharmacy_cost metric sql (metrics.md) for both passes
- direction_favorable: decrease
- unit: usd

### admin_burden
- label: Administrative Burden (PA-processing volume proxy)
- expr: rejects_delta * pa_touch_minutes
- pa_touch_minutes: 12
- direction_favorable: decrease
- unit: minutes

### affected_members
- label: Member Abrasion (affected member count)
- affected_member_rule: members whose governed cohort predicate value changes
  between the baseline pass and the simulated pass (touched by an override)
- direction_favorable: decrease
- unit: count

### pharmacy_tier_shift
- label: Pharmacy Formulary Tier Shift
- expr: SUM(CASE WHEN tier_after != tier_before THEN 1 ELSE 0 END)
- direction_favorable: decrease
- unit: count
