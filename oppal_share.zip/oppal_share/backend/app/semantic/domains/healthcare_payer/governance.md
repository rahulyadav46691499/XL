# Data Governance & Scoping Rules

Declarative RBAC/ABAC data-scoping rules read by the MCP Zero-Copy layer's
ScopeEnforcer. Nothing here is hardcoded in Python — editing this file changes
how every warehouse connector scopes queries, with no code change.

## Scope Column

- lob

The physical column that carries the line-of-business value on directly-governed
tables. A user is authorized to a set of LOB values; the connector restricts
every governed table to that set.

## Governed Tables

Tables that carry the scope column directly. Every query touching one of these
is restricted to the caller's authorized LOB values.

- plans: lob
- members: lob
- claims: lob
- pharmacy_claims: lob
- prior_auth: lob
- cdag_universe: lob
- fwa_cases: lob

## Transitive Tables

Tables with no scope column of their own; scoped by joining up the plan
hierarchy. Format: `table: key_column -> parent_table.parent_key`.

- products: plan_id -> plans.plan_id
- benefit_packages: product_id -> products.product_id

## Excluded Tables

Credential, identity and RBAC-directory tables. These must never be exposed to
an analytical query, at any scope. The connector omits them from every scoped
data plane.

- users
- roles
- role_lob_access
- user_attributes

## Ungoverned Tables

Reference tables that are legitimately cross-LOB (no member/claim rows, no scope
column, no PHI). Available at every scope without restriction.

- formulary
- providers

## Scope Strategy

Default enforcement strategy per connector capability class. `predicate_pushdown`
appends a governed `WHERE lob IN (...)` (and transitive semi-joins) to the query
sent to the warehouse — the warehouse never returns out-of-scope rows.
`physical_sandbox` builds a data plane physically containing only in-scope rows
(used where SQL text cannot be trusted, e.g. the local reference engine).

- predicate_pushdown_capable: bigquery, snowflake, databricks, redshift, postgres
- physical_sandbox: local_reference, sqlite_demo

## Enforcement

- deny_by_default: true
- require_scope_context: true
- forbid_unscoped_execution: true
