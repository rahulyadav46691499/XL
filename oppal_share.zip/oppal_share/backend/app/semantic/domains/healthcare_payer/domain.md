# Healthcare Insurance (US Payer / MCO)
- icon: 🏥
- description: US Healthcare payer & managed-care book — benefit hierarchy (plans → products → benefit packages → members → medical + PBM pharmacy claims), RxNorm formulary, CMS-HCC risk adjustment, HEDIS quality and Medicare/Medicaid compliance.
- tables: plans, products, benefit_packages, members, claims, pharmacy_claims, formulary, providers
