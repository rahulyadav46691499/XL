# Reference Knowledge

## Drugs (RxNorm → formulary)

- 1991302 | Semaglutide (Ozempic) | GLP-1 Agonist | tier 4 | pa 1 | synonyms: ozempic, semaglutide
- 2601723 | Tirzepatide (Mounjaro) | GLP-1 Agonist | tier 4 | pa 1 | synonyms: mounjaro
- 352385 | Adalimumab (Humira) | Biologic DMARD | tier 5 | pa 1 | synonyms: humira
- 1364445 | Apixaban (Eliquis) | Anticoagulant | tier 2 | pa 0 | synonyms: eliquis

## Reject Codes

- 70: Product/Service Not Covered — drug not on formulary
- 75: Prior Authorization Required — PA edit fired at point of sale
- 76: Plan Limitations Exceeded — quantity/days-supply limit

## Source Documents

- doc:ES-NPF-2026: Express Scripts National Preferred Formulary 2026 v2, §4.2 Tier Assignments (eff. 2026-04-01)

## Dimension Values

- lob: Medicare Advantage, Medicaid, Commercial, ACA Exchange
- region: Northeast, Southeast, Midwest, Southwest, West
- claim_type: Inpatient, Outpatient, ER, Specialist Visit, Lab
- diagnosis_category: Cardiology, Oncology, Orthopedics, Diabetes, Respiratory, Maternity, Mental Health, Preventive
- drug_class: GLP-1 Agonist, Biguanide, Statin, Biologic DMARD, ARNI, Antibiotic, Anticoagulant, SGLT2 Inhibitor, Insulin
- reject_code: 70, 75, 76
