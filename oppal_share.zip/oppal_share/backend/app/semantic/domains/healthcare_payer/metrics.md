# Governed Metrics

### mlr
- label: Medical Loss Ratio
- definition: Medical paid / earned premium (POC proxy). MA plans must stay >= 85% (42 CFR §422.2410).
- formula: SUM(claims.paid_amount) / SUM(members.monthly_premium * 3)
- sql: ROUND(SUM(c.paid_amount) * 1.0 / SUM(m.monthly_premium * 3), 3)
- base: claims
- needs_members: true
- average: false
- format: percent
- value_sql: c.paid_amount
- depends: claims.paid_amount, members.monthly_premium
- owner: Actuarial
- certified: true

### medical_cost
- label: Medical Cost
- definition: Total allowed amount. Uses ALLOWED, never billed.
- formula: SUM(claims.allowed_amount)
- sql: ROUND(SUM(c.allowed_amount), 0)
- base: claims
- needs_members: false
- average: false
- format: currency
- depends: claims.allowed_amount
- owner: Finance
- certified: true

### claim_severity
- label: Claim Severity
- definition: Average allowed amount per medical claim.
- formula: AVG(claims.allowed_amount)
- sql: ROUND(AVG(c.allowed_amount), 0)
- base: claims
- needs_members: false
- average: true
- format: currency
- value_sql: c.allowed_amount
- depends: claims.allowed_amount
- owner: Medical Economics
- certified: true

### utilization
- label: Utilization
- definition: Medical claim volume.
- formula: COUNT(claims.claim_id)
- sql: COUNT(c.claim_id)
- base: claims
- needs_members: false
- average: false
- format: number
- depends: claims
- owner: Medical Economics
- certified: true

### denial_rate
- label: Denial Rate
- definition: Share of medical claims with status 'Denied'.
- formula: AVG(CASE WHEN claims.status='Denied' THEN 1.0 ELSE 0 END)
- sql: ROUND(AVG(CASE WHEN c.status='Denied' THEN 1.0 ELSE 0 END), 4)
- base: claims
- needs_members: false
- average: true
- format: percent
- value_sql: CASE WHEN c.status='Denied' THEN 1.0 ELSE 0 END
- depends: claims.status, claims.denial_reason
- owner: Claims Ops
- certified: true

### fraud_rate
- label: Fraud Referral Rate
- definition: Share of medical claims flagged by SIU.
- formula: AVG(claims.fraud_flag)
- sql: ROUND(AVG(c.fraud_flag), 4)
- base: claims
- needs_members: false
- average: true
- format: percent
- value_sql: c.fraud_flag
- depends: claims.fraud_flag
- owner: SIU
- certified: true

### pharmacy_cost
- label: Pharmacy Cost
- definition: PBM plan-paid amount (net of member cost share).
- formula: SUM(pharmacy_claims.plan_paid)
- sql: ROUND(SUM(rx.plan_paid), 0)
- base: rx
- needs_members: false
- average: false
- format: currency
- depends: pharmacy_claims.plan_paid
- owner: Pharmacy
- certified: true

### pbm_reject_rate
- label: PBM Reject Rate
- definition: Share of pharmacy claims rejected at adjudication (NCPDP reject codes; 70/75/76 are benefit-driven).
- formula: AVG(CASE WHEN pharmacy_claims.status='Rejected' THEN 1.0 ELSE 0 END)
- sql: ROUND(AVG(CASE WHEN rx.status='Rejected' THEN 1.0 ELSE 0 END), 4)
- base: rx
- needs_members: false
- average: true
- format: percent
- value_sql: CASE WHEN rx.status='Rejected' THEN 1.0 ELSE 0 END
- depends: pharmacy_claims.status, pharmacy_claims.reject_code
- owner: Pharmacy
- certified: true

### raf_score
- label: Average RAF Score
- definition: Mean CMS-HCC Risk Adjustment Factor across members.
- formula: AVG(members.raf_score)
- sql: ROUND(AVG(m2.raf_score), 3)
- base: members
- needs_members: false
- average: true
- format: number
- depends: members.raf_score
- owner: Risk Adjustment
- certified: true

### hedis_gap_rate
- label: HEDIS Gap Rate
- definition: Share of members with >= 1 open HEDIS care gap.
- formula: AVG(CASE WHEN members.hedis_gap_count > 0 THEN 1.0 ELSE 0 END)
- sql: ROUND(AVG(CASE WHEN m2.hedis_gap_count > 0 THEN 1.0 ELSE 0 END), 3)
- base: members
- needs_members: false
- average: true
- format: percent
- depends: members.hedis_gap_count
- owner: Quality (HEDIS)
- certified: true

### enrollment
- label: Enrollment
- definition: Count of distinct enrolled members (membership headcount).
- formula: COUNT(DISTINCT members.member_id)
- sql: COUNT(DISTINCT m2.member_id)
- base: members
- needs_members: false
- average: false
- format: number
- depends: members
- owner: Membership & Billing
- certified: true

### total_paid_amount
- label: Total paid amount (evil_name_drop)
- definition: Auto-onboarded SUM of evil_name_drop.paid_amount. Uncertified until a data steward reviews it in the Brain.
- formula: SUM(evil_name_drop.paid_amount)
- sql: ROUND(SUM(t.paid_amount), 2)
- base: generic
- table: evil_name_drop
- time_column: 
- dims: member_id, notes
- needs_members: false
- average: false
- format: number
- depends: evil_name_drop.paid_amount
- owner: auto-onboarding
- certified: false

### avg_paid_amount
- label: Avg paid amount (evil_name_drop)
- definition: Auto-onboarded AVG of evil_name_drop.paid_amount. Uncertified until a data steward reviews it in the Brain.
- formula: AVG(evil_name_drop.paid_amount)
- sql: ROUND(AVG(t.paid_amount), 2)
- base: generic
- table: evil_name_drop
- time_column: 
- dims: member_id, notes
- needs_members: false
- average: true
- format: number
- depends: evil_name_drop.paid_amount
- owner: auto-onboarding
- certified: false

### total_gap_open
- label: Total gap open (hedis_measure_results)
- definition: Auto-onboarded SUM of hedis_measure_results.gap_open. Uncertified until a data steward reviews it in the Brain.
- formula: SUM(hedis_measure_results.gap_open)
- sql: ROUND(SUM(t.gap_open), 2)
- base: generic
- table: hedis_measure_results
- time_column: last_service_date
- dims: measure_code, measure_name, region
- needs_members: false
- average: false
- format: number
- depends: hedis_measure_results.gap_open
- owner: auto-onboarding
- certified: false

### avg_gap_open
- label: Avg gap open (hedis_measure_results)
- definition: Auto-onboarded AVG of hedis_measure_results.gap_open. Uncertified until a data steward reviews it in the Brain.
- formula: AVG(hedis_measure_results.gap_open)
- sql: ROUND(AVG(t.gap_open), 2)
- base: generic
- table: hedis_measure_results
- time_column: last_service_date
- dims: measure_code, measure_name, region
- needs_members: false
- average: true
- format: number
- depends: hedis_measure_results.gap_open
- owner: Quality (HEDIS)
- certified: true

### total_numerator_compliant
- label: Total numerator compliant (hedis_measure_results)
- definition: Auto-onboarded SUM of hedis_measure_results.numerator_compliant. Uncertified until a data steward reviews it in the Brain.
- formula: SUM(hedis_measure_results.numerator_compliant)
- sql: ROUND(SUM(t.numerator_compliant), 2)
- base: generic
- table: hedis_measure_results
- time_column: last_service_date
- dims: measure_code, measure_name, region
- needs_members: false
- average: false
- format: number
- depends: hedis_measure_results.numerator_compliant
- owner: auto-onboarding
- certified: false

### avg_numerator_compliant
- label: Avg numerator compliant (hedis_measure_results)
- definition: Auto-onboarded AVG of hedis_measure_results.numerator_compliant. Uncertified until a data steward reviews it in the Brain.
- formula: AVG(hedis_measure_results.numerator_compliant)
- sql: ROUND(AVG(t.numerator_compliant), 2)
- base: generic
- table: hedis_measure_results
- time_column: last_service_date
- dims: measure_code, measure_name, region
- needs_members: false
- average: true
- format: number
- depends: hedis_measure_results.numerator_compliant
- owner: auto-onboarding
- certified: false

### total_outreach_attempts
- label: Total outreach attempts (hedis_measure_results)
- definition: Auto-onboarded SUM of hedis_measure_results.outreach_attempts. Uncertified until a data steward reviews it in the Brain.
- formula: SUM(hedis_measure_results.outreach_attempts)
- sql: ROUND(SUM(t.outreach_attempts), 2)
- base: generic
- table: hedis_measure_results
- time_column: last_service_date
- dims: measure_code, measure_name, region
- needs_members: false
- average: false
- format: number
- depends: hedis_measure_results.outreach_attempts
- owner: auto-onboarding
- certified: false

### avg_outreach_attempts
- label: Avg outreach attempts (hedis_measure_results)
- definition: Auto-onboarded AVG of hedis_measure_results.outreach_attempts. Uncertified until a data steward reviews it in the Brain.
- formula: AVG(hedis_measure_results.outreach_attempts)
- sql: ROUND(AVG(t.outreach_attempts), 2)
- base: generic
- table: hedis_measure_results
- time_column: last_service_date
- dims: measure_code, measure_name, region
- needs_members: false
- average: true
- format: number
- depends: hedis_measure_results.outreach_attempts
- owner: auto-onboarding
- certified: false



