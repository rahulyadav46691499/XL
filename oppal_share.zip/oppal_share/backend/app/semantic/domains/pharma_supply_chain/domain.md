# Pharma Supply Chain Management & Distribution

- icon: 🧊
- description: Cold-chain integrity, DSCSA serialization and distributor chargeback governance for a specialty pharma distributor.
- owner: Supply Chain Quality
