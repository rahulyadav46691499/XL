# Compliance Guardrails

### DSCSA-T2-QUARANTINE
- citation: FDA DSCSA Title II interoperability (2023/2024); 21 CFR 203.50
- requirement: An unverified SGTIN or a broken chain of custody triggers a mandatory 24-hour quarantine hold before the unit may be further distributed.
- check: dscsa_quarantine
- pillar: regulatory
- quarantine_hours: 24
- breach_action: quarantine
- headline: Lot {lot_id} — {exceptions} SGTIN(s) unverified or custody-broken, 24h quarantine hold required
- query: SELECT u.lot_id, SUM(CASE WHEN u.verified = 0 OR u.custody_broken = 1 THEN 1 ELSE 0 END) AS exceptions FROM serialized_units u GROUP BY u.lot_id HAVING exceptions > 0 ORDER BY exceptions DESC
- remediation: Quarantine the affected SGTINs, notify the trading partner, and record the verification attempt against the lot.

### COLD-CHAIN-SLA-2-8
- citation: ICH Q1A(R2) stability; product label 2-8 C
- requirement: A 2-8 C biologic's stability claim is void after a continuous thermal excursion above 15 C for more than 120 minutes, or a cumulative MKT above 10 C.
- check: thermal_excursion
- pillar: regulatory
- max_celsius: 15
- max_excursion_minutes: 120
- max_mkt_celsius: 10
- breach_action: fail
- headline: Lot {lot_id} at {hub_id} — MKT {mkt_c} C (ceiling 10), {minutes_over} min above 15 C (SLA 120), {units_spoiled} units unsaleable
- query: SELECT s.lot_id, s.hub_id, s.units_spoiled, mkt(r.temp_c) AS mkt_c, SUM(CASE WHEN r.temp_c > 15 THEN 30 ELSE 0 END) AS minutes_over FROM iot_readings r JOIN shipments s ON s.shipment_id = r.shipment_id GROUP BY s.shipment_id HAVING minutes_over > 120 AND mkt_c > 10 ORDER BY s.units_spoiled DESC
- remediation: Quarantine the lot, open a deviation, and reconcile any chargeback claimed against it before credit is issued.

### CHARGEBACK-FRAUD-Z
- citation: Internal SIU policy; distributor contract audit clause
- requirement: A hub whose chargeback-claims-to-spoilage ratio is a peer outlier beyond 3 standard deviations is referred for recovery review.
- check: chargeback_zscore
- pillar: fwa
- z_threshold: 3.0
- min_claims: 5
- remediation: Reconcile claimed units against confirmed spoilage per lot and open an overpayment recovery action.

### ACTION-DUAL-CONTROL-5K
- citation: Finance delegation of authority
- requirement: Any write-back over $5,000 requires two distinct approvers, a Quality Lead and a Finance Controller.
- check: action_dual_control
- financial_impact_threshold: 5000
- regulatory_severity_triggers: critical, high
- dual_control_action_types: chargeback_recovery, quarantine_hold, lot_disposition, compensating
- self_approval_allowed: false
- always_dual_control: false

### ACTION-TRUST-GATE
- citation: Internal AI governance standard
- requirement: No write-back executes below the enterprise trust gate.
- check: action_trust_gate
- execution_trust_gate: 0.85

### ACTION-APPROVER-ROLES
- citation: Finance delegation of authority
- requirement: Approvers must hold the quality or finance control role.
- check: action_approver_roles
- approver_roles: quality_lead, finance_controller, compliance_officer

### ACTION-COMPENSATION
- citation: Internal reversal policy
- requirement: A reversal is itself a dual-control action; the original ledger entry is never edited.
- check: action_compensation
- modes: void, credit
- min_reason_chars: 8
