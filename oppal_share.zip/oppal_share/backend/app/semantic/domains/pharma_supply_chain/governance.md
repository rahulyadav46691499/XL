# Data Governance & Scoping Rules

Scope is the DISTRIBUTOR, not a line of business. Nothing below is hardcoded in
Python — the MCP ScopeEnforcer reads this file.

## Scope Column

- distributor_id

## Governed Tables

- shipments: distributor_id
- chargeback_claims: distributor_id
- serialized_units: distributor_id

## Transitive Tables

IoT telemetry carries no distributor of its own; it is scoped by joining up to
the shipment that produced it.

- iot_readings: shipment_id -> shipments.shipment_id

## Excluded Tables

- users
- roles
- role_lob_access
- user_attributes

## Ungoverned Tables

Reference data: no distributor column, no commercially sensitive rows.

- drug_products
- batch_lots

## Role Aliases

This deployment's role vocabulary, mapped onto known capability classes.
An alias grants a class; it cannot invent a permission.

- quality_lead: compliance_officer
- finance_controller: compliance_officer
- logistics_analyst: ma_analyst

## Scope Strategy

- predicate_pushdown_capable: bigquery, snowflake, databricks, redshift, postgres
- physical_sandbox: local_reference, sqlite_demo

## Enforcement

- deny_by_default: true
- require_scope_context: true
- forbid_unscoped_execution: true
