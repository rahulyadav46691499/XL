# Governed Metrics

Every metric names its own table, so the SQL compiler resolves it without a
payer base. Tables declared governed in governance.md get the distributor scope
predicate injected automatically.

### mean_kinetic_temperature
- label: Mean Kinetic Temperature (MKT)
- definition: Single temperature that, held constant, would cause the same thermal degradation as the observed profile. MKT = (dH/R) / -ln( (1/n) SUM exp(-dH/(R*T_i)) ), T_i in Kelvin, dH=83.144 kJ/mol, R=8.314 J/(mol K). Above 10 C a 2-8 C biologic's stability claim is invalid.
- formula: MKT over iot_readings.temp_c
- sql: mkt(t.temp_c)
- base: iot_readings
- table: iot_readings
- time_column:
- dims: shipment_id, sensor_id
- format: number
- depends: iot_readings.temp_c
- owner: Supply Chain Quality
- certified: true

### excursion_minutes
- label: Thermal Excursion Minutes above 15 C
- definition: Cumulative minutes a shipment spent above 15 C. The SLA invalidates stability beyond 120 continuous minutes.
- formula: SUM(30) WHERE temp_c > 15
- sql: SUM(CASE WHEN t.temp_c > 15 THEN 30 ELSE 0 END)
- base: iot_readings
- table: iot_readings
- time_column:
- dims: shipment_id
- format: number
- depends: iot_readings.temp_c
- owner: Supply Chain Quality
- certified: true

### units_spoiled
- label: Units Spoiled
- definition: Units confirmed unsaleable after transit.
- formula: SUM(units_spoiled)
- sql: SUM(t.units_spoiled)
- base: shipments
- table: shipments
- time_column: ship_quarter
- dims: hub_id, distributor_id, status
- format: number
- depends: shipments.units_spoiled
- owner: Supply Chain Quality
- certified: true

### spoilage_rate
- label: Spoilage Rate
- definition: Share of shipped units confirmed unsaleable.
- formula: SUM(units_spoiled) / SUM(units_shipped)
- sql: ROUND(SUM(t.units_spoiled) * 1.0 / NULLIF(SUM(t.units_shipped), 0), 4)
- base: shipments
- table: shipments
- time_column: ship_quarter
- dims: hub_id, distributor_id
- average: true
- format: percent
- depends: shipments.units_spoiled, shipments.units_shipped
- owner: Supply Chain Quality
- certified: true

### chargeback_leakage_variance
- label: Chargeback Leakage Variance (CLV)
- definition: Difference between the WAC amount claimed and the contractually agreed IWP amount. The gap a distributor captures above contract.
- formula: SUM(amount_claimed - amount_contract)
- sql: ROUND(SUM(t.amount_claimed - t.amount_contract), 2)
- base: chargeback_claims
- table: chargeback_claims
- time_column: claim_quarter
- dims: hub_id, distributor_id
- format: currency
- depends: chargeback_claims.amount_claimed, chargeback_claims.amount_contract
- owner: Finance Controller
- certified: true

### units_over_claimed
- label: Units Claimed for Chargeback
- definition: Units claimed for chargeback credit. Compared against confirmed spoilage to expose over-claim.
- formula: SUM(units_claimed)
- sql: SUM(t.units_claimed)
- base: chargeback_claims
- table: chargeback_claims
- time_column: claim_quarter
- dims: hub_id, distributor_id
- format: number
- depends: chargeback_claims.units_claimed
- owner: Finance Controller
- certified: true

### unverified_sgtin_count
- label: Unverified SGTINs
- definition: Serialized units whose product identifier could not be verified, or whose chain of custody is broken. DSCSA Title II requires a quarantine hold.
- formula: COUNT WHERE verified = 0 OR custody_broken = 1
- sql: SUM(CASE WHEN t.verified = 0 OR t.custody_broken = 1 THEN 1 ELSE 0 END)
- base: serialized_units
- table: serialized_units
- time_column:
- dims: lot_id, distributor_id
- format: number
- depends: serialized_units.verified, serialized_units.custody_broken
- owner: DSCSA Compliance
- certified: true
