# Entities, Columns & Joins

## Tables

### drug_products
NDC/GTIN catalogue with the labelled storage envelope per product.

### batch_lots
Manufactured lots. A lot is the unit a recall or stability failure applies to.

### shipments
One movement of a lot from a manufacturer through a distribution hub. Carries
units shipped and units spoiled, and is the scope anchor for telemetry.

### iot_readings
Raw data-logger time series: one temperature reading per sensor per 30 minutes.
Mean Kinetic Temperature is computed FROM these rows, never stored pre-baked.

### chargeback_claims
A distributor's claim for credit against spoiled or returned units. Carries the
WAC claimed and the contractually agreed IWP, so the variance is computable.

### serialized_units
DSCSA Title II serialized units (SGTIN). Verification state and chain-of-custody
integrity per unit.

## Columns

- drug_products.ndc: National Drug Code, primary key
- drug_products.gtin: GS1 Global Trade Item Number
- drug_products.storage_min_c: labelled lower storage bound, Celsius
- drug_products.storage_max_c: labelled upper storage bound, Celsius
- drug_products.biologic: 1 = 2-8 C biologic, stability-critical
- drug_products.wac_unit: Wholesaler Acquisition Cost per unit
- batch_lots.lot_id: manufacturing lot identifier
- batch_lots.units_released: units released to distribution
- shipments.shipment_id: primary key
- shipments.hub_id: distribution hub that handled the shipment
- shipments.distributor_id: scope column, the commercial owner
- shipments.ship_quarter: quarter of shipment, the time axis for trends
- shipments.units_spoiled: units confirmed unsaleable after transit
- iot_readings.temp_c: measured temperature, Celsius
- iot_readings.minutes_since_start: elapsed minutes, for excursion duration
- chargeback_claims.units_claimed: units the distributor claims credit for
- chargeback_claims.wac_claimed: WAC per unit as claimed
- chargeback_claims.iwp_contract: contractually agreed indirect wholesale price
- chargeback_claims.amount_claimed: total claimed
- chargeback_claims.amount_contract: total at contract price
- serialized_units.sgtin: serialized GTIN, unit-level identifier
- serialized_units.verified: 1 = product identifier verified per DSCSA
- serialized_units.custody_broken: 1 = chain of custody could not be established

## Joins

- shipments.lot_id = batch_lots.lot_id
- shipments.ndc = drug_products.ndc
- iot_readings.shipment_id = shipments.shipment_id
- chargeback_claims.shipment_id = shipments.shipment_id
- serialized_units.shipment_id = shipments.shipment_id

## Dimensions (shipments)

- hub_id: shipments.hub_id
- distributor_id: shipments.distributor_id
- ship_quarter: shipments.ship_quarter
- status: shipments.status
