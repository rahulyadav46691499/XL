# Reference Data

## Storage Envelopes

- 2-8 C: refrigerated biologic (Oncolytive, Vaxaria RSV, Insulistat)
- 15-25 C: controlled room temperature (Nephrolate)

## Standards

- DSCSA Title II: unit-level serialization, verification and interoperable tracing
- SGTIN: serialized GTIN, the unit-level identifier
- EPCIS: event standard for commissioning, shipping and receiving
- ICH Q1A(R2): stability testing; the MKT convention (dH 83.144 kJ/mol)
- WAC: Wholesaler Acquisition Cost; IWP: Indirect Wholesale Price
