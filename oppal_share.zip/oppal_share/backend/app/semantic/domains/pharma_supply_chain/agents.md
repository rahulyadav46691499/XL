# Departmental Agent Swarm

Five personas. None has a Python class — each declares its detector as SQL plus
a finding template, executed by the base DepartmentAgent. A persona with a
`case_type` also opens a de-duplicated case, which is what populates the Cases
tab without an engine change.

Model lineup: Haiku 4.5 classifies, Sonnet 5 analyses, Opus 5 is reserved for
high-impact write-back proposals.

## sentry
- department: Supply Chain Command
- role: Triage the question and decide which departmental agents to activate.
- triggers: *
- pillars: all
- tools: anomaly_scan, metric_trend
- detector: triage
- priority: 0
- always_on: true
- model_tier: cheap
- required_permission: agent_invoke_triage

## cold_chain_iot
- department: Cold Chain Quality
- role: Detect thermal excursions from raw data-logger series and compute MKT against the labelled envelope.
- triggers: cold chain, temperature, thermal, excursion, mkt, spoilage, spoiled, logger, iot, stability
- pillars: regulatory
- tools: metric_trend
- detector: brain_query
- priority: 10
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: thermal_excursion
- severity_column: mkt_c
- severity_threshold: 10
- impact_column: exposure_usd
- headline: Thermal excursion on lot {lot_id} at {hub_id} - MKT {mkt_c} C
- detail: {minutes_over} minutes above 15 C (SLA 120), peak {peak_c} C. MKT {mkt_c} C exceeds the 10 C stability ceiling, so {units_spoiled} units are unsaleable ({exposure_usd} USD at WAC).
- case_type: ColdChainCase
- case_subject_column: lot_id
- case_pattern: thermal_excursion
- query: SELECT s.lot_id, s.hub_id, s.shipment_id, s.distributor_id, s.units_spoiled, mkt(r.temp_c) AS mkt_c, MAX(r.temp_c) AS peak_c, SUM(CASE WHEN r.temp_c > 15 THEN 30 ELSE 0 END) AS minutes_over, ROUND(s.units_spoiled * 850.0, 2) AS exposure_usd FROM iot_readings r JOIN shipments s ON s.shipment_id = r.shipment_id GROUP BY s.shipment_id HAVING minutes_over > 120 AND mkt_c > 10 ORDER BY exposure_usd DESC

## dscsa_compliance
- department: DSCSA Compliance
- role: Verify serialized product identifiers and chain of custody; enforce the 24-hour quarantine hold.
- triggers: dscsa, sgtin, serialization, serialized, custody, chain of custody, verification, quarantine, epcis, traceability
- pillars: regulatory
- tools: policy_check
- detector: brain_query
- priority: 20
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: dscsa_exception
- severity: high
- headline: DSCSA verification failure on lot {lot_id} - {exceptions} SGTIN(s) unverified
- detail: {exceptions} of {total} serialized units on lot {lot_id} could not be verified or have a broken chain of custody. 21 CFR 203.50 requires a 24-hour quarantine hold before further distribution.
- case_type: DSCSACase
- case_subject_column: lot_id
- case_pattern: unverified_sgtin
- query: SELECT u.lot_id, COUNT(*) AS total, SUM(CASE WHEN u.verified = 0 OR u.custody_broken = 1 THEN 1 ELSE 0 END) AS exceptions FROM serialized_units u GROUP BY u.lot_id HAVING exceptions > 0 ORDER BY exceptions DESC

## chargeback_reconciliation
- department: Finance / Gross-to-Net
- role: Reconcile claimed chargeback units against confirmed spoilage and price claims against contract.
- triggers: chargeback, claim, claims, leakage, clv, wac, iwp, credit, recovery, overpayment, fraud, waste, abuse
- pillars: fwa
- tools: metric_trend, root_cause_additive
- detector: brain_query
- priority: 30
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_fwa
- finding_kind: chargeback_leakage
- severity_column: units_over
- severity_threshold: 100
- impact_column: leakage_usd
- min_impact: 1000
- headline: Chargeback over-claim at {hub_id} on lot {lot_id} - {units_over} units, {leakage_usd} USD
- detail: {hub_id} claimed {units_claimed} units against lot {lot_id} but only {units_spoiled} were confirmed spoiled. The {units_over}-unit excess is {leakage_usd} USD at {wac_claimed} WAC. Contract IWP is {iwp_contract}.
- case_type: ChargebackCase
- case_subject_column: incident
- case_pattern: chargeback_over_claim
- query: SELECT c.hub_id || ' / ' || c.lot_id AS incident, c.hub_id, c.lot_id, c.distributor_id, c.units_claimed, s.units_spoiled, (c.units_claimed - s.units_spoiled) AS units_over, c.wac_claimed, c.iwp_contract, ROUND((c.units_claimed - s.units_spoiled) * c.wac_claimed, 2) AS leakage_usd FROM chargeback_claims c JOIN shipments s ON s.shipment_id = c.shipment_id WHERE c.units_claimed > s.units_spoiled ORDER BY leakage_usd DESC

## supply_allocation
- department: Supply Planning
- role: Quantify saleable supply lost per lot so allocation can be re-planned.
- triggers: allocation, supply, shortage, inventory, availability, reallocate, planning
- pillars: risk_analytics
- tools: metric_trend
- detector: brain_query
- priority: 40
- always_on: false
- model_tier: analysis
- required_permission: agent_invoke_analytics
- finding_kind: supply_at_risk
- severity: medium
- impact_column: at_risk_usd
- min_impact: 50000
- headline: {units_spoiled} units of lot {lot_id} lost to spoilage - {at_risk_usd} USD at risk
- detail: Lot {lot_id} released {units_released} units; {units_spoiled} are unsaleable. Re-plan allocation for the affected hubs before the next release.
- query: SELECT s.lot_id, b.units_released, SUM(s.units_spoiled) AS units_spoiled, ROUND(SUM(s.units_spoiled) * 850.0, 2) AS at_risk_usd FROM shipments s JOIN batch_lots b ON b.lot_id = s.lot_id GROUP BY s.lot_id HAVING units_spoiled > 0 ORDER BY at_risk_usd DESC

## prescriptive_action
- department: Operations
- role: Convert qualifying findings into persistent, de-duplicated cases for human approval.
- triggers: *
- pillars: all
- tools: propose_action
- detector: propose_actions
- priority: 90
- always_on: true
- model_tier: writeback
- required_permission: agent_invoke_prescriptive

## Swarm Settings

- max_active_agents: 4
- min_active_agents: 1
- trust_gate: 0.85
- case_creation_min_trust: 0.60
- example_question: Are there supply or quality anomalies at any site or distributor?
