# Simulation Formulas

### recovery_net
- label: Net Chargeback Recovery
- definition: Recoverable over-claim after recovery cost and expected dispute leakage.
- formula: over_claimed_units * wac * (1 - dispute_rate) - recovery_cost
- dispute_rate: 0.05
- recovery_cost: 12000
- owner: Finance Controller

### spoilage_avoided
- label: Spoilage Avoided by Cold-Chain Remediation
- definition: Units preserved if excursion minutes are held under the SLA.
- formula: units_at_risk * remediation_effectiveness
- remediation_effectiveness: 0.72
- owner: Supply Chain Quality
