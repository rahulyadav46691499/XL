# FinOps Policy

- session_budget_usd: 5.00
- daily_budget_usd: 50.00
- kill_switch_on_breach: true
- cheap_tier_tasks: classification, triage, vocabulary_match
- analysis_tier_tasks: root_cause, correlation, narrative
- writeback_tier_tasks: action_proposal, policy_evaluation, compliance_audit
