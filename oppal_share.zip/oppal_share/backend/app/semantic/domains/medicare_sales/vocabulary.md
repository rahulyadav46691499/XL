# Business Vocabulary (term → canonical node)

How a Medicare Sales leader actually says it, mapped onto the governed metric
or dimension that answers it. Every term below is one an executive, sales
leader, marketing lead, enrolment operations manager or compensation analyst
uses in a real reporting conversation.

## Sales & portfolio

- sales => metric:effectuated_enrollments
- enrolments => metric:effectuated_enrollments
- enrollments => metric:effectuated_enrollments
- effectuated enrolments => metric:effectuated_enrollments
- effectuated enrollments => metric:effectuated_enrollments
- effectuated sales => metric:effectuated_enrollments
- volume => metric:effectuated_enrollments
- net growth => metric:net_membership_growth
- membership growth => metric:net_membership_growth
- net membership growth => metric:net_membership_growth
- premium => metric:enrollment_premium
- written premium => metric:enrollment_premium
- annualised premium => metric:enrollment_premium
- annualized premium => metric:enrollment_premium
- revenue per enrolment => metric:revenue_per_enrollment
- revenue per enrollment => metric:revenue_per_enrollment
- revenue per sale => metric:revenue_per_enrollment
- quota => metric:sales_to_goal_pct
- goal => metric:sales_to_goal_pct
- target => metric:sales_to_goal_pct
- sales to goal => metric:sales_to_goal_pct
- attainment => metric:sales_to_goal_pct
- pace => metric:daily_sales_pace
- sales pace => metric:daily_sales_pace
- daily pace => metric:daily_sales_pace
- required pace => metric:daily_sales_pace

## Lead & campaign

- lead quality => metric:qualified_lead_rate
- qualified lead rate => metric:qualified_lead_rate
- qualification rate => metric:qualified_lead_rate
- qualified leads => metric:qualified_lead_rate
- contact rate => metric:lead_to_contact_rate
- lead to contact => metric:lead_to_contact_rate
- contactability => metric:lead_to_contact_rate
- conversion => metric:lead_to_enrollment_rate
- lead conversion => metric:lead_to_enrollment_rate
- lead to enrolment => metric:lead_to_enrollment_rate
- lead to enrollment => metric:lead_to_enrollment_rate
- funnel conversion => metric:lead_to_enrollment_rate
- cpql => metric:cost_per_qualified_lead
- cost per qualified lead => metric:cost_per_qualified_lead
- cost per lead => metric:cost_per_qualified_lead
- lead cost => metric:cost_per_qualified_lead
- cac => metric:cost_per_effectuated_enrollment
- acquisition cost => metric:cost_per_effectuated_enrollment
- customer acquisition cost => metric:cost_per_effectuated_enrollment
- cost per enrolment => metric:cost_per_effectuated_enrollment
- cost per enrollment => metric:cost_per_effectuated_enrollment
- cost per sale => metric:cost_per_effectuated_enrollment
- response rate => metric:campaign_response_rate
- campaign response rate => metric:campaign_response_rate
- campaign performance => metric:campaign_response_rate
- marketing spend => metric:campaign_spend
- campaign spend => metric:campaign_spend
- media spend => metric:campaign_spend

## Agent, broker & channel

- agent conversion => metric:agent_conversion_rate
- broker conversion => metric:agent_conversion_rate
- agent conversion rate => metric:agent_conversion_rate
- close rate => metric:agent_conversion_rate
- effectuation by agent => metric:agent_conversion_rate
- persistency => metric:agent_persistency_rate
- agent persistency => metric:agent_persistency_rate
- broker persistency => metric:agent_persistency_rate
- channel cost => metric:channel_cost_per_enrollment
- channel cost per enrolment => metric:channel_cost_per_enrollment
- distribution cost => metric:channel_cost_per_enrollment
- commission => metric:commission_paid
- commissions => metric:commission_paid
- compensation => metric:commission_paid
- agent pay => metric:commission_paid
- broker pay => metric:commission_paid
- clawback => metric:clawback_exposure
- clawbacks => metric:clawback_exposure
- chargeback => metric:clawback_exposure
- recoupment => metric:clawback_exposure
- clawback exposure => metric:clawback_exposure
- unrecovered commission => metric:clawback_exposure
- follow up compliance => metric:lead_followup_compliance
- followup compliance => metric:lead_followup_compliance
- sla compliance => metric:lead_followup_compliance
- lead follow up => metric:lead_followup_compliance

## Enrolment & retention

- approval rate => metric:application_approval_rate
- application approval rate => metric:application_approval_rate
- effectuation => metric:approval_to_effectuation_rate
- effectuation rate => metric:approval_to_effectuation_rate
- approval to effectuation => metric:approval_to_effectuation_rate
- turnaround => metric:enrollment_turnaround_hours
- turnaround time => metric:enrollment_turnaround_hours
- tat => metric:enrollment_turnaround_hours
- processing time => metric:enrollment_turnaround_hours
- cancellation rate => metric:cancellation_before_effective_rate
- cancels => metric:cancellation_before_effective_rate
- cancel before effective => metric:cancellation_before_effective_rate
- pre effective cancellation => metric:cancellation_before_effective_rate
- rapid disenrolment => metric:rapid_disenrollment_rate
- rapid disenrollment => metric:rapid_disenrollment_rate
- fast disenrolment => metric:rapid_disenrollment_rate
- 90 day disenrolment => metric:rapid_disenrollment_rate
- retention => metric:member_retention_rate
- retention rate => metric:member_retention_rate
- member retention => metric:member_retention_rate
- 12 month retention => metric:member_retention_rate
- attrition => metric:member_retention_rate
- reconciliation => metric:enrollment_reconciliation_rate
- reconciliation rate => metric:enrollment_reconciliation_rate
- cms reconciliation => metric:enrollment_reconciliation_rate
- ctm => metric:ctm_complaint_rate
- complaints => metric:ctm_complaint_rate
- ctm rate => metric:ctm_complaint_rate
- grievances => metric:ctm_complaint_rate
- complaint rate => metric:ctm_complaint_rate

## Dimensions

- market => dim:market
- region => dim:market
- territory => dim:market
- geography => dim:market
- state => dim:state
- channel => dim:channel
- distribution channel => dim:channel
- lead source => dim:lead_source
- source => dim:lead_source
- vendor => dim:lead_source
- campaign => dim:campaign_id
- agent => dim:agent_id
- broker => dim:agent_id
- producer => dim:agent_id
- agency => dim:agency_id
- fmo => dim:agency_id
- plan type => dim:plan_type
- product => dim:plan_type
- contract => dim:contract_id
- cms contract => dim:contract_id
- pbp => dim:pbp_id
- plan benefit package => dim:pbp_id
- cohort => dim:cohort
- segment => dim:cohort
- age in => dim:cohort
- funnel stage => dim:funnel_stage
- stage => dim:funnel_stage
- election period => dim:enrollment_period
- aep => dim:enrollment_period
- oep => dim:enrollment_period
- quarter => dim:enrollment_quarter
- comm type => dim:comm_type
- commission type => dim:comm_type
- complaint category => dim:complaint_category
- total county fips => metric:total_county_fips
- avg county fips => metric:avg_county_fips
- total enrolled => metric:total_enrolled
- avg enrolled => metric:avg_enrolled
- total eligible => metric:total_eligible
- avg eligible => metric:avg_eligible
- cms market enrollment => metric:total_county_fips
