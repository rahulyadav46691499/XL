# Simulation Formulas

What-if formulas for the Medicare Sales remediation and growth levers. The
delta engine looks up a formula id here and holds no arithmetic literal of its
own — a missing id raises SimulationConfigError rather than falling back to a
hardcoded number.

### simulator_bindings
- definition: Binds this domain's metrics and physical tables into the what-if delta model. Without this section the engine falls back to its payer strings (mlr over claims joined to members, medical and pharmacy cost, a pharmacy reject count and a member population), which under a sales Brain means a named configuration error and a dead Simulator tab. Every `*_from` clause carries the alias the bound metric's SQL and the compiled cohort predicate expect: `c` for the cohort base, and a distinct alias per secondary table.
- ratio_metric: sim_lead_loss_ratio
- ratio_formula: lead_loss_ratio
- ratio_from: FROM leads c
- ratio_stress_key: sim_lead_loss_ratio
- cost_a_metric: sim_acquisition_cost
- cost_a_formula: acquisition_cost
- cost_a_from: FROM leads c
- cost_a_stress_key: sim_acquisition_cost
- cost_b_metric: sim_commission_cost
- cost_b_formula: commission_cost
- cost_b_from: FROM agent_commissions cm
- cost_b_scope_alias: cm.lob
- cost_b_stress_key: sim_commission_cost
- volume_metric: sim_cancellation_count
- volume_formula: cancellation_burden
- volume_from: FROM enrollments en
- volume_scope_alias: en.lob
- volume_stress_key: sim_cancellation_count
- population_formula: affected_leads
- population_sql: COUNT(DISTINCT m2.lead_id)
- population_from: FROM leads m2
- population_scope_alias: m2.lob
- net_formula: net_dollar_impact
- cohort_scope_alias: c.lob
- owner: Medicare Sales Analytics

### lead_loss_ratio
- label: Lead Loss Ratio
- definition: Share of leads that ended at funnel stage Lost. The ratio the simulator reports in basis points, chosen because lower is better — the same polarity as the payer's loss ratio, so the engine's favourable/adverse direction needs no domain-specific inversion.
- formula: COUNT(leads at stage Lost) / COUNT(leads)
- owner: Marketing & Growth

### acquisition_cost
- label: Allocated Acquisition Cost
- definition: Acquisition cost allocated to the leads in the baseline audience. The first cost leg of the net-impact calculation.
- formula: SUM(cost_allocated)
- owner: Finance

### commission_cost
- label: Compensation Cost
- definition: Compensation paid — commission, override and bonus — in the caller's scope. The second cost leg of the net-impact calculation.
- formula: SUM(commission_paid + override_paid + bonus_paid)
- owner: Sales Compensation

### cancellation_burden
- label: Cancellation Rework Burden
- definition: Enrolment-operations rework created by cancellations before the effective date. The count is stressed like any other lever; the per-cancellation minutes below convert the count into an operations burden.
- formula: cancellations * rework_minutes_per_cancellation
- pa_touch_minutes: 35
- pa_touch_minutes_note: Named pa_touch_minutes because the delta engine reads that leaf by name for the burden unit. In this domain it means minutes of enrolment-operations rework per cancelled enrolment — reconciling the CMS transaction, reversing the commission and contacting the beneficiary.
- owner: Enrolment Operations

### net_dollar_impact
- label: Net Dollar Impact
- definition: Acquisition cost avoided plus compensation cost avoided. Positive is a saving, negative an exposure.
- formula: (baseline_acquisition_cost - simulated_acquisition_cost) + (baseline_commission_cost - simulated_commission_cost)
- owner: Finance

### affected_leads
- label: Affected Leads
- definition: Distinct leads inside the caller's scope that the modelled change would touch. Reported as zero when no lever moved.
- formula: COUNT(DISTINCT lead_id)
- owner: Medicare Sales Analytics

### lead_source_suspension_net
- label: Net Saving from Suspending a Lead Source
- definition: Acquisition spend recovered by pausing an underperforming lead source, net of the enrolments that source would still have delivered and the cost of replacing them through a compliant source at the peer rate.
- formula: source_spend - (source_effectuated * peer_cost_per_effectuated) * (1 - replacement_gap)
- replacement_gap: 0.20
- owner: Marketing & Growth

### commission_recovery_net
- label: Net Commission Recovery
- definition: Compensation recoverable on enrolments that never effectuated, after recovery cost and expected agent dispute leakage.
- formula: overpaid_commission * (1 - dispute_rate) - recovery_cost
- dispute_rate: 0.18
- recovery_cost: 750
- owner: Sales Compensation

### retention_remediation_net
- label: Net Value of Channel Retention Remediation
- definition: Annualised premium protected by remediating a channel's rapid-disenrolment pattern, at the expected remediation success rate, less the cost of the conduct review and agent retraining.
- formula: premium_at_risk * remediation_success_rate - review_cost
- remediation_success_rate: 0.45
- review_cost: 12000
- owner: Distribution Leadership
