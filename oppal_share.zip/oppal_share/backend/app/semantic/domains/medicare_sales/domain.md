# Medicare Sales

- icon: 📈
- description: Governed Medicare Sales reporting and analytics across the lead → contact → application → approval → enrolment → effectuation → retention lifecycle. Covers lead and campaign effectiveness, agent/broker and channel performance, enrolment and retention outcomes, and CMS marketing and compensation compliance under 42 CFR §422.2264 and §422.2274.
- owner: Medicare Sales Analytics
