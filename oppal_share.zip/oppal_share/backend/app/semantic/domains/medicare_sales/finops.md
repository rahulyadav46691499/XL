# FinOps Policy

Cost and savings policy for the Medicare Sales domain. Model rates stay in
`llm.base.PRICING_PER_M`; this section governs how those rates become reported
figures, which task classes may use the cheap tier, and the advisory budget
thresholds.

### budget
- session_budget_usd: 5.00
- daily_budget_usd: 50.00
- kill_switch_on_breach: true
- owner: Analytics Engineering

### tiering
- cheap_tier_tasks: classification, triage, vocabulary_match
- analysis_tier_tasks: root_cause, correlation, narrative
- writeback_tier_tasks: action_proposal, policy_evaluation, compliance_audit
- tiering_note: Trust-critical work is never routed to the cheap tier. A compensation recovery or an agent suspension is gated on a trust score, so the model that produced the score cannot be the cheapest one available.
- owner: Analytics Engineering

### reporting
- latency_percentile: 95
- reconcile_session_against_global: true
- reconciliation_tolerance_usd: 0.01
- owner: Analytics Engineering
