# Data Governance & Scoping Rules

Declarative RBAC/ABAC data-scoping rules read by the MCP Zero-Copy layer's
ScopeEnforcer. Scope is the line of business, the same as the payer domain — a
Medicare Sales organisation sells across Medicare Advantage, D-SNP/Medicaid and
Commercial/ACA, and an analyst carrying one of those books sees only that book.

Because this dataset's `lob` values are exactly the payer's four, the existing
`role_lob_access` grants apply unchanged and the dataset loader seeds no new
ones. `market`, `state`, `county`, `contract_id`, `plan_id`, `plan_type`,
`channel`, `lead_source`, `campaign_id`, `funnel_stage`, `cohort` and `agent_id`
are analysis dimensions, not scope boundaries.

## Scope Column

- lob

## Governed Tables

Every table carrying a beneficiary or prospect record. All six carry `lob`
directly and are scoped on it.

- leads: lob
- applications: lob
- enrollments: lob
- agent_commissions: lob
- interactions: lob
- sales_targets: lob

## Transitive Tables

`lead_activities` carries no LOB of its own — an outreach event inherits the
scope of the lead it is against. This exercises the same transitive path the
payer domain uses for `products -> plans`.

- lead_activities: lead_id -> leads.lead_id

## Excluded Tables

Credential, identity and RBAC-directory tables. Never exposed to an analytical
query at any scope.

- users
- roles
- role_lob_access
- user_attributes

The remaining entries are the OTHER domains' warehouse tables. They live in the
same physical SQLite file, and the scope enforcer copies any table it does not
recognise into the caller's data plane unfiltered — a table absent from this
domain's governed and transitive maps is treated as ungoverned reference data.
Payer claims are not reference data for a Medicare Sales analyst, so they are
excluded outright rather than left to be copied whole. Excluding a table that
does not exist is a no-op, so this list is safe in a deployment that ships only
this domain.

- claims
- members
- providers
- pharmacy_claims
- prior_auth
- plans
- products
- benefit_packages
- hedis_measure_results
- medicaid_coding_worksheet
- drug_products
- batch_lots
- shipments
- iot_readings
- chargeback_claims
- serialized_units

## Ungoverned Tables

Reference data that is legitimately cross-line-of-business and contains no
beneficiary or prospect record. An agent directory, a certification register, a
campaign ledger and a plan/PBP catalogue describe the plan's own distribution
and product estate, not its members — scoping them to one book would make the
agent who sells across three books invisible in two of them.

`cms_market_enrollment` is listed here because it is public CMS data. It is not
loaded by the dataset builder: it arrives through the Data tab importer and is
catalogued as `imported`, at which point this declaration governs it.

- sales_agents
- agent_certifications
- campaigns
- plan_benefit_packages
- cms_market_enrollment

## Role Aliases

This deployment's Medicare Sales role vocabulary, mapped onto known capability
classes. An alias grants a class; it cannot invent a permission.

- sales_compliance_officer: compliance_officer
- sales_ops_analyst: ma_analyst
- distribution_analyst: ma_analyst
- marketing_analyst: ma_analyst
- enrolment_ops_analyst: ma_analyst

## Scope Strategy

- predicate_pushdown_capable: bigquery, snowflake, databricks, redshift, postgres
- physical_sandbox: local_reference, sqlite_demo

## Enforcement

- deny_by_default: true
- require_scope_context: true
- forbid_unscoped_execution: true
