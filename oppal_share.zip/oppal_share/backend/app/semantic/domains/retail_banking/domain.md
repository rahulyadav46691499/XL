# Retail Banking (template)
- icon: 🏦
- description: Template domain proving configurability — fill entities.md, metrics.md, vocabulary.md, reference.md, policy_rules.md and prompts.md, then Activate. The engine adapts with zero code changes.
- tables: accounts, customers, transactions
