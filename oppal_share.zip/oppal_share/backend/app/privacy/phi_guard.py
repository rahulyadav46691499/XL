"""PHI/PII protector.

Wraps every LLM provider so protected health information and personal
identifiers NEVER leave the backend in plain form:

  1. Detect  — regex + schema-aware patterns: member IDs, claim IDs,
     provider IDs, person names ("Dr. Maya B."), SSNs, phone numbers,
     emails, dates of birth, street addresses, ZIP codes.
  2. Pseudonymize — replace with deterministic HMAC-derived tokens
     (same input -> same token, so the LLM can still reason about
     repeated entities: "MEMBER_4f2a1c had 3 claims").
  3. Detokenize — LLM responses are re-identified locally before being
     shown to the user, using the in-memory vault (never persisted).

The mapping salt is generated per process; the vault lives only in
memory. With the mock provider nothing leaves the machine at all.
"""
import hashlib
import hmac
import os
import re

_SALT = os.urandom(16)

PATTERNS = [
    # schema-aware identifiers first (most specific)
    ("MBI", re.compile(  # Medicare Beneficiary Identifier, e.g. 4EG5-TE1-MK72
        r"\b[1-9][AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y0-9]\d-?"
        r"[AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y0-9]\d-?"
        r"[AC-HJKMNP-RT-Y]{2}\d\d\b")),
    ("NPI", re.compile(r"\b[12]\d{9}\b")),   # National Provider Identifier
    ("MEMBER", re.compile(r"\bM-\d{6}\b")),
    ("CLAIM", re.compile(r"\bC-\d{7}\b")),
    ("PROVIDER", re.compile(r"\bPR-\d{3}\b")),
    ("NAME", re.compile(r"\bDr\.\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]*\.?)+")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    # undashed SSN — only meaningful for exactly-9-digit values, which
    # scrub_value() gates on so it cannot swallow a monetary amount
    ("SSN_RAW", re.compile(r"^\d{9}$")),
    ("PHONE", re.compile(r"\b(?:\+1[ .-]?)?\(?\d{3}\)?[ .-]?\d{3}[ .-]?\d{4}\b")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")),
    ("DOB", re.compile(r"\b(?:19|20)\d{2}-\d{2}-\d{2}\b")),
    ("ADDRESS", re.compile(r"\b\d{1,5}\s+[A-Z][a-z]+\s+(?:St|Ave|Rd|Blvd|Ln|Dr|Way|Ct)\.?\b")),
    ("ZIP", re.compile(r"\b\d{5}(?:-\d{4})?\b")),
]


# Patterns that are UNAMBIGUOUS identifiers — safe to apply to structured
# write-back payloads. "ZIP" is deliberately excluded: \d{5} also matches a
# dollar amount (e.g. "10000"), and silently tokenizing a monetary value in an
# outbound payload would corrupt a client's system of record.
_STRUCTURED_SAFE_KINDS = {"MBI", "NPI", "MEMBER", "CLAIM", "PROVIDER", "NAME",
                          "SSN", "SSN_RAW", "EMAIL", "DOB", "ADDRESS"}


class PHIGuard:
    """Reversible pseudonymizer with an in-memory token vault."""

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.vault: dict[str, str] = {}      # token -> original
        self.last_report: dict[str, int] = {}

    def _token(self, kind: str, value: str) -> str:
        digest = hmac.new(_SALT, value.encode(), hashlib.sha256).hexdigest()[:6]
        return f"{kind}_{digest}"

    # -- structured (payload) scrubbing ------------------------------------
    def _sub(self, out: str, kinds) -> str:
        for kind, pattern in PATTERNS:
            if kind not in kinds:
                continue

            def repl(m, kind=kind):
                tok = self._token(kind, m.group(0))
                self.vault[tok] = m.group(0)
                return tok
            out = pattern.sub(repl, out)
        return out

    def scrub_value(self, value):
        """Scrub a single scalar for STRUCTURED payloads.

        A purely numeric string is NOT blanket-skipped — that would make the
        all-digit identifier patterns (NPI, undashed SSN) dead code. Instead
        numeric strings are matched against the long numeric identifiers only,
        so a 10-digit NPI or a 9-digit SSN is still tokenized while a monetary
        amount ("10000", "-42.50") passes through untouched.
        """
        if not self.enabled or not isinstance(value, str) or not value:
            return value
        stripped = value.strip()
        is_numeric = False
        try:
            float(stripped.replace(",", ""))
            is_numeric = True
        except (TypeError, ValueError):
            pass
        if is_numeric:
            # only identifiers that are unambiguous at their exact length:
            # NPI = 10 digits starting 1|2, undashed SSN = 9 digits. Monetary
            # amounts of that magnitude do not occur in a claim payload.
            digits = stripped.replace(",", "").lstrip("+-")
            if digits.isdigit() and len(digits) in (9, 10):
                return self._sub(value, {"NPI", "SSN_RAW"})
            return value
        return self._sub(value, _STRUCTURED_SAFE_KINDS)

    def scrub_structure(self, obj):
        """Recursively scrub dicts / lists / tuples / scalars — INCLUDING dict
        keys, which can also carry an identifier (e.g. {"M-123456": ...})."""
        if isinstance(obj, dict):
            return {self.scrub_value(k) if isinstance(k, str) else k:
                    self.scrub_structure(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            scrubbed = [self.scrub_structure(v) for v in obj]
            return type(obj)(scrubbed) if isinstance(obj, tuple) else scrubbed
        return self.scrub_value(obj)

    def scrub(self, text: str) -> tuple[str, dict]:
        """Replace PHI/PII with tokens. Returns (clean_text, report)."""
        if not self.enabled or not text:
            return text, {}
        report: dict[str, int] = {}
        out = text
        for kind, pattern in PATTERNS:
            def repl(m):
                tok = self._token(kind, m.group(0))
                self.vault[tok] = m.group(0)
                report[kind] = report.get(kind, 0) + 1
                return tok
            out = pattern.sub(repl, out)
        self.last_report = report
        return out, report

    def detokenize(self, text: str) -> str:
        """Re-identify tokens in an LLM response (local only)."""
        if not self.enabled or not text:
            return text
        return re.sub(
            r"\b(?:MBI|NPI|MEMBER|CLAIM|PROVIDER|NAME|SSN|PHONE|EMAIL|DOB|ADDRESS|ZIP)_[0-9a-f]{6}\b",
            lambda m: self.vault.get(m.group(0), m.group(0)), text)


class GuardedProvider:
    """Decorator around any LLMProvider: scrub out, detokenize in."""

    def __init__(self, inner, guard: PHIGuard):
        self.inner = inner
        self.guard = guard
        self.name = f"{inner.name}+phi-guard"

    def complete(self, system, user, json_mode=False):
        clean_sys, r1 = self.guard.scrub(system)
        clean_usr, r2 = self.guard.scrub(user)
        self.guard.last_report = {
            k: r1.get(k, 0) + r2.get(k, 0) for k in {**r1, **r2}}
        out = self.inner.complete(clean_sys, clean_usr, json_mode)
        return self.guard.detokenize(out) if out else out

    def complete_json(self, system, user):
        # reuse base parsing on the detokenized text
        from ..llm.base import LLMProvider
        return LLMProvider.complete_json(self, system, user)  # type: ignore
