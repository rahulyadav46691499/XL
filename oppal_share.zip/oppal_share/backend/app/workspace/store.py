"""VS Workspace persistence (Phase 5, REQ-5.6-5.8).

Pins durable artifacts — simulation results, saved charts/grids — onto a
named, LOB-scoped, drag/resize-able dashboard. Mirrors the
``agents/case_store.py`` sqlite + ABAC-visibility pattern. ``lineage_for``
answers REQ-5.8: given a pinned artifact, resolve back to the journey/trust/
logic-tree snapshot that produced it (today: simulation runs; a chat-chart
artifact degrades to its stored spec, gracefully, with empty trust/logic
sections rather than an error).
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import uuid
from datetime import datetime, timezone

from ..schemas.workspace import (Artifact, ArtifactPin, GridItem, ShareGrant,
                                 Workspace, WorkspaceSummary)

log = logging.getLogger("oppal.workspace")

WORKSPACE_DB = os.environ.get(
    "OPPAL_WORKSPACE_DB",
    os.path.join(os.path.dirname(os.path.dirname(__file__)), "data",
                 "workspaces.db"))
_lock = threading.Lock()


def _con():
    os.makedirs(os.path.dirname(WORKSPACE_DB), exist_ok=True)
    con = sqlite3.connect(WORKSPACE_DB, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS workspaces (
            id TEXT PRIMARY KEY, name TEXT, owner TEXT, lob TEXT,
            layout_json TEXT, artifacts_json TEXT,
            created_at TEXT, updated_at TEXT)""")
    # Migration: dashboards created before per-user sharing existed have no
    # shared_with column. Add it in place rather than recreating the table, so
    # an existing install keeps its boards. Absent column => no grants => the
    # board becomes private to its owner, which is the safe direction: a
    # migration must never widen access.
    cols = {r["name"] for r in con.execute("PRAGMA table_info(workspaces)")}
    if "shared_with_json" not in cols:
        con.execute("ALTER TABLE workspaces ADD COLUMN shared_with_json TEXT")
        con.commit()
    return con


def _row_to_workspace(row) -> Workspace:
    d = dict(row)
    return Workspace(
        id=d["id"], name=d["name"], owner=d["owner"], lob=d["lob"],
        layout=[GridItem(**g) for g in json.loads(d["layout_json"] or "[]")],
        artifacts=[Artifact(**a) for a in
                  json.loads(d["artifacts_json"] or "[]")],
        created_at=d["created_at"] or "", updated_at=d["updated_at"] or "",
        shared_with=[ShareGrant(**g) for g in
                     json.loads(d.get("shared_with_json") or "[]")])


def _save(ws: Workspace) -> None:
    with _lock:
        con = _con()
        try:
            con.execute(
                "INSERT OR REPLACE INTO workspaces "
                "(id, name, owner, lob, layout_json, artifacts_json, "
                " created_at, updated_at, shared_with_json) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (ws.id, ws.name, ws.owner, ws.lob,
                 json.dumps([g.model_dump() for g in ws.layout]),
                 json.dumps([a.model_dump() for a in ws.artifacts]),
                 ws.created_at, ws.updated_at,
                 json.dumps([g.model_dump() for g in ws.shared_with])))
            con.commit()
        finally:
            con.close()


def _uid(scope) -> str:
    """The calling principal's user id. Empty string is never a match."""
    return getattr(scope, "user_id", None) or ""


def access_level(ws: Workspace, scope) -> str | None:
    """What the caller may do with this board: 'owner' | 'edit' | 'view' |
    None.

    A dashboard is PRIVATE to its owner. Access is granted only by an explicit
    per-user share. The previous rule ORed in ``_can_see(ws.lob, scope)``,
    which — because ``ws.lob`` is the owner's scope LABEL, not a real
    restriction — meant any two principals holding the same LOB authorization
    could read AND write each other's dashboards. Identical authorization is
    not identity; LOB scope is a data-access boundary, not a personal one.
    """
    uid = _uid(scope)
    if not uid:
        return None
    if ws.owner and ws.owner == uid:
        return "owner"
    for g in ws.shared_with:
        if g.user_id == uid:
            return g.level          # "view" or "edit"
    return None


def _visible(ws: Workspace, scope) -> bool:
    return access_level(ws, scope) is not None


def _can_write(ws: Workspace, scope) -> bool:
    return access_level(ws, scope) in ("owner", "edit")


# ---------------------------------------------------------------------------
def create(name: str, user: dict, scope) -> Workspace:
    from ..agents.case_store import scope_label
    now = datetime.now(timezone.utc).isoformat()
    ws = Workspace(id=f"WS-{uuid.uuid4().hex[:10]}", name=name,
                   owner=user.get("user_id", ""),
                   lob=scope_label(scope) or "", created_at=now,
                   updated_at=now)
    _save(ws)
    return ws


def list_for(scope) -> list:
    """Boards the caller owns, plus boards explicitly shared with them.

    Filtered in SQL on ``owner`` first (so an unrelated user's rows are never
    even materialised), then re-checked in Python for the share case. The
    belt-and-braces double check mirrors the Phase 4 "engine and adapter both
    re-verify" convention: a future query change cannot silently widen access
    without also defeating ``access_level``.
    """
    uid = _uid(scope)
    if not uid:
        return []
    con = _con()
    try:
        rows = con.execute(
            "SELECT * FROM workspaces WHERE owner = ? "
            "   OR (shared_with_json IS NOT NULL "
            "       AND shared_with_json LIKE ?) "
            "ORDER BY updated_at DESC",
            (uid, f'%"{uid}"%')).fetchall()
    finally:
        con.close()
    out = []
    for r in rows:
        ws = _row_to_workspace(r)
        lvl = access_level(ws, scope)
        if lvl:                      # authoritative check, not the LIKE
            out.append(WorkspaceSummary(
                id=ws.id, name=ws.name, owner=ws.owner, lob=ws.lob,
                artifact_count=len(ws.artifacts), updated_at=ws.updated_at,
                access=lvl, shared_with=ws.shared_with))
    return out


def own_or_create_default(user: dict, scope) -> Workspace:
    """The caller's own most-recent board, creating one if they have none.

    Pinning used to target ``boards[0]`` of a list ordered by ``updated_at``
    across every VISIBLE board — so a chart could be pinned into someone
    else's dashboard. Pin targets must be owned, never merely visible.
    """
    uid = _uid(scope)
    mine = [w for w in list_for(scope) if w.owner == uid]
    if mine:
        ws = get(mine[0].id, scope)
        if ws:
            return ws
    return create("My Dashboard", user, scope)


def get(ws_id: str, scope) -> Workspace | None:
    con = _con()
    try:
        row = con.execute("SELECT * FROM workspaces WHERE id = ?",
                          (ws_id,)).fetchone()
    finally:
        con.close()
    if not row:
        return None
    ws = _row_to_workspace(row)
    return ws if _visible(ws, scope) else None


def _for_write(ws_id: str, scope) -> Workspace:
    """Load a board the caller may MODIFY. A 'view' grant is not enough."""
    ws = get(ws_id, scope)
    if not ws:
        raise PermissionError("workspace not found in your authorized scope")
    if not _can_write(ws, scope):
        raise PermissionError(
            "this dashboard was shared with you as view-only")
    return ws


def set_layout(ws_id: str, layout: list, scope) -> Workspace:
    ws = _for_write(ws_id, scope)
    ws.layout = [g if isinstance(g, GridItem) else GridItem(**g)
                for g in layout]
    ws.updated_at = datetime.now(timezone.utc).isoformat()
    _save(ws)
    return ws


def share(ws_id: str, grantee: str, level: str, scope) -> Workspace:
    """Grant another USER access. Owner-only: a shared-with-edit recipient
    must not be able to re-share someone else's board onward."""
    ws = get(ws_id, scope)
    if not ws:
        raise PermissionError("workspace not found in your authorized scope")
    if access_level(ws, scope) != "owner":
        raise PermissionError("only the owner can share this dashboard")
    grantee = (grantee or "").strip()
    if not grantee:
        raise ValueError("a grantee user_id is required")
    if grantee == ws.owner:
        raise ValueError("the owner already has full access")
    now = datetime.now(timezone.utc).isoformat()
    kept = [g for g in ws.shared_with if g.user_id != grantee]
    ws.shared_with = kept + [ShareGrant(
        user_id=grantee, level=level, granted_by=_uid(scope), granted_at=now)]
    ws.updated_at = now
    _save(ws)
    return ws


def unshare(ws_id: str, grantee: str, scope) -> Workspace:
    ws = get(ws_id, scope)
    if not ws:
        raise PermissionError("workspace not found in your authorized scope")
    if access_level(ws, scope) != "owner":
        raise PermissionError("only the owner can change sharing")
    ws.shared_with = [g for g in ws.shared_with if g.user_id != grantee]
    ws.updated_at = datetime.now(timezone.utc).isoformat()
    _save(ws)
    return ws


GRID_COLS = 8
DEFAULT_W, DEFAULT_H = 4, 2


def _overlaps(a, b) -> bool:
    return not (a["x"] + a["w"] <= b.x or b.x + b.w <= a["x"]
                or a["y"] + a["h"] <= b.y or b.y + b.h <= a["y"])


def next_free_slot(layout, w: int = DEFAULT_W, h: int = DEFAULT_H,
                   cols: int = GRID_COLS) -> dict:
    """First grid position that collides with nothing, scanned row by row.

    Pinning previously stored NO layout entry, so the UI fell back to a
    hardcoded {x:0, y:0} for every artifact and each new chart landed exactly
    on top of the last one in row 1 / column 1. A pin has to claim its own
    space at the moment it is created, otherwise "add to dashboard" silently
    means "hide the previous chart".
    """
    for y in range(0, 200):
        for x in range(0, max(1, cols - w + 1)):
            cand = {"x": x, "y": y, "w": w, "h": h}
            if not any(_overlaps(cand, g) for g in layout):
                return cand
    return {"x": 0, "y": 0, "w": w, "h": h}


def pin_artifact(ws_id: str, pin: ArtifactPin, scope) -> Artifact:
    ws = _for_write(ws_id, scope)
    artifact = Artifact(
        id=f"ART-{uuid.uuid4().hex[:10]}", type=pin.type, spec=pin.spec,
        lineage_ref=pin.lineage_ref,
        created_at=datetime.now(timezone.utc).isoformat())
    ws.artifacts = list(ws.artifacts) + [artifact]
    slot = next_free_slot(ws.layout)
    ws.layout = list(ws.layout) + [GridItem(artifact_id=artifact.id, **slot)]
    ws.updated_at = artifact.created_at
    _save(ws)
    return artifact


def autoarrange(ws_id: str, scope, cols: int = GRID_COLS) -> Workspace:
    """Repack every artifact into a tidy, gap-free grid, preserving each
    card's own width/height so a deliberately wide chart stays wide."""
    ws = _for_write(ws_id, scope)
    by_id = {g.artifact_id: g for g in ws.layout}
    placed: list = []
    out: list = []
    for a in ws.artifacts:
        old = by_id.get(a.id)
        w = min(cols, max(1, old.w if old else DEFAULT_W))
        h = max(1, old.h if old else DEFAULT_H)
        slot = next_free_slot(placed, w, h, cols)
        item = GridItem(artifact_id=a.id, **slot)
        out.append(item)
        placed.append(item)
    ws.layout = out
    ws.updated_at = datetime.now(timezone.utc).isoformat()
    _save(ws)
    return ws


def rename_artifact(ws_id: str, artifact_id: str, title: str, scope):
    """Set a pinned artifact's display title.

    Titles are machine-generated from the metric and intent, which reads
    badly in a board pack. Renaming writes to the artifact's own spec so the
    new name follows it into exports and PNGs — a rename that only lived in
    the browser would silently revert for the next reader.
    """
    ws = _for_write(ws_id, scope)
    title = str(title or "").strip()[:120]
    hit = None
    for a in ws.artifacts:
        if a.id == artifact_id:
            hit = a
            break
    if not hit:
        return None
    spec = dict(hit.spec or {})
    spec["title"] = title
    hit.spec = spec
    ws.updated_at = datetime.now(timezone.utc).isoformat()
    _save(ws)
    return hit


def delete_artifact(ws_id: str, artifact_id: str, scope) -> bool:
    ws = _for_write(ws_id, scope)
    before = len(ws.artifacts)
    ws.artifacts = [a for a in ws.artifacts if a.id != artifact_id]
    ws.layout = [g for g in ws.layout if g.artifact_id != artifact_id]
    ws.updated_at = datetime.now(timezone.utc).isoformat()
    _save(ws)
    return len(ws.artifacts) < before


def _find_artifact(artifact_id: str, scope):
    """Resolve an artifact id, but only within boards the caller may see.

    Scoped in SQL as well as in Python: an artifact id is guessable, and
    lineage_for() must not become an oracle that confirms the existence of
    another user's pinned artifact.
    """
    uid = _uid(scope)
    if not uid:
        return None, None
    con = _con()
    try:
        rows = con.execute(
            "SELECT * FROM workspaces WHERE owner = ? "
            "   OR (shared_with_json IS NOT NULL "
            "       AND shared_with_json LIKE ?)",
            (uid, f'%"{uid}"%')).fetchall()
    finally:
        con.close()
    for r in rows:
        ws = _row_to_workspace(r)
        if not _visible(ws, scope):
            continue
        for a in ws.artifacts:
            if a.id == artifact_id:
                return ws, a
    return None, None


def lineage_for(artifact_id: str, scope) -> dict:
    """REQ-5.8 — journey/trust/logic-tree for a pinned artifact. Degrades
    gracefully for artifact types that don't carry a simulation lineage."""
    ws, artifact = _find_artifact(artifact_id, scope)
    if not artifact:
        return {"journey": [], "trust": None, "logic_tree": {},
               "found": False}
    ref = artifact.lineage_ref or ""
    if ref.startswith("SIM-LOGIC-"):
        run_id = ref[len("SIM-LOGIC-"):]
        try:
            from ..simulation import engine as sim_engine
            logic = sim_engine.get_logic_tree(run_id, scope)
        except Exception:                                 # pragma: no cover
            log.debug("lineage lookup failed for %s", ref, exc_info=True)
            logic = None
        if logic:
            return {"journey": [{"step": "simulation_run", "run_id":
                                run_id}],
                   "trust": logic.get("trust"), "logic_tree": logic,
                   "found": True}
    return {"journey": [{"step": "pinned", "artifact_id": artifact.id,
                        "type": artifact.type}],
           "trust": None, "logic_tree": {"spec": artifact.spec},
           "found": True}


def reset():
    """Test helper."""
    with _lock:
        con = _con()
        try:
            con.execute("DELETE FROM workspaces")
            con.commit()
        finally:
            con.close()


__all__ = ["create", "list_for", "get", "set_layout", "pin_artifact",
           "delete_artifact", "lineage_for", "reset", "share", "unshare",
           "access_level", "own_or_create_default", "autoarrange",
           "next_free_slot", "GRID_COLS", "rename_artifact"]
