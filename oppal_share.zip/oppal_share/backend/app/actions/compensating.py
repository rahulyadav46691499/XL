"""Compensating actions — credit / void reversal of an EXECUTED action
(Phase 6 amendment, Phase 4 handoff Limitation 2).

The ledger is append-only; a reversal is NEVER an edit. This module proposes
a compensating action through the EXACT SAME dual-control + double-gate +
adapter path as any other Phase 4 action (``action_type="compensating"``),
so no new authorization surface is introduced. Two independent, Brain-driven
paths force dual control on every compensation (belt-and-braces, mirroring
the Phase 4 "engine + adapter both re-check" philosophy):

  1. ``compensating`` is listed in ``policy_rules.md``'s
     ``ACT-DUAL-CONTROL.dual_control_action_types``.
  2. Every compensation is proposed at ``regulatory_severity="critical"``,
     which is itself a ``regulatory_severity_triggers`` value.

``propose_compensation`` refuses outright (``CompensationError``) if, despite
both paths, the resulting control mode is ever not DUAL — a compensation can
never be single-approved.

Once the compensating ActionRequest itself reaches EXECUTED (via the normal
``/api/actions/{id}/execute`` path), ``finalize_compensation`` marks the
ORIGINAL action COMPENSATED and appends the cryptographic void/credit block
to the v2 ledger, backlinked to the original entry's ``record_hash`` AND its
``ActionPayload.payload_hash()`` (F1).
"""
from __future__ import annotations

import logging
import os
import sqlite3
import threading
from datetime import datetime, timezone
from decimal import Decimal

from ..schemas.actions import (ActionPayload, ActionState, CompensationRequest,
                               ControlMode)
from . import engine

log = logging.getLogger("oppal.actions.compensating")

COMP_DB = os.environ.get(
    "OPPAL_COMPENSATION_DB",
    os.path.join(os.path.dirname(os.path.dirname(__file__)), "data",
                 "compensations.db"))
_lock = threading.Lock()


class CompensationError(Exception):
    """Refused: not EXECUTED, dual control could not be established, or the
    Pydantic contract (maker!=checker-safe credit validator) rejected the
    request."""


def _con():
    os.makedirs(os.path.dirname(COMP_DB), exist_ok=True)
    con = sqlite3.connect(COMP_DB, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS compensations (
            compensating_action_id TEXT PRIMARY KEY,
            original_action_id TEXT, mode TEXT, credit_amount TEXT,
            reason TEXT, compensates_record_hash TEXT,
            compensates_payload_hash TEXT, finalized INTEGER DEFAULT 0,
            created_at TEXT)""")
    return con


def _save_link(compensating_action_id, original_action_id, mode,
              credit_amount, reason, record_hash, payload_hash):
    with _lock:
        con = _con()
        try:
            con.execute(
                "INSERT OR REPLACE INTO compensations VALUES "
                "(?,?,?,?,?,?,?,0,?)",
                (compensating_action_id, original_action_id, mode,
                 str(credit_amount) if credit_amount is not None else None,
                 reason, record_hash, payload_hash,
                 datetime.now(timezone.utc).isoformat()))
            con.commit()
        finally:
            con.close()


def _get_link(compensating_action_id):
    con = _con()
    try:
        row = con.execute(
            "SELECT * FROM compensations WHERE compensating_action_id = ?",
            (compensating_action_id,)).fetchone()
    finally:
        con.close()
    return dict(row) if row else None


def _mark_finalized(compensating_action_id):
    with _lock:
        con = _con()
        try:
            con.execute(
                "UPDATE compensations SET finalized = 1 WHERE "
                "compensating_action_id = ?", (compensating_action_id,))
            con.commit()
        finally:
            con.close()


def _find_executed_ledger_record(original_action_id: str) -> dict | None:
    """The original action's ``executed`` ledger commitment — the
    cryptographic backlink target (F1)."""
    from ..trust.audit_ledger import read_all
    matches = [r for r in read_all()
              if r.get("kind") == "action" and r.get("event") == "executed"
              and r.get("action_id") == original_action_id]
    return matches[-1] if matches else None


def _always_dual_by_brain() -> bool:
    from ..semantic.brain import get_brain
    for r in get_brain().get("policy_rules", []):
        if r.get("check") == "action_compensation":
            return str(r.get("always_dual_control", "")).strip().lower() \
                in ("true", "1", "yes")
    return False


# ---------------------------------------------------------------------------
def propose_compensation(action_id: str, body: dict, user: dict, scope):
    """``action_id`` is the ORIGINAL action (path param); ``body`` is the
    raw request dict validated here into a ``CompensationRequest``."""
    body = dict(body or {})
    body.setdefault("original_action_id", action_id)
    if body["original_action_id"] != action_id:
        raise CompensationError(
            "original_action_id in the body must match the path action id")
    req = CompensationRequest(**body)          # raises ValidationError -> 422

    original = engine.get(action_id, scope)
    if not original:
        raise PermissionError("action not found in your authorized scope")
    if original.state != ActionState.EXECUTED:
        raise CompensationError(
            f"action is {original.state.value}; only an EXECUTED action can "
            f"be compensated")

    ledger_rec = _find_executed_ledger_record(action_id)
    if not ledger_rec:
        raise CompensationError(
            "no execution ledger commitment found for this action; refusing "
            "to compensate an action whose execution is not tamper-evident")
    compensates_record_hash = ledger_rec.get("record_hash")
    compensates_payload_hash = (original.payload.payload_hash()
                                if original.payload else "")

    # EXECUTED -> PENDING_COMPENSATION on the ORIGINAL (state-machine only).
    engine.mark_pending_compensation(action_id, scope)

    amount = (float(req.credit_amount) if req.mode == "credit"
             else original.estimated_financial_impact)
    reversal_fields = {
        "compensates_action_id": original.action_id,
        "compensates_payload_hash": compensates_payload_hash,
        "compensates_record_hash": compensates_record_hash,
        "mode": req.mode,
        "credit_amount": str(req.credit_amount) if req.credit_amount
        else None,
        "original_target_object": original.target_object,
    }

    compensating = engine.propose(
        case_id=original.case_id, action_type="compensating",
        target_object=original.target_object, lob=original.lob,
        summary=f"{req.mode.upper()} compensation for {original.action_id}: "
               f"{req.reason}"[:500],
        estimated_financial_impact=amount,
        # ALWAYS critical — the second of two independent Brain-driven paths
        # that force dual control on a compensation (belt-and-braces).
        regulatory_severity="critical", trust_score=original.trust_score,
        compliance_logic={
            "compensation": {
                "original_action_id": original.action_id,
                "mode": req.mode, "reason": req.reason,
                "compensates_record_hash": compensates_record_hash,
                "compensates_payload_hash": compensates_payload_hash,
                "always_dual_control_rule": "ACT-COMPENSATION",
                "always_dual_control_brain_value": _always_dual_by_brain()}},
        fields=reversal_fields, target_system=original.target_system,
        operation=("void" if req.mode == "void" else "credit"),
        proposed_by="compensating_action",
        proposer_user_id=user.get("user_id", ""))

    if compensating.control_mode != ControlMode.DUAL:
        # should be unreachable given the two forcing paths above; fail
        # LOUD rather than let a single-approver compensation exist.
        raise CompensationError(
            "dual control could not be established for a compensating "
            "action — refusing to queue it")

    _save_link(compensating.action_id, original.action_id, req.mode,
              req.credit_amount, req.reason, compensates_record_hash,
              compensates_payload_hash)
    return compensating


def finalize_compensation(compensating_action_id: str, user: dict, scope):
    """Call once the compensating ActionRequest reaches EXECUTED (hooked at
    the API layer right after ``actions.engine.execute`` succeeds). Marks the
    ORIGINAL action COMPENSATED and appends the void/credit block to the v2
    ledger, cryptographically backlinked to the original (F1)."""
    link = _get_link(compensating_action_id)
    if not link:
        return None
    if link["finalized"]:
        return {"already_finalized": True}
    compensating = engine.get(compensating_action_id, scope)
    if not compensating or compensating.state != ActionState.EXECUTED:
        return None

    original = engine.mark_compensated(link["original_action_id"], scope)

    from ..trust import ledger_v2
    entry = ledger_v2.append(
        "action", "compensated", user.get("user_id", ""),
        {"compensates_action_id": link["original_action_id"],
         "compensating_action_id": compensating_action_id,
         "mode": link["mode"], "credit_amount": link["credit_amount"],
         "reason": link["reason"]},
        compensates_record_hash=link["compensates_record_hash"])
    _mark_finalized(compensating_action_id)

    try:
        from ..notify.bus import emit
        from ..schemas.notify import NotificationEvent
        emit(NotificationEvent(
            event="compensated", action_id=link["original_action_id"],
            lob=original.lob,
            summary=f"{link['mode']} compensation executed for "
                   f"{link['original_action_id']}",
            severity="warning"))
    except Exception:
        log.debug("compensated notification failed", exc_info=True)

    return {"original": original.model_dump(),
           "compensating": compensating.model_dump(),
           "ledger_entry": entry.model_dump()}


def is_compensating(action) -> bool:
    return getattr(action, "action_type", "") == "compensating"


def reset():
    """Test helper."""
    with _lock:
        con = _con()
        try:
            con.execute("DELETE FROM compensations")
            con.commit()
        finally:
            con.close()


__all__ = ["propose_compensation", "finalize_compensation",
           "is_compensating", "CompensationError", "reset"]
