"""Core-admin (CAPS) write-back adapters — Facets and QNXT.

Both build a vendor-shaped request from the ontology's CAPS bindings, so the
outbound field names match the client's system without bespoke mapping code.
Transport is deliberately pluggable and credential-guarded: absent a configured
service endpoint the adapter raises AdapterUnavailable and the base class
returns a clean, audited failure. Nothing here writes without an APPROVED,
gated action — the base class enforces that.
"""
from __future__ import annotations

import json
import logging
import os

from ...schemas.actions import ActionPayload, ActionRequest
from ..base import AdapterUnavailable, BaseActionAdapter

log = logging.getLogger("oppal.actions.caps")


class _CAPSAdapter(BaseActionAdapter):
    """Shared behaviour: ontology-driven field mapping + guarded transport."""
    vendor: str = ""
    env_var: str = ""

    def _endpoint(self) -> str:
        return (self.config.get("endpoint")
                or os.environ.get(self.env_var, ""))

    def _map_fields(self, payload: ActionPayload) -> dict:
        """Translate ontology attribute names -> vendor column names using the
        Phase 2 CAPS bindings (reverse of the read-path column_map)."""
        try:
            from ...semantic import ontology
            binding = ontology.caps_binding(self.vendor) or {}
            objects = binding.get("objects") or {}
            reverse: dict = {}
            for obj in objects.values():
                for attr, src in (obj.get("column_map") or {}).items():
                    reverse.setdefault(attr, src)
            return {reverse.get(k, k): v
                    for k, v in (payload.fields or {}).items()}
        except Exception:                              # pragma: no cover
            log.debug("caps field mapping unavailable", exc_info=True)
            return dict(payload.fields or {})

    def _send(self, payload: ActionPayload, action: ActionRequest) -> dict:
        url = self._endpoint()
        if not url:
            raise AdapterUnavailable(
                f"{self.vendor} service endpoint not configured "
                f"({self.env_var})")
        body = json.dumps({
            "vendor": self.vendor,
            "operation": payload.operation,
            "object": payload.target_object,
            "fields": self._map_fields(payload),
            "action_id": action.action_id,
            "payload_hash": payload.payload_hash(),
        }).encode()
        try:
            import urllib.request
            req = urllib.request.Request(
                url, data=body, method="POST",
                headers={"Content-Type": "application/json",
                         "Idempotency-Key": payload.idempotency_key
                         or payload.payload_hash()})
            with urllib.request.urlopen(
                    req, timeout=float(
                        self.config.get("timeout_seconds", 20))) as resp:
                return {"status": resp.status,
                        "response": resp.read().decode(
                            "utf-8", "replace")[:2000],
                        "mapped_fields": list(self._map_fields(payload))}
        except Exception as e:
            raise AdapterUnavailable(
                f"{self.vendor} write failed: {e}") from e

    def healthcheck(self) -> dict:
        configured = bool(self._endpoint())
        mapped = 0
        try:
            from ...semantic import ontology
            b = ontology.caps_binding(self.vendor) or {}
            mapped = sum(len((o.get("column_map") or {}))
                         for o in (b.get("objects") or {}).values())
        except Exception:
            pass
        return {"name": self.name, "target_system": self.target_system,
                "healthy": configured, "available": configured,
                "detail": (f"{self.vendor} endpoint configured" if configured
                           else f"{self.env_var} not configured"),
                "ontology_mapped_columns": mapped}


class FacetsAdapter(_CAPSAdapter):
    target_system = "facets"
    vendor = "facets"
    env_var = "OPPAL_FACETS_ENDPOINT"


class QNXTAdapter(_CAPSAdapter):
    target_system = "qnxt"
    vendor = "qnxt"
    env_var = "OPPAL_QNXT_ENDPOINT"
