"""Dry-run write-back adapter — the working, verifiable default.

Records the EXACT payload it would have transmitted (and to which system),
without performing any external write. This is the default target so the whole
HITL pipeline — proposal, dual control, gate, audit — is fully exercisable and
testable before a client's core-admin credentials exist.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from ...schemas.actions import ActionPayload, ActionRequest
from ..base import BaseActionAdapter

log = logging.getLogger("oppal.actions.dry_run")

#: in-memory transcript of simulated writes (inspectable by the UI/tests)
TRANSCRIPT: list = []


class DryRunAdapter(BaseActionAdapter):
    target_system = "dry_run"

    def _send(self, payload: ActionPayload, action: ActionRequest) -> dict:
        entry = {
            "at": datetime.now(timezone.utc).isoformat(),
            "action_id": action.action_id,
            "action_type": action.action_type,
            "would_send_to": self.config.get("simulated_system", "dry_run"),
            "operation": payload.operation,
            "target_object": payload.target_object,
            "fields": dict(payload.fields or {}),
            "payload_hash": payload.payload_hash(),
            "idempotency_key": payload.idempotency_key,
        }
        TRANSCRIPT.append(entry)
        log.info("dry-run write recorded action=%s hash=%s",
                 action.action_id, entry["payload_hash"][:12])
        return {"simulated": True, "transcript_index": len(TRANSCRIPT) - 1,
                **entry}

    def healthcheck(self) -> dict:
        return {"name": self.name, "target_system": self.target_system,
                "healthy": True, "available": True,
                "detail": "dry-run simulator (no external writes)",
                "writes_recorded": len(TRANSCRIPT)}
