"""Generic webhook write-back adapter (typed, credential-guarded).

Posts the validated ActionPayload to a client-configured endpoint with an
idempotency header. The endpoint/secret come from settings/env — never
hardcoded. Absent configuration it raises AdapterUnavailable and the base
class returns a clean, audited failure rather than throwing.
"""
from __future__ import annotations

import json
import logging
import os

from ...schemas.actions import ActionPayload, ActionRequest
from ..base import AdapterUnavailable, BaseActionAdapter

log = logging.getLogger("oppal.actions.webhook")


class WebhookAdapter(BaseActionAdapter):
    target_system = "webhook"

    def _endpoint(self) -> str:
        return (self.config.get("endpoint")
                or os.environ.get("OPPAL_ACTION_WEBHOOK_URL", ""))

    def _secret(self) -> str:
        return (self.config.get("secret")
                or os.environ.get("OPPAL_ACTION_WEBHOOK_SECRET", ""))

    def _send(self, payload: ActionPayload, action: ActionRequest) -> dict:
        url = self._endpoint()
        if not url:
            raise AdapterUnavailable("action webhook endpoint not configured")
        body = json.dumps({
            "action_id": action.action_id,
            "action_type": action.action_type,
            "lob": action.lob,
            "operation": payload.operation,
            "target_object": payload.target_object,
            "fields": payload.fields,
            "effective_date": payload.effective_date,
            "approvals": [s.model_dump() if hasattr(s, "model_dump") else s
                          for s in action.signatures],
            "trust_score": action.trust_score,
            "payload_hash": payload.payload_hash(),
        }).encode()
        headers = {"Content-Type": "application/json",
                   "Idempotency-Key": payload.idempotency_key
                   or payload.payload_hash()}
        if self._secret():
            import hashlib
            import hmac
            headers["X-OpPal-Signature"] = hmac.new(
                self._secret().encode(), body, hashlib.sha256).hexdigest()
        try:                                # stdlib only; no new dependency
            import urllib.request
            req = urllib.request.Request(url, data=body, headers=headers,
                                         method="POST")
            timeout = float(self.config.get("timeout_seconds", 15))
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", "replace")[:2000]
                return {"status": resp.status, "response": raw}
        except Exception as e:
            raise AdapterUnavailable(f"webhook post failed: {e}") from e

    def healthcheck(self) -> dict:
        configured = bool(self._endpoint())
        return {"name": self.name, "target_system": self.target_system,
                "healthy": configured, "available": configured,
                "detail": ("webhook endpoint configured" if configured
                           else "OPPAL_ACTION_WEBHOOK_URL not configured"),
                "signed": bool(self._secret())}
