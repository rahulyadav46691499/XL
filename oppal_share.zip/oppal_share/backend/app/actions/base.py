"""BaseActionAdapter — the write-back abstraction (Phase 4).

Guarantees enforced BY THIS BASE CLASS (not by adapter goodwill), mirroring the
Phase 1 data-layer pattern:

  * ``execute()`` is FINAL — an ``__init_subclass__`` guard resolves it across
    the whole MRO, so no adapter (or mixin) can supply its own and skip the
    controls.
  * DOUBLE GATE — the action must be in state APPROVED **and** its trust score
    must meet the Brain-configured execution gate. Approval alone never
    suffices.
  * SEPARATION OF DUTIES — for dual-control actions the base re-validates
    ``approver_1_id != approver_2_id`` immediately before transmission.
  * TYPED PAYLOAD ONLY — the outbound body must be an ``ActionPayload``
    instance; anything else is refused before the adapter is called.
  * PHI GUARD — payload fields are scrubbed before they leave the platform.
  * IDEMPOTENCY — a completed idempotency key is never transmitted twice.
  * AUDIT — a hashed record is appended to the tamper-evident ledger BEFORE
    the attempt and AFTER the outcome.

Adapters implement only ``_send`` and ``healthcheck``.
"""
from __future__ import annotations

import abc
import hashlib
import logging
import time
from datetime import datetime, timezone

from ..schemas.actions import ActionPayload, ActionRequest, ActionState

log = logging.getLogger("oppal.actions")
if not log.handlers:
    log.addHandler(logging.NullHandler())


class ActionRefused(Exception):
    """Raised when a control (gate, SoD, state, payload) blocks execution."""


class AdapterUnavailable(Exception):
    """Raised when the target system's driver/credentials are not configured."""


# process-level idempotency ledger: key -> receipt
_COMPLETED: dict = {}


class BaseActionAdapter(abc.ABC):
    target_system: str = "abstract"

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if cls.execute is not BaseActionAdapter.execute:
            raise TypeError(
                f"{cls.__name__} (or a base/mixin) overrides execute(); this "
                "is forbidden. Implement _send(). The HITL controls live in "
                "BaseActionAdapter.execute() by design.")

    def __init__(self, name: str, config: dict | None = None):
        self.name = name
        self.config = config or {}

    # -- adapter hooks -----------------------------------------------------
    @abc.abstractmethod
    def _send(self, payload: ActionPayload, action: ActionRequest) -> dict:
        """Transmit the already-approved, already-validated payload. Return a
        receipt dict. Raise AdapterUnavailable if not configured."""

    @abc.abstractmethod
    def healthcheck(self) -> dict:
        ...

    # -- the single, final execution path ----------------------------------
    def execute(self, action: ActionRequest, *, actor: str,
                gate: float | None = None) -> dict:
        t0 = time.time()
        gate = self._gate(gate)
        try:
            self._preflight(action, gate)
            payload = action.payload
            key = payload.idempotency_key or payload.payload_hash()
            if key in _COMPLETED:                     # never double-write
                log.info("action.execute idempotent-replay action=%s",
                         action.action_id)
                return {**_COMPLETED[key], "idempotent_replay": True}

            scrubbed = self._scrub(payload)
            self._audit("execute_attempt", action, scrubbed, actor=actor)
            receipt = self._send(scrubbed, action)
            out = {
                "ok": True, "target_system": self.target_system,
                "action_id": action.action_id,
                "payload_hash": payload.payload_hash(),
                "idempotency_key": key,
                "receipt": receipt,
                "at": datetime.now(timezone.utc).isoformat(),
                "ms": round((time.time() - t0) * 1000, 1),
            }
            _COMPLETED[key] = out
            self._audit("executed", action, scrubbed, actor=actor,
                        extra={"receipt": self._safe_receipt(receipt)})
            log.info("action.execute ok action=%s system=%s",
                     action.action_id, self.target_system)
            return out
        except ActionRefused as e:
            log.warning("action.execute REFUSED action=%s reason=%s",
                        action.action_id, e)
            self._audit("execute_refused", action, action.payload, actor=actor,
                        extra={"reason": str(e)})
            return {"ok": False, "refused": True, "reason": str(e),
                    "action_id": action.action_id}
        except AdapterUnavailable as e:
            log.error("action.execute unavailable action=%s: %s",
                      action.action_id, e)
            self._audit("execute_failed", action, action.payload, actor=actor,
                        extra={"error": f"unavailable: {e}"})
            return {"ok": False, "error": f"adapter unavailable: {e}",
                    "action_id": action.action_id}
        except Exception as e:                        # degrade, never crash
            log.exception("action.execute error action=%s", action.action_id)
            self._audit("execute_failed", action, action.payload, actor=actor,
                        extra={"error": f"{type(e).__name__}: {e}"})
            return {"ok": False, "error": f"{type(e).__name__}: {e}",
                    "action_id": action.action_id}

    # -- controls -----------------------------------------------------------
    @staticmethod
    def _gate(explicit: float | None) -> float:
        if explicit is not None:
            return float(explicit)
        try:
            from ..semantic.brain import get_brain
            return float(get_brain()["action_rules"]["execution_trust_gate"])
        except Exception:                             # pragma: no cover
            return 0.85

    def _preflight(self, action: ActionRequest, gate: float) -> None:
        if not isinstance(action, ActionRequest):
            raise ActionRefused("action must be an ActionRequest")
        if not isinstance(action.payload, ActionPayload):
            raise ActionRefused(
                "outbound body must be a validated ActionPayload")
        ok, reason = action.executable(gate)          # state + gate + SoD
        if not ok:
            raise ActionRefused(reason)
        if action.payload.target_system != self.target_system:
            raise ActionRefused(
                f"payload targets '{action.payload.target_system}' but this "
                f"adapter is '{self.target_system}'")

    @staticmethod
    def _scrub(payload: ActionPayload) -> ActionPayload:
        """PHI/PII guard on everything leaving the platform.

        Recursive (nested dicts/lists are covered), applies only unambiguous
        identifier patterns (so monetary values are never corrupted), and
        includes ``target_object`` and ``note`` — not just ``fields``.
        """
        try:
            from ..privacy.phi_guard import PHIGuard
            guard = PHIGuard(enabled=True)
            data = payload.model_dump()
            data["fields"] = guard.scrub_structure(payload.fields or {})
            data["target_object"] = guard.scrub_value(payload.target_object)
            data["note"] = guard.scrub_value(payload.note or "")
            return ActionPayload(**data)
        except Exception:                             # never block on guard
            log.debug("phi guard unavailable for payload", exc_info=True)
            return payload

    @staticmethod
    def _safe_receipt(receipt: dict) -> dict:
        """Ledger-safe view of a transport receipt: metadata only, never the
        echoed payload/fields (which can carry member identifiers)."""
        if not isinstance(receipt, dict):
            return {}
        allow = ("status", "simulated", "transcript_index", "would_send_to",
                 "operation", "payload_hash", "idempotency_key",
                 "mapped_fields", "at")
        return {k: receipt[k] for k in allow if k in receipt}

    def _audit(self, event: str, action: ActionRequest,
               payload: ActionPayload | None, *, actor: str,
               extra: dict | None = None) -> None:
        try:
            from ..trust.audit_ledger import _write
            phash = payload.payload_hash() if payload else ""
            rec = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "kind": "action", "event": event,
                "action_id": action.action_id,
                "action_type": action.action_type,
                "target_system": self.target_system,
                "lob": action.lob,
                "state": action.state.value,
                "control_mode": action.control_mode.value,
                "trust_score": action.trust_score,
                "estimated_financial_impact":
                    action.estimated_financial_impact,
                "approver_1_id": action.approver_1_id,
                "approver_2_id": action.approver_2_id,
                "actor": actor,
                "payload_hash": phash,
                # cryptographic commitment over the exact outbound payload
                "payload_commitment": hashlib.sha256(
                    (action.action_id + phash + event).encode()).hexdigest(),
            }
            rec.update(extra or {})
            _write(rec)
        except Exception:                             # pragma: no cover
            log.debug("action audit failed", exc_info=True)
