"""HITL action engine (Phase 4).

Owns the action lifecycle and every human-in-the-loop control:

  propose → PENDING_FIRST_APPROVAL
          → (dual control?) PENDING_SECOND_APPROVAL
          → APPROVED → execute → EXECUTED
          → REJECTED (reason mandatory, logged)

Controls (all Brain-driven; no thresholds or role names in this module):
  * dual control when estimated financial impact >= threshold, OR regulatory
    severity is a trigger severity, OR the action type is listed as
    dual-control-only;
  * separation of duties — approver_1_id != approver_2_id, and the proposer
    may not approve unless self-approval is explicitly allowed;
  * approver role must be in the Brain's approver_roles;
  * a DOUBLE GATE on execution: state == APPROVED and trust >= gate;
  * every signature, rejection reason and execution payload is hashed and
    appended to the tamper-evident ledger;
  * LOB scoping — an action is only visible/actionable to a principal whose
    scope covers it (same subset contract as cases).
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import threading
import uuid
from datetime import datetime, timezone

from ..schemas.actions import (ActionPayload, ActionRequest, ActionState,
                               ApprovalSignature, ControlMode)
from .registry import get_adapter

log = logging.getLogger("oppal.actions.engine")

ACTION_DB = os.environ.get(
    "OPPAL_ACTION_DB",
    os.path.join(os.path.dirname(os.path.dirname(__file__)), "data",
                 "actions.db"))
_lock = threading.Lock()


class ActionError(Exception):
    """Control violation (bad transition, SoD, role, gate)."""


# ---------------------------------------------------------------------------
def rules() -> dict:
    from ..semantic.brain import get_brain
    return get_brain().get("action_rules", {})


def _con():
    os.makedirs(os.path.dirname(ACTION_DB), exist_ok=True)
    con = sqlite3.connect(ACTION_DB, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS actions (
            action_id TEXT PRIMARY KEY, case_id TEXT, action_type TEXT,
            target_system TEXT, target_object TEXT, lob TEXT,
            proposed_by TEXT, proposer_user_id TEXT, summary TEXT,
            estimated_financial_impact REAL, regulatory_severity TEXT,
            trust_score REAL, control_mode TEXT, state TEXT,
            approver_1_id TEXT, approver_2_id TEXT, signatures TEXT,
            compliance_logic TEXT, payload TEXT, rejection_reason TEXT,
            created_at TEXT, updated_at TEXT, executed_at TEXT,
            execution_receipt TEXT)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_act_state ON actions(state)")
    return con


def _scrub_for_ledger(value):
    """PHI/PII guard on any free text or structure entering the ledger."""
    try:
        from ..privacy.phi_guard import PHIGuard
        return PHIGuard(enabled=True).scrub_structure(value)
    except Exception:                                  # never block auditing
        return value


def _audit(event: str, action: ActionRequest, *, actor: str,
           extra: dict | None = None):
    """Hash-chained ledger entry with a cryptographic commitment.

    Free-text and nested values (summary, reasons, rejection reason, case
    detail) are PHI-scrubbed before persistence — the ledger must be
    tamper-evident, not a PHI store."""
    try:
        from ..trust.audit_ledger import _write
        phash = action.payload.payload_hash() if action.payload else ""
        rec = {"ts": datetime.now(timezone.utc).isoformat(),
               "kind": "action", "event": event,
               "action_id": action.action_id,
               "action_type": action.action_type,
               "state": action.state.value,
               "control_mode": action.control_mode.value,
               "lob": action.lob, "actor": actor,
               "trust_score": action.trust_score,
               "estimated_financial_impact":
                   action.estimated_financial_impact,
               "regulatory_severity": action.regulatory_severity,
               "approver_1_id": action.approver_1_id,
               "approver_2_id": action.approver_2_id,
               "payload_hash": phash,
               "payload_commitment": hashlib.sha256(
                   (action.action_id + phash + event + actor).encode()
               ).hexdigest()}
        rec["target_object_ref"] = _scrub_for_ledger(action.target_object)
        rec.update(_scrub_for_ledger(extra or {}))
        _write(rec)
    except Exception:                                  # pragma: no cover
        log.debug("action audit failed", exc_info=True)


# ---------------------------------------------------------------------------
def norm_token(value) -> str:
    """Canonicalize a control-relevant token: trim, collapse inner whitespace,
    lowercase. Without this, ' critical ' or 'claim_adjustment ' would silently
    dodge a dual-control trigger."""
    return " ".join(str(value or "").split()).lower()


def norm_impact(value) -> float:
    """Non-negative magnitude. A missing, null, negative or unparseable impact
    must never *reduce* the control requirement — it becomes 0.0 and the other
    triggers still apply."""
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return 0.0


def determine_control_mode(action_type: str, impact: float,
                           severity: str) -> tuple:
    """(mode, reasons) — impact-threshold dual control, Brain-driven.

    All comparisons run on normalized tokens so whitespace/case variants of a
    trigger value cannot bypass dual control.
    """
    r = rules()
    threshold = float(r.get("financial_impact_threshold", 10000))
    amount = norm_impact(impact)
    at = norm_token(action_type)
    sev = norm_token(severity)
    reasons = []
    if amount >= threshold:
        reasons.append(f"estimated impact ${amount:,.0f} ≥ threshold "
                       f"${threshold:,.0f}")
    if sev in {norm_token(s) for s in
               r.get("regulatory_severity_triggers", [])}:
        reasons.append(f"regulatory severity '{sev}' is a dual-control trigger")
    if at in {norm_token(t) for t in r.get("dual_control_action_types", [])}:
        reasons.append(f"action type '{at}' always requires dual control")
    return (ControlMode.DUAL if reasons else ControlMode.SINGLE), reasons


def _row_to_action(row) -> ActionRequest:
    d = dict(row)
    sigs = [ApprovalSignature(**s) for s in json.loads(d["signatures"] or "[]")]
    payload = (ActionPayload(**json.loads(d["payload"]))
               if d.get("payload") else None)
    return ActionRequest(
        action_id=d["action_id"], case_id=d["case_id"] or "",
        action_type=d["action_type"], target_system=d["target_system"],
        target_object=d["target_object"], lob=d["lob"],
        proposed_by=d["proposed_by"],
        proposer_user_id=d["proposer_user_id"] or "",
        summary=d["summary"] or "",
        estimated_financial_impact=d["estimated_financial_impact"] or 0.0,
        regulatory_severity=d["regulatory_severity"] or "medium",
        trust_score=d["trust_score"] or 0.0,
        control_mode=ControlMode(d["control_mode"]),
        state=ActionState(d["state"]),
        approver_1_id=d["approver_1_id"], approver_2_id=d["approver_2_id"],
        signatures=sigs,
        compliance_logic=json.loads(d["compliance_logic"] or "{}"),
        payload=payload, rejection_reason=d["rejection_reason"] or "",
        created_at=d["created_at"] or "", updated_at=d["updated_at"] or "",
        executed_at=d["executed_at"],
        execution_receipt=json.loads(d["execution_receipt"] or "{}"))


def _save(a: ActionRequest):
    with _lock:
        con = _con()
        try:
            con.execute(
                "INSERT OR REPLACE INTO actions VALUES "
                "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (a.action_id, a.case_id, a.action_type, a.target_system,
                 a.target_object, a.lob, a.proposed_by, a.proposer_user_id,
                 a.summary, a.estimated_financial_impact,
                 a.regulatory_severity, a.trust_score, a.control_mode.value,
                 a.state.value, a.approver_1_id, a.approver_2_id,
                 json.dumps([s.model_dump() for s in a.signatures]),
                 json.dumps(a.compliance_logic),
                 json.dumps(a.payload.model_dump()) if a.payload else None,
                 a.rejection_reason, a.created_at, a.updated_at,
                 a.executed_at, json.dumps(a.execution_receipt)))
            con.commit()
        finally:
            con.close()


def _visible(a: ActionRequest, scope) -> bool:
    from ..agents.case_store import _can_see
    return _can_see(a.lob, scope)


# ---------------------------------------------------------------------------
def propose(*, case_id: str = "", action_type: str, target_object: str,
            lob: str, summary: str, estimated_financial_impact: float = 0.0,
            regulatory_severity: str = "medium", trust_score: float = 0.0,
            compliance_logic: dict | None = None,
            fields: dict | None = None, target_system: str = "dry_run",
            operation: str = "update", proposed_by: str = "prescriptive_action",
            proposer_user_id: str = "") -> ActionRequest:
    """Create a proposal. Never executes; always lands in a pending state."""
    now = datetime.now(timezone.utc).isoformat()
    aid = f"ACT-{uuid.uuid4().hex[:10]}"
    # CANONICALIZE before evaluating and before persisting, so the stored
    # action reflects exactly what the control decision was made on.
    action_type = norm_token(action_type) or "unspecified"
    regulatory_severity = norm_token(regulatory_severity) or "medium"
    estimated_financial_impact = norm_impact(estimated_financial_impact)
    trust_score = max(0.0, min(1.0, float(trust_score or 0)))
    mode, reasons = determine_control_mode(
        action_type, estimated_financial_impact, regulatory_severity)
    logic = dict(compliance_logic or {})
    logic["control_determination"] = {
        "mode": mode.value, "reasons": reasons,
        "threshold": rules().get("financial_impact_threshold"),
        "severity_triggers": rules().get("regulatory_severity_triggers"),
        "rule_ids": rules().get("rule_ids", []),
        "citations": rules().get("citations", {})}
    payload = ActionPayload(
        action_id=aid, action_type=action_type, target_system=target_system,
        target_object=str(target_object), lob=lob, operation=operation,
        fields=dict(fields or {}),
        idempotency_key=hashlib.sha256(
            f"{aid}|{action_type}|{target_object}|{operation}".encode()
        ).hexdigest()[:32],
        note=summary)
    a = ActionRequest(
        action_id=aid, case_id=case_id, action_type=action_type,
        target_system=target_system, target_object=str(target_object),
        lob=lob, proposed_by=proposed_by, proposer_user_id=proposer_user_id,
        summary=summary,
        estimated_financial_impact=float(estimated_financial_impact or 0),
        regulatory_severity=regulatory_severity,
        trust_score=float(trust_score or 0), control_mode=mode,
        state=ActionState.PROPOSED, compliance_logic=logic, payload=payload,
        created_at=now, updated_at=now)
    a.assert_transition(ActionState.PENDING_FIRST_APPROVAL)
    a.state = ActionState.PENDING_FIRST_APPROVAL
    _save(a)
    _audit("proposed", a, actor=proposer_user_id or proposed_by,
           extra={"reasons": reasons, "summary": _scrub_for_ledger(summary),
                  "control_reasons_count": len(reasons)})
    return a


def get(action_id: str, scope) -> ActionRequest | None:
    con = _con()
    try:
        row = con.execute("SELECT * FROM actions WHERE action_id = ?",
                          (action_id,)).fetchone()
    finally:
        con.close()
    if not row:
        return None
    a = _row_to_action(row)
    return a if _visible(a, scope) else None


def list_actions(scope, *, state: str = "") -> list:
    con = _con()
    try:
        rows = con.execute(
            "SELECT * FROM actions ORDER BY created_at DESC").fetchall()
    finally:
        con.close()
    out = []
    for r in rows:
        a = _row_to_action(r)
        if not _visible(a, scope):
            continue
        if state and a.state.value != state:
            continue
        out.append(a)
    return out


def _check_approver(user: dict, a: ActionRequest):
    """Role + separation-of-duties gate. All identity comparisons run on
    NORMALIZED ids so whitespace/case variants of the same principal cannot
    satisfy both signatures."""
    r = rules()
    role = norm_token(user.get("role"))
    if role not in {norm_token(x) for x in r.get("approver_roles", [])}:
        raise ActionError(
            f"role '{user.get('role')}' is not authorized to approve "
            f"write-back actions")
    uid = norm_token(user.get("user_id"))
    if not uid:
        raise ActionError("an identified approver is required")
    if not r.get("self_approval_allowed", False):
        if uid == norm_token(a.proposer_user_id):
            raise ActionError(
                "separation of duties: the proposer may not approve this "
                "action")
    if norm_token(a.approver_1_id) and uid == norm_token(a.approver_1_id):
        raise ActionError(
            "separation of duties: approver_2 must differ from approver_1")
    # an id already present on ANY prior approval signature cannot sign again
    if uid in a.approver_ids_from_signatures():
        raise ActionError(
            "separation of duties: this approver has already signed")


def approve(action_id: str, user: dict, scope, *, note: str = "") -> ActionRequest:
    a = get(action_id, scope)
    if not a:
        raise PermissionError("action not found in your authorized scope")
    if a.state not in (ActionState.PENDING_FIRST_APPROVAL,
                       ActionState.PENDING_SECOND_APPROVAL):
        raise ActionError(f"action is {a.state.value}; not awaiting approval")
    _check_approver(user, a)
    uid = norm_token(user.get("user_id", ""))
    now = datetime.now(timezone.utc).isoformat()
    phash = a.payload.payload_hash() if a.payload else ""
    sig = ApprovalSignature(
        approver_id=uid, approver_role=user.get("role", ""),
        decision="approved", at=now, reason=note,
        signature=ApprovalSignature.sign(a.action_id, uid, "approved", now,
                                         note, phash))
    a.signatures = list(a.signatures) + [sig]

    if a.state == ActionState.PENDING_FIRST_APPROVAL:
        a.approver_1_id = uid
        if a.control_mode == ControlMode.DUAL:
            a.assert_transition(ActionState.PENDING_SECOND_APPROVAL)
            a.state = ActionState.PENDING_SECOND_APPROVAL
        else:
            a.assert_transition(ActionState.APPROVED)
            a.state = ActionState.APPROVED
    else:                                   # PENDING_SECOND_APPROVAL
        a.approver_2_id = uid
        if not a.distinct_approvers():      # belt-and-braces
            raise ActionError("separation of duties: approvers must differ")
        a.assert_transition(ActionState.APPROVED)
        a.state = ActionState.APPROVED
    a.updated_at = now
    _save(a)
    _audit("approved", a, actor=uid,
           extra={"signature": sig.signature, "note": note,
                  "resulting_state": a.state.value})
    if a.state == ActionState.PENDING_SECOND_APPROVAL:
        _notify_pending_second_approval(a)
    return a


def _notify_pending_second_approval(a: ActionRequest) -> None:
    """Phase 6 amendment (Limitation 3) — the maker-checker trigger. Never
    raises; an unconfigured/failed channel must not block approval."""
    try:
        from ..notify.bus import emit
        from ..schemas.notify import NotificationEvent
        emit(NotificationEvent(
            event="pending_second_approval", action_id=a.action_id,
            lob=a.lob,
            summary=f"Action {a.action_id} ({a.action_type}) needs a "
                   f"second, distinct approver — impact "
                   f"${a.estimated_financial_impact:,.0f}, severity "
                   f"{a.regulatory_severity}",
            severity="warning"))
    except Exception:                                     # pragma: no cover
        log.debug("pending_second_approval notification failed",
                 exc_info=True)


def reject(action_id: str, user: dict, scope, *, reason: str) -> ActionRequest:
    """Rejection requires a reason; it is signed and written to the ledger."""
    if not (reason or "").strip():
        raise ActionError("a rejection reason is required")
    a = get(action_id, scope)
    if not a:
        raise PermissionError("action not found in your authorized scope")
    if not a.can_transition(ActionState.REJECTED):
        raise ActionError(f"cannot reject from state {a.state.value}")
    _check_approver(user, a)
    uid = norm_token(user.get("user_id", ""))
    now = datetime.now(timezone.utc).isoformat()
    phash = a.payload.payload_hash() if a.payload else ""
    sig = ApprovalSignature(
        approver_id=uid, approver_role=user.get("role", ""),
        decision="rejected", at=now, reason=reason,
        signature=ApprovalSignature.sign(a.action_id, uid, "rejected", now,
                                         reason, phash))
    a.signatures = list(a.signatures) + [sig]
    a.state = ActionState.REJECTED
    a.rejection_reason = reason
    a.updated_at = now
    _save(a)
    _audit("rejected", a, actor=uid,
           extra={"signature": sig.signature, "rejection_reason": reason})
    return a


def execute(action_id: str, user: dict, scope) -> dict:
    """Double gate + adapter dispatch. The adapter base re-validates."""
    a = get(action_id, scope)
    if not a:
        raise PermissionError("action not found in your authorized scope")
    gate = float(rules().get("execution_trust_gate", 0.85))
    ok, reason = a.executable(gate)
    if not ok:
        _audit("execute_blocked", a, actor=user.get("user_id", ""),
               extra={"reason": reason})
        raise ActionError(reason)
    if norm_token(user.get("role")) not in {
            norm_token(x) for x in rules().get("approver_roles", [])}:
        raise ActionError(
            f"role '{user.get('role')}' may not execute write-back actions")
    adapter = get_adapter(a.target_system)
    receipt = adapter.execute(a, actor=user.get("user_id", ""), gate=gate)
    now = datetime.now(timezone.utc).isoformat()
    if receipt.get("ok"):
        a.assert_transition(ActionState.EXECUTED)
        a.state = ActionState.EXECUTED
        a.executed_at = now
    else:
        if a.can_transition(ActionState.FAILED):
            a.state = ActionState.FAILED
    a.execution_receipt = receipt
    a.updated_at = now
    _save(a)
    return {"action": a.model_dump(), "receipt": receipt}


def summary(scope) -> dict:
    acts = list_actions(scope)
    by_state: dict = {}
    pending_impact = 0.0
    for a in acts:
        by_state[a.state.value] = by_state.get(a.state.value, 0) + 1
        if a.state in (ActionState.PENDING_FIRST_APPROVAL,
                       ActionState.PENDING_SECOND_APPROVAL,
                       ActionState.APPROVED):
            pending_impact += a.estimated_financial_impact or 0
    return {"total": len(acts), "by_state": by_state,
            "pending_impact": round(pending_impact, 2),
            "gate": float(rules().get("execution_trust_gate", 0.85)),
            "dual_control_threshold": rules().get(
                "financial_impact_threshold")}


def mark_pending_compensation(action_id: str, scope) -> ActionRequest:
    """Phase 6 amendment (Limitation 2): an EXECUTED action enters
    PENDING_COMPENSATION the moment a reversal is PROPOSED against it — a
    state-machine transition only, no write-back happens here. The actual
    void/credit write-back runs through the compensating ActionRequest's own
    dual-control + double-gate + adapter path (see app/actions/
    compensating.py)."""
    a = get(action_id, scope)
    if not a:
        raise PermissionError("action not found in your authorized scope")
    a.assert_transition(ActionState.PENDING_COMPENSATION)
    a.state = ActionState.PENDING_COMPENSATION
    a.updated_at = datetime.now(timezone.utc).isoformat()
    _save(a)
    _audit("pending_compensation", a, actor="system")
    return a


def mark_compensated(action_id: str, scope) -> ActionRequest:
    """Called once the compensating ActionRequest itself reaches EXECUTED."""
    a = get(action_id, scope)
    if not a:
        raise PermissionError("action not found in your authorized scope")
    a.assert_transition(ActionState.COMPENSATED)
    a.state = ActionState.COMPENSATED
    a.updated_at = datetime.now(timezone.utc).isoformat()
    _save(a)
    _audit("compensated", a, actor="system")
    return a


def reset():
    """Test helper."""
    with _lock:
        con = _con()
        try:
            con.execute("DELETE FROM actions")
            con.commit()
        finally:
            con.close()
