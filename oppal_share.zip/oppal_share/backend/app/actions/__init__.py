"""OpPal HITL action & write-back engine (Phase 4).

Public surface: propose an action, route it through human approval (with
impact-threshold dual control), then execute it through a governed adapter.
Nothing writes without APPROVED state + trust gate + separation of duties.
"""
from .base import ActionRefused, AdapterUnavailable, BaseActionAdapter
from .engine import (ActionError, approve, determine_control_mode, execute,
                     get, list_actions, propose, reject, rules, summary)
from .registry import (available_adapters, default_target, get_adapter, health,
                       register)

__all__ = [
    "propose", "approve", "reject", "execute", "get", "list_actions",
    "summary", "rules", "determine_control_mode", "ActionError",
    "BaseActionAdapter", "ActionRefused", "AdapterUnavailable",
    "get_adapter", "register", "available_adapters", "default_target",
    "health",
]
