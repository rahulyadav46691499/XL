"""Action adapter registry — open for extension, closed for modification."""
from __future__ import annotations

import logging
from typing import Type

from .. import config
from .adapters.caps import FacetsAdapter, QNXTAdapter
from .adapters.dry_run import DryRunAdapter
from .adapters.webhook import WebhookAdapter
from .base import BaseActionAdapter

log = logging.getLogger("oppal.actions.registry")

_REGISTRY: dict = {
    "dry_run": DryRunAdapter,
    "webhook": WebhookAdapter,
    "facets": FacetsAdapter,
    "qnxt": QNXTAdapter,
}


def register(name: str, cls: Type[BaseActionAdapter]) -> None:
    if not issubclass(cls, BaseActionAdapter):
        raise TypeError("adapter must subclass BaseActionAdapter")
    # defense in depth alongside __init_subclass__
    if cls.execute is not BaseActionAdapter.execute:
        raise TypeError(f"{cls.__name__} overrides execute(); refused")
    _REGISTRY[name] = cls


def available_adapters() -> list:
    return sorted(_REGISTRY)


def _adapter_config(name: str) -> dict:
    settings = config.load()
    return (settings.get("actions", {}) or {}).get(name, {})


def get_adapter(name: str) -> BaseActionAdapter:
    cls = _REGISTRY.get(name)
    if cls is None:
        raise KeyError(f"unknown action adapter '{name}'")
    return cls(name, _adapter_config(name))


def default_target() -> str:
    """Configured write-back target; dry-run unless explicitly changed."""
    import os
    env = os.environ.get("OPPAL_ACTION_TARGET")
    if env:
        return env
    return (config.load().get("actions", {}) or {}).get(
        "default_target", "dry_run")


def health() -> dict:
    out = {}
    for name in available_adapters():
        try:
            out[name] = get_adapter(name).healthcheck()
        except Exception as e:                        # pragma: no cover
            out[name] = {"name": name, "healthy": False, "available": False,
                         "detail": f"{type(e).__name__}: {e}"}
    return {"default_target": default_target(), "adapters": out}
