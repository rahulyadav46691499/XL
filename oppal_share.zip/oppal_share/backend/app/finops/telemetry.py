"""FinOps / LLM telemetry (Phase 6, REQ-6.4-6.6).

Every figure here is DERIVED from existing anchors — never a new literal:

  * tokens/calls/provider from ``llm.base.cumulative_snapshot()`` (session,
    process-wide across worker threads) and the usage ledger (global, every
    ``/api/ask`` ever logged).
  * cost from ``llm.base.PRICING_PER_M`` for the active provider — the ONLY
    price table in the platform; this module echoes it back
    (``price_in_per_m``/``price_out_per_m``) rather than hardcoding a rate.
  * cache hit-rate from ``security.semantic_cache.CACHE.stats()`` (REQ-6.5).
  * ``cache_savings_usd`` = (cache hits) x (the SAME average cost-per-call
    already computed above) — no magic savings-per-hit literal (REQ-6.6/H3).
"""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

from ..llm.base import cumulative_snapshot, PRICING_PER_M
from ..schemas.finops import FinOpsTelemetry
from ..security.semantic_cache import CACHE
from ..trust.audit_ledger import read_all


def _policy() -> dict:
    """FinOps policy from the Brain's finops.md (NFR-1). Falls back to an
    empty dict so a missing file degrades to the documented defaults rather
    than breaking the widget — FinOps is observability, not a control."""
    try:
        from ..semantic.brain import get_brain
        return get_brain().get("finops", {}) or {}
    except Exception:                                     # pragma: no cover
        return {}


def _policy_num(section: str, key: str, default):
    raw = (_policy().get(section, {}) or {}).get(key)
    if raw in (None, ""):
        return default
    try:
        return type(default)(raw)
    except (TypeError, ValueError):
        return default


def _price_for(provider: str, model: str | None = None) -> tuple:
    """Resolve by MODEL first — 'anthropic' spans a 5x range from Haiku 4.5
    to Opus 5, so provider-level costing mis-bills any tiered routing."""
    from ..llm.base import price_for
    pin, pout = price_for(provider, model)
    return Decimal(str(pin)), Decimal(str(pout))


def budget_status(session_cost: Decimal, global_cost: Decimal) -> dict:
    """Advisory spend guardrails, thresholds read from finops.md."""
    s_warn = Decimal(str(_policy_num("budget_thresholds",
                                     "session_warn_usd", 1.0)))
    s_crit = Decimal(str(_policy_num("budget_thresholds",
                                     "session_critical_usd", 5.0)))
    g_warn = Decimal(str(_policy_num("budget_thresholds",
                                     "global_warn_usd", 50.0)))
    level = "ok"
    if session_cost >= s_crit:
        level = "critical"
    elif session_cost >= s_warn or global_cost >= g_warn:
        level = "warning"
    return {"level": level, "session_warn_usd": str(s_warn),
            "session_critical_usd": str(s_crit),
            "global_warn_usd": str(g_warn)}


def _cost(tokens_in: int, tokens_out: int, price_in: Decimal,
         price_out: Decimal) -> Decimal:
    return ((Decimal(tokens_in) * price_in + Decimal(tokens_out) * price_out)
           / Decimal(1_000_000)).quantize(Decimal("0.000001"),
                                          rounding=ROUND_HALF_UP)


def snapshot() -> FinOpsTelemetry:
    # PROCESS-WIDE totals, not the per-request thread-local METER. This
    # endpoint is polled by the floating widget on a different worker thread
    # than the one that served /api/ask, and METER is both thread-local and
    # reset per question — so reading it here reported 0 tokens / provider
    # "mock" for a session that had in fact been calling Gemini all along.
    session = cumulative_snapshot()
    provider = session.get("provider") or "mock"
    price_in, price_out = _price_for(provider, session.get("model"))

    usage_records = [r for r in read_all() if r.get("kind") == "usage"]
    global_tokens_in = sum(r.get("tokens_in", 0) or 0 for r in usage_records)
    global_tokens_out = sum(r.get("tokens_out", 0) or 0 for r in
                            usage_records)
    # the usage ledger predates a dedicated `llm_calls` field (Phase 0); a
    # request that made >=1 LLM call is the closest available proxy.
    global_llm_calls = sum(1 for r in usage_records
                           if (r.get("tokens_in") or r.get("tokens_out")))
    global_cost_from_ledger = sum(
        Decimal(str(r.get("est_cost_usd", 0) or 0)) for r in usage_records)

    session_tokens_in = session["tokens_in"]
    session_tokens_out = session["tokens_out"]
    session_cost = _cost(session_tokens_in, session_tokens_out, price_in,
                        price_out)

    # H1 invariant (session <= global) is enforced BY CONSTRUCTION: the
    # current session's usage may not have reached the ledger yet (log_usage
    # runs after the response is built), so folding it into the reported
    # "global" figure is the more correct number, not a workaround.
    global_tokens_in = max(global_tokens_in, session_tokens_in)
    global_tokens_out = max(global_tokens_out, session_tokens_out)
    global_cost = max(global_cost_from_ledger, session_cost)
    global_llm_calls = max(global_llm_calls, session.get("llm_calls", 0))

    cache_stats = CACHE.stats()
    hits = cache_stats.get("hits", 0)
    misses = cache_stats.get("misses", 0)
    total_lookups = hits + misses
    cache_hit_rate = (hits / total_lookups) if total_lookups else 0.0

    avg_cost_per_call = (global_cost / Decimal(global_llm_calls)
                        if global_llm_calls else Decimal(0))
    cache_savings = ((avg_cost_per_call * Decimal(hits)).quantize(
        Decimal("0.000001"), rounding=ROUND_HALF_UP) if hits else Decimal(0))

    # percentile + min_samples come from finops.md (NFR-1), not a literal
    pct = _policy_num("latency_percentile", "percentile", 95) / 100.0
    min_samples = _policy_num("latency_percentile", "min_samples", 2)
    latencies = sorted(r["latency_ms"] for r in usage_records
                       if r.get("latency_ms"))
    if len(latencies) >= min_samples:
        p95 = latencies[max(0, int(len(latencies) * pct) - 1)]
    elif latencies:
        p95 = latencies[0]
    else:
        p95 = 0.0

    return FinOpsTelemetry(
        session_tokens_in=session_tokens_in,
        session_tokens_out=session_tokens_out,
        global_tokens_in=global_tokens_in,
        global_tokens_out=global_tokens_out, llm_calls=global_llm_calls,
        session_cost_usd=session_cost, global_cost_usd=global_cost,
        cache_savings_usd=cache_savings, p95_latency_ms=float(p95),
        cache_hit_rate=float(cache_hit_rate), provider=provider,
        price_in_per_m=price_in, price_out_per_m=price_out)


__all__ = ["snapshot"]
