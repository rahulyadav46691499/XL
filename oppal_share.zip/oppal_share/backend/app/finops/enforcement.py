"""Hard budget caps and the kill switch (Sprint B item 6).

FROM ADVISORY TO ENFORCING
--------------------------
FinOps already measured spend accurately — Decimal arithmetic, per-model rates,
reconciliation invariants — and then only ever *warned*. The thresholds in
finops.md are named "Advisory spend guardrails" and that is exactly what they
were: a coloured chip in a widget. A runaway agent loop, a pathological prompt,
or a workload nobody sized would keep spending until someone happened to look.

Unity AI Gateway offers hard budget limits in its control plane. This module is
the equivalent, with one difference worth stating: enforcement is a REFUSAL of
the model call, not a silent truncation. Truncating context to fit a budget
would quietly degrade answer quality while still reporting success, which is
the worse failure — the caller cannot tell a cheap answer from a good one.

WHAT IS DECLARATIVE AND WHAT IS NOT
-----------------------------------
The LIMITS are business policy and live in finops.md, editable by a compliance
officer under the same eval gate and ledger as any other Brain edit. Raising a
spend cap is a legitimate business decision.

The ENFORCEMENT MECHANISM and the kill switch are in code. A kill switch that
can be disabled by editing the artefact it polices is not a kill switch — the
same reasoning as brain_governance.PROTECTED_KEYS and brain_eval's floors. The
switch is operated through an explicit call or environment variable, and both
its activation and every refusal are written to the tamper-evident ledger.

FAIL DIRECTION
--------------
This control fails CLOSED on a genuine cap breach (refuse the call) but OPEN on
its own internal error (allow the call). Rationale: the purpose is to stop
runaway *spend*, and a bug in the accountant should not take the platform
offline. A breach is a definite signal and is enforced; an unreadable budget is
an unknown and defaults to letting business continue, loudly logged.
"""
from __future__ import annotations

import logging
import os
import threading
from decimal import Decimal

log = logging.getLogger("oppal.finops.enforcement")

_lock = threading.Lock()
_state = {"killed": False, "reason": "", "actor": ""}

# Env override so an operator can stop spend without a running API.
_KILL_ENV = "OPPAL_LLM_KILL_SWITCH"

# Hard caps default to a generous multiple of the advisory thresholds so that
# enabling enforcement does not immediately break an existing deployment; the
# real values belong in finops.md.
_DEFAULT_SESSION_HARD_USD = 25.00
_DEFAULT_GLOBAL_HARD_USD = 250.00


class BudgetExceeded(Exception):
    """Raised instead of making a model call that would breach a hard cap."""


class KillSwitchEngaged(Exception):
    """Raised when LLM traffic has been administratively halted."""


# ---------------------------------------------------------------------------
def _limit(key: str, default: float) -> Decimal:
    """Read a hard cap from finops.md, falling back to the code default."""
    try:
        from ..semantic.brain import get_brain
        section = (get_brain().get("finops", {}) or {}).get(
            "budget_thresholds", {}) or {}
        raw = section.get(key)
        if raw is not None:
            return Decimal(str(raw))
    except Exception:                                    # pragma: no cover
        log.debug("could not read budget limit %s", key, exc_info=True)
    return Decimal(str(default))


def limits() -> dict:
    return {
        "session_hard_usd": _limit("session_hard_usd",
                                   _DEFAULT_SESSION_HARD_USD),
        "global_hard_usd": _limit("global_hard_usd",
                                  _DEFAULT_GLOBAL_HARD_USD),
    }


# ---------------------------------------------------------------------------
def kill_switch_engaged() -> bool:
    if os.environ.get(_KILL_ENV, "").strip().lower() in ("1", "true", "yes"):
        return True
    return bool(_state["killed"])


def engage_kill_switch(reason: str, actor: str = "") -> dict:
    """Halt all LLM traffic. Deterministic agent paths keep working."""
    with _lock:
        _state.update({"killed": True, "reason": reason[:200],
                       "actor": actor or "system"})
    _ledger("llm_kill_switch_engaged", actor, {"reason": reason[:200]})
    log.warning("LLM kill switch ENGAGED by %s: %s", actor or "system", reason)
    return status()


def release_kill_switch(actor: str = "") -> dict:
    with _lock:
        _state.update({"killed": False, "reason": "", "actor": ""})
    _ledger("llm_kill_switch_released", actor, {})
    return status()


def status() -> dict:
    lim = limits()
    return {
        "kill_switch": kill_switch_engaged(),
        "kill_reason": _state["reason"],
        "kill_actor": _state["actor"],
        "env_override": os.environ.get(_KILL_ENV, "") or None,
        "session_hard_usd": str(lim["session_hard_usd"]),
        "global_hard_usd": str(lim["global_hard_usd"]),
        "enforcement": "refuse the model call (never silent truncation)",
    }


# ---------------------------------------------------------------------------
def check(actor: str = "", task: str = "") -> dict:
    """Gate one model call. Raises rather than returning a soft signal.

    Called before an LLM request. Deterministic detector paths do not route
    through here, so a breached budget degrades the platform to its rules-based
    behaviour instead of taking it down.
    """
    if kill_switch_engaged():
        _ledger("llm_call_refused", actor,
                {"cause": "kill_switch", "task": task,
                 "reason": _state["reason"]})
        raise KillSwitchEngaged(
            "LLM traffic is administratively halted"
            + (f": {_state['reason']}" if _state["reason"] else ""))

    try:
        from . import telemetry
        snap = telemetry.snapshot()
        session = Decimal(str(getattr(snap, "session_cost_usd", 0) or 0))
        glob = Decimal(str(getattr(snap, "global_cost_usd", 0) or 0))
    except Exception:                                    # fail OPEN — see docstring
        log.debug("budget check could not read telemetry", exc_info=True)
        return {"allowed": True, "reason": "telemetry unavailable; "
                                           "allowing the call"}

    lim = limits()
    if session >= lim["session_hard_usd"]:
        _ledger("llm_call_refused", actor,
                {"cause": "session_hard_cap", "task": task,
                 "session_cost_usd": str(session),
                 "limit_usd": str(lim["session_hard_usd"])})
        raise BudgetExceeded(
            f"session spend ${session} has reached the hard cap "
            f"${lim['session_hard_usd']} — the model call was refused, not "
            f"truncated")
    if glob >= lim["global_hard_usd"]:
        _ledger("llm_call_refused", actor,
                {"cause": "global_hard_cap", "task": task,
                 "global_cost_usd": str(glob),
                 "limit_usd": str(lim["global_hard_usd"])})
        raise BudgetExceeded(
            f"global spend ${glob} has reached the hard cap "
            f"${lim['global_hard_usd']} — the model call was refused")
    return {"allowed": True, "session_cost_usd": str(session),
            "global_cost_usd": str(glob)}


def allowed(actor: str = "", task: str = "") -> bool:
    """Non-raising form, for callers that prefer to degrade quietly."""
    try:
        check(actor, task)
        return True
    except (BudgetExceeded, KillSwitchEngaged):
        return False


def _ledger(event: str, actor: str, payload: dict) -> None:
    try:
        from ..trust import ledger_v2
        ledger_v2.append("system", event, actor or "system", payload)
    except Exception:                                    # pragma: no cover
        log.debug("enforcement ledger write failed", exc_info=True)


def reset() -> None:
    """Test helper."""
    with _lock:
        _state.update({"killed": False, "reason": "", "actor": ""})
    os.environ.pop(_KILL_ENV, None)
