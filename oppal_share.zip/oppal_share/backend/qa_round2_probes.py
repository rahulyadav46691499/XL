"""Independent round-2 QA probes (Sonnet verifier) — NOT the author's tests.

Verifies the fixes to the two round-1 BLOCKERs (Sentry degradation,
case LOB mislabelling) and the crowd-out issue the generator found while
fixing #1. Adversarial by design: tries to break each fix, not just confirm
the happy path.

Run: OPPAL_DB_PATH=/tmp/qa2_p3.db OPPAL_CASE_DB=/tmp/qa2_cases.db \
     PYTHONPATH=. python3 qa_round2_probes.py
"""
import json
import sqlite3
import sys
import traceback

RESULTS = []


def check(name, fn):
    try:
        fn()
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}")
    except AssertionError as e:
        RESULTS.append((name, False, str(e)))
        print(f"  FAIL  {name} -- {e}")
    except Exception as e:
        RESULTS.append((name, False, f"{type(e).__name__}: {e}"))
        print(f"  FAIL  {name} -- {type(e).__name__}: {e}")
        traceback.print_exc(limit=3)


def _user(uid):
    from app.data.db import get_user_context
    return get_user_context(uid)


def _scope(uid):
    from app.mcp import scope_from_user
    return scope_from_user(_user(uid))


# =============================================================================
# FIX 1: Sentry no longer degraded
# =============================================================================
def sentry_no_degraded_step_multi_user():
    from app.agents import swarm
    for uid in ("u-compliance", "u-ma", "u-medicaid", "u-commercial"):
        r = swarm.run_swarm("What is driving our numbers this quarter?",
                            _user(uid))
        degraded = [s for s in r["trace"] if "degraded" in s.get("step", "")]
        assert not degraded, (uid, degraded)


def sentry_in_trust_components():
    from app.agents import swarm
    r = swarm.run_swarm("General portfolio review", _user("u-compliance"))
    assert "sentry" in r["trust_components"], r["trust_components"]
    assert 0 < r["trust_components"]["sentry"] <= 1


def sentry_anomaly_findings_have_evidence_shape():
    from app.agents import swarm
    r = swarm.run_swarm("What is driving medical cost?", _user("u-compliance"))
    sentry_findings = [f for f in r["findings"] if f["agent"] == "sentry"]
    assert sentry_findings, "sentry produced no findings at all"
    for f in sentry_findings:
        ev = f["evidence"]
        assert "z_score" in ev, ev
        assert "period" in ev, ev
        assert "pct_change" in ev, ev
        assert isinstance(ev["z_score"], (int, float))
        assert isinstance(ev["pct_change"], (int, float))


def sentry_detect_anomalies_called_correctly_no_typeerror():
    """Direct unit check: call SentryAgent.triage against a live scope and
    confirm no TypeError/AttributeError bubbles from a tuple/dict mismatch."""
    from app.agents.departmental import SentryAgent
    from app.agents.framework import AgentContext
    from app.mcp import scope_from_user
    persona = {"name": "sentry", "department": "Operations Command",
               "detector": "triage", "tools": []}
    agent = SentryAgent(persona)
    ctx = AgentContext(user=_user("u-compliance"))
    ctx.pipeline["scope"] = scope_from_user(_user("u-compliance"))
    findings = agent.triage(ctx)   # must not raise
    assert isinstance(findings, list)


def degradation_guard_still_works_when_department_broken():
    """The fix must not have disabled the framework's degradation guard to
    make Sentry pass. Deliberately break a different department and confirm
    the run still completes and records a degraded step for THAT agent,
    while sentry itself still reports cleanly."""
    from app.agents import departmental, swarm
    original = departmental.FWASIUAgent.fwa_scan

    def boom(self, ctx):
        raise RuntimeError("qa-injected department outage")
    departmental.FWASIUAgent.fwa_scan = boom
    try:
        r = swarm.run_swarm(
            "Are there billing anomalies or upcoding from any provider?",
            _user("u-compliance"))
        assert isinstance(r["findings"], list), "run must not crash"
        degraded_steps = [s for s in r["trace"] if "degraded" in s["step"]]
        assert any("fwa_siu" in s["step"] for s in degraded_steps), \
            (degraded_steps, "expected fwa_siu to degrade")
        # sentry, untouched, must still be clean
        assert not any("sentry" in s["step"] and "degraded" in s["step"]
                      for s in r["trace"])
        assert "sentry" in r["trust_components"]
    finally:
        departmental.FWASIUAgent.fwa_scan = original


def degradation_guard_also_catches_broken_sentry():
    """Sanity: if sentry itself is broken, the guard still catches IT too
    (confirms the guard wasn't special-cased around sentry to hide bugs)."""
    from app.agents import departmental, swarm
    original = departmental.SentryAgent.triage

    def boom(self, ctx):
        raise RuntimeError("qa-injected sentry outage")
    departmental.SentryAgent.triage = boom
    try:
        r = swarm.run_swarm("anything at all", _user("u-compliance"))
        assert isinstance(r["findings"], list)
        assert any("sentry" in s["step"] and "degraded" in s["step"]
                   for s in r["trace"]), r["trace"]
        assert "sentry" not in r["trust_components"]
    finally:
        departmental.SentryAgent.triage = original


# =============================================================================
# FIX 2: Case LOB labelling / visibility
# =============================================================================
def commercial_creates_and_sees_all_own_cases():
    from app.agents import case_store, swarm
    case_store.reset()
    r = swarm.run_swarm(
        "Are there billing anomalies or upcoding from any provider?",
        _user("u-commercial"))
    assert r["cases_created"], "u-commercial should have created cases"
    cscope = _scope("u-commercial")
    own = case_store.list_cases(cscope)
    assert len(own) == len(set(r["cases_created"])), \
        (len(own), len(set(r["cases_created"])))
    for cid in r["cases_created"]:
        c = case_store.get_case(cid, cscope)
        assert c is not None, f"{cid} not visible to its own creator"
        # must be able to update its own case
        out = case_store.update_status(cid, "reviewing", cscope,
                                       owner="blair", actor="u-commercial")
        assert out["status"] == "reviewing"
    # none of them should be labelled the bare cross-LOB "ALL" sentinel
    assert all(c["lob"] != case_store.CROSS_LOB for c in own), own


def ma_and_medicaid_see_none_of_commercial_cases():
    from app.agents import case_store, swarm
    case_store.reset()
    r = swarm.run_swarm(
        "Are there billing anomalies or upcoding from any provider?",
        _user("u-commercial"))
    assert r["cases_created"]
    for uid in ("u-ma", "u-medicaid"):
        assert case_store.list_cases(_scope(uid)) == [], uid
        for cid in r["cases_created"]:
            assert case_store.get_case(cid, _scope(uid)) is None, (uid, cid)
            try:
                case_store.update_status(cid, "reviewing", _scope(uid))
                assert False, f"{uid} must not be able to update {cid}"
            except PermissionError:
                pass


def full_scope_sees_commercial_cases_but_not_labelled_all():
    from app.agents import case_store, swarm
    case_store.reset()
    swarm.run_swarm(
        "Are there billing anomalies or upcoding from any provider?",
        _user("u-commercial"))
    full = case_store.list_cases(_scope("u-compliance"))
    comm = case_store.list_cases(_scope("u-commercial"))
    assert full, "full-scope officer should see the commercial cases"
    assert len(full) == len(comm), (len(full), len(comm))
    assert all(c["lob"] != case_store.CROSS_LOB for c in full), \
        [c["lob"] for c in full]
    # label should be the canonical sorted multi-LOB tag
    assert all(c["lob"] == "ACA Exchange|Commercial" for c in full), \
        [c["lob"] for c in full]


def full_scope_case_labelled_all_and_invisible_to_narrower_users():
    from app.agents import case_store, swarm
    case_store.reset()
    swarm.run_swarm("How is our CMS audit readiness?", _user("u-compliance"))
    full = case_store.list_cases(_scope("u-compliance"))
    cross = [c for c in full if c["lob"] == case_store.CROSS_LOB]
    assert cross, "expected a genuine cross-LOB (ALL) case from a full-scope run"
    cid = cross[0]["case_id"]
    for uid in ("u-commercial", "u-ma", "u-medicaid"):
        assert case_store.get_case(cid, _scope(uid)) is None, uid
        try:
            case_store.update_status(cid, "reviewing", _scope(uid))
            assert False, f"{uid} must not touch a genuine ALL case"
        except PermissionError:
            pass


def scope_label_exact_semantics():
    from app.agents import case_store
    assert case_store.scope_label(_scope("u-compliance")) == "ALL"
    assert case_store.scope_label(_scope("u-ma")) == "Medicare Advantage"
    assert case_store.scope_label(_scope("u-medicaid")) == "Medicaid"
    assert case_store.scope_label(_scope("u-commercial")) == \
        "ACA Exchange|Commercial"    # sorted, canonical


def subset_visibility_narrow_case_visible_to_broader_subset():
    """A case labelled with a single LOB inside u-commercial's allowed set
    (Commercial subset of {ACA Exchange, Commercial}) must be visible."""
    from app.agents import case_store
    case_store.reset()
    case_store.upsert_case(case_type="FWACase", lob="Commercial",
                           subject="PRV-1", pattern="upcoding",
                           created_by="qa")
    cscope = _scope("u-commercial")
    seen = case_store.list_cases(cscope)
    assert len(seen) == 1, seen
    assert case_store._can_see("Commercial", cscope) is True


def subset_visibility_wider_multilob_case_not_visible_to_narrower_user():
    """A case labelled 'Commercial|Medicaid' is NOT a subset of
    u-commercial's {ACA Exchange, Commercial} scope -- must be invisible."""
    from app.agents import case_store
    case_store.reset()
    case_store.upsert_case(case_type="FWACase", lob="Commercial|Medicaid",
                           subject="PRV-2", pattern="upcoding",
                           created_by="qa")
    cscope = _scope("u-commercial")
    assert case_store.list_cases(cscope) == []
    assert case_store._can_see("Commercial|Medicaid", cscope) is False


def adversarial_separator_injection_in_lob_value():
    """Craft a case whose lob VALUE embeds the separator itself, e.g. a
    single 'LOB' string that is literally 'Commercial|Medicaid' inserted as
    one token via a scope-like object with an allowed_lobs entry containing
    the separator. Confirms _can_see doesn't get confused into granting
    access to a case actually spanning an unauthorized LOB."""
    from app.agents import case_store

    class FakeScope:
        allowed_lobs = ["Commercial|Medicaid"]   # attacker-supplied LOB value
        full_lobs = ["Medicare Advantage", "Medicaid", "Commercial",
                    "ACA Exchange"]

        @staticmethod
        def is_full_scope():
            return False

    fake = FakeScope()
    # A genuine cross-lob case labelled "Commercial|Medicaid" (two real LOBs)
    # must NOT be treated as visible just because the attacker's single
    # allowed_lobs *string* happens to collide textually with the label.
    visible = case_store._can_see("Commercial|Medicaid", fake)
    # set(["Commercial|Medicaid"]) as allowed vs case_lobs {"Commercial","Medicaid"}
    # case_lobs <= allowed is False because allowed is a 1-element set whose
    # single element is the whole pipe-joined string, not the two LOBs.
    assert visible is False, \
        "separator-injected allowed_lobs entry wrongly satisfied subset check"


def adversarial_empty_label_and_unknown_lob():
    from app.agents import case_store
    cscope = _scope("u-commercial")
    fullscope = _scope("u-compliance")
    # empty label: must never be visible to anyone (not even full scope,
    # since _label_lobs("", scope) -> empty set -> case_lobs is falsy)
    assert case_store._can_see("", cscope) is False
    assert case_store._can_see("", fullscope) is False
    # unknown LOB name not in anyone's allowed set / full universe
    assert case_store._can_see("Atlantis", cscope) is False
    assert case_store._can_see("Atlantis", fullscope) is False


def adversarial_spoofed_all_label_without_full_scope():
    """Insert a case row directly with lob='ALL' as if crafted by a
    non-full-scope creator (simulating a bypass of scope_label). Confirm
    _can_see still gates it correctly -- a non-full-scope viewer must NOT
    see it even though the label says ALL, and a genuinely full-scope
    viewer legitimately can (that's the contract for the ALL sentinel)."""
    from app.agents import case_store
    case_store.reset()
    case_store.upsert_case(case_type="FWACase", lob=case_store.CROSS_LOB,
                           subject="PRV-99", pattern="spoof",
                           created_by="qa-attacker")
    assert case_store.list_cases(_scope("u-commercial")) == []
    assert case_store.list_cases(_scope("u-ma")) == []
    assert len(case_store.list_cases(_scope("u-compliance"))) == 1


def adversarial_case_id_enumeration_across_users():
    """Even knowing the exact case_id of another LOB's case (e.g. by
    enumerating FWA-prefixed ids), an out-of-scope user gets None/refused,
    never partial data."""
    from app.agents import case_store, swarm
    case_store.reset()
    swarm.run_swarm("How is our CMS audit readiness?", _user("u-compliance"))
    all_cases = case_store.list_cases(_scope("u-compliance"))
    assert all_cases
    for c in all_cases:
        got = case_store.get_case(c["case_id"], _scope("u-ma"))
        got2 = case_store.get_case(c["case_id"], _scope("u-medicaid"))
        # only assert None if u-ma/u-medicaid truly shouldn't see it
        cscope_ma, cscope_md = _scope("u-ma"), _scope("u-medicaid")
        if not case_store._can_see(c["lob"], cscope_ma):
            assert got is None, (c["case_id"], c["lob"])
        if not case_store._can_see(c["lob"], cscope_md):
            assert got2 is None, (c["case_id"], c["lob"])


def raw_db_row_lob_values_match_scope_label_contract():
    """Inspect the raw sqlite rows (bypassing case_store's own API) to
    confirm what's actually persisted, not just what the read path returns."""
    from app.agents import case_store, swarm
    case_store.reset()
    swarm.run_swarm(
        "Are there billing anomalies or upcoding from any provider?",
        _user("u-commercial"))
    con = sqlite3.connect(case_store.CASE_DB)
    try:
        rows = con.execute("SELECT lob FROM cases").fetchall()
    finally:
        con.close()
    assert rows, "no rows persisted"
    for (lob,) in rows:
        assert lob == "ACA Exchange|Commercial", lob
        assert lob != "ALL"


# =============================================================================
# FIX 3: activation crowd-out
# =============================================================================
LIVE_ANOMALIES = [{"evidence": {"metric": "medical_cost"}},
                  {"evidence": {"metric": "pbm_reject_rate"}}]


def explicit_intent_wins_with_live_anomalies():
    from app.agents import swarm
    cases = {
        "Are there billing anomalies or upcoding from any provider?": "fwa_siu",
        "How is our CMS audit readiness?": "compliance",
        "Show the prior authorization backlog": "clinical_um",
        "Why did pharmacy rejects spike this quarter?": "pbm_forensics",
        "What is driving medical cost?": "medical_economics",
    }
    for q, expected in cases.items():
        names = [p["name"] for p in swarm.select_agents(q, LIVE_ANOMALIES)]
        assert expected in names, (q, names, "crowded out by ambient anomalies")


def departmental_count_never_exceeds_budget_with_anomalies():
    from app.agents import swarm
    cfg = swarm.settings()
    kitchen_sink = ("cost pharmacy reject provider network prior auth hedis "
                    "raf fraud compliance audit medical pmpm upcoding cms")
    names = [p["name"] for p in swarm.select_agents(kitchen_sink,
                                                    LIVE_ANOMALIES)]
    departmental = [n for n in names
                    if n not in ("sentry", "prescriptive_action")]
    assert len(departmental) <= cfg["max_active_agents"], names


def attempt_to_construct_crowdout_with_ties():
    """Adversarial construction: try to build a question + anomaly mix where
    an EXPLICITLY requested department is still pushed out of the budget by
    tied/competing keyword matches on other departments. Budget is
    max_active_agents(4) minus always-on-with-priority<90 (sentry) = 3
    departmental slots. Target a high-priority-number department
    (compliance, priority 40) against three lower-priority (earlier) equal-
    score competitors."""
    from app.agents import swarm
    target = "compliance"
    # one hit each for medical_economics(10), pbm_forensics(20),
    # clinical_um(25) -- all lower priority number than compliance(40) --
    # plus exactly one hit for compliance itself. If scores tie, sort is by
    # priority ascending, so compliance (highest priority number) sorts last
    # among the tied set.
    q = "cost pharmacy prior auth audit"
    names = [p["name"] for p in swarm.select_agents(q, [])]
    result = {"question": q, "activated": names,
              "target_present": target in names}
    print("    crowd-out construction attempt:", json.dumps(result))
    assert target in names, \
        f"CROWD-OUT REPRODUCED: {target} pushed out by {names}"


def attempt_crowdout_with_multi_hit_competitors_outscoring_target():
    """Stronger adversarial attempt: give competing departments MULTIPLE
    trigger hits (higher score) than the explicitly-requested target's
    single-phrase match, while keeping the target's own phrase present."""
    from app.agents import swarm
    target = "compliance"
    # medical_economics triggers: cost, spend, mlr, pmpm, utilization, trend,
    # severity, allowed, paid, medical -> stack many for a high score
    # pbm_forensics triggers: pharmacy, rx, pbm, reject, formulary, drug,
    # tier, ncpdp
    # clinical_um triggers: prior auth, authorization, um, pended
    q = ("cost spend mlr pmpm utilization trend severity allowed paid medical "
        "pharmacy rx pbm reject formulary drug tier ncpdp "
        "prior auth authorization pended "
        "compliance audit")   # target's own single-phrase match
    names = [p["name"] for p in swarm.select_agents(q, LIVE_ANOMALIES)]
    print("    multi-hit crowd-out attempt activated:", names)
    assert target in names, \
        f"CROWD-OUT REPRODUCED under multi-hit competition: {names}"


def anomaly_alone_never_beats_explicit_absence_correctly():
    """Sanity check the weighting direction: with NO keyword match at all,
    ambient anomalies alone should still be able to activate a department
    (that's the intended, legitimate anomaly-driven path) -- confirms the
    fix didn't neuter anomaly-driven activation entirely while fixing
    crowd-out."""
    from app.agents import swarm
    names = [p["name"] for p in
             swarm.select_agents("hello", LIVE_ANOMALIES)]
    assert ("medical_economics" in names or "pbm_forensics" in names), \
        ("anomaly-driven activation appears disabled entirely", names)


if __name__ == "__main__":
    tests = [(k, v) for k, v in sorted(globals().items())
             if callable(v) and not k.startswith("_") and k not in
             ("check",) and v.__module__ == "__main__"]
    print(f"Running {len(tests)} independent round-2 probes\n")
    for name, fn in tests:
        check(name, fn)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = len(RESULTS) - passed
    print(f"\n{passed} passed, {failed} failed")
    if failed:
        print("\nFAILURES:")
        for name, ok, msg in RESULTS:
            if not ok:
                print(f"  - {name}: {msg}")
    sys.exit(1 if failed else 0)
