"""Independent Phase 4 QA probes (Opus verifier) — NOT the author's tests.

Adversarial probe suite for the HITL Action & Write-Back Engine. Written from
scratch by the independent QA reviewer; test_phase4.py was deliberately not
reused or trusted. Every probe tries to BREAK a control rather than confirm a
happy path: dual-control boundary arithmetic, separation-of-duties evasion
(string variants, empty ids, races, second-slot-first, DB tampering), the
double gate (pending / rejected / replay / below-gate / one-approver /
zero-approver / forged in-memory action), the adapter contract (MRO and
post-hoc execute() overrides, untyped payloads, cross-target payloads, direct
_send), idempotency durability, audit/ledger integrity and PHI egress, LOB
scoping, and finally whether the control INPUTS themselves are trustworthy.

Run (SQLite cannot lock a mounted volume, so use /tmp):

    cd oppal/backend
    OPPAL_DB_PATH=/tmp/qa_p4.db OPPAL_CASE_DB=/tmp/qa_p4cases.db \
    OPPAL_ACTION_DB=/tmp/qa_p4act.db OPPAL_AUDIT_LOG=/tmp/qa_ledger.jsonl \
    PYTHONPATH=. python3 qa4_probes.py

Findings are printed as `*** VULN/FAIL [tag]` (a broken claim) or
`--- NOTE [tag]` (a real weakness that is not a bypass on its own), and
summarised at the end. See qa/phase_4_verdict.md for the classification.

NOTE: the Brain sections temporarily edit
semantic/domains/healthcare_payer/policy_rules.md and restore it in a
`finally:` block. Do not interrupt them.
"""
"""INDEPENDENT QA probe suite for OpPal Phase 4 (written by the QA verifier,
NOT the code author). Deliberately adversarial."""
import json, os, sys, copy, sqlite3, hashlib, threading
import re as _re

from app.actions import engine
from app.actions.base import (BaseActionAdapter, ActionRefused,
                              AdapterUnavailable, _COMPLETED)
from app.actions import registry
from app.actions.adapters.dry_run import DryRunAdapter, TRANSCRIPT
from app.schemas.actions import (ActionPayload, ActionRequest, ActionState,
                                 ApprovalSignature, ControlMode)
from app.mcp.models import ScopeContext
from app.data.db import ALL_LOBS, ensure_db

ensure_db()
FULL = ALL_LOBS()
CO = {"user_id": "u-compliance", "role": "compliance_officer"}
CO2 = {"user_id": "u-compliance2", "role": "compliance_officer"}
ANALYST = {"user_id": "u-ma", "role": "ma_analyst"}
S_FULL = ScopeContext(user_id="u-compliance", role="compliance_officer",
                      allowed_lobs=list(FULL), full_lobs=list(FULL),
                      authorized=True)
S_MA = ScopeContext(user_id="u-ma", role="ma_analyst",
                    allowed_lobs=["Medicare Advantage"], full_lobs=list(FULL),
                    authorized=True)
S_COMM = ScopeContext(user_id="u-commercial", role="commercial_analyst",
                      allowed_lobs=["Commercial"], full_lobs=list(FULL),
                      authorized=True)
FAILS, NOTES = [], []

def p(label, out): print("  %s: %s" % (label, out))
def hdr(t): print("\n" + "=" * 78 + "\n" + t + "\n" + "=" * 78)
def fail(tag, msg):
    FAILS.append((tag, msg)); print("  *** VULN/FAIL [%s] %s" % (tag, msg))
def note(tag, msg):
    NOTES.append((tag, msg)); print("  --- NOTE [%s] %s" % (tag, msg))

def mk(**kw):
    d = dict(action_type="letter_send", target_object="C-1234567",
             lob="Medicare Advantage", summary="qa probe",
             estimated_financial_impact=100.0, regulatory_severity="low",
             trust_score=0.95)
    d.update(kw)
    return engine.propose(**d)

def poke(aid, **cols):
    con = sqlite3.connect(engine.ACTION_DB)
    try:
        for k, v in cols.items():
            con.execute("UPDATE actions SET %s=? WHERE action_id=?" % k,
                        (v, aid))
        con.commit()
    finally:
        con.close()

engine.reset()
ad = registry.get_adapter("dry_run")
GATE = float(engine.rules()["execution_trust_gate"])

# ===========================================================================
hdr("CLAIM 1 -- DUAL CONTROL (Brain-driven) boundary probes")
for imp in [0.0, 9999.99, 10000.0, 10000.01, 25000.0, -50000.0, -0.01]:
    m, r = engine.determine_control_mode("letter_send", imp, "low")
    p("impact=%r" % imp, "%s reasons=%s" % (m.value, r))
    if imp >= 10000 and m != ControlMode.DUAL:
        fail("C1-threshold", "impact %s did not force dual" % imp)
if engine.determine_control_mode("letter_send", -50000.0, "low")[0] == ControlMode.SINGLE:
    note("C1-negative", "negative impact -$50,000 yields SINGLE control (no abs()"
         " on impact); a large credit in the other direction escapes dual control")
for sev in ["critical", "CRITICAL", "Critical", "cRiTiCaL", "high", "HIGH",
            " critical ", "critical\n", "medium", "low", ""]:
    m, r = engine.determine_control_mode("letter_send", 100.0, sev)
    p("severity=%r" % sev, m.value)
    if sev.strip().lower() in ("critical", "high") and m != ControlMode.DUAL:
        fail("C1-severity", "severity %r did not force dual control" % sev)
for at in ["claim_adjustment", "overpayment_recovery", "auth_override",
           "universe_resubmission", "letter_send", "Claim_Adjustment",
           " claim_adjustment", "claim_adjustment "]:
    m, r = engine.determine_control_mode(at, 1.0, "low")
    p("action_type=%r" % at, m.value)

print("\n  -- None / missing / string impact")
try:
    m, r = engine.determine_control_mode("letter_send", None, "low")
    p("impact=None", m.value)
    if m != ControlMode.DUAL:
        note("C1-none", "impact=None -> %s" % m.value)
except Exception as e:
    p("impact=None", "RAISED %s: %s" % (type(e).__name__, e))
    note("C1-none-raises", "determine_control_mode(None) raises %s; propose() "
         "with impact=None fails closed but ungracefully" % type(e).__name__)
try:
    a = engine.propose(action_type="letter_send", target_object="X",
                       lob="Medicare Advantage", summary="s",
                       estimated_financial_impact=None,
                       regulatory_severity="low", trust_score=0.9)
    p("propose(impact=None)", "%s impact=%s" % (a.control_mode.value,
                                                a.estimated_financial_impact))
except Exception as e:
    p("propose(impact=None)", "RAISED %s: %s" % (type(e).__name__, e))
for bad in ["99999", "abc"]:
    try:
        m, r = engine.determine_control_mode("letter_send", bad, "low")
        p("impact=%r (str)" % bad, m.value)
        if m != ControlMode.DUAL and bad == "99999":
            fail("C1-str-impact", "string impact %r bypasses the threshold -> %s"
                 % (bad, m.value))
    except Exception as e:
        p("impact=%r (str)" % bad, "RAISED %s: %s" % (type(e).__name__, e))
try:
    a = engine.propose(action_type="letter_send", target_object="X",
                       lob="Medicare Advantage", summary="s",
                       estimated_financial_impact="99999",
                       regulatory_severity="low", trust_score=0.9)
    p("propose(impact='99999' str)", "mode=%s stored=%s"
      % (a.control_mode.value, a.estimated_financial_impact))
    if a.control_mode == ControlMode.SINGLE:
        fail("C1-str-impact-propose", "propose() with a STRING impact '99999' -> "
             "SINGLE control although the stored impact is 99999.0 (>= $10k)")
except Exception as e:
    p("propose(impact='99999')", "RAISED %s: %s" % (type(e).__name__, e))

print("\n  -- Brain edit changes behaviour with NO code change")
RULES_MD = "app/semantic/domains/healthcare_payer/policy_rules.md"
orig = open(RULES_MD).read()
from app.semantic.brain import reload_brain
try:
    open(RULES_MD, "w").write(orig.replace(
        "- financial_impact_threshold: 10000",
        "- financial_impact_threshold: 250").replace(
        "- execution_trust_gate: 0.85", "- execution_trust_gate: 0.99"))
    reload_brain()
    m, r = engine.determine_control_mode("letter_send", 500.0, "low")
    p("threshold->250, impact=500", "%s %s" % (m.value, r))
    p("gate->0.99", engine.rules()["execution_trust_gate"])
    if m != ControlMode.DUAL:
        fail("C1-brain", "editing the Brain threshold did NOT change behaviour")
    g2 = mk(trust_score=0.95)
    engine.approve(g2.action_id, CO2, S_FULL)
    try:
        engine.execute(g2.action_id, CO, S_FULL)
        fail("C1-brain-gate", "0.95-trust action executed under a 0.99 gate")
    except Exception as e:
        p("execute trust=0.95 under gate 0.99", "REFUSED %s: %s"
          % (type(e).__name__, e))
finally:
    open(RULES_MD, "w").write(orig)
    reload_brain()
    p("restored", engine.rules())

# ===========================================================================
hdr("CLAIM 2 -- SEPARATION OF DUTIES")
a = mk(estimated_financial_impact=25000.0, proposer_user_id="u-compliance")
p("dual action", "%s mode=%s state=%s" % (a.action_id, a.control_mode.value,
                                          a.state.value))
print("\n  2a. proposer self-approval")
try:
    engine.approve(a.action_id, CO, S_FULL)
    fail("C2-self", "the PROPOSER approved its own action")
except Exception as e:
    p("proposer approve", "REFUSED %s: %s" % (type(e).__name__, e))
print("\n  2b. unauthorized role")
for u in [ANALYST, {"user_id": "x", "role": None},
          {"user_id": "x", "role": "compliance_officer "},
          {"user_id": "x", "role": "Compliance_Officer"}, {}]:
    try:
        engine.approve(a.action_id, u, S_FULL)
        fail("C2-role", "role %r approved a write-back action" % u.get("role"))
    except Exception as e:
        p("approve as role=%r" % u.get("role"),
          "REFUSED %s: %s" % (type(e).__name__, str(e)[:70]))
print("\n  2c. same user approves twice (sequential)")
a2 = engine.approve(a.action_id, CO2, S_FULL)
p("1st approval", "state=%s ap1=%s" % (a2.state.value, a2.approver_1_id))
try:
    engine.approve(a.action_id, CO2, S_FULL)
    fail("C2-twice", "the SAME user supplied both approvals")
except Exception as e:
    p("2nd approval same user", "REFUSED %s: %s" % (type(e).__name__, e))
print("\n  2d. case / whitespace variant of the same user id")
for variant in ["U-COMPLIANCE2", " u-compliance2", "u-compliance2 "]:
    b = mk(estimated_financial_impact=25000.0)
    engine.approve(b.action_id, CO2, S_FULL)
    try:
        r = engine.approve(b.action_id,
                           {"user_id": variant, "role": "compliance_officer"},
                           S_FULL)
        ok, why = r.executable(GATE)
        msg = ("variant %r accepted as approver_2 (ap1=%r ap2=%r) executable=%s %s"
               % (variant, r.approver_1_id, r.approver_2_id, ok, why))
        if ok:
            fail("C2-variant-exec", "ENGINE-LEVEL: one human string-variant "
                 "completed dual control and the action is EXECUTABLE: " + msg)
        else:
            fail("C2-variant", msg)
    except Exception as e:
        p("variant %r" % variant, "REFUSED %s: %s" % (type(e).__name__, e))
print("\n  2d-bis. can a real login produce a variant user_id?")
from app.data.db import get_user_context
for v in ["u-compliance2", "U-COMPLIANCE2", " u-compliance2"]:
    ctx = get_user_context(v)
    p("get_user_context(%r)" % v, "authorized=%s canonical_user_id=%r"
      % (ctx.get("authorized"), ctx.get("user_id")))
print("\n  2e. empty proposer_user_id + empty approver user_id")
c = mk(estimated_financial_impact=25000.0, proposer_user_id="")
EMPTY = {"user_id": "", "role": "compliance_officer"}
try:
    r1 = engine.approve(c.action_id, EMPTY, S_FULL)
    p("1st approval (uid='')", "state=%s ap1=%r" % (r1.state.value,
                                                    r1.approver_1_id))
    r2 = engine.approve(c.action_id, EMPTY, S_FULL)
    ok, why = r2.executable(GATE)
    p("2nd approval (uid='')", "state=%s ap1=%r ap2=%r distinct=%s executable=%s %s"
      % (r2.state.value, r2.approver_1_id, r2.approver_2_id,
         r2.distinct_approvers(), ok, why))
    if r2.state == ActionState.APPROVED:
        if ok:
            fail("C2-empty-exec", "empty-uid principal single-handedly reached an "
                 "EXECUTABLE dual-control APPROVED state")
        else:
            fail("C2-empty", "a single empty-user_id principal drove a "
                 "dual-control action to APPROVED (SoD is skipped for falsy "
                 "user ids); execution still blocked: " + why)
except Exception as e:
    p("empty uid approve", "REFUSED %s: %s" % (type(e).__name__, e))
print("\n  2f. approve the SECOND slot first (state forced in DB)")
d = mk(estimated_financial_impact=25000.0)
poke(d.action_id, state="PENDING_SECOND_APPROVAL")
try:
    r = engine.approve(d.action_id, CO2, S_FULL)
    ok, why = r.executable(GATE)
    p("second-slot-first", "state=%s ap1=%r ap2=%r executable=%s %s"
      % (r.state.value, r.approver_1_id, r.approver_2_id, ok, why))
    if ok:
        fail("C2-slot2-first", "ONE approval in the second slot produced an "
             "EXECUTABLE action")
    else:
        note("C2-slot2-first", "a DB-forced PENDING_SECOND state lets ONE "
             "approval reach APPROVED with approver_1_id=None; executable() "
             "refuses: " + why)
except Exception as e:
    p("second-slot-first", "REFUSED %s: %s" % (type(e).__name__, e))
print("\n  2g. race: 8 concurrent approvals by the SAME user (ap1 already set)")
e_act = mk(estimated_financial_impact=25000.0)
engine.approve(e_act.action_id, CO, S_FULL)
res = []
def racer(u):
    try: res.append(engine.approve(e_act.action_id, u, S_FULL))
    except Exception as ex: res.append(ex)
ths = [threading.Thread(target=racer, args=(CO,)) for _ in range(8)]
[t.start() for t in ths]; [t.join() for t in ths]
oks = [r for r in res if isinstance(r, ActionRequest)]
p("race outcomes", "%d accepted / %d attempts errors=%s"
  % (len(oks), len(res), sorted({type(r).__name__ for r in res
                                 if isinstance(r, Exception)})))
fin = engine.get(e_act.action_id, S_FULL)
okx, why = fin.executable(GATE)
p("post-race", "state=%s ap1=%s ap2=%s sigs=%d executable=%s %s"
  % (fin.state.value, fin.approver_1_id, fin.approver_2_id,
     len(fin.signatures), okx, why))
if okx and fin.approver_1_id == fin.approver_2_id:
    fail("C2-race", "race produced an executable single-human dual action")
print("\n  2g-bis. race: two DIFFERENT users approve concurrently at slot 1")
e2 = mk(estimated_financial_impact=25000.0)
res2 = []
def racer2(u):
    try: res2.append(("ok", engine.approve(e2.action_id, u, S_FULL)))
    except Exception as ex: res2.append(("err", ex))
ths = [threading.Thread(target=racer2, args=(u,)) for u in (CO, CO2)]
[t.start() for t in ths]; [t.join() for t in ths]
f2 = engine.get(e2.action_id, S_FULL)
p("both-users race", "accepted=%d state=%s ap1=%s ap2=%s stored_sigs=%d"
  % (len([1 for k, _ in res2 if k == "ok"]), f2.state.value, f2.approver_1_id,
     f2.approver_2_id, len(f2.signatures)))
ok2, why2 = f2.executable(GATE)
p("executable", "%s %s" % (ok2, why2))
if ok2 and f2.approver_2_id is None:
    fail("C2-race2", "concurrent slot-1 approvals produced an executable action "
         "with a single recorded approver")
if len([1 for k, _ in res2 if k == "ok"]) == 2 and len(f2.signatures) < 2:
    note("C2-race-lostsig", "read-modify-write on the action row is not atomic "
         "(engine.get() happens outside engine._lock): two concurrent accepted "
         "approvals persist only %d signature(s) on the row (last write wins). "
         "The audit ledger still records both." % len(f2.signatures))
print("\n  2h. approver with the right ROLE but NO scope over the action")
f_act = mk(lob="Medicare Advantage", estimated_financial_impact=25000.0)
OUT = ScopeContext(user_id="u-x", role="compliance_officer",
                   allowed_lobs=["Commercial"], full_lobs=list(FULL),
                   authorized=True)
try:
    engine.approve(f_act.action_id, {"user_id": "u-x",
                                     "role": "compliance_officer"}, OUT)
    fail("C2-scope", "compliance_officer scoped only to Commercial approved a "
         "Medicare Advantage action")
except Exception as e:
    p("out-of-scope approve", "REFUSED %s: %s" % (type(e).__name__, e))
print("\n  2i. approver_1 == approver_2 forced directly in the DB")
g = mk(estimated_financial_impact=25000.0)
engine.approve(g.action_id, CO, S_FULL)
poke(g.action_id, state="APPROVED", approver_2_id="u-compliance")
gg = engine.get(g.action_id, S_FULL)
ok, why = gg.executable(GATE)
p("DB-forced identical approvers", "ap1=%s ap2=%s executable=%s %s"
  % (gg.approver_1_id, gg.approver_2_id, ok, why))
if ok:
    fail("C2-db-identical", "identical approvers passed executable()")
before = len(TRANSCRIPT)
try:
    out = engine.execute(g.action_id, CO, S_FULL)
    fail("C2-db-identical-exec", "engine.execute TRANSMITTED: %s" % out)
except Exception as e:
    p("engine.execute", "REFUSED %s: %s" % (type(e).__name__, e))
r = ad.execute(gg, actor="attacker")
p("adapter.execute (bypassing engine)", json.dumps(r)[:200] +
  " transcript+%d" % (len(TRANSCRIPT) - before))
if r.get("ok"):
    fail("C2-db-identical-adapter", "adapter transmitted identical-approver action")
# ===========================================================================
hdr("CLAIM 3 -- DOUBLE GATE (state == APPROVED and trust >= gate)")
p("brain gate", GATE)
print("\n  3a. execute a PENDING action")
h = mk(estimated_financial_impact=25000.0)
before = len(TRANSCRIPT)
try:
    engine.execute(h.action_id, CO, S_FULL); fail("C3-pending", "a PENDING action executed")
except Exception as e:
    p("PENDING engine.execute", "REFUSED %s: %s" % (type(e).__name__, e))
r = ad.execute(h, actor="attacker")
p("PENDING adapter.execute", json.dumps(r)[:170] + " transcript+%d" % (len(TRANSCRIPT)-before))
if r.get("ok") or len(TRANSCRIPT) > before:
    fail("C3-pending-adapter", "adapter transmitted a PENDING action")

print("\n  3b. execute a REJECTED action")
i = mk()
engine.reject(i.action_id, CO2, S_FULL, reason="qa reject")
ii = engine.get(i.action_id, S_FULL)
before = len(TRANSCRIPT)
try:
    engine.execute(i.action_id, CO, S_FULL); fail("C3-rejected", "a REJECTED action executed")
except Exception as e:
    p("REJECTED engine.execute", "REFUSED %s: %s" % (type(e).__name__, e))
r = ad.execute(ii, actor="attacker")
p("REJECTED adapter.execute", json.dumps(r)[:170] + " transcript+%d" % (len(TRANSCRIPT)-before))
if r.get("ok"): fail("C3-rejected-adapter", "adapter transmitted a REJECTED action")

print("\n  3c. happy path single control, then replay (EXECUTED)")
j = mk(trust_score=0.95)
p("proposed", "mode=%s" % j.control_mode.value)
engine.approve(j.action_id, CO2, S_FULL)
before = len(TRANSCRIPT)
out = engine.execute(j.action_id, CO, S_FULL)
p("execute", "ok=%s transcript+%d" % (out["receipt"].get("ok"), len(TRANSCRIPT)-before))
p("state", engine.get(j.action_id, S_FULL).state.value)
before = len(TRANSCRIPT)
try:
    out2 = engine.execute(j.action_id, CO, S_FULL)
    p("replay", json.dumps(out2)[:150])
    if len(TRANSCRIPT) > before: fail("C3-replay", "replay of an EXECUTED action wrote again")
except Exception as e:
    p("replay engine.execute", "REFUSED %s: %s (transcript+%d)"
      % (type(e).__name__, e, len(TRANSCRIPT)-before))
jj = engine.get(j.action_id, S_FULL)
before = len(TRANSCRIPT)
r = ad.execute(jj, actor="attacker")
p("replay adapter.execute", json.dumps(r)[:170] + " transcript+%d" % (len(TRANSCRIPT)-before))
if len(TRANSCRIPT) > before: fail("C3-replay-adapter", "adapter re-wrote an EXECUTED action")

print("\n  3d. below-gate approved action")
k = mk(trust_score=0.62)
engine.approve(k.action_id, CO2, S_FULL)
kk = engine.get(k.action_id, S_FULL)
p("state/trust", "%s trust=%s" % (kk.state.value, kk.trust_score))
before = len(TRANSCRIPT)
try:
    engine.execute(k.action_id, CO, S_FULL); fail("C3-belowgate", "below-gate action executed via the engine")
except Exception as e:
    p("engine.execute", "REFUSED %s: %s" % (type(e).__name__, e))
r = ad.execute(kk, actor="attacker")
p("adapter.execute (independent)", json.dumps(r)[:200])
if r.get("ok"): fail("C3-adapter-belowgate", "the ADAPTER transmitted a below-gate action")
if len(TRANSCRIPT) > before: fail("C3-belowgate-transcript", "below-gate write reached the transcript")

print("\n  3e. mutate trust in the DB after approval (0.62 -> 0.99)")
poke(k.action_id, trust_score=0.99)
before = len(TRANSCRIPT)
out = engine.execute(k.action_id, CO, S_FULL)
p("execute after DB trust bump", "ok=%s transcript+%d"
  % (out["receipt"].get("ok"), len(TRANSCRIPT)-before))
if out["receipt"].get("ok"):
    note("C3-trust-mutable", "the gate is re-evaluated against PERSISTED state, so a "
         "direct DB write raising trust_score 0.62->0.99 makes a previously-blocked "
         "APPROVED action executable. Approval signatures do NOT commit to "
         "trust_score/state/control_mode and are never re-verified, so this tamper is "
         "not signature-detectable. Requires DB write access.")

print("\n  3f. dual-control action forced APPROVED with only ONE approver")
m_ = mk(estimated_financial_impact=25000.0)
engine.approve(m_.action_id, CO, S_FULL)
poke(m_.action_id, state="APPROVED")
mm = engine.get(m_.action_id, S_FULL)
ok, why = mm.executable(GATE)
p("executable", "%s %s (ap1=%s ap2=%s)" % (ok, why, mm.approver_1_id, mm.approver_2_id))
before = len(TRANSCRIPT)
try:
    engine.execute(m_.action_id, CO, S_FULL); fail("C3-one-approver", "dual action with ONE approver executed")
except Exception as e:
    p("engine.execute", "REFUSED %s: %s" % (type(e).__name__, e))
r = ad.execute(mm, actor="attacker")
p("adapter.execute", json.dumps(r)[:200])
if r.get("ok") or len(TRANSCRIPT) > before:
    fail("C3-one-approver-adapter", "adapter transmitted a 1-approver dual action")

print("\n  3g. downgrade control_mode in the DB (dual -> single), one approver")
n_ = mk(estimated_financial_impact=250000.0, regulatory_severity="critical",
        trust_score=0.99)
engine.approve(n_.action_id, CO, S_FULL)
poke(n_.action_id, state="APPROVED", control_mode="single")
nn = engine.get(n_.action_id, S_FULL)
ok, why = nn.executable(GATE)
before = len(TRANSCRIPT)
out = engine.execute(n_.action_id, CO, S_FULL) if ok else None
p("executable/execute", "%s %s -> ok=%s transcript+%d"
  % (ok, why, (out or {}).get("receipt", {}).get("ok"), len(TRANSCRIPT)-before))
if ok and (out or {}).get("receipt", {}).get("ok"):
    note("C3-mode-downgrade", "a direct DB write of control_mode dual->single lets a "
         "$250k CRITICAL action transmit on ONE signature. Nothing re-derives "
         "control_mode from the Brain at approval/execution time. Requires DB access.")

print("\n  3h. state forced straight to APPROVED with ZERO approvers/signatures")
o_ = mk(trust_score=0.99)
poke(o_.action_id, state="APPROVED")
oo = engine.get(o_.action_id, S_FULL)
ok, why = oo.executable(GATE)
before = len(TRANSCRIPT)
out = engine.execute(o_.action_id, CO, S_FULL) if ok else None
p("zero-approver APPROVED", "executable=%s sigs=%d ap1=%r -> ok=%s transcript+%d"
  % (ok, len(oo.signatures), oo.approver_1_id,
     (out or {}).get("receipt", {}).get("ok"), len(TRANSCRIPT)-before))
if ok:
    fail("C3-zero-approver", "a SINGLE-control action in state APPROVED with NO "
         "approver_1_id and NO signature is executable and TRANSMITS: executable() "
         "never verifies that a human signature exists for single control")
before = len(TRANSCRIPT)
r = ad.execute(oo, actor="attacker")
p("adapter (fresh, zero-approver)", json.dumps(r)[:170] + " transcript+%d" % (len(TRANSCRIPT)-before))

print("\n  3i. in-memory ActionRequest with state=APPROVED, never persisted")
fab = ActionRequest(action_id="ACT-forged", action_type="claim_adjustment",
                    target_object="C-0000001", lob="Medicare Advantage",
                    proposed_by="attacker", trust_score=1.0,
                    control_mode=ControlMode.SINGLE, state=ActionState.APPROVED,
                    payload=ActionPayload(action_id="ACT-forged",
                                          action_type="claim_adjustment",
                                          target_system="dry_run",
                                          target_object="C-0000001",
                                          lob="Medicare Advantage",
                                          fields={"paid_amount": "0"}))
before = len(TRANSCRIPT)
r = ad.execute(fab, actor="attacker")
p("forged in-memory action", json.dumps(r)[:200] + " transcript+%d" % (len(TRANSCRIPT)-before))
if r.get("ok"):
    fail("C3-forged", "a hand-built ActionRequest with state=APPROVED, zero "
         "approvers and zero signatures TRANSMITS through the adapter base")

# ===========================================================================
hdr("CLAIM 4 -- ADAPTER CONTRACT")
print("\n  4a. direct subclass overriding execute()")
try:
    class Evil(BaseActionAdapter):
        target_system = "evil"
        def execute(self, action, *, actor, gate=None): return {"ok": True, "pwned": True}
        def _send(self, payload, action): return {}
        def healthcheck(self): return {}
    fail("C4-direct", "a subclass overrode execute() with no error")
except TypeError as e:
    p("direct override", "TypeError: %s" % e)
print("\n  4b. mixin further up the MRO")
try:
    class Mixin:
        def execute(self, action, *, actor, gate=None): return {"ok": True, "pwned": "mixin"}
    class Sneaky(Mixin, BaseActionAdapter):
        target_system = "sneaky"
        def _send(self, payload, action): return {}
        def healthcheck(self): return {}
    fail("C4-mixin", "a mixin supplied execute() and class creation succeeded")
except TypeError as e:
    p("mixin override", "TypeError: %s" % e)
print("\n  4b-bis. deep MRO: mixin under an already-valid adapter")
try:
    class Mixin2:
        def execute(self, action, *, actor, gate=None): return {"ok": True, "pwned": "deep"}
    class Deep(DryRunAdapter, Mixin2):
        target_system = "deep"
    p("DryRunAdapter+Mixin2 created", "execute is base? %s"
      % (Deep.execute is BaseActionAdapter.execute))
    if Deep.execute is not BaseActionAdapter.execute:
        fail("C4-deepmixin", "a mixin AFTER a valid adapter in the MRO won")
except TypeError as e:
    p("deep mixin", "TypeError: %s" % e)
print("\n  4c. post-hoc assignment (monkeypatch)")
class Ok1(BaseActionAdapter):
    target_system = "dry_run"
    def _send(self, payload, action):
        TRANSCRIPT.append({"posthoc": True}); return {"sent": True}
    def healthcheck(self): return {}
Ok1.execute = lambda self, action, *, actor, gate=None: {"ok": True, "pwned": "posthoc"}
p("post-hoc class assignment", Ok1("x").execute(None, actor="a"))
note("C4-posthoc", "execute() can still be replaced by post-hoc attribute assignment "
     "(Ok1.execute = ...) because __init_subclass__ only fires at class creation. "
     "registry.register() re-checks and refuses such a class, and nothing in the app "
     "patches execute, so this needs code-execution in the process.")
try:
    registry.register("posthoc", Ok1)
    fail("C4-register", "registry accepted a class whose execute() was patched")
except TypeError as e:
    p("registry.register(post-hoc)", "TypeError: %s" % e)
try:
    registry.register("notadapter", dict)
    fail("C4-register2", "registry accepted a non-adapter class")
except TypeError as e:
    p("registry.register(dict)", "TypeError: %s" % e)

print("\n  4d. non-ActionPayload body")
good = mk(trust_score=0.99)
engine.approve(good.action_id, CO2, S_FULL)
gd = engine.get(good.action_id, S_FULL)
bad = copy.deepcopy(gd)
bad.payload = {"action_id": gd.action_id, "target_system": "dry_run", "fields": {"x": 1}}
before = len(TRANSCRIPT)
r = ad.execute(bad, actor="attacker")
p("dict payload", json.dumps(r)[:180] + " transcript+%d" % (len(TRANSCRIPT)-before))
if r.get("ok"): fail("C4-dictpayload", "a raw dict payload transmitted")
class FakePayload(object):
    action_id = "x"; operation = "update"; target_object = "C-1"
    fields = {"a": 1}; idempotency_key = "k"; target_system = "dry_run"
    effective_date = None
    def payload_hash(self): return "deadbeef"
    def model_dump(self): return {}
bad2 = copy.deepcopy(gd); bad2.payload = FakePayload()
before = len(TRANSCRIPT)
r = ad.execute(bad2, actor="attacker")
p("duck-typed payload", json.dumps(r)[:180] + " transcript+%d" % (len(TRANSCRIPT)-before))
if r.get("ok"): fail("C4-duckpayload", "a duck-typed non-ActionPayload transmitted")
before = len(TRANSCRIPT)
try:
    r = ad.execute("not-an-action", actor="attacker")
    p("non-ActionRequest action", json.dumps(r)[:150])
    if r.get("ok"): fail("C4-notaction", "a non-ActionRequest transmitted")
except Exception as e:
    p("non-ActionRequest action", "adapter CRASHED %s: %s" % (type(e).__name__, e))
    note("C4-crash", "BaseActionAdapter.execute() refuses a non-ActionRequest but then "
         "crashes in its own ActionRefused handler (log/_audit touch "
         "action.action_id), turning a clean refusal into an unhandled exception. "
         "No write occurs (transcript+%d) and the engine never passes a non-"
         "ActionRequest, so this is a robustness defect, not a bypass."
         % (len(TRANSCRIPT)-before))

print("\n  4e. target_system mismatch, both directions")
mism = copy.deepcopy(gd)
mism.payload = ActionPayload(**dict(list(gd.payload.model_dump().items()) +
                                    [("target_system", "facets")]))
before = len(TRANSCRIPT)
r = ad.execute(mism, actor="attacker")
p("facets payload -> dry_run adapter", json.dumps(r)[:220] +
  " transcript+%d" % (len(TRANSCRIPT)-before))
if r.get("ok") or len(TRANSCRIPT) > before:
    fail("C4-mismatch1", "cross-target payload transmitted via dry_run")
fad = registry.get_adapter("facets")
r = fad.execute(gd, actor="attacker")
p("dry_run payload -> facets adapter", json.dumps(r)[:220])
if r.get("ok"): fail("C4-mismatch2", "dry_run payload transmitted via facets")
print("      unconfigured facets adapter with a matching payload:")
mm2 = copy.deepcopy(gd)
mm2.payload = ActionPayload(**dict(list(gd.payload.model_dump().items()) +
                                   [("target_system", "facets")]))
r = fad.execute(mm2, actor="attacker")
p("facets (no endpoint)", json.dumps(r)[:220])
print("\n  4f. is _send reachable with an unapproved action?")
unappr = mk(trust_score=0.1)
before = len(TRANSCRIPT)
r = ad._send(unappr.payload, unappr)
p("ad._send(...) called directly", json.dumps(r)[:160] +
  " transcript+%d" % (len(TRANSCRIPT)-before))
note("C4-send", "_send() is a plain (single-underscore) method: in-process Python can "
     "call it and bypass every control. It is NOT reachable from any HTTP route -- the "
     "only caller is BaseActionAdapter.execute(), and the only caller of execute() is "
     "engine.execute(). Calling a private method directly is not itself a "
     "vulnerability; execute() is the sole sanctioned path and it is final at class "
     "creation and re-checked at registration. Worth hardening (name-mangle to "
     "__send or assert a preflight token) but not remotely exploitable.")
# ===========================================================================
hdr("CLAIM 5 -- IDEMPOTENCY")
q = mk(trust_score=0.99)
engine.approve(q.action_id, CO2, S_FULL)
qq = engine.get(q.action_id, S_FULL)
before = len(TRANSCRIPT)
r1 = ad.execute(qq, actor="u-compliance")
r2 = ad.execute(qq, actor="u-compliance")
p("two adapter executes", "first ok=%s second replay=%s transcript+%d"
  % (r1.get("ok"), r2.get("idempotent_replay"), len(TRANSCRIPT)-before))
if len(TRANSCRIPT) - before != 1:
    fail("C5-double", "double transmission: transcript grew by %d" % (len(TRANSCRIPT)-before))
print("\n  5b. identical fields, DIFFERENT action_id -> both must transmit")
r_a = mk(target_object="C-9999999", trust_score=0.99, fields={"paid": "1"})
r_b = mk(target_object="C-9999999", trust_score=0.99, fields={"paid": "1"})
engine.approve(r_a.action_id, CO2, S_FULL); engine.approve(r_b.action_id, CO2, S_FULL)
before = len(TRANSCRIPT)
o1 = engine.execute(r_a.action_id, CO, S_FULL)
o2 = engine.execute(r_b.action_id, CO, S_FULL)
p("distinct actions", "keys equal? %s ok1=%s ok2=%s transcript+%d"
  % (r_a.payload.idempotency_key == r_b.payload.idempotency_key,
     o1["receipt"].get("ok"), o2["receipt"].get("ok"), len(TRANSCRIPT)-before))
if len(TRANSCRIPT) - before != 2:
    fail("C5-overdedupe", "two distinct actions were wrongly deduped")
print("\n  5c. force a double write by clearing the in-process ledger")
key = qq.payload.idempotency_key
p("key in _COMPLETED before", key in _COMPLETED)
_COMPLETED.pop(key, None)
before = len(TRANSCRIPT)
r3 = ad.execute(qq, actor="attacker")
p("after clearing _COMPLETED", "ok=%s transcript+%d" % (r3.get("ok"), len(TRANSCRIPT)-before))
if len(TRANSCRIPT) > before:
    note("C5-inprocess", "the idempotency ledger is a process-local dict "
         "(base._COMPLETED). Clearing it -- or simply restarting the API, or running "
         "more than one worker process -- lets the same idempotency key transmit "
         "again. Adapter idempotency is NOT durable. The durable defence is the "
         "persisted state machine (EXECUTED is terminal), which held in probe 3c.")
print("\n  5d. does the STATE machine stop a restart-style replay?")
poke(r_a.action_id, state="APPROVED")
_COMPLETED.pop(r_a.payload.idempotency_key, None)
before = len(TRANSCRIPT)
o = engine.execute(r_a.action_id, CO, S_FULL)
p("re-execute after state rollback + ledger clear", "ok=%s transcript+%d"
  % (o["receipt"].get("ok"), len(TRANSCRIPT)-before))
if len(TRANSCRIPT) > before:
    note("C5-restart", "with BOTH the persisted state rolled back and the process "
         "ledger cleared the same payload transmits twice (needs DB write access).")
print("\n  5e. mutate the idempotency_key in the DB, then re-execute")
r_c = mk(target_object="C-8888888", trust_score=0.99)
engine.approve(r_c.action_id, CO2, S_FULL)
before = len(TRANSCRIPT)
engine.execute(r_c.action_id, CO, S_FULL)
row_payload = json.loads(sqlite3.connect(engine.ACTION_DB).execute(
    "SELECT payload FROM actions WHERE action_id=?", (r_c.action_id,)).fetchone()[0])
row_payload["idempotency_key"] = "attacker-chosen-key"
poke(r_c.action_id, state="APPROVED", payload=json.dumps(row_payload))
o = engine.execute(r_c.action_id, CO, S_FULL)
p("altered key re-execute", "ok=%s transcript+%d"
  % (o["receipt"].get("ok"), len(TRANSCRIPT)-before))

# ===========================================================================
hdr("CLAIM 6 -- AUDIT INTEGRITY")
from app.trust import audit_ledger
LEDGER = audit_ledger.AUDIT_LOG_PATH
p("ledger path", LEDGER)
n0 = len(audit_ledger.read_all()) if os.path.exists(LEDGER) else 0
s = mk(estimated_financial_impact=25000.0, trust_score=0.99,
       proposer_user_id="u-ma", target_object="C-7654321")
engine.approve(s.action_id, CO, S_FULL, note="looks right")
engine.approve(s.action_id, CO2, S_FULL, note="second pair of eyes")
o = engine.execute(s.action_id, CO, S_FULL)
recs = [r for r in audit_ledger.read_all()[n0:] if r.get("action_id") == s.action_id]
events = [r["event"] for r in recs]
p("events", events)
for want in ("proposed", "approved", "execute_attempt", "executed"):
    if want not in events: fail("C6-missing", "ledger is missing the '%s' event" % want)
p("all have payload_commitment", all(r.get("payload_commitment") for r in recs))
if not all(r.get("payload_commitment") for r in recs):
    fail("C6-commit", "some action ledger records lack payload_commitment")
sigs = [r.get("signature") for r in recs if r["event"] == "approved"]
p("approval signatures in ledger", sigs)
if len(sigs) != 2 or sigs[0] == sigs[1]:
    fail("C6-sigs", "expected 2 DIFFERENT approval signatures, got %s" % sigs)
ss = engine.get(s.action_id, S_FULL)
p("stored signatures", [(x.approver_id, x.decision, x.signature[:12]) for x in ss.signatures])
print("\n  6b. rejection reason recorded")
t = mk()
engine.reject(t.action_id, CO2, S_FULL, reason="not supported by evidence")
tt = engine.get(t.action_id, S_FULL)
rec = [r for r in audit_ledger.read_all() if r.get("action_id") == t.action_id
       and r.get("event") == "rejected"]
p("action.rejection_reason", tt.rejection_reason)
p("ledger rejection_reason", rec[0].get("rejection_reason") if rec else None)
p("ledger rejection signature", (rec[0].get("signature") or "")[:16] if rec else None)
if not tt.rejection_reason or not (rec and rec[0].get("rejection_reason")):
    fail("C6-reject", "rejection reason not recorded")
for empty in ["", "   ", "\n"]:
    u = mk()
    try:
        engine.reject(u.action_id, CO2, S_FULL, reason=empty)
        fail("C6-emptyreason", "rejection accepted with reason=%r" % empty)
    except Exception as e:
        p("reject reason=%r" % empty, "REFUSED %s" % type(e).__name__)
print("\n  6c. signature determinism / sensitivity")
base_args = ("ACT-1", "u-a", "approved", "2026-01-01T00:00:00Z", "note", "ph")
b0 = ApprovalSignature.sign(*base_args)
p("deterministic", ApprovalSignature.sign(*base_args) == b0)
p("sig", b0)
for idx, name in enumerate(["action_id", "approver", "decision", "at", "reason",
                            "payload_hash"]):
    args = list(base_args); args[idx] = args[idx] + "X"
    changed = ApprovalSignature.sign(*args) != b0
    p("changing %s changes sig" % name, changed)
    if not changed: fail("C6-sigfield", "signature is insensitive to %s" % name)
p("manual sha256 of the canonical tuple matches",
  hashlib.sha256("|".join(base_args).encode()).hexdigest() == b0)
note("C6-sigscope", "the signature commits to (action_id, approver, decision, at, "
     "reason, payload_hash) ONLY -- not to trust_score, state, control_mode or the "
     "approver's role -- and nothing re-verifies stored signatures at execution time, "
     "so the DB tampering in probes 3e/3g is not signature-detectable.")
print("\n  6d. hash chain after Phase 4 writes")
lines = [l for l in open(LEDGER).read().splitlines() if l.strip()]
prev = "GENESIS"; breaks = []; checked = 0
for ln in lines:
    r = json.loads(ln)
    if r.get("prev_hash") is None: continue
    checked += 1
    if r["prev_hash"] != prev: breaks.append((checked, r.get("kind"), r.get("event")))
    body = ln[:ln.rindex(', "record_hash"')] + "}"
    prev = hashlib.sha256(body.encode()).hexdigest()[:16]
    if r.get("record_hash") != prev: breaks.append(("REHASH-MISMATCH", checked, r.get("event")))
p("records checked", checked)
p("chain breaks", breaks[:8] if breaks else "none")
if breaks:
    note("C6-chain", "%d chain discontinuities across %d records. "
         "audit_ledger._last_hash is a module global reset to 'GENESIS' on every "
         "process start, so the chain restarts per process and appending to an "
         "existing file leaves a break at each process boundary; there is also NO "
         "verifier function anywhere in the codebase, so the chain is never checked. "
         "Pre-existing Phase-0 design that Phase 4 inherits." % (len(breaks), checked))
else:
    p("chain", "verifies end to end")
print("\n  6e. PHI / member identifiers in ledger records?")
phi_pat = [("MBI", _re.compile(r"\b[1-9][AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y0-9]\d-?[AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y0-9]\d-?[AC-HJKMNP-RT-Y]{2}\d\d\b")),
           ("MEMBER", _re.compile(r"\bM-\d{6}\b")),
           ("CLAIM", _re.compile(r"\bC-\d{7}\b"))]
phi_act = engine.propose(
    action_type="letter_send", target_object="M-123456", lob="Medicare Advantage",
    summary="member 4EG5-TE1-MK72 / M-123456 needs a letter",
    estimated_financial_impact=100.0, regulatory_severity="low", trust_score=0.99,
    fields={"mbi": "4EG5-TE1-MK72", "member_id": "M-123456",
            "adjusted_amount": "10000", "npi": "1234567893",
            "nested": {"mbi": "4EG5-TE1-MK72"}, "listed": ["4EG5-TE1-MK72"],
            "numeric": 4321})
engine.approve(phi_act.action_id, CO2, S_FULL)
n1 = len(audit_ledger.read_all())
before = len(TRANSCRIPT)
o = engine.execute(phi_act.action_id, CO, S_FULL)
newrecs = [r for r in audit_ledger.read_all()[n1:] if r.get("action_id") == phi_act.action_id]
hits = {}
for r in newrecs:
    blob = json.dumps(r)
    for kind, pat in phi_pat:
        for m in pat.findall(blob):
            hits.setdefault("%s::%s" % (r.get("event"), kind), set()).add(m)
p("new ledger events", [r.get("event") for r in newrecs])
p("PHI hits in the new ledger records",
  dict((k, sorted(v)) for k, v in hits.items()) or "none")
if hits:
    fail("C6-phi-ledger", "raw PHI/member identifiers appear in ledger records: %s"
         % sorted(hits))
print("  also check the 'proposed' record (free-text summary):")
prop_rec = [r for r in audit_ledger.read_all() if r.get("action_id") == phi_act.action_id
            and r.get("event") == "proposed"]
p("proposed.summary as logged", (prop_rec[0].get("summary") if prop_rec else None))

# ===========================================================================
hdr("CLAIM 7 -- PHI SCRUB ON THE OUTBOUND PAYLOAD")
entry = TRANSCRIPT[-1]
print(json.dumps(entry, indent=2, default=str))
tb = json.dumps(entry)
leaks = dict((k, sorted(set(pat.findall(tb)))) for k, pat in phi_pat if pat.findall(tb))
p("raw PHI in the dry_run transcript", leaks or "none")
f = entry["fields"]
p("top-level MBI scrubbed", f.get("mbi") != "4EG5-TE1-MK72")
p("member_id scrubbed", f.get("member_id"))
p("npi scrubbed", f.get("npi"))
p("nested dict value", f.get("nested"))
p("list value", f.get("listed"))
p("non-str value", f.get("numeric"))
if isinstance(f.get("nested"), dict) and "4EG5-TE1-MK72" in json.dumps(f["nested"]):
    fail("C7-nested", "PHI inside a NESTED dict payload field is NOT scrubbed and is "
                      "transmitted raw")
if "4EG5-TE1-MK72" in json.dumps(f.get("listed")):
    fail("C7-list", "PHI inside a LIST payload field is NOT scrubbed and is "
                    "transmitted raw")
p("target_object as transmitted", entry.get("target_object"))
if phi_pat[1][1].findall(str(entry.get("target_object"))):
    fail("C7-target", "the member identifier in target_object is transmitted and "
                      "logged raw -- target_object is never passed through _scrub")
p("adjusted_amount '10000' after scrub", f.get("adjusted_amount"))
if f.get("adjusted_amount") != "10000":
    fail("C7-corrupt", "a legitimate 5-digit business value was mangled by the ZIP "
         "regex: '10000' -> %r. This corrupted value is what would be written to the "
         "core admin system." % f.get("adjusted_amount"))
sent_hash = entry.get("payload_hash")
approved_hash = engine.get(phi_act.action_id, S_FULL).payload.payload_hash()
p("hash SENT vs hash APPROVED", "%s vs %s same=%s"
  % (sent_hash[:16], approved_hash[:16], sent_hash == approved_hash))
if sent_hash != approved_hash:
    note("C7-hashdrift", "scrubbing mutates the payload AFTER approval, so the bytes "
         "transmitted differ from the payload_hash the approvers signed. The receipt "
         "and both ledger commitments use the PRE-scrub hash while the transcript "
         "records the POST-scrub hash, so no audit record commits to what actually "
         "left the platform.")

# ===========================================================================
hdr("CLAIM 8 -- LOB SCOPING")
ma = mk(lob="Medicare Advantage", estimated_financial_impact=25000.0, trust_score=0.99)
p("MA action", ma.action_id)
p("get() as Commercial analyst", engine.get(ma.action_id, S_COMM))
p("in Commercial list", any(x.action_id == ma.action_id for x in engine.list_actions(S_COMM)))
p("get() as MA analyst", bool(engine.get(ma.action_id, S_MA)))
if engine.get(ma.action_id, S_COMM) is not None:
    fail("C8-get", "an MA action is visible out of scope")
for fn, name in [(lambda: engine.approve(ma.action_id, CO, S_COMM), "approve"),
                 (lambda: engine.reject(ma.action_id, CO, S_COMM, reason="x"), "reject"),
                 (lambda: engine.execute(ma.action_id, CO, S_COMM), "execute")]:
    try:
        fn(); fail("C8-" + name, "out-of-scope %s succeeded on the exact ID" % name)
    except Exception as e:
        p("out-of-scope %s" % name, "REFUSED %s: %s" % (type(e).__name__, e))
EMPTY_SCOPE = ScopeContext(user_id="u-none", role="compliance_officer",
                           allowed_lobs=[], full_lobs=list(FULL), authorized=True)
p("empty-scope list", len(engine.list_actions(EMPTY_SCOPE)))
try:
    engine.execute(ma.action_id, CO, EMPTY_SCOPE)
    fail("C8-emptyscope", "empty-scope principal executed an action")
except Exception as e:
    p("empty-scope execute", "REFUSED %s: %s" % (type(e).__name__, e))
cross = mk(lob="ALL", estimated_financial_impact=1.0)
p("cross-LOB action visible to MA analyst", bool(engine.get(cross.action_id, S_MA)))
p("cross-LOB action visible to full scope", bool(engine.get(cross.action_id, S_FULL)))

# ===========================================================================
hdr("CLAIM 9-EXTRA -- ARE THE CONTROL INPUTS TRUSTWORTHY? (endpoint semantics)")
print("  /api/actions/propose has NO _require() permission check and passes the")
print("  request body straight through: action_type, estimated_financial_impact,")
print("  regulatory_severity, trust_score and target_system are all caller-supplied")
print("  and OVERRIDE the case's values. Simulating an analyst's crafted body:")
body = {"action_type": "claim_adjustment_v2", "target_object": "C-1234567",
        "estimated_financial_impact": 0.0, "regulatory_severity": "low",
        "trust_score": 1.0, "fields": {"paid_amount": "0"}}
crafted = engine.propose(
    case_id="", action_type=body["action_type"], target_object=body["target_object"],
    lob="Medicare Advantage", summary="reverse a $250,000 overpayment",
    estimated_financial_impact=body["estimated_financial_impact"],
    regulatory_severity=body["regulatory_severity"], trust_score=body["trust_score"],
    fields=body["fields"], proposer_user_id="u-ma")
p("crafted proposal", "mode=%s trust=%s impact=%s"
  % (crafted.control_mode.value, crafted.trust_score,
     crafted.estimated_financial_impact))
before = len(TRANSCRIPT)
engine.approve(crafted.action_id, CO2, S_FULL)
out = engine.execute(crafted.action_id, CO, S_FULL)
p("ONE approval then execute", "ok=%s transcript+%d"
  % (out["receipt"].get("ok"), len(TRANSCRIPT)-before))
if out["receipt"].get("ok"):
    fail("C9-selfasserted", "an ANY-ROLE authenticated proposer chooses "
         "action_type / impact / severity / trust_score, so a materially large write "
         "can be presented as $0 impact, 'low' severity, trust 1.00, an unlisted "
         "action_type -> SINGLE control and the gate is cleared by a caller-supplied "
         "float. One compliance-officer click then transmits. Dual control and the "
         "trust gate are only as strong as unvalidated request-body input.")

hdr("SUMMARY")
print("transcript writes recorded overall: %d" % len(TRANSCRIPT))
print("\nVULN/FAIL count: %d" % len(FAILS))
for t_, m in FAILS: print("  [%s] %s" % (t_, m))
print("\nNOTE count: %d" % len(NOTES))
for t_, m in NOTES: print("  [%s] %s" % (t_, m))


# ===========================================================================
# SECTION 10 -- /api/actions/propose ARGUMENT MAPPING (verbatim from main.py)
# ===========================================================================
"""Simulate the EXACT argument mapping performed by /api/actions/propose
(app/main.py:376-410) with an analyst's crafted body, to test whether the
control inputs are attacker-controlled end-to-end."""
import json
from app.actions import engine
from app.actions.adapters.dry_run import TRANSCRIPT
from app.mcp.models import ScopeContext
from app.agents import case_store
from app.data.db import ALL_LOBS, ensure_db, get_user_context
ensure_db(); FULL = ALL_LOBS()
engine.reset()
S_MA = ScopeContext(user_id="u-ma", role="ma_analyst",
                    allowed_lobs=["Medicare Advantage"], full_lobs=list(FULL),
                    authorized=True)
S_FULL = ScopeContext(user_id="u-compliance", role="compliance_officer",
                      allowed_lobs=list(FULL), full_lobs=list(FULL), authorized=True)
CO = {"user_id": "u-compliance", "role": "compliance_officer"}
CO2 = {"user_id": "u-compliance2", "role": "compliance_officer"}

def endpoint_propose(user, scope, body):
    """verbatim mapping from main.propose_action_endpoint (case_id omitted)."""
    case = None
    return engine.propose(
        case_id="",
        action_type=str(body.get("action_type", "claim_adjustment")),
        target_object=str(body.get("target_object") or ""),
        lob=(case or {}).get("lob") or case_store.scope_label(scope),
        summary=str(body.get("summary", ""))[:500],
        estimated_financial_impact=float(body.get("estimated_financial_impact")
                                         or (case or {}).get("estimated_impact") or 0),
        regulatory_severity=str(body.get("regulatory_severity")
                                or (case or {}).get("severity", "medium")),
        trust_score=float(body.get("trust_score")
                          or (case or {}).get("trust_score") or 0),
        compliance_logic=body.get("compliance_logic") or {},
        fields=body.get("fields") or {},
        target_system=str(body.get("target_system") or "dry_run"),
        proposer_user_id=user.get("user_id", ""))

ANALYST = get_user_context("u-ma")
print("caller:", ANALYST["user_id"], ANALYST["role"], ANALYST["allowed_lobs"])

print("\nA) truthful body: $250,000 claim_adjustment, severity critical, trust 0.9")
a = endpoint_propose(ANALYST, S_MA, {
    "action_type": "claim_adjustment", "target_object": "C-1234567",
    "estimated_financial_impact": 250000, "regulatory_severity": "critical",
    "trust_score": 0.9, "summary": "reverse a $250k overpayment",
    "fields": {"paid_amount": "0"}})
print("   ->", a.control_mode.value, "trust", a.trust_score, "impact",
      a.estimated_financial_impact, a.state.value)

print("\nB) same real-world write, LAUNDERED body from the SAME analyst:")
b = endpoint_propose(ANALYST, S_MA, {
    "action_type": "claim_adjustment ",              # trailing space
    "target_object": "C-1234567",
    "estimated_financial_impact": 0,                  # understated
    "regulatory_severity": " critical ",              # padded
    "trust_score": 1.0,                               # self-asserted
    "summary": "minor correction",
    "fields": {"paid_amount": "0"}})
print("   ->", b.control_mode.value, "trust", b.trust_score, "impact",
      b.estimated_financial_impact, b.state.value)
print("   control_determination reasons:",
      b.compliance_logic["control_determination"]["reasons"])
before = len(TRANSCRIPT)
r = engine.approve(b.action_id, CO2, S_FULL, note="looks minor")
print("   after ONE compliance-officer approval:", r.state.value)
out = engine.execute(b.action_id, CO, S_FULL)
print("   execute ->", out["receipt"].get("ok"),
      "transcript+%d" % (len(TRANSCRIPT) - before))
print("   TRANSMITTED:", json.dumps(TRANSCRIPT[-1]))

print("\nC) can the analyst also choose the LIVE target system?")
c = endpoint_propose(ANALYST, S_MA, {
    "action_type": "letter_send", "target_object": "C-1", "trust_score": 1.0,
    "target_system": "facets", "fields": {"x": "1"}})
print("   target_system stored:", c.target_system, "| payload target:",
      c.payload.target_system, "(default_target is dry_run)")

print("\nD) can the analyst forge the LOB (scope) too?")
d = endpoint_propose(ANALYST, S_MA, {
    "action_type": "letter_send", "target_object": "C-1", "trust_score": 1.0,
    "lob": "Commercial", "fields": {}})
print("   lob stored:", d.lob, "(body 'lob' is IGNORED -- derived from scope) OK")


# ===========================================================================
# SECTION 11 -- BRAIN-DRIVEN SWITCHES: absent rules, gate 0, self-approval
# ===========================================================================
import re, os, json
from app.actions import engine
from app.semantic.brain import reload_brain
from app.mcp.models import ScopeContext
from app.data.db import ALL_LOBS, ensure_db
from app.actions.adapters.dry_run import TRANSCRIPT
ensure_db(); FULL = ALL_LOBS()
S = ScopeContext(user_id="u-compliance", role="compliance_officer",
                 allowed_lobs=list(FULL), full_lobs=list(FULL), authorized=True)
CO = {"user_id": "u-compliance", "role": "compliance_officer"}
CO2 = {"user_id": "u-compliance2", "role": "compliance_officer"}
P = "app/semantic/domains/healthcare_payer/policy_rules.md"
orig = open(P).read()

def show(tag):
    r = engine.rules()
    print("  %-28s gate=%s threshold=%s roles=%s triggers=%s self_approval=%s"
          % (tag, r["execution_trust_gate"], r["financial_impact_threshold"],
             r["approver_roles"], r["regulatory_severity_triggers"],
             r["self_approval_allowed"]))

try:
    print("A) baseline"); reload_brain(); show("as shipped")

    print("\nB) DELETE the whole ACT-TRUST-GATE + ACT-APPROVER-ROLES sections")
    stripped = re.sub(r"### ACT-TRUST-GATE.*?(?=###)", "", orig, flags=re.S)
    stripped = re.sub(r"### ACT-APPROVER-ROLES.*?(?=###)", "", stripped, flags=re.S)
    open(P, "w").write(stripped); reload_brain(); show("rules removed")
    print("     -> falls back to the code literals in brain.py (0.85 / "
          "compliance_officer): fails SAFE, but the gate is NOT absent-fail-closed")

    print("\nC) set execution_trust_gate: 0  (an operator trying to disable the gate)")
    open(P, "w").write(orig.replace("- execution_trust_gate: 0.85",
                                    "- execution_trust_gate: 0"))
    reload_brain(); show("gate: 0")
    z = engine.propose(action_type="letter_send", target_object="C-0",
                       lob="Medicare Advantage", summary="s",
                       estimated_financial_impact=100.0,
                       regulatory_severity="low", trust_score=0.0)
    engine.approve(z.action_id, CO2, S)
    nz = len(TRANSCRIPT)
    oz = engine.execute(z.action_id, CO, S)
    print("     trust=0.0 action EXECUTED:", oz["receipt"].get("ok"),
          "transcript+%d" % (len(TRANSCRIPT) - nz))
    print("     -> the 'hard' gate has NO floor: a compliance_officer with the "
          "brain_write permission can set it to 0 and every approved action, at "
          "any trust level, becomes executable. Authorized-but-unfloored switch.")

    print("\nD) set self_approval_allowed: true  (Brain-driven SoD relaxation)")
    open(P, "w").write(orig.replace("- self_approval_allowed: false",
                                    "- self_approval_allowed: true"))
    reload_brain(); show("self_approval: true")
    a = engine.propose(action_type="letter_send", target_object="C-1",
                       lob="Medicare Advantage", summary="s",
                       estimated_financial_impact=100.0,
                       regulatory_severity="low", trust_score=0.99,
                       proposer_user_id="u-compliance")
    r = engine.approve(a.action_id, CO, S)
    print("     proposer self-approved:", r.state.value, "ap1=", r.approver_1_id)
    before = len(TRANSCRIPT)
    o = engine.execute(a.action_id, CO, S)
    print("     execute ->", o["receipt"].get("ok"),
          "transcript+%d" % (len(TRANSCRIPT) - before))
    print("     -> a SINGLE human proposes, approves and executes. Reachable only "
          "by editing the Brain, which itself needs the brain_write permission "
          "(compliance_officer). Documented switch, but it is a one-line "
          "self-service removal of maker-checker with no second-person control.")
    print("\n     does it also let ONE human satisfy DUAL control?")
    b = engine.propose(action_type="claim_adjustment", target_object="C-2",
                       lob="Medicare Advantage", summary="s",
                       estimated_financial_impact=250000.0,
                       regulatory_severity="critical", trust_score=0.99,
                       proposer_user_id="u-compliance")
    engine.approve(b.action_id, CO, S)
    try:
        r2 = engine.approve(b.action_id, CO, S)
        print("     *** dual control satisfied by one human:", r2.executable(0.85))
    except Exception as e:
        print("     2nd approval by the same human REFUSED:", type(e).__name__, e)
finally:
    open(P, "w").write(orig); reload_brain(); show("restored")
