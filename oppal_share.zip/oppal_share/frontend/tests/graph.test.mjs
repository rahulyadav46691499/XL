/**
 * Regression: the semantic graph must be explorable, not just decorative.
 *
 * Background: GraphView styled every node with `cursor: pointer` but attached
 * no click handler. The graph LOOKED interactive and was not — hover
 * highlighting was the only behaviour. The backend half of sub-graph work
 * (app/semantic/subgraph.py, one-hop expansion + connectivity guarantee) had
 * shipped long before and was in use by the SQL agent; the UI half never was.
 *
 * Two kinds of check here:
 *   1. SOURCE checks — the drill affordances exist and are wired.
 *   2. BEHAVIOURAL checks — the BFS neighbourhood logic is re-implemented
 *      against a fixture graph and asserted, so hop expansion, undirected
 *      traversal and isolation are verified rather than assumed.
 *
 * Run:  node frontend/tests/graph.test.mjs
 */
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const HERE = dirname(fileURLToPath(import.meta.url))
const SRC = join(HERE, '..', 'src')
const gv = readFileSync(join(SRC, 'components', 'GraphView.jsx'), 'utf8')
const css = readFileSync(join(SRC, 'styles.css'), 'utf8')

const PASS = [], FAIL = []
const check = (label, cond, detail = '') => {
  ;(cond ? PASS : FAIL).push(label)
  console.log(`  ${cond ? 'ok  ' : 'FAIL'} ${label}${detail ? ' — ' + detail : ''}`)
}

console.log('\n=== 1. nodes are actually clickable (the original defect) ===')
check('a node has an onClick handler, not just a pointer cursor',
      /onClick=\{\(\) => drill\(n\.id\)\}/.test(gv),
      'cursor:pointer with no handler was the bug')
check('clicking sets the focused node', /const drill = \(id\)/.test(gv))
check('the focused node is visually distinct from its neighbours',
      gv.includes('isFocus') && /stroke=\{isFocus \? 'var\(--accent\)'/.test(gv))
check('the tooltip tells the user the node is clickable',
      gv.includes('Click to drill into this node'))

console.log('\n=== 2. hop depth, breadcrumb, escape hatches ===')
check('hop depth is user-controllable', /\[1, 2, 3\]\.map/.test(gv))
check('a breadcrumb trail records the walk', gv.includes('setTrail'))
check('there is a back step', /const back = \(\)/.test(gv))
check('there is a way back to the whole graph',
      gv.includes('show whole graph') && /const clearFocus/.test(gv))
check('a stale focus is cleared when the node set changes',
      gv.includes('!graph.nodes.some(n => n.id === focus)'),
      'toggling "show all columns" cannot strand the view')

console.log('\n=== 3. layout is computed over the VISIBLE sub-graph ===')
check('layout filters to the neighbourhood before positioning',
      /const visible = nbhd/.test(gv),
      'otherwise a focused sub-graph scatters across an empty canvas')
check('layout recomputes when the neighbourhood changes',
      /\}, \[graph, nbhd\]\)/.test(gv), 'useMemo dependency')

console.log('\n=== 4. the neighbour panel reads the graph out in words ===')
check('a focus panel exists', gv.includes('function FocusPanel'))
check('neighbours are grouped by relationship AND direction',
      gv.includes("dir = '→'") && gv.includes("dir = '←'"),
      '"governs" and "is governed by" are different facts')
check('every neighbour is itself a drill target',
      /onClick=\{\(\) => onDrill\(nb\.id\)\}/.test(gv),
      'the graph can be walked without hunting for a 5px circle')
check('an unconnected node says so instead of rendering blank',
      gv.includes('Nothing in the Brain connects to this node yet'))
check('the panel is styled', /\.graph-focus-panel\s*\{/.test(css)
      && /\.graph-rel-item\s*\{/.test(css))

console.log('\n=== 5. BEHAVIOUR: BFS neighbourhood, re-implemented and asserted ===')
// Mirrors the traversal in GraphView's `nbhd` useMemo.
function nbhd(nodes, edges, focus, hops) {
  const adj = new Map()
  for (const e of edges) {
    if (!adj.has(e.source)) adj.set(e.source, [])
    if (!adj.has(e.target)) adj.set(e.target, [])
    adj.get(e.source).push(e.target)
    adj.get(e.target).push(e.source)
  }
  const depth = new Map([[focus, 0]])
  let frontier = [focus]
  for (let d = 1; d <= hops; d++) {
    const next = []
    for (const id of frontier)
      for (const nb of (adj.get(id) || []))
        if (!depth.has(nb)) { depth.set(nb, d); next.push(nb) }
    frontier = next
    if (!frontier.length) break
  }
  return depth
}

// term → metric → column → table, plus an unrelated island.
const N = ['mlr', 'metric:mlr', 'claims.paid', 'claims', 'island']
const E = [
  { source: 'mlr', target: 'metric:mlr', rel: 'SYNONYM_OF' },
  { source: 'metric:mlr', target: 'claims.paid', rel: 'DERIVED_FROM' },
  { source: 'claims', target: 'claims.paid', rel: 'HAS_COLUMN' },
]

const h1 = nbhd(N, E, 'metric:mlr', 1)
check('1 hop reaches immediate neighbours only',
      h1.size === 3 && h1.has('mlr') && h1.has('claims.paid')
      && !h1.has('claims'),
      [...h1.keys()].join(', '))

const h2 = nbhd(N, E, 'metric:mlr', 2)
check('2 hops reach the table behind the column',
      h2.has('claims') && h2.get('claims') === 2,
      'metric → column → table')

check('traversal is UNDIRECTED — a metric finds its table even though the '
      + 'HAS_COLUMN edge points the other way',
      h2.has('claims'), 'edge direction must not hide lineage')

check('an unconnected node is never pulled in at any depth',
      !nbhd(N, E, 'metric:mlr', 3).has('island'), 'island stays excluded')

const fromIsland = nbhd(N, E, 'island', 3)
check('focusing an isolated node yields just itself',
      fromIsland.size === 1 && fromIsland.get('island') === 0)

check('hop distance is recorded for every reached node',
      h2.get('metric:mlr') === 0 && h2.get('mlr') === 1
      && h2.get('claims') === 2, 'used for the tooltip and the count')

// A cycle must not loop forever or double-count.
const cyc = nbhd(['a', 'b', 'c'],
  [{ source: 'a', target: 'b' }, { source: 'b', target: 'c' },
   { source: 'c', target: 'a' }], 'a', 5)
check('cycles terminate and each node is visited once',
      cyc.size === 3 && cyc.get('a') === 0, 'a=0, b=1, c=1')

console.log('\n=== 6. layout MEASURES itself — long names cannot collide ===')
// Reported: after onboarding the HEDIS table, lineage appeared to stop at
// Columns. Cause: colX/W were the literals [90,360,640,890]/980 and the
// right-hand columns anchored their labels 'end', so they grew LEFTWARDS.
// "hedis_measure_results.denominator_eligible" (42 chars, ~258px) reached
// back over the Metrics band, and Tables sat past the visible width.
check('column positions are computed, not hardcoded literals',
      !/const W = 980, colX = \[90, 360, 640, 890\]/.test(gv)
      && /bands\.push\(\{ x, header, count: nodes\.length \}\)/.test(gv),
      'a fixed canvas cannot fit names it has never seen')
check('column spacing is driven by the widest label in the column',
      /widest\(nodes\)/.test(gv) && /const widest =/.test(gv))
check('the header is measured too, so a long header cannot overrun its band',
      /HEAD_CHAR_W/.test(gv) && /\$\{header\} \$\{nodes\.length\}/.test(gv),
      '"Source documents" is wider than the ids beneath it')
check('every label anchors "start" — none grows back over its neighbour',
      /textAnchor="start"/.test(gv)
      && !/textAnchor=\{meta\.col >= 2 \? 'end' : 'start'\}/.test(gv))
check('the canvas widens to fit the content',
      /const W = Math\.max\(980, /.test(gv), 'container scrolls horizontally')
check('band headers are DERIVED from the nodes present, not hardcoded',
      /const headOf = \(nodes\)/.test(gv)
      && !/'Terms', 'Metrics', 'Columns', 'Tables'/.test(gv),
      'a fixed header array lies the moment a new node type joins a band')

// Re-implement the placement maths and assert non-overlap on a worst case.
function place(colLabels) {
  const CHAR_W = 6.15, LABEL_DX = 11, COL_GAP = 46
  const widest = (ls) => ls.reduce((m, s) => Math.max(m, s.length * CHAR_W), 0)
  const colX = []; let x = 92
  for (let ci = 0; ci < 4; ci++) {
    colX.push(x); x += LABEL_DX + widest(colLabels[ci] || []) + COL_GAP
  }
  return { colX, W: Math.max(980, x - COL_GAP + 40), widest, LABEL_DX }
}
const worst = [
  ['controlling high blood pressure'],
  ['total_numerator_compliant'],
  ['hedis_measure_results.denominator_eligible'],
  ['hedis_measure_results'],
]
const L = place(worst)
let clashes = 0
for (let ci = 0; ci < 3; ci++) {
  const end = L.colX[ci] + L.LABEL_DX + L.widest(worst[ci])
  if (end >= L.colX[ci + 1]) clashes++
}
check('the real worst-case labels leave every column clear',
      clashes === 0,
      `colX=[${L.colX.map(Math.round)}] W=${Math.round(L.W)}`)
const lastEnd = L.colX[3] + L.LABEL_DX + L.widest(worst[3])
check('the Tables column fits inside the canvas (lineage no longer "stops")',
      lastEnd <= L.W, `label ends ${Math.round(lastEnd)} <= W ${Math.round(L.W)}`)
// The bug, reproduced against the OLD constants, so the test proves a change.
const oldX = [90, 360, 640, 890]
const colLabelStart = oldX[2] - 12 - worst[2][0].length * 6.15
check('the OLD fixed layout genuinely did overlap (bug reproduced)',
      colLabelStart < oldX[1] + 12 + worst[1][0].length * 6.15,
      `Columns label started at ${Math.round(colLabelStart)}, inside the `
      + 'Metrics label band — this is the artefact in the screenshot')

console.log('\n=== 7. source documents are OUT of the semantic graph ===')
// Reported against Medicare Sales: the Tables column listed "42 CFR
// §422.2274(d)", "CMS Complaints Tracking Module" and eleven more citations
// alongside the eleven real tables, because TYPE_META put `document` in col 3,
// the same band as `table`, under a header reading "Tables". Documents are now
// dropped from this view entirely — they stay in the Brain and still reach the
// user through the Trust panel's source documents.
check('no band is declared for documents',
      !/^\s*document: \{/m.test(gv) && /const BAND_COUNT = 4/.test(gv),
      'a citation is not a table, and not a band of its own either')
check('document nodes are filtered out of the fetched graph',
      /HIDDEN_NTYPES = new Set\(\['document'\]\)/.test(gv)
      && /HIDDEN_NTYPES\.has\(n\.ntype\)/.test(gv))
check('their edges go with them',
      /edges: g\.edges\.filter\(e => !gone\.has\(e\.source\)/.test(gv),
      'an edge to a node that is not drawn renders as a line to nowhere')
check('the filter runs at FETCH, not at render',
      gv.indexOf('HIDDEN_NTYPES.has(n.ntype)') < gv.indexOf('const layout'),
      'the focus panel and search read `graph` directly')
check('SOURCED_FROM leaves the legend with them',
      !/SOURCED_FROM: '#f78fb3'/.test(gv),
      'every SOURCED_FROM edge ends at a document')
check('the help text no longer advertises SOURCED_FROM',
      !/SOURCED_FROM/.test(readFileSync(join(SRC, 'help', 'helpData.js'), 'utf8')))
check('bands the domain does not populate are dropped, not labelled empty',
      /if \(!nodes\.length\) continue/.test(gv),
      'a header over nothing is a worse lie than none')
check('regulation ids sort as decimals, not as strings',
      /\{ numeric: true \}/.test(gv), 'kept: ids elsewhere sort the same way')
check('each band header carries its own count',
      /\{b\.count\}/.test(gv))

// Behavioural: re-run the fetch filter over the real Medicare Sales mix.
const RAW = {
  nodes: [
    ...['leads', 'applications', 'enrollments', 'agent_commissions']
        .map(id => ({ id, ntype: 'table', label: id })),
    ...['42 CFR §422.2274(d)', '42 CFR §422.52', 'CMS Complaints Tracking Module']
        .map(id => ({ id: `doc:${id}`, ntype: 'document', label: id })),
    { id: 'policy:CMS-RAPID-DISENROLL-RECOUP', ntype: 'policy', label: 'x' },
  ],
  edges: [
    { source: 'policy:CMS-RAPID-DISENROLL-RECOUP',
      target: 'doc:42 CFR §422.2274(d)', rel: 'SOURCED_FROM' },
    { source: 'agent_commissions', target: 'enrollments', rel: 'JOINS_ON' },
  ],
}
const HIDE = new Set(['document'])
const gone = new Set(RAW.nodes.filter(n => HIDE.has(n.ntype)).map(n => n.id))
const kept = {
  nodes: RAW.nodes.filter(n => !gone.has(n.id)),
  edges: RAW.edges.filter(e => !gone.has(e.source) && !gone.has(e.target)),
}
check('not one citation survives the filter',
      !kept.nodes.some(n => /CFR|^CMS /.test(n.label)),
      kept.nodes.map(n => n.label).join(', '))
check('the eleven-real-tables band is untouched',
      kept.nodes.filter(n => n.ntype === 'table').length === 4)
check('the policy node stays — only its citation edge goes',
      kept.nodes.some(n => n.ntype === 'policy')
      && kept.edges.length === 1
      && kept.edges[0].rel === 'JOINS_ON',
      'a rule is still a rule without its document drawn')

console.log('\n=== 8. Analysis: the engine pill must not wrap ===')
const analysis = readFileSync(join(SRC, 'components', 'AnalysisTab.jsx'), 'utf8')
check('the engine pill is marked no-wrap',
      /chip chip-nowrap/.test(analysis),
      'a bordered pill that wraps renders a broken outline')
check('.chip-nowrap enforces it in CSS',
      /\.chip-nowrap\s*\{[^}]*white-space:\s*nowrap/.test(css))
check('the cell gives the pill room instead of squeezing it',
      /\.fn-engine\s*\{[^}]*white-space:\s*nowrap/.test(css)
      && /fn-engine/.test(analysis))

console.log('\n' + '='.repeat(74))
console.log(`  semantic-graph drill-down regression: ${PASS.length}/${PASS.length + FAIL.length} passed`)
FAIL.forEach(f => console.log(`    FAIL ${f}`))
console.log('='.repeat(74))
process.exit(FAIL.length ? 1 : 0)
