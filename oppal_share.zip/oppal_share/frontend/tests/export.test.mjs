/**
 * Export regression — runs in plain Node, no test framework, no npm install.
 *
 *   cd oppal/frontend && node tests/export.test.mjs
 *
 * exportUtils.js is deliberately dependency-free, which also makes it testable
 * with nothing but a stubbed DOM. The assertions that matter most are the
 * ESCAPING ones: a dashboard export embeds user-controlled text (chart titles,
 * the original question, and warehouse cell values) into an HTML document that
 * someone will open locally. If a value carrying markup were interpolated raw,
 * the export itself would become the injection vector — the data may be
 * governed, but "governed" is not the same as "inert HTML".
 */
import { exportDashboardHtml, safeFilename } from '../src/exportUtils.js'

let captured = null
const PASS = [], FAIL = []
const check = (label, cond, detail = '') => {
  ;(cond ? PASS : FAIL).push(label)
  console.log(`  ${cond ? 'ok  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`)
}

// ---- minimal DOM: capture the download instead of performing it ----------
const fakeAnchor = { href: '', download: '', click() {}, remove() {} }
globalThis.document = {
  createElement: () => fakeAnchor,
  createElementNS: () => ({ setAttribute() {} }),
  body: { appendChild() {}, removeChild() {} },
}
globalThis.window = { btoa: (s) => Buffer.from(s, 'binary').toString('base64') }
globalThis.URL = {
  createObjectURL: (blob) => { captured = blob; return 'blob:stub' },
  revokeObjectURL: () => {},
}
globalThis.Blob = class {
  constructor(parts) { this.text = parts.join('') }
}
globalThis.XMLSerializer = class { serializeToString() { return '<svg/>' } }

const htmlOf = (args) => { captured = null; exportDashboardHtml(args); return captured.text }

console.log('\n=== 1. the document carries the dashboard and its data ===')
let html = htmlOf({
  name: 'Q2 Pharmacy Review',
  owner: 'u-compliance',
  artifacts: [{
    id: 'ART-1', type: 'chart', lineage_ref: 'SIM-LOGIC-42',
    spec: { title: 'Reject Count by reject code',
            columns: ['reject_code', 'reject_count'],
            rows: [['75', 229], ['70', 118]] },
  }],
  containers: {},
})
check('the dashboard name appears', html.includes('Q2 Pharmacy Review'))
check('the owner is attributed', html.includes('u-compliance'))
check('the artifact title appears', html.includes('Reject Count by reject code'))
check('column headers are emitted', html.includes('<th>reject_code</th>'))
check('data cells are emitted', html.includes('<td>229</td>'))
check('lineage reference is carried', html.includes('SIM-LOGIC-42'))
check('it is a standalone document', html.startsWith('<!DOCTYPE html>'))
check('a print stylesheet is embedded', html.includes('@media print'))
check('no external resource is referenced',
      !/<(script|link)\b/i.test(html) && !/https?:\/\//i.test(html),
      'self-contained: nothing to fetch, safe air-gapped')

console.log('\n=== 2. user-controlled text is ESCAPED, not interpolated ===')
html = htmlOf({
  name: '<img src=x onerror=alert(1)>',
  owner: 'u-x',
  artifacts: [{
    id: 'ART-2', type: 'chart', lineage_ref: '"><b>x</b>',
    spec: { title: '<script>alert("xss")</script>',
            columns: ['<th>evil</th>'],
            rows: [['</td><script>alert(2)</script>']] },
  }],
  containers: {},
})
check('a malicious dashboard NAME is escaped',
      !html.includes('<img src=x'), 'expected &lt;img …')
check('a malicious chart TITLE is escaped',
      !html.includes('<script>alert("xss")</script>'))
check('a malicious COLUMN name is escaped',
      html.includes('&lt;th&gt;evil&lt;/th&gt;'))
check('a malicious CELL value is escaped',
      !html.includes('<script>alert(2)</script>'))
check('a malicious lineage_ref is escaped', !html.includes('"><b>x</b>'))
check('no raw <script> survives anywhere',
      !/<script/i.test(html), 'the export must never execute embedded data')

console.log('\n=== 3. large results are capped, and the cap is disclosed ===')
const many = Array.from({ length: 1200 }, (_, i) => [`r${i}`, i])
html = htmlOf({
  name: 'Big', owner: 'u', containers: {},
  artifacts: [{ id: 'A', type: 'chart',
                spec: { columns: ['k', 'v'], rows: many } }],
})
const rowCount = (html.match(/<tr>/g) || []).length - 1   // minus header row
check('the embedded table is capped', rowCount === 500, `${rowCount} rows`)
check('the truncation is stated, not silent',
      html.includes('Showing first 500 of 1200 rows'))

console.log('\n=== 4. empty and malformed specs degrade gracefully ===')
html = htmlOf({ name: 'Empty', owner: 'u', artifacts: [], containers: {} })
check('an empty dashboard still produces a valid document',
      html.startsWith('<!DOCTYPE html>') && html.includes('no artifacts'))
html = htmlOf({
  name: 'Odd', owner: 'u', containers: {},
  artifacts: [{ id: 'A', type: 'simulation', spec: { note: 'no table here' } }],
})
check('an artifact with no columns/rows omits the table, without throwing',
      !html.includes('<table>') && html.includes('simulation'))

console.log('\n=== 5. filenames are sanitised ===')
check('path separators cannot escape the filename',
      !safeFilename('../../etc/passwd').includes('/'),
      safeFilename('../../etc/passwd'))
check('an empty name falls back', safeFilename('') === 'dashboard')
check('spaces become hyphens', safeFilename('My Board') === 'My-Board')

const total = PASS.length + FAIL.length
console.log('\n' + '='.repeat(74))
console.log(`  dashboard export regression: ${PASS.length}/${total} passed`)
FAIL.forEach(f => console.log(`    FAIL ${f}`))
console.log('='.repeat(74))
process.exit(FAIL.length ? 1 : 0)
