/**
 * Regression: the left-rail navigation must reach every tab.
 *
 * The real risk in regrouping 19 tabs from 2 groups into 5 is not a broken
 * drawer animation — it is a tab that quietly stops being reachable because
 * it was dropped from the grouping while its render branch still exists in
 * App.jsx. Nothing in the app would throw; the feature would simply become
 * invisible. So these checks parse the ACTUAL source and compare the menu
 * against the set of tabs App.jsx knows how to render.
 *
 * Run:  node frontend/tests/nav.test.mjs
 */
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const HERE = dirname(fileURLToPath(import.meta.url))
const SRC = join(HERE, '..', 'src')

const PASS = [], FAIL = []
const check = (label, cond, detail = '') => {
  ;(cond ? PASS : FAIL).push(label)
  console.log(`  ${cond ? 'ok  ' : 'FAIL'} ${label}${detail ? ' — ' + detail : ''}`)
}

const app = readFileSync(join(SRC, 'App.jsx'), 'utf8')
const nav = readFileSync(join(SRC, 'components', 'NavMenu.jsx'), 'utf8')
const side = readFileSync(join(SRC, 'components', 'Sidebar.jsx'), 'utf8')
const css = readFileSync(join(SRC, 'styles.css'), 'utf8')

// ---- parse TAB_GROUPS out of App.jsx ------------------------------------
const block = app.slice(app.indexOf('const TAB_GROUPS'),
                        app.indexOf('const TABS ='))
const groups = [...block.matchAll(/\['([^']+)',\s*\[([\s\S]*?)\]\]/g)]
  .map(([, name, body]) => [name,
    [...body.matchAll(/\['([^']+)',\s*'[^']*',\s*'[^']*'\]/g)].map(m => m[1])])

console.log('\n=== 1. five groups, every tab present exactly once ===')
check('there are exactly 5 stacked groups', groups.length === 5,
      groups.map(([g]) => g).join(' · '))

const menuTabs = groups.flatMap(([, items]) => items)
check('no tab appears in two groups',
      new Set(menuTabs).size === menuTabs.length,
      `${menuTabs.length} entries, ${new Set(menuTabs).size} unique`)

// Every `tab === 'X' &&` render branch in App.jsx is a reachable screen.
const rendered = new Set(
  [...app.matchAll(/tab === '([^']+)'/g)].map(m => m[1]))
const missing = [...rendered].filter(t => !menuTabs.includes(t))
check('every screen App.jsx can render is reachable from the menu',
      missing.length === 0,
      missing.length ? 'ORPHANED: ' + missing.join(', ')
        : `${rendered.size} render branches all covered`)

const dangling = menuTabs.filter(t => !rendered.has(t) && t !== 'Chat')
check('no menu entry points at a screen that does not exist',
      dangling.length === 0,
      dangling.length ? 'DEAD: ' + dangling.join(', ') : 'none dangling')

console.log('\n=== 2. the old horizontal tab rows are gone ===')
check('App.jsx no longer renders .tab-row',
      !app.includes('className="tab-row"'), 'header rows removed')
check('the sticky header now carries only the metrics strip',
      !/className="tabs"/.test(app), 'no .tabs block left in App.jsx')

console.log('\n=== 3. drawer behaviour ===')
check('a group drawer opens/closes on click', nav.includes('toggle(group)'))
check('Expand all / Collapse all is present',
      nav.includes('Collapse all') && nav.includes('Expand all'))
check('the group holding the CURRENT tab is force-opened',
      nav.includes('groupOf[current] === g'),
      'the rail always shows where you are')
check('the current submenu item is marked with its own class',
      nav.includes("current === t ? 'on' : ''"))
check('and that class is styled in a distinct colour',
      /\.nav-item\.on\s*\{[^}]*var\(--accent\)/.test(css),
      'accent colour + inset marker')
check('the active item is exposed to assistive tech, not colour alone',
      nav.includes('aria-current'))

console.log('\n=== 4. search-as-you-type ===')
check('a menu search box exists', nav.includes('Search menu…'))
check('it filters on every keystroke (controlled input)',
      nav.includes('onChange={e => setQ(e.target.value)}'))
check('matching groups are force-opened so hits are never hidden',
      nav.includes('!!query || open.has(g)'),
      'a visible count with invisible contents would be a dead end')
check('search matches group NAMES as well as item names',
      nav.includes('g.toLowerCase().includes(query)'))
check('Escape clears the query', nav.includes("e.key === 'Escape'"))

console.log('\n=== 5. rail layout: nav on top, history collapsed beneath ===')
check('Sidebar renders the NavMenu', side.includes('<NavMenu'))
check('a horizontal rule separates nav from history',
      side.includes('sidebar-rule') && /\.sidebar-rule\s*\{/.test(css))
check('chat history starts COLLAPSED so nav is never pushed off-screen',
      side.includes('useState(false)') && side.includes('histOpen'))
check('history can still be expanded', side.includes('setHistOpen'))

console.log('\n=== 6. per-user persistence (the recurring bug class here) ===')
check('open/closed state is namespaced per user via userKey',
      nav.includes("userKey('oppal-nav-open'"),
      'a shared workstation must not leak one person’s rail to the next')
check('it re-reads when the signed-in user changes',
      /useEffect\([\s\S]{0,400}storeKey/.test(nav), '[storeKey] dependency')
check('localStorage failures degrade instead of crashing the rail',
      (nav.match(/catch/g) || []).length >= 3, 'private mode / quota safe')

console.log('\n=== 7. Ontology phase column no longer wraps ===')
check('the phase chip is prevented from breaking mid-value',
      /\.data-grid td \.chip\s*\{[^}]*white-space:\s*nowrap/.test(css))
check('and the column has a minimum width',
      /\.data-grid t[hd]:nth-child\(3\)[^{]*\{[^}]*min-width/.test(css))

console.log('\n' + '='.repeat(74))
console.log(`  left-rail navigation regression: ${PASS.length}/${PASS.length + FAIL.length} passed`)
FAIL.forEach(f => console.log(`    FAIL ${f}`))
console.log('='.repeat(74))
process.exit(FAIL.length ? 1 : 0)
