/**
 * Regression: two defects reported together, both in the left rail.
 *
 * 1. CHAT HISTORY VANISHED ON LOGOUT. auth.js exported
 *    clearUserLocalState(), and App.jsx called it in the logout handler, so
 *    every sign-out deleted 'oppal-history:<uid>'. Sign back in and the whole
 *    transcript list was gone.
 *
 *    The wipe was not arbitrary — history once lived under a single global
 *    key, so the next person at a shared workstation inherited the previous
 *    analyst's questions. But that leak was ALREADY closed by namespacing
 *    every personal key with the user id. Two mechanisms guarded one problem
 *    and the redundant one was the destructive one. Namespacing is kept;
 *    the wipe is not.
 *
 * 2. THE NAV MENU COULD NOT SCROLL. .nav-menu was `flex: 0 0 auto` with no
 *    overflow inside a 100vh flex column, so it could neither shrink nor
 *    scroll. Expand all five drawers on a short window and the bottom items
 *    were unreachable — while the history list below kept its own scrollbar,
 *    which is why it read as "sometimes".
 *
 * UPDATED for v14.8.0: history is now server-side (app/history/store.py),
 * so the checks below additionally assert that the client reads and writes
 * it through the API and adopts any leftover localStorage exactly once.
 * Ownership and isolation are covered server-side by
 * backend/tests/test_chat_history.py.
 *
 * Run:  node frontend/tests/sidebar-history.test.mjs
 */
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const HERE = dirname(fileURLToPath(import.meta.url))
const SRC = join(HERE, '..', 'src')
const auth = readFileSync(join(SRC, 'auth.js'), 'utf8')
const app = readFileSync(join(SRC, 'App.jsx'), 'utf8')
const css = readFileSync(join(SRC, 'styles.css'), 'utf8')

const PASS = [], FAIL = []
const check = (label, cond, detail = '') => {
  ;(cond ? PASS : FAIL).push(label)
  console.log(`  ${cond ? 'ok  ' : 'FAIL'} ${label}${detail ? ' — ' + detail : ''}`)
}

// Strip comments before scanning for behaviour: this file's own prose, and
// auth.js's explanatory comments, both mention the removed function by name.
// A substring match on raw source would "pass" on an explanation of the bug.
const codeOnly = (src) => src
  .replace(/\/\*[\s\S]*?\*\//g, ' ')
  .replace(/(^|[^:])\/\/[^\n]*/g, '$1 ')

const authCode = codeOnly(auth)
const appCode = codeOnly(app)

console.log('\n=== 1. logout must NOT destroy the signed-in user\'s history ===')
check('logout does not call a wipe-this-user helper',
      !/clearUserLocalState\s*\(/.test(appCode),
      'this call in the logout handler was the defect')
check('no wipe-this-user helper is exported at all',
      !/export\s+const\s+clearUserLocalState/.test(authCode),
      'dead destructive helpers get re-wired by accident later')
check('logout clears only the ANONYMOUS bucket',
      /clearAnonymousLocalState\s*\(\s*\)/.test(appCode)
      && /export\s+const\s+clearAnonymousLocalState/.test(authCode),
      'pre-login state belongs to nobody and must not be inherited')
check('the anonymous clear targets the empty user id, not the current one',
      /clearAnonymousLocalState[\s\S]{0,260}userKey\(base,\s*''\)/.test(authCode),
      "userKey(base, '') — not currentUserId()")
check('history is loaded from the SERVER, not localStorage',
      /fetch\('\/api\/history'\)/.test(appCode)
      && !/useState\(\(\)\s*=>\s*\{[\s\S]{0,120}getItem\(userKey\('oppal-history'/
           .test(appCode),
      'server-side history survives a cache clear and a change of machine')
check('asking a question writes through to the server',
      /fetch\('\/api\/history',\s*\{[\s\S]{0,200}method:\s*'POST'/
        .test(appCode),
      'optimistic local update plus a durable write')
check('a leftover localStorage history is migrated exactly once',
      /\/api\/history\/import/.test(appCode)
      && /removeItem\(userKey\('oppal-history', forUid\)\)/.test(appCode),
      'and the local copy is dropped only after the server confirms')
check('the local copy is NOT deleted when the migration fails',
      /if \(r\.ok\) localStorage\.removeItem\(userKey\('oppal-history'/
        .test(appCode),
      'a failed migration must lose nothing and retry next sign-in')
check('the list is emptied before loading another user\'s',
      /setHistory\(\[\]\)[\s\S]{0,120}loadHistory\(uid\)/.test(appCode),
      'never render the previous principal\'s transcripts mid-fetch')
check('clearing history calls the server DELETE, not just a local hide',
      /fetch\('\/api\/history',\s*\{\s*method:\s*'DELETE'\s*\}\)/
        .test(appCode),
      'the user must be able to really erase it')
check('the in-memory transcript is still reset on logout',
      /clearAnonymousLocalState\(\)[\s\S]{0,400}setHistory\(\[\]\)/.test(appCode),
      'nothing from the session may stay rendered on the login screen')
const onClearBlock = (appCode.match(
  /onClear=\{\(\)\s*=>\s*\{[\s\S]{0,600}?\}\}/) || [''])[0]
check('a deliberate user-initiated clear still exists',
      /setHistory\(\[\]\)/.test(onClearBlock)
      && /method:\s*'DELETE'/.test(onClearBlock),
      'purging your own work must be a choice, not a side effect of logout')
check('the explicit clear removes ONLY history',
      !/oppal-pipeline|oppal-mode/.test(onClearBlock),
      'clearing history must not also reset unrelated preferences')
check('a failed clear reloads the truth instead of faking success',
      /loadHistory\(uid\)/.test(onClearBlock),
      'the user must not believe it went and later find it back')

console.log('\n=== 2. the nav menu must be able to scroll ===')
const navBlock = (css.match(/\.nav-menu\s*\{[^}]*\}/) || [''])[0]
check('.nav-menu declares overflow-y',
      /overflow-y:\s*auto/.test(navBlock), navBlock.replace(/\s+/g, ' ').trim())
check('.nav-menu sets min-height: 0',
      /min-height:\s*0/.test(navBlock),
      'a flex child defaults to min-height:auto and refuses to shrink, so '
      + 'overflow-y never engages without this')
check('.nav-menu is allowed to shrink (not flex: 0 0 auto)',
      !/flex:\s*0\s+0\s+auto/.test(navBlock),
      'the exact declaration that caused the bug')
check('.sidebar itself can shrink its children',
      /\.sidebar\s*\{[^}]*min-height:\s*0/.test(css),
      'the 100vh column needs it too, or the constraint just moves up a level')
check('the history list is capped so it cannot starve the menu',
      /\.sidebar-list\s*\{[^}]*max-height:/.test(css),
      'the menu is used on every screen; history is reference material')
check('the history list can also shrink',
      /\.sidebar-list\s*\{[^}]*min-height:\s*0/.test(css))
check('history header, rule and search stay pinned while the menu scrolls',
      /\.sidebar-head\s*\{[^}]*flex:\s*0\s+0\s+auto/.test(css)
      && /\.sidebar-rule\s*\{[^}]*flex:\s*0\s+0\s+auto/.test(css))
check('scroll chaining is contained to the rail',
      /overscroll-behavior:\s*contain/.test(navBlock),
      'scrolling the menu must not scroll the page behind it')

console.log('\n=== 3. the fix is explained where the next person will look ===')
check('auth.js records why the wipe was removed, not just that it was',
      /already closed by namespacing/i.test(auth),
      'otherwise someone re-adds it as a privacy fix')
check('styles.css records the min-height:auto flexbox trap',
      /min-height: auto/.test(css))

console.log('\n' + '='.repeat(74))
console.log(`  sidebar history + nav scroll regression: ${PASS.length}/${PASS.length + FAIL.length} passed`)
FAIL.forEach(f => console.log(`    FAIL ${f}`))
console.log('='.repeat(74))
process.exit(FAIL.length ? 1 : 0)
