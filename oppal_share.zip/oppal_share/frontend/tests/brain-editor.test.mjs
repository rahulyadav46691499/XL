/**
 * Regression: the Context Brain editor must be navigable, and one thing
 * must have one name.
 *
 * Three reported defects, all in the same screen:
 *   1. Search results printed the RAW filename ("metrics.md") while the file
 *      chip beside them printed the label ("Governed metrics") — the same
 *      thing named two ways on one screen.
 *   2. The editor had no line numbers, but search results are reported as
 *      file:line. The user was given a coordinate and no grid to read it on.
 *   3. Clicking a search result switched files and dropped you at line 1.
 *      Tolerable at 40 lines; useless in the policy rulebook.
 *
 * The subtle part is alignment: line numbers live in a sibling gutter (a
 * <textarea> cannot render children), so the gutter and the text pane must
 * share font, size, line-height and vertical padding EXACTLY, and one
 * logical line must occupy exactly one visual row — otherwise the numbers
 * drift and the drift compounds down the file. Those invariants are asserted
 * here because they are invisible until someone scrolls a long file.
 *
 * Run:  node frontend/tests/brain-editor.test.mjs
 */
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const HERE = dirname(fileURLToPath(import.meta.url))
const SRC = join(HERE, '..', 'src')
const tab = readFileSync(join(SRC, 'components', 'ContextBrainTab.jsx'), 'utf8')
const css = readFileSync(join(SRC, 'styles.css'), 'utf8')

const PASS = [], FAIL = []
const check = (label, cond, detail = '') => {
  ;(cond ? PASS : FAIL).push(label)
  console.log(`  ${cond ? 'ok  ' : 'FAIL'} ${label}${detail ? ' — ' + detail : ''}`)
}

const rule = (sel) => {
  const i = css.indexOf(sel + ' {')
  if (i === -1) return ''
  return css.slice(i, css.indexOf('}', i))
}
const prop = (body, name) => {
  const m = body.match(new RegExp(name + '\\s*:\\s*([^;]+)'))
  return m ? m[1].trim() : null
}

console.log('\n=== 1. one file, one name ===')
check('a single labelling helper exists',
      /const fileLabel\s*=/.test(tab) && /const fileName\s*=/.test(tab),
      'not ad-hoc strings per call site')
check('search results show the LABEL, not the raw filename',
      /\{fileName\(r\.file\)\}/.test(tab)
      && !/\{r\.file\}:\{r\.line\}/.test(tab),
      'was: metrics.md:42 next to a chip saying "Governed metrics"')
check('the raw filename is still available, in a tooltip',
      /title=\{`Open \$\{r\.file\} at line \$\{r\.line\}`\}/.test(tab),
      'discoverable without being the primary label')
check('the editor footer names the file the same way',
      /\{fileName\(file\)\}/.test(tab))
check('"Governed metrics" is the label for metrics.md',
      /'metrics\.md':\s*'📐 Governed metrics'/.test(tab))

console.log('\n=== 2. line numbers exist ===')
check('a gutter is rendered from the real line count',
      tab.includes('brain-gutter')
      && /Array\.from\(\{ length: lineCount \}/.test(tab))
check('line count is derived from the content, not guessed',
      /content\.split\('\\n'\)\.length/.test(tab))
check('the gutter is hidden from screen readers (decorative)',
      /aria-hidden="true"/.test(tab))
check('the gutter is styled', rule('.brain-gutter') !== '')

console.log('\n=== 3. ALIGNMENT: gutter metrics match the text pane exactly ===')
const ed = rule('.brain-editor'), gut = rule('.brain-gutter')
check('same font-family as the editor',
      prop(gut, 'font-family') === prop(ed, 'font-family'),
      `${prop(gut, 'font-family')} vs ${prop(ed, 'font-family')}`)
check('same font-size',
      prop(gut, 'font-size') === prop(ed, 'font-size'),
      `${prop(gut, 'font-size')} vs ${prop(ed, 'font-size')}`)
check('same line-height',
      prop(gut, 'line-height') === prop(ed, 'line-height'),
      `${prop(gut, 'line-height')} vs ${prop(ed, 'line-height')} — a 1.5/1.55 `
      + 'mismatch drifts a full row every ~20 lines')
const gpadTop = (prop(gut, 'padding') || '').split(/\s+/)[0]
const epadTop = (prop(ed, 'padding') || '').split(/\s+/)[0]
check('same top padding, so row 1 starts at the same y',
      gpadTop === epadTop, `${gpadTop} vs ${epadTop}`)
check('the gutter row height is pinned to the line-height',
      /\.brain-gutter div \{[^}]*height:\s*1\.55em/.test(css))

console.log('\n=== 4. one logical line = one visual row (no wrapping) ===')
check('the highlight pane does not wrap inside the gutter wrapper',
      /\.brain-editor-wrap \.brain-highlight \{[^}]*white-space:\s*pre\b/.test(css),
      'pre-wrap would make a long formula occupy 2 rows against 1 number')
check('the textarea does not wrap either',
      /\.brain-editor-wrap textarea\.brain-editor \{[^}]*white-space:\s*pre\b/.test(css))
check('panes scroll horizontally instead',
      /\.brain-editor-wrap \.brain-highlight \{[^}]*overflow:\s*auto/.test(css))

console.log('\n=== 5. the gutter tracks the pane while scrolling ===')
check('both panes push their scrollTop into the gutter',
      (tab.match(/onScroll=\{syncGutter\}/g) || []).length === 2,
      'highlight view AND textarea')
check('sync reads the scrolling element, not a hardcoded ref',
      /gutRef\.current\.scrollTop = e\.currentTarget\.scrollTop/.test(tab))

console.log('\n=== 6. clicking a search hit JUMPS to the line ===')
check('the hit records the target line',
      /setJump\(Number\(r\.line\) \|\| 1\)/.test(tab),
      'was: only setFile(), landing at line 1')
check('the jump waits for the target file to load',
      /\}, \[jump, content, highlight, lineCount\]\)/.test(tab),
      'switching file is async — jumping before content arrives does nothing')
check('read mode scrolls the row into view',
      /scrollIntoView\(\{ block: 'center'/.test(tab))
check('edit mode selects the line so the browser reveals it',
      /setSelectionRange\(start, start \+ lines\[line - 1\]\.length\)/.test(tab))
check('the target line is visually flagged',
      /jump === i \+ 1 \? 'hl-jump'/.test(tab)
      && /\.hl-jump\s*\{/.test(css))
check('the flag fades rather than staying forever',
      /@keyframes jumpFlash/.test(css))
check('an out-of-range line cannot break the jump',
      /Math\.max\(1, Math\.min\(jump, lineCount\)\)/.test(tab),
      'a stale hit against an edited file is clamped')
check('the gutter marks the jumped line too',
      /gut-jump/.test(tab) && /\.gut-jump\s*\{/.test(css))

console.log('\n=== 7. the domain picker collapses, and says which is live ===')
check('domains are COLLAPSED on arrival',
      /useState\(false\)\s*\/\/ collapsed by default/.test(tab),
      'the editor is the work surface; switching domain is rare')
check('the collapsed header can be expanded',
      /setDomainsOpen\(o => !o\)/.test(tab))
check('the collapsed line names the live domain',
      /brain-domain-pill/.test(tab) && /activeDomain/.test(tab),
      'answers "which domain am I in?" without opening')
check('it reports the domain the ENGINE says is active, not merely the one '
      + 'selected in this tab',
      /domains\.find\(d => d\.active\) \|\| selected/.test(tab),
      'showing the selection would misreport which knowledge is answering')
check('picking a domain closes the picker again',
      /activate\(d\.id\); setDomainsOpen\(false\)/.test(tab),
      'no second click needed to get back to the editor')
check('expanded state is exposed to assistive tech',
      /aria-expanded=\{domainsOpen\}/.test(tab))
check('the pill and toggle are styled',
      /\.brain-domain-pill\s*\{/.test(css)
      && /\.brain-domains-toggle\s*\{/.test(css))

console.log('\n' + '='.repeat(74))
console.log(`  brain-editor regression: ${PASS.length}/${PASS.length + FAIL.length} passed`)
FAIL.forEach(f => console.log(`    FAIL ${f}`))
console.log('='.repeat(74))
process.exit(FAIL.length ? 1 : 0)
