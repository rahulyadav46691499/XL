import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // 127.0.0.1, not localhost: Node 18+ resolves "localhost" to ::1 first,
    // while uvicorn binds IPv4 only — on Windows that makes every /api call
    // in dev fail with ECONNREFUSED against a backend that is plainly running.
    proxy: { '/api': 'http://127.0.0.1:8001' }
  }
})
