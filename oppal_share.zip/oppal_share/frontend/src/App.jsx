import React, { useEffect, useRef, useState } from 'react'
import ChartArtifact from './components/ChartArtifact.jsx'
import DataGrid from './components/DataGrid.jsx'
import TrustPanel from './components/TrustPanel.jsx'
import CohortBar from './components/CohortBar.jsx'
import InsightCards from './components/InsightCards.jsx'
import DataPreview from './components/DataPreview.jsx'
import GraphView from './components/GraphView.jsx'
import AudiencesTab from './components/AudiencesTab.jsx'
import SettingsTab from './components/SettingsTab.jsx'
import DataQualityTab from './components/DataQualityTab.jsx'
import MetricsBar from './components/MetricsBar.jsx'
import Sidebar from './components/Sidebar.jsx'
import GovernanceTab from './components/GovernanceTab.jsx'
import SqlLogTab from './components/SqlLogTab.jsx'
import UsageChip from './components/UsageChip.jsx'
import JourneyStrip from './components/JourneyStrip.jsx'
import ContextBrainTab from './components/ContextBrainTab.jsx'
import DataLayerTab from './components/DataLayerTab.jsx'
import OntologyTab from './components/OntologyTab.jsx'
import PillarsTab from './components/PillarsTab.jsx'
import SwarmTab from './components/SwarmTab.jsx'
import CasesTab from './components/CasesTab.jsx'
import CasesTabCards from './components/CasesTabCards.jsx'
import ActionQueueTab from './components/ActionQueueTab.jsx'
import WhatIfSandbox from './components/WhatIfSandbox.jsx'
import Workspace from './components/Workspace.jsx'
import FinOpsWidget from './components/FinOpsWidget.jsx'
import HelpTab from './components/HelpTab.jsx'
import Login from './components/Login.jsx'
import WelcomeBar from './components/WelcomeBar.jsx'
import AnalysisTab from './components/AnalysisTab.jsx'
import EditableTitle from './components/EditableTitle.jsx'
import { getSession, clearSession, currentUserId, userKey,
         clearAnonymousLocalState } from './auth.js'

function ScrollTop() {
  const [show, setShow] = React.useState(false)
  React.useEffect(() => {
    const fn = () => setShow(window.scrollY > 400)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])
  if (!show) return null
  return (
    <button className="scroll-top" title="Go to top"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
      ↑ Top
    </button>
  )
}

// Tabs are grouped into two rows: the analyst's exploration surface, and the
// governed operate/audit surface. A single flex row overflowed horizontally
// once Phases 2-6 added their tabs; the rows also wrap, so the layout holds
// at any viewport width.
// FIVE groups, not two. Nineteen tabs split across two horizontal rows wrapped
// unpredictably at narrow widths and consumed header height on every screen.
// Five short vertical stacks live in the left rail instead, grouped by what a
// user is trying to DO rather than by which build phase shipped them.
const TAB_GROUPS = [
  ['Ask & Explore', [
    ['Chat', '💬', 'wiggle'],
    ['Analysis', '📈', 'pulse'],
    ['Audiences', '👥', 'bounce'],
  ]],
  ['Data', [
    ['Data', '🗄️', 'bounce'],
    ['Data Layer', '🔗', 'spin'],
    ['Data Quality', '🩺', 'wiggle'],
  ]],
  ['Knowledge', [
    ['Semantic Graph', '🕸️', 'spin'],
    ['Context Brain', '🧠', 'pulse'],
    ['Ontology', '🧬', 'pulse'],
  ]],
  ['Operate', [
    ['Pillars', '🏛️', 'bounce'],
    ['Swarm', '🛰️', 'spin'],
    ['Cases', '📁', 'wiggle'],
    ['Actions', '✅', 'pulse'],
    ['Simulator', '🧮', 'pulse'],
    ['Workspace', '📊', 'bounce'],
  ]],
  ['Govern & Admin', [
    ['Governance', '🛡️', 'wiggle'],
    ['SQL Log', '🖥️', 'bounce'],
    ['Settings', '⚙️', 'spin'],
    ['Help', '📖', 'pulse'],
  ]],
]
const TABS = TAB_GROUPS.flatMap(([, items]) => items)

function ExlLogo() {
  return (
    <div className="exl-logo" title="EXL">
      <span className="mark">EXL</span>
      <span className="tag">Agentic Payer Engine</span>
    </div>
  )
}

export default function App() {
  const [session, setSessionState] = useState(getSession)
  useEffect(() => {
    const onLogout = () => setSessionState(null)
    window.addEventListener('oppal-logout', onLogout)
    return () => window.removeEventListener('oppal-logout', onLogout)
  }, [])
  const [tab, setTab] = useState('Chat')
  const [theme, setThemeState] = useState(
    () => localStorage.getItem('oppal-theme') || 'light')
  const setTheme = (t) => {
    setThemeState(t)
    localStorage.setItem('oppal-theme', t)
  }
  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])

  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [cohorts, setCohorts] = useState([])
  const [activeCohort, setActiveCohort] = useState(null)
  const [users, setUsers] = useState([])
  const [me, setMe] = useState(null)
  const [starters, setStarters] = useState([])
  // Browser-local personal state is namespaced by signed-in user id. Theme
  // stays global on purpose — it is a display preference for the machine, not
  // information about anyone's work.
  const uid = session?.user?.user_id || currentUserId()
  const DEFAULT_PIPE = { use_cache: true, root_cause: true, llm_assist: true }
  const [mode, setModeState] = useState(
    () => localStorage.getItem(userKey('oppal-mode')) || 'ai')
  const setMode = (m) => {
    setModeState(m); localStorage.setItem(userKey('oppal-mode'), m)
  }
  const [pipeline, setPipelineState] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(userKey('oppal-pipeline')))
             || DEFAULT_PIPE
    } catch { return DEFAULT_PIPE }
  })
  const setPipeline = (p) => {
    setPipelineState(p)
    localStorage.setItem(userKey('oppal-pipeline'), JSON.stringify(p))
  }
  const [showPipe, setShowPipe] = useState(false)
  const loadStarters = () =>
    fetch('/api/suggestions').then(r => r.json())
      .then(d => setStarters(d.suggestions || [])).catch(() => {})
  // Depends on `session`, not just `tab`. This effect runs once on mount --
  // BEFORE sign-in, when there is no bearer token -- so /api/suggestions
  // 401'd and, with `tab` never changing afterwards, was never retried. The
  // chat landing then sat on 'loading suggestions from the Brain...' until
  // the user reloaded by hand. Same gate the /api/me effect below uses.
  useEffect(() => { if (tab === 'Chat') loadStarters() }, [tab, session])
  // History is SERVER-side now (see app/history/store.py). It is loaded per
  // signed-in user in the [uid] effect below, so it survives a logout, a
  // cleared cache and a change of machine — none of which the old
  // localStorage version did. Starting empty rather than from localStorage
  // also removes the flash of the previous browser's list before the fetch
  // lands.
  const [history, setHistory] = useState([])
  const [chatId, setChatId] = useState(() => Date.now())
  const newChat = () => {
    setMessages([])
    setChartViews({})     // view state is keyed by message index — reset with it
    setChatId(Date.now())
  }
  // one history entry per CHAT session; questions club under it
  // Optimistic local update + server write-through. The list re-renders
  // immediately (typing a question and waiting on a round trip to see it
  // appear feels broken), while the durable copy is written in the
  // background. A failed write is deliberately silent: losing a history row
  // must never surface as an error over the answer the user actually asked
  // for.
  const pushHistory = (q, title) => {
    fetch('/api/history', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: String(chatId), question: q,
                             title: title || '' })
    }).catch(() => {})
    setHistory(h => {
      const next = [...h]
      const idx = next.findIndex(x => x.id === chatId)
      if (idx >= 0) {
        const entry = { ...next[idx] }
        entry.qs = [...(entry.qs || []), q]
        entry.ts = Date.now()
        next.splice(idx, 1)
        next.unshift(entry)
      } else {
        next.unshift({ id: chatId, ts: Date.now(),
          title: title || q, qs: [q] })
      }
      return next.slice(0, 100)
    })
  }
  const titleFor = (q, data) => {
    const intent = (data.audit || []).find(s => s.step === 'intent_routing')?.detail
    if (!intent?.metric) return q.slice(0, 48)
    const verb = { root_cause: 'root cause', metric_trend: 'trend',
      breakdown: 'breakdown', top_n: 'ranking', compliance_audit: 'audit',
      formulary_lookup: 'formulary', correlation: 'correlation',
      detail_lookup: 'detail' }[intent.intent] || 'analysis'
    return `${intent.metric.replace(/_/g, ' ')} · ${verb}`
  }
  const [toast, setToast] = useState(null)
  // Per-chart view state (type/orientation/shape/palette/SQL/re-run result),
  // held HERE rather than inside ChartArtifact. The chat pane is conditionally
  // rendered, so leaving the tab unmounts it and component state is dropped —
  // which meant every chart customisation and every re-run result silently
  // reverted the moment you looked at the Workspace and came back.
  const [chartViews, setChartViews] = useState({})
  const patchChartView = (key, patch) => setChartViews(v => ({
    ...v, [key]: { ...(v[key] || {}), ...patch } }))
  // Pin a chart to the SERVER-persisted, LOB-scoped Workspace (REQ-5.6-5.8).
  // The old build kept a browser-local tray, which meant a "saved" chart was
  // invisible to reviewers, unscoped, and lost on cache clear.
  // Re-run analyst-edited SQL from a chart's SQL panel. The server applies the
  // same read-only + LOB gates as agent SQL and scores the result as
  // user-authored, so this cannot be used to widen access — only to ask the
  // same question a different way.
  const rerunSql = async (sql, aiConfirm = false) => {
    const r = await fetch('/api/query/rerun', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, ai_confirm: !!aiConfirm })
    })
    const out = await r.json().catch(() => null)
    if (!r.ok) {
      return { ok: false,
               reason: out?.detail || `request failed (${r.status})` }
    }
    // A model-backed ai_* over a column is refused until a human confirms.
    // Surfaced as a structured payload rather than an error so the UI can
    // explain the cost and the PHI exposure before anyone agrees to it.
    if (out && out.needs_confirmation) return { ...out, ok: false }
    return out
  }

  const saveToWorkspace = async (spec, question) => {
    try {
      // Ask the server for MY board. This used to take boards[0] of the
      // visible list ordered by updated_at, which could be a dashboard
      // belonging to another user — pinning then wrote a chart into their
      // dashboard. A pin target must be owned, not merely visible.
      const tRes = await fetch('/api/workspace/mine')
      if (!tRes.ok) throw new Error(await tRes.text())
      const target = await tRes.json()
      const res = await fetch(`/api/workspace/${target.id}/pin`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'chart', spec: { ...spec, question },
                               lineage_ref: '' })
      })
      if (!res.ok) throw new Error(await res.text())
      setToast(`📌 Pinned to ${target.name}`)
      window.dispatchEvent(new Event('oppal-workspace-changed'))
    } catch {
      setToast('Could not pin to your dashboard — check your permissions')
    }
    setTimeout(() => setToast(null), 2800)
  }
  const endRef = useRef(null)

  useEffect(() => {
    if (tab === 'Chat') endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, tab])

  useEffect(() => {
    fetch('/api/users').then(r => r.json())
      .then(d => setUsers(d.users || [])).catch(() => {})
  }, [])
  useEffect(() => {   // RBAC context for the badge row
    fetch('/api/me').then(r => r.json()).then(setMe).catch(() => {})
  }, [session])
  useEffect(() => {   // re-fetch when Context Brain switches the active domain
    const onDomainChange = () =>
      fetch('/api/me').then(r => r.json()).then(setMe).catch(() => {})
    window.addEventListener('oppal-domain-changed', onDomainChange)
    return () => window.removeEventListener('oppal-domain-changed', onDomainChange)
  }, [])

  // Re-bind browser-local personal state whenever the signed-in user
  // changes. App is NOT remounted on login (the Login screen is rendered by
  // this same component), so the useState initializers above run only once —
  // without this, whoever signed in second would keep reading the first
  // user's namespace and see their chat history.
  // Load THIS user's history from the server, adopting anything still sitting
  // in this browser from before the move. The migration is one-way, additive
  // and idempotent (the server skips ids the user already has), and the local
  // copy is removed only after the server confirms — so a failed migration
  // loses nothing and simply retries on the next sign-in.
  const loadHistory = async (forUid) => {
    try {
      let local = []
      try {
        local = JSON.parse(
          localStorage.getItem(userKey('oppal-history', forUid)) || '[]')
      } catch { local = [] }
      if (Array.isArray(local) && local.length) {
        const r = await fetch('/api/history/import', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ entries: local })
        })
        if (r.ok) localStorage.removeItem(userKey('oppal-history', forUid))
      }
      const res = await fetch('/api/history')
      if (!res.ok) throw new Error('history unavailable')
      const d = await res.json()
      setHistory(Array.isArray(d.history) ? d.history : [])
    } catch {
      // Server unreachable: show an empty list rather than a stale one. The
      // durable copy is intact and returns on the next successful load.
      setHistory([])
    }
  }

  useEffect(() => {
    setHistory([])            // never show the previous user's list mid-fetch
    if (uid) loadHistory(uid)
    setModeState(localStorage.getItem(userKey('oppal-mode', uid)) || 'ai')
    try {
      setPipelineState(JSON.parse(
        localStorage.getItem(userKey('oppal-pipeline', uid))) || DEFAULT_PIPE)
    } catch { setPipelineState(DEFAULT_PIPE) }
    setMessages([])          // never carry one user's transcript into another
    setChartViews({})
    setActiveCohort(null)
    setChatId(Date.now())
    // Audiences are SERVER-side and per-user, but the list was fetched once
    // with an empty dependency array — so it never refreshed when the signed-in
    // user changed. Because this component is not remounted on login, whoever
    // signed in second kept seeing the first user's audiences ("they're being
    // shared") and, on the way back, the previous occupant's list instead of
    // their own ("my audience is gone"). Both were stale client state, not a
    // server leak: the backend was returning the right rows all along. Clear
    // first, then refetch, so a slow response never shows the old list.
    setCohorts([])
    loadCohorts()
  }, [uid])

  const loadCohorts = () =>
    fetch('/api/cohorts').then(r => r.json()).then(setCohorts).catch(() => {})
  // NOTE: deliberately no mount-only useEffect here. The [uid] effect above
  // owns loading audiences, so the list is always bound to the CURRENT user.
  // A second fetch with [] deps is what caused one user's audiences to persist
  // into the next user's session.

  const deleteCohort = async (id) => {
    await fetch(`/api/cohorts/${id}`, { method: 'DELETE' })
    if (activeCohort === id) setActiveCohort(null)
    loadCohorts()
  }

  const pushAnswer = (data) => {
    setMessages(m => [...m, { role: 'assistant', data }])
    if (data.cohort) {
      setActiveCohort(data.cohort.id)
      loadCohorts()
    }
  }

  const ask = async (q, opts) => {
    if (!q.trim() || busy) return
    setTab('Chat')
    setMessages(m => [...m, { role: 'user', text: q }])
    pushHistory(q)
    setInput('')
    setBusy(true)
    try {
      const r = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q, cohort_id: activeCohort,
          pipeline: { ...pipeline, replay: !!opts?.replay } })
      })
      const data = await r.json()
      pushAnswer(data)
      pushHistory(q, titleFor(q, data))
    } catch {
      pushAnswer({ summary: 'Backend unreachable — is uvicorn running on :8000?', artifacts: [], followups: [], trust: null })
    }
    setBusy(false)
  }

  const createAudience = async (prompt, name) => {
    setTab('Chat')
    setMessages(m => [...m, { role: 'user', text: `[Audience builder] ${name ? name + ': ' : ''}${prompt}` }])
    setBusy(true)
    try {
      const r = await fetch('/api/cohorts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, name })
      })
      pushAnswer(await r.json())
    } catch { }
    setBusy(false)
  }

  const compareAudiences = async (a, b) => {
    setTab('Chat')
    setMessages(m => [...m, { role: 'user', text: '[Compare audiences]' }])
    setBusy(true)
    try {
      const r = await fetch('/api/cohorts/compare', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ a, b })
      })
      pushAnswer(await r.json())
    } catch { }
    setBusy(false)
  }

  if (!session) {
    return <Login onLogin={(s) => setSessionState(s)} />
  }
  return (
    <div className="shell">
      {mode === 'ai' && <Sidebar history={history}
        navGroups={TAB_GROUPS} tab={tab} onTab={setTab} uid={uid}
        onSelect={(q) => ask(q, { replay: true })}
        onNewChat={newChat}
        onClear={() => {
          // Real server-side erase, not just a local hide. Optimistic clear so
          // the list empties instantly; a failure reloads the truth rather
          // than leaving the user believing it went and finding it back.
          setHistory([])
          fetch('/api/history', { method: 'DELETE' })
            .then(r => { if (!r.ok) loadHistory(uid) })
            .catch(() => loadHistory(uid))
          localStorage.removeItem(userKey('oppal-history', uid))
        }} />}

      <div className="app">
        <ScrollTop />
        {mode === 'ai' && <FinOpsWidget />}
        {toast && <div className="toast rise-in">{toast}</div>}

        <div className="header">
          <ExlLogo />
          <div className="titles">
            <h1>OpPal</h1>
            <span className="sub">US Payer/MCO · governed analytics · agentic compliance · human-approved write-back</span>
          </div>
          <div className="spacer" />
          <div className="mode-toggle" title="Simple = just ask & get answers. AI Mode = full platform.">
            <button className={mode === 'simple' ? 'on' : ''}
              onClick={() => { setMode('simple'); setTab('Chat') }}>
              💬 Simple
            </button>
            <button className={`ai-btn ${mode === 'ai' ? 'on' : ''}`}
              onClick={() => setMode('ai')}>
              ✨ AI Mode
            </button>
          </div>
          <span className="theme-toggle" title={session?.user?.role}>
            👤 {session?.user?.display_name}
          </span>
          <button className="theme-toggle"
            onClick={() => {
              // Clear only the ANONYMOUS bucket. This user's own history stays
              // on disk under their namespaced key so it is still there when
              // they sign back in — losing it on every logout was the reported
              // defect. The next person to sign in reads their own namespace
              // and can never see this one's transcripts, which is what
              // actually prevents the shared-workstation leak.
              clearAnonymousLocalState()
              // In-memory view state is still reset, so nothing from this
              // session is left rendered on the login screen.
              setHistory([]); setMessages([]); setActiveCohort(null)
              setCohorts([])          // never leave a list on the login screen
              setChartViews({})
              clearSession(); setSessionState(null)
            }}>
            Logout
          </button>
          <button className="theme-toggle" title="Toggle theme"
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
            {theme === 'light' ? '🌙' : '☀️'}
          </button>
        </div>

        {me && mode === 'ai' && (
          <div className="rbac-row fade-in">
            <span className="rbac-role">🛡 {me.role || 'unauthorized'}</span>
            <span className="rbac-label">authorized LOBs:</span>
            {(me.allowed_lobs || []).map(l => (
              <span key={l} className="rbac-lob">{l}</span>
            ))}
            {(!me.allowed_lobs || me.allowed_lobs.length === 0) &&
              <span className="rbac-lob none">none</span>}
            {me.attributes?.phi_access &&
              <span className="rbac-attr">PHI: {me.attributes.phi_access}</span>}
          </div>
        )}

        {/* Navigation now lives in the left rail (see Sidebar/NavMenu), so the
            sticky header carries only the metrics strip. That returned roughly
            two rows of vertical space to every screen in the app. */}
        {mode === 'ai' && (
          <div className="top-sticky">
            <MetricsBar />
          </div>
        )}

        {tab === 'Analysis' && <div className="fade-in"><AnalysisTab /></div>}
        {tab === 'Data' && <div className="fade-in"><DataPreview /></div>}
        {tab === 'Data Layer' && <DataLayerTab />}
        {tab === 'Data Quality' && <div className="fade-in"><DataQualityTab onAsk={ask} /></div>}
        {tab === 'Semantic Graph' && <div className="fade-in"><GraphView /></div>}
        {tab === 'Ontology' && <OntologyTab />}
        {tab === 'Pillars' && <PillarsTab />}
        {tab === 'Swarm' && <SwarmTab />}
        {tab === 'Cases' && <CasesTabCards />}
        {tab === 'Actions' && <ActionQueueTab />}
        {tab === 'Simulator' && <div className="fade-in"><WhatIfSandbox /></div>}
        {tab === 'Workspace' && <div className="fade-in"><Workspace /></div>}
        {tab === 'Context Brain' && <ContextBrainTab />}
        {tab === 'SQL Log' && <SqlLogTab />}
        {tab === 'Governance' && <GovernanceTab />}
        {tab === 'Settings' && <div className="fade-in"><SettingsTab theme={theme} setTheme={setTheme} me={me} /></div>}
        {tab === 'Help' && <HelpTab />}
        {tab === 'Audiences' && (
          <div className="fade-in">
            <AudiencesTab cohorts={cohorts} active={activeCohort}
              onSelect={setActiveCohort} onDelete={deleteCohort}
              onCreate={createAudience} onCompare={compareAudiences} />
          </div>
        )}

        {tab === 'Chat' && <>
          {mode === 'ai' && <CohortBar cohorts={cohorts} active={activeCohort}
            onSelect={setActiveCohort} onDelete={deleteCohort} />}

          {mode === 'ai' && (
            <div className="pipe-bar">
              <button className="linkbtn" onClick={() => setShowPipe(v => !v)}>
                ⚙ pipeline config {showPipe ? '▴' : '▸'}
              </button>
              {showPipe && (
                <div className="pipe-opts fade-in">
                  <label><input type="checkbox" checked={pipeline.llm_assist}
                    onChange={e => setPipeline({ ...pipeline, llm_assist: e.target.checked })} />
                    ✨ LLM assist (Brain/Semantic grounding always on; unchecked = pure governed templates)</label>
                  <label><input type="checkbox" checked={pipeline.use_cache}
                    onChange={e => setPipeline({ ...pipeline, use_cache: e.target.checked })} />
                    ⚡ Semantic cache</label>
                  <label><input type="checkbox" checked={pipeline.root_cause}
                    onChange={e => setPipeline({ ...pipeline, root_cause: e.target.checked })} />
                    🔎 Proactive root-cause (SQL + anomaly mining)</label>
                </div>
              )}
            </div>
          )}

          {messages.length === 0 && (
            <>
              <WelcomeBar session={session} me={me} onAsk={ask}
                starters={starters} />
              {starters.length === 0 && (
                <div className="card">
                  <span className="thinking">loading suggestions from the Brain…</span>
                </div>
              )}
              {starters.length > 4 && (
                <div className="card fade-in">
                  <div style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 6 }}>
                    More suggestions from the Brain
                  </div>
                  <div className="chips">
                    {starters.slice(4).map(s => (
                      <button key={s} className="chip" onClick={() => ask(s)}>{s}</button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {messages.map((m, i) => m.role === 'user' ? (
            <div key={i} className="msg user rise-in">
              <span className="bubble">{m.text}</span>
            </div>
          ) : (
            <div key={i} className="msg rise-in">
              <div className={`card ${m.data.degraded ? 'card-degraded' : ''}`}>
                {mode === 'ai' && <JourneyStrip audit={m.data.audit} />}
                <div className="summary">{m.data.summary}</div>

                {m.data.artifacts?.map((a, j) => (
                  <div key={j} className="artifact rise-in"
                    style={{ animationDelay: `${0.08 * (j + 1)}s` }}>
                    {/* Titles are generated from metric + intent, which is
                        frequently not what a human would call the chart. One
                        click renames it, and the rename travels with the
                        artifact when pinned or exported. Held in chartViews so
                        it survives the tab unmount like the rest of the view
                        state. */}
                    <EditableTitle
                      value={chartViews[`${i}:${j}`]?.title ?? a.title}
                      onChange={t => patchChartView(`${i}:${j}`, { title: t })}
                      placeholder={a.title || 'Untitled chart'} />
                    {a.type === 'chart'
                      ? <ChartArtifact spec={a} onDrill={ask}
                          sql={m.data.sql}
                          onRerun={rerunSql}
                          view={chartViews[`${i}:${j}`]}
                          onViewChange={p => patchChartView(`${i}:${j}`, p)}
                          onSave={sp => saveToWorkspace(
                            { ...sp, title: chartViews[`${i}:${j}`]?.title ?? a.title },
                            m.data.question)} />
                      : a.type === 'insights'
                        ? <InsightCards items={a.items} />
                        : <DataGrid columns={a.columns} rows={a.rows} collapsed={a.collapsed} />}
                  </div>
                ))}

                {mode === 'ai' && <UsageChip usage={m.data.usage} />}

                {mode === 'ai' && m.data.trust && (
                  <TrustPanel trust={m.data.trust} audit={m.data.audit}
                    sql={m.data.sql} grounding={m.data.grounding}
                    question={m.data.question} />
                )}

                {m.data.followups?.length > 0 && (
                  <div className="chips">
                    {m.data.followups.map(f => (
                      <button key={f} className="chip" onClick={() => ask(f)}>{f}</button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {busy && (
            <div className="thinking-card rise-in">
              <div className="shimmer" />
              <span>agents working: RBAC → grounding → routing → SQL → validation → root-cause → viz…</span>
            </div>
          )}
          <div ref={endRef} />

          <div className="composer">
            <div className="inner">
              <input value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && ask(input)}
                placeholder={activeCohort
                  ? `Asking within: ${cohorts.find(c => c.id === activeCohort)?.name ?? ''} — or "create a risk pool of…"`
                  /* `starters` is already fetched from /api/suggestions, which
                     builds from the ACTIVE Brain. The literal that used to be
                     here named MLR, PBM rejects, RAF and HEDIS in every domain,
                     so a Medicare Sales analyst was prompted with four things
                     this domain does not have. */
                  : starters[0]
                    ? `Try "${starters[0]}" — or "create a risk pool of…"`
                    : 'Ask a question of your governed data…'} />
              <button onClick={() => ask(input)} disabled={busy}>Ask</button>
            </div>
          </div>
        </>}
      </div>
    </div>
  )
}
