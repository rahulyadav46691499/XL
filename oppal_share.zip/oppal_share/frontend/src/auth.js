// OpPal auth layer: token in sessionStorage (dev) / memory,
// injected into every /api call; 401 forces re-login.
export const getSession = () => {
  try { return JSON.parse(sessionStorage.getItem('oppal-session')) } catch { return null }
}
export const setSession = (s) =>
  sessionStorage.setItem('oppal-session', JSON.stringify(s))
export const clearSession = () => sessionStorage.removeItem('oppal-session')

// The signed-in principal, for namespacing browser-local state.
export const currentUserId = () => getSession()?.user?.user_id || ''

// Per-user localStorage key. Chat history lived under one global key
// ('oppal-history'), so on a shared workstation the next person to sign in
// inherited the previous analyst's question history — including cohort
// definitions and phrasing that can be sensitive on its own. Anything
// personal must be namespaced by user id; '' (signed out) gets its own
// throwaway bucket that is cleared on logout.
export const userKey = (base, uid) =>
  `${base}:${uid !== undefined ? uid : currentUserId()}`

// Chat history SURVIVES logout, on purpose — and as of v14.8.0 it does not
// live here at all: it is server-side (app/history/store.py), fetched per
// signed-in user, so it also survives a cleared cache and a change of
// machine. What follows is why the destructive logout wipe was removed, kept
// because the reasoning still governs the anonymous bucket below.
//
// This function used to delete 'oppal-history' on every logout, and the whole
// transcript list vanished the moment anyone signed out and back in. The wipe
// was added to stop a real leak — history once lived under a single global
// key, so the next person to sign in at a shared workstation inherited the
// previous analyst's questions, including cohort phrasing that is sensitive
// on its own.
//
// But that leak was ALREADY closed by namespacing every personal key with the
// signed-in user id (see userKey above). Once each user reads and writes their
// own bucket, deleting on logout protects nobody — it only destroys the
// returning user's own work. Two mechanisms were solving one problem, and the
// redundant one was the destructive one.
//
// What is cleared on logout is the anonymous ('' user) bucket: state written
// before anyone signed in belongs to nobody and must not be adopted by the
// next principal to arrive.
//
// A user who genuinely wants their history gone still has an explicit,
// deliberate control: "clear history" in the sidebar. Purging someone's work
// should be something they choose, not a side effect of signing out.
export const clearAnonymousLocalState = () => {
  for (const base of ['oppal-history', 'oppal-mode', 'oppal-pipeline']) {
    try { localStorage.removeItem(userKey(base, '')) } catch { /* ignore */ }
  }
}

// NOTE: there is deliberately no clear-this-user's-everything helper. The one
// destructive control a user has is "clear history" in the sidebar, which
// removes exactly the history key for the signed-in id and nothing else.

export async function login(user_id, password) {
  const r = await fetch('/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user_id, password })
  })
  if (!r.ok) throw new Error((await r.json()).detail || 'Login failed')
  const out = await r.json()
  setSession(out)
  return out
}

// patch global fetch once so ALL existing components are covered
const rawFetch = window.fetch.bind(window)
window.fetch = async (input, init = {}) => {
  const url = typeof input === 'string' ? input : input.url
  if (url.startsWith('/api') && !url.startsWith('/api/auth/')) {
    const s = getSession()
    init.headers = { ...(init.headers || {}),
      ...(s ? { Authorization: `Bearer ${s.token}` } : {}) }
  }
  const res = await rawFetch(input, init)
  if (res.status === 401 && url.startsWith('/api')
      && !url.startsWith('/api/auth/')) {
    clearSession()
    window.dispatchEvent(new Event('oppal-logout'))
  }
  return res
}
export const authToken = () => getSession()?.token
