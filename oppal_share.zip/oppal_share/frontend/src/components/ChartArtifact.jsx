import React, { useMemo, useState } from 'react'
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, AreaChart, Area,
  PieChart, Pie, Cell, ScatterChart, Scatter, LabelList, ReferenceDot,
  XAxis, YAxis, ZAxis, Tooltip, Legend, CartesianGrid
} from 'recharts'

// Three selectable palettes. All are checked for adjacent-hue contrast so a
// bar chart stays readable, and none encodes meaning by hue alone (anomalies
// are marked with a shape + label, never colour only) — a chart that only
// works for trichromatic vision is not an enterprise chart.
export const SCHEMES = {
  pastel: {
    label: 'Pastel',
    colors: ['#6c8ef5', '#5bbf9a', '#f0a860', '#e58787', '#a98ff2',
             '#5fc3d8', '#e894c0', '#9cc96a', '#c9a76a', '#7fa8d9'],
  },
  corporate: {
    label: 'Corporate',
    colors: ['#1F3864', '#2E74B5', '#4A9BD1', '#7FB3D5', '#5B6B79',
             '#356B4F', '#8A6B2E', '#6B3F5B', '#2F6F6F', '#8C4A3F'],
  },
  vivid: {
    label: 'Vivid',
    colors: ['#3b6ef2', '#00a37a', '#f08a24', '#e0483d', '#8b5cf6',
             '#0ea5c4', '#db2777', '#65a30d', '#b45309', '#0f766e'],
  },
}
const DEFAULT_SCHEME = 'pastel'

const fmtVal = (v, format) => {
  if (v == null || v === '') return ''
  if (format === 'percent') return (v * 100).toFixed(1) + '%'
  if (format === 'currency')
    return '$' + (Math.abs(v) >= 1e6 ? (v / 1e6).toFixed(1) + 'M'
      : Math.abs(v) >= 1e3 ? (v / 1e3).toFixed(1) + 'k'
        : Number(v).toLocaleString())
  return Math.abs(v) >= 1e6 ? (v / 1e6).toFixed(1) + 'M'
    : Number(v).toLocaleString()
}

// Generative chart artifact: line/area/bar/multiline/pie/scatter, with
// data-point labels, click-to-drill-down, and a right-hand control panel
// (orientation, bar shape, palette, and the governed SQL behind the chart).
export default function ChartArtifact({ spec, onDrill, onSave, sql, onRerun,
                                       view, onViewChange }) {
  // View state can be OWNED BY THE PARENT (`view` + `onViewChange`) or kept
  // locally. The chat tab is conditionally rendered, so switching tabs
  // unmounts it and React discards component state — every customisation
  // (chart type, orientation, palette, and any re-run result) was being lost
  // on the way to the Workspace tab and back. Hoisting it to App.jsx makes
  // those choices outlive the unmount. Defaults still come from the spec, so
  // a PINNED chart opens the way its author left it.
  const defaults = {
    typeOverride: null,
    orientation: spec.orientation || 'vertical',
    barShape: spec.bar_shape || 'rounded',
    scheme: SCHEMES[spec.color_scheme] ? spec.color_scheme : DEFAULT_SCHEME,
    panelOpen: false,
    sqlOpen: false,
    sqlText: sql || '',
    rerun: null,
    rerunErr: '',
  }
  const [localView, setLocalView] = useState(defaults)
  const v = { ...defaults, ...(view || (onViewChange ? {} : localView)) }
  const setV = (patch) => (onViewChange
    ? onViewChange(patch)
    : setLocalView(s => ({ ...s, ...patch })))

  const { typeOverride, orientation, barShape, scheme, panelOpen,
          sqlOpen, sqlText, rerun, rerunErr } = v
  const setTypeOverride = (x) => setV({ typeOverride: x })
  const setOrientation = (x) => setV({ orientation: x })
  const setBarShape = (x) => setV({ barShape: x })
  const setScheme = (x) => setV({ scheme: x })
  const setSqlText = (x) => setV({ sqlText: x })
  const [busy, setBusy] = useState(false)
  // Pending model-cost confirmation, and what the last confirmed run spent.
  const [confirm, setConfirm] = useState(null)
  const [aiUsage, setAiUsage] = useState(null)

  const COLORS = (SCHEMES[scheme] || SCHEMES[DEFAULT_SCHEME]).colors
  const chartType = typeOverride || spec.chart_type

  // A successful re-run REPLACES the plotted data but never the spec's
  // semantics: the axis/series keys still come from the governed spec, so an
  // edited query that no longer returns those columns renders empty rather
  // than silently mislabelling someone else's numbers as the original metric.
  const eff = rerun
    ? { ...spec, columns: rerun.columns, rows: rerun.rows }
    : spec
  const { columns, rows, format } = eff

  const data = useMemo(() => {
    if (!Array.isArray(columns) || !Array.isArray(rows)) return []
    if (spec.series_dim) {                  // dim × quarter matrix pivot
      const si = columns.indexOf(spec.series_dim)
      const xi = columns.indexOf(spec.x)
      const vi = columns.indexOf(spec.value)
      const byX = {}
      for (const r of rows) {
        byX[r[xi]] = byX[r[xi]] || { [spec.x]: r[xi] }
        byX[r[xi]][r[si]] = r[vi]
      }
      return Object.values(byX)
    }
    return rows.map(r => Object.fromEntries(columns.map((c, i) => [c, r[i]])))
  }, [columns, rows, spec.series_dim, spec.x, spec.value])

  const seriesKeys = spec.series_dim
    ? [...new Set((rows || []).map(r => r[columns.indexOf(spec.series_dim)]))]
    : (spec.series || [])

  const pieData = useMemo(() => {
    if (!spec.series_dim) return data
    const si = columns.indexOf(spec.series_dim)
    const vi = columns.indexOf(spec.value)
    const agg = {}
    for (const r of (rows || [])) agg[r[si]] = (agg[r[si]] || 0) + (r[vi] || 0)
    return Object.entries(agg).map(([k, v]) => ({ [spec.x || 'name']: k, value: v }))
  }, [data, columns, rows, spec.series_dim, spec.value, spec.x])

  const handleClick = (e) => {
    if (!spec.drilldown || !e?.activeLabel || !onDrill) return
    onDrill(spec.drilldown.prompt_template.replace('{x}', e.activeLabel))
  }

  const doRerun = async (aiConfirm = false) => {
    if (!onRerun || !sqlText.trim()) return
    setBusy(true); setV({ rerunErr: '' })
    setConfirm(null)
    try {
      const out = await onRerun(sqlText, aiConfirm)
      if (out && out.needs_confirmation) {
        setConfirm(out)                 // ask before spending / sending text
      } else if (!out || out.ok === false) {
        setV({ rerunErr: out?.reason || 'the governance gate refused this query' })
      } else if (!out.columns?.length) {
        setV({ rerunErr: 'the query returned no columns' })
      } else {
        setV({ rerun: out, rerunErr: '' })
        setAiUsage(out.ai_usage || null)
      }
    } catch (e) { setV({ rerunErr: String(e.message || e) }) }
    setBusy(false)
  }
  const resetRerun = () =>
    setV({ rerun: null, rerunErr: '', sqlText: sql || '' })

  const axis = { stroke: 'var(--muted)', fontSize: 11 }
  const labelStyle = { fill: 'var(--chart-label)', fontSize: 10 }
  const showLabels = data.length <= 16   // avoid clutter on dense charts
  const tooltipStyle = { background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text)' }
  const horizontal = orientation === 'horizontal'
  const barRadius = barShape === 'square' ? 0
    : barShape === 'pill' ? (horizontal ? [999, 999, 999, 999] : [999, 999, 0, 0])
      : (horizontal ? [0, 4, 4, 0] : [4, 4, 0, 0])

  const catAxis = (props) => (
    <XAxis dataKey={spec.x} {...axis}
      angle={data.length > 8 ? -25 : 0} height={data.length > 8 ? 55 : 30}
      textAnchor={data.length > 8 ? 'end' : 'middle'} interval={0} {...props} />
  )
  const common = (
    <>
      <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
      {catAxis()}
      <YAxis {...axis} tickFormatter={v => fmtVal(v, format)} width={64} />
      <Tooltip contentStyle={tooltipStyle} formatter={v => fmtVal(v, format)} />
      <Legend wrapperStyle={{ fontSize: 12 }} />
    </>
  )

  let chart
  if (chartType === 'pie') {
    const key = spec.series_dim ? 'value' : seriesKeys[0]
    const pdata = spec.series_dim ? pieData : data
    chart = (
      <PieChart>
        <Pie data={pdata} dataKey={key} nameKey={spec.x || 'name'}
          cx="50%" cy="50%" outerRadius={92}
          label={(e) => `${e[spec.x]}: ${fmtVal(e[key], format)}`}
          labelLine={{ stroke: 'var(--muted)' }}
          onClick={(e) => spec.drilldown && onDrill &&
            onDrill(spec.drilldown.prompt_template.replace('{x}', e[spec.x]))}>
          {pdata.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} cursor="pointer" />
          ))}
        </Pie>
        <Tooltip contentStyle={tooltipStyle} formatter={v => fmtVal(v, format)} />
      </PieChart>
    )
  } else if (chartType === 'scatter') {
    chart = (
      <ScatterChart margin={{ top: 12, right: 20 }}>
        <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
        <XAxis dataKey={spec.x} name={spec.x} {...axis} type="number"
          tickFormatter={v => fmtVal(v, 'number')} />
        <YAxis dataKey={spec.y} name={spec.y} {...axis} type="number"
          tickFormatter={v => fmtVal(v, format)} width={64} />
        <ZAxis range={[60, 61]} />
        <Tooltip contentStyle={tooltipStyle} cursor={{ strokeDasharray: '3 3' }}
          formatter={(v, name) => fmtVal(v, name === spec.y ? format : 'number')}
          labelFormatter={() => ''} />
        <Scatter data={data} fill={COLORS[0]}>
          {showLabels && <LabelList dataKey={spec.label} position="top" style={labelStyle} />}
        </Scatter>
      </ScatterChart>
    )
  } else if (chartType === 'bar') {
    // Horizontal bars are recharts' layout="vertical": the CATEGORY axis
    // becomes Y and the value axis becomes X. Long category names (drug
    // classes, provider names) are far more legible this way, which is the
    // main reason to offer the toggle at all.
    chart = (
      <BarChart data={data} onClick={handleClick} margin={{ top: 18, right: 18 }}
        layout={horizontal ? 'vertical' : 'horizontal'}>
        <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
        {horizontal ? (
          <>
            <XAxis type="number" {...axis} tickFormatter={v => fmtVal(v, format)} />
            <YAxis type="category" dataKey={spec.x} {...axis} width={128}
              interval={0} />
          </>
        ) : (
          <>
            {catAxis()}
            <YAxis {...axis} tickFormatter={v => fmtVal(v, format)} width={64} />
          </>
        )}
        <Tooltip contentStyle={tooltipStyle} formatter={v => fmtVal(v, format)} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        {seriesKeys.map((k, i) => (
          <Bar key={k} dataKey={k} radius={barRadius}
            fill={COLORS[i % COLORS.length]} cursor="pointer">
            {seriesKeys.length === 1 && data.map((_, j) => (
              <Cell key={j} fill={COLORS[j % COLORS.length]} />
            ))}
            {showLabels &&
              <LabelList dataKey={k} position={horizontal ? 'right' : 'top'}
                style={labelStyle} formatter={v => fmtVal(v, format)} />}
          </Bar>
        ))}
      </BarChart>
    )
  } else if (chartType === 'area') {
    const areaAnomalyDots = (spec.anomaly_periods || []).map(period => {
      const datum = data.find(d => d[spec.x] === period)
      const yKey = seriesKeys[0]
      if (!datum || datum[yKey] == null) return null
      return (
        <ReferenceDot key={period} x={period} y={datum[yKey]} r={9}
          fill="none" stroke="var(--bad)" strokeWidth={2.5}
          label={{ value: '⚠ anomaly', position: 'top',
                   fill: 'var(--bad)', fontSize: 10 }} />
      )
    })
    chart = (
      <AreaChart data={data} onClick={handleClick} margin={{ top: 24 }}>
        {common}
        {areaAnomalyDots}
        {seriesKeys.map((k, i) => (
          <Area key={k} dataKey={k} stroke={COLORS[i % COLORS.length]}
            fill={COLORS[i % COLORS.length]}
            fillOpacity={0.25} strokeWidth={2} cursor="pointer">
            {showLabels &&
              <LabelList dataKey={k} position="top" style={labelStyle}
                formatter={v => fmtVal(v, format)} />}
          </Area>
        ))}
      </AreaChart>
    )
  } else { // line, multiline, multiline_wide
    const anomalyDots = (spec.anomaly_periods || []).map(period => {
      const datum = data.find(d => d[spec.x] === period)
      const yKey = seriesKeys[0]
      if (!datum || datum[yKey] == null) return null
      return (
        <ReferenceDot key={period} x={period} y={datum[yKey]} r={9}
          fill="none" stroke="var(--bad)" strokeWidth={2.5}
          label={{ value: '⚠ anomaly', position: 'top',
                   fill: 'var(--bad)', fontSize: 10 }} />
      )
    })
    chart = (
      <LineChart data={data} onClick={handleClick} margin={{ top: 24 }}>
        {common}
        {anomalyDots}
        {seriesKeys.map((k, i) => (
          <Line key={k} dataKey={k} stroke={COLORS[i % COLORS.length]}
            strokeWidth={2} dot={{ r: 3 }} cursor="pointer" connectNulls>
            {showLabels && seriesKeys.length <= 2 &&
              <LabelList dataKey={k} position="top" style={labelStyle}
                formatter={v => fmtVal(v, format)} />}
          </Line>
        ))}
      </LineChart>
    )
  }

  const isBar = chartType === 'bar'
  const seg = (active) => `chip chart-seg${active ? ' chip-on' : ''}`

  return (
    <div>
      {(spec.chart_mismatch || typeOverride) && spec.recommended_chart && (
        <div className="chart-suggest fade-in">
          💡 Engine suggests <b>{spec.recommended_chart}</b> — {spec.recommendation_reason}
          {chartType !== spec.recommended_chart
            ? <button className="chip" style={{ marginLeft: 8 }}
                onClick={() => setTypeOverride(spec.recommended_chart)}>
                Switch to {spec.recommended_chart}</button>
            : <button className="chip" style={{ marginLeft: 8 }}
                onClick={() => setTypeOverride(null)}>
                Back to {spec.chart_type}</button>}
        </div>
      )}

      {rerun && (
        <div className="chart-edited-banner fade-in">
          ✏️ Showing results of <b>your edited SQL</b>
          {rerun.trust != null &&
            ` · trust ${Math.round((rerun.trust.score || 0) * 100)}%`}
          {' '}— authored by you, not the governed template, so it is scored
          lower and is not certified.
          <button className="chip" style={{ marginLeft: 8 }} onClick={resetRerun}>
            Restore governed result
          </button>
        </div>
      )}

      <div className="chart-shell">
        <div className="chart-main">
          <ResponsiveContainer width="100%" height={chartType === 'pie' ? 300 : 280}>
            {chart}
          </ResponsiveContainer>
        </div>

        <aside className={`chart-panel ${panelOpen ? 'open' : ''}`}>
          <button className="chart-panel-toggle"
            title={panelOpen ? 'hide chart options' : 'chart options'}
            onClick={() => setV({ panelOpen: !panelOpen })}>
            {panelOpen ? '›' : '‹'} <span>Options</span>
          </button>
          {panelOpen && (
            <div className="chart-panel-body fade-in">
              <div className="chart-panel-group">
                <label>Chart type</label>
                <div className="chart-seg-row">
                  {['bar', 'line', 'area', 'pie'].map(t => (
                    <button key={t} className={seg(chartType === t)}
                      onClick={() => setTypeOverride(t)}>{t}</button>
                  ))}
                </div>
              </div>

              {isBar && (
                <>
                  <div className="chart-panel-group">
                    <label>Orientation</label>
                    <div className="chart-seg-row">
                      <button className={seg(!horizontal)}
                        onClick={() => setOrientation('vertical')}>▯ vertical</button>
                      <button className={seg(horizontal)}
                        onClick={() => setOrientation('horizontal')}>▭ horizontal</button>
                    </div>
                  </div>
                  <div className="chart-panel-group">
                    <label>Bar shape</label>
                    <div className="chart-seg-row">
                      {[['rounded', 'rounded'], ['square', 'square'],
                        ['pill', 'pill']].map(([v, l]) => (
                        <button key={v} className={seg(barShape === v)}
                          onClick={() => setBarShape(v)}>{l}</button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              <div className="chart-panel-group">
                <label>Colour scheme</label>
                <div className="chart-scheme-list">
                  {Object.entries(SCHEMES).map(([key, s]) => (
                    <button key={key}
                      className={`chart-scheme ${scheme === key ? 'on' : ''}`}
                      onClick={() => setScheme(key)} title={s.label}>
                      <span className="chart-swatches">
                        {s.colors.slice(0, 5).map((c, i) => (
                          <i key={i} style={{ background: c }} />
                        ))}
                      </span>
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {sql && (
                <div className="chart-panel-group">
                  <label>
                    <button className="linkbtn" onClick={() => setV({ sqlOpen: !sqlOpen })}>
                      {sqlOpen ? '▾' : '▸'} SQL behind this chart
                    </button>
                  </label>
                  {sqlOpen && (
                    <div className="fade-in">
                      <textarea className="chart-sql" spellCheck={false}
                        value={sqlText} rows={8}
                        onChange={e => setSqlText(e.target.value)}
                        readOnly={!onRerun} />
                      {onRerun ? (
                        <>
                          <div className="chart-sql-actions">
                            <button className="primary-btn" disabled={busy}
                              onClick={() => doRerun(false)}>
                              {busy ? 'Running…' : '▶ Run'}
                            </button>
                            <button className="chip" disabled={busy}
                              onClick={resetRerun}>Reset</button>
                          </div>
                          <p className="chart-sql-note">
                            Runs read-only and inside your authorized lines of
                            business — the gate refuses anything else. Edited
                            results are marked uncertified.
                          </p>
                        </>
                      ) : (
                        <p className="chart-sql-note">Read-only view.</p>
                      )}
                      {aiUsage && (
                        <div className="chart-sql-note" style={{ color: 'var(--good)' }}>
                          ✓ {aiUsage.model_calls_used}/{aiUsage.model_calls_max}
                          {' '}model calls used · {aiUsage.note}
                        </div>
                      )}
                      {confirm && (
                        <div className="ai-confirm fade-in" role="alertdialog"
                          aria-label="Confirm model-backed function">
                          <b>⚠ {confirm.headline}</b>
                          <p>{confirm.detail}</p>
                          <p className="ai-confirm-sample">{confirm.if_confirmed}</p>
                          <p className="ai-confirm-phi">{confirm.phi_note}</p>
                          <div className="chart-sql-actions">
                            <button className="primary-btn" disabled={busy}
                              onClick={() => doRerun(true)}>
                              Run {confirm.sample_rows}-row sample
                            </button>
                            <button className="chip" disabled={busy}
                              onClick={() => setConfirm(null)}>Cancel</button>
                          </div>
                        </div>
                      )}
                      {rerunErr && (
                        <div className="chart-sql-err fade-in">⛔ {rerunErr}</div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </aside>
      </div>

      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        {spec.drilldown && (
          <span style={{ fontSize: 11, color: 'var(--muted)' }}>
            💡 Click a data point to drill down by {spec.drilldown.dimension}
          </span>
        )}
        {onSave && (
          <button className="chip" style={{ fontSize: 11 }}
            onClick={() => onSave({ ...spec, chart_type: chartType,
                                    color_scheme: scheme,
                                    orientation, bar_shape: barShape })}>
            📌 Pin to Workspace
          </button>
        )}
      </div>
    </div>
  )
}
