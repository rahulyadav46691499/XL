import React, { useEffect, useMemo, useRef, useState } from 'react'
import { userKey } from '../auth.js'

// Left-rail navigation: five stacked groups, each opening a drawer of tabs.
//
// Replaces the two horizontal tab rows that used to sit in the sticky header.
// With 19 tabs across 2 rows those wrapped unpredictably at narrow widths and
// ate vertical space above every screen; five short vertical stacks in the
// rail that already exists cost no content height at all.
//
// Behaviour notes that matter:
//   * The group holding the CURRENT tab auto-opens, so the rail always shows
//     you where you are — including after a deep link or a tab change made
//     from somewhere else in the app.
//   * Search filters items as you type and force-opens matching groups, so a
//     match is never hidden inside a collapsed drawer.
//   * Expanded/collapsed state is remembered per user (userKey), because
//     which areas you live in is a personal preference, and a shared
//     workstation must not leak one person's layout to the next.
export default function NavMenu({ groups, current, onSelect, uid }) {
  const storeKey = userKey('oppal-nav-open', uid)

  const allNames = useMemo(() => groups.map(([g]) => g), [groups])

  // Which group owns the active tab? That one is always open.
  const groupOf = useMemo(() => {
    const m = {}
    for (const [g, items] of groups) for (const [t] of items) m[t] = g
    return m
  }, [groups])

  const [open, setOpen] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(storeKey) || 'null')
      if (Array.isArray(saved)) return new Set(saved)
    } catch { /* fall through to the default below */ }
    return new Set(allNames)          // first visit: everything open
  })
  const [q, setQ] = useState('')
  const searchRef = useRef(null)

  // Re-read when the signed-in user changes. Without this the next person at
  // a shared machine inherits the previous person's open/closed rail — the
  // same class of bug that leaked chat history and audiences before.
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(storeKey) || 'null')
      setOpen(new Set(Array.isArray(saved) ? saved : allNames))
    } catch {
      setOpen(new Set(allNames))
    }
  }, [storeKey, allNames])

  useEffect(() => {
    try { localStorage.setItem(storeKey, JSON.stringify([...open])) }
    catch { /* private mode / quota — the rail still works, just not sticky */ }
  }, [open, storeKey])

  const query = q.trim().toLowerCase()

  // Filter items by the query. A group survives if its own name matches or if
  // any of its items do — searching "govern" should find the group AND the
  // Governance tab inside it.
  const shown = useMemo(() => {
    if (!query) return groups.map(([g, items]) => [g, items])
    return groups
      .map(([g, items]) => {
        const groupHit = g.toLowerCase().includes(query)
        const hits = items.filter(([t]) => t.toLowerCase().includes(query))
        if (groupHit) return [g, hits.length ? hits : items]
        return hits.length ? [g, hits] : null
      })
      .filter(Boolean)
  }, [groups, query])

  const matchCount = shown.reduce((a, [, items]) => a + items.length, 0)

  const toggle = (g) => setOpen(prev => {
    const next = new Set(prev)
    next.has(g) ? next.delete(g) : next.add(g)
    return next
  })

  const allOpen = allNames.every(g => open.has(g))
  const isOpen = (g) =>
    // While searching every surviving group is forced open: a result the user
    // can see the count of but not the contents of is a dead end.
    !!query || open.has(g) || groupOf[current] === g

  return (
    <nav className="nav-menu" aria-label="Main">
      <div className="nav-head">
        <b>Navigate</b>
        <button className="linkbtn nav-expand"
          title={allOpen ? 'Collapse every group' : 'Expand every group'}
          onClick={() => setOpen(allOpen ? new Set() : new Set(allNames))}>
          {allOpen ? 'Collapse all' : 'Expand all'}
        </button>
      </div>

      <input
        ref={searchRef}
        className="sidebar-search nav-search"
        placeholder="Search menu…"
        value={q}
        onChange={e => setQ(e.target.value)}
        onKeyDown={e => {
          if (e.key === 'Escape') { setQ(''); e.currentTarget.blur() }
          // Enter jumps straight to the only remaining match — the fastest
          // path for someone who knows the tab name and just types it.
          if (e.key === 'Enter' && matchCount === 1) {
            const only = shown.find(([, items]) => items.length)[1][0][0]
            onSelect(only); setQ('')
          }
        }}
      />
      {query && (
        <div className="nav-hits">
          {matchCount === 0 ? 'No menu item matches.'
            : `${matchCount} match${matchCount === 1 ? '' : 'es'}`
              + (matchCount === 1 ? ' — press Enter' : '')}
        </div>
      )}

      <div className="nav-groups">
        {shown.map(([group, items]) => {
          const openNow = isOpen(group)
          const holdsCurrent = groupOf[current] === group
          return (
            <div className={`nav-group ${openNow ? 'open' : ''}`} key={group}>
              <button
                className={`nav-group-btn ${holdsCurrent ? 'holds-current' : ''}`}
                aria-expanded={openNow}
                onClick={() => toggle(group)}>
                <span className="nav-caret">{openNow ? '▾' : '▸'}</span>
                <span className="nav-group-name">{group}</span>
                <span className="sidebar-count">{items.length}</span>
              </button>
              {openNow && (
                <div className="nav-drawer">
                  {items.map(([t, icon, anim]) => (
                    <button
                      key={t}
                      className={`nav-item ${current === t ? 'on' : ''}`}
                      aria-current={current === t ? 'page' : undefined}
                      onClick={() => { onSelect(t); setQ('') }}>
                      <span className={`tab-icon anim-${anim}`}>{icon}</span>
                      <span className="nav-item-text">{t}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </nav>
  )
}
