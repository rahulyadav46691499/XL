// REMOVED — superseded by components/Workspace.jsx (Phase 5, REQ-5.6-5.8).
//
// This was the POC's browser-local chart tray: dashboards and pinned charts
// lived in localStorage under 'bi-workspace'. That is the wrong model for a
// payer platform — a "saved" artifact was invisible to any reviewer, carried
// no LOB scope, had no lineage back to the trust score or logic tree that
// produced it, and vanished when the browser cache was cleared.
//
// Workspace.jsx replaces it with the server-persisted, LOB-scoped workspace:
// artifacts are stored via /api/workspace, visible only within the caller's
// authorized lines of business, and every tile resolves back to its
// journey/trust/logic-tree lineage through /api/artifact/{id}/lineage.
//
// This file is retained only as a tombstone so a stale import fails loudly at
// the import site rather than silently resolving to a shadowed module.
throw new Error(
  'WorkspaceTab was removed in Phase 5; import Workspace.jsx instead ' +
  '(server-persisted, LOB-scoped workspace with artifact lineage).')
