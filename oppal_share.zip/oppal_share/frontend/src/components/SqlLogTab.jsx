import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Terminal-style live log of every SQL executed, with search.
export default function SqlLogTab() {
  const [items, setItems] = useState([])
  const [total, setTotal] = useState(0)
  const [q, setQ] = useState('')
  const [auto, setAuto] = useState(true)

  const load = (query = q) =>
    fetch(`/api/sql-log?q=${encodeURIComponent(query)}`)
      .then(r => r.json())
      .then(d => { setItems(d.items || []); setTotal(d.total || 0) })
      .catch(() => {})

  useEffect(() => { load() }, [q])
  useEffect(() => {
    if (!auto) return
    const i = setInterval(() => load(), 4000)
    return () => clearInterval(i)
  }, [auto, q])

  return (
    <div className="card fade-in">
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <h3>SQL execution log<InfoDot id="sql_log.log_feed" /></h3>
        <span style={{ fontSize: 12, color: 'var(--muted)' }}>
          {items.length} shown / {total} in buffer
        </span>
        <div style={{ flex: 1 }} />
        <label style={{ fontSize: 12, color: 'var(--muted)' }}>
          <input type="checkbox" checked={auto}
            onChange={e => setAuto(e.target.checked)} /> live
        </label>
        <button className="chip" onClick={() => load()}>↻ refresh</button>
      </div>
      <input className="settings-input" style={{ width: '100%', marginTop: 8 }}
        placeholder="Search SQL… (e.g. pharmacy_claims, reject_code, lob IN)"
        value={q} onChange={e => setQ(e.target.value)} />
      <div className="sql-terminal">
        {items.map((i, idx) => (
          <div key={idx} className={`sql-line ${i.ok ? '' : 'err'}`}>
            <span className="sql-ts">{(i.ts || '').slice(11, 23)}</span>
            <span className={`sql-status ${i.ok ? 'ok' : 'fail'}`}>
              {i.ok ? 'OK' : 'ERR'}
            </span>
            <span className="sql-meta">{i.rows}r · {i.ms}ms</span>
            <code className="sql-text">{i.sql}</code>
            {i.error && <span className="sql-err-msg">{i.error}</span>}
          </div>
        ))}
        {items.length === 0 && (
          <div style={{ color: 'var(--muted)', padding: 12 }}>
            No SQL yet{q ? ' matching your search' : ' — ask something in Chat'}.
          </div>
        )}
      </div>
    </div>
  )
}
