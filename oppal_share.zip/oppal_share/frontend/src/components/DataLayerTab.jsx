import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Phase 1 — MCP Zero-Copy / Zero-Persistence data layer surface.
// Shows the active connector, its scope strategy, zero-persistence posture,
// the caller's LOB scope, and the governed catalog (with search, per the
// OpPal "search in every UI" standard).
export default function DataLayerTab() {
  const [data, setData] = useState(null)
  const [err, setErr] = useState('')
  const [q, setQ] = useState('')

  useEffect(() => {
    fetch('/api/data-layer').then(r => r.json())
      .then(setData).catch(() => setErr('Could not load data layer'))
  }, [])

  if (err) return <div className="brain-status err">{err}</div>
  if (!data) return <div className="thinking">loading data layer…</div>

  const c = data.connector || {}
  const term = q.trim().toLowerCase()
  const catalog = (data.catalog || []).filter(t =>
    !term || t.name.toLowerCase().includes(term) ||
    (term === 'governed' && t.governed) ||
    (t.columns || []).some(col => col.name.toLowerCase().includes(term)))

  const Badge = ({ ok, on, off }) => (
    <span className={`chip ${ok ? 'chip-on' : ''}`}>{ok ? on : off}</span>
  )

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <h3>🔗 Zero-Copy Data Layer<InfoDot id="data_layer.governed_catalog_table" /></h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
          Queries run in the source warehouse and results stream back; nothing is
          copied or persisted. Line-of-business scope is enforced on every query.
        </p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          <Badge ok={c.healthy} on={`● ${c.name}`} off={`○ ${c.name}`} />
          <span className="chip">strategy: {c.strategy}</span>
          <Badge ok={data.zero_persistence} on="zero-persistence: on"
            off="zero-persistence: off" />
          <Badge ok={c.available} on="driver available" off="driver not installed" />
          <span className="chip">
            scope: {data.scope?.full_scope ? 'all LOBs' :
              (data.scope?.allowed_lobs || []).join(', ')}
          </span>
        </div>
        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>
          {c.detail}
        </div>
        {data.available_connectors?.length > 0 && (
          <div style={{ fontSize: 12, marginTop: 6 }}>
            <span style={{ color: 'var(--muted)' }}>Registered connectors: </span>
            {data.available_connectors.join(' · ')}
          </div>
        )}
      </div>

      <div className="card">
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <b style={{ fontSize: 13 }}>Governed catalog</b>
          <span className="sidebar-count">{catalog.length}</span>
          <div style={{ flex: 1 }} />
          <input className="settings-input" style={{ maxWidth: 260 }}
            placeholder="Search tables / columns…  (try 'governed')"
            value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 8px' }}>
          Credential and RBAC tables are intentionally absent — they are never
          exposed to the analytical data plane.
        </p>
        <table className="data-grid" style={{ width: '100%' }}>
          <thead>
            <tr><th>Table</th><th>Scoping</th><th>Columns</th></tr>
          </thead>
          <tbody>
            {catalog.map(t => (
              <tr key={t.name}>
                <td style={{ fontFamily: 'monospace' }}>{t.name}</td>
                <td>
                  <span className={`chip ${t.governed ? 'chip-on' : ''}`}>
                    {t.governed ? 'LOB-scoped' : 'reference (cross-LOB)'}
                  </span>
                </td>
                <td style={{ fontSize: 12, color: 'var(--muted)' }}>
                  {(t.columns || []).map(col => col.name).join(', ') || '—'}
                </td>
              </tr>
            ))}
            {catalog.length === 0 && (
              <tr><td colSpan={3} style={{ color: 'var(--muted)' }}>
                No tables match “{q}”.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
