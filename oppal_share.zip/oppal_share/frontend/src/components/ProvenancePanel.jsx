import React, { useEffect, useState } from 'react'

// Answer provenance receipts (Recommendation 2).
//
// The auditor's question is never "is it reproducible" in the abstract — it is
// "how was THIS number produced, and would it come out the same today". Each
// row answers the first; the check button answers the second, and reports which
// governed file moved rather than a bare pass/fail.
export default function ProvenancePanel() {
  const [receipts, setReceipts] = useState(null)
  const [current, setCurrent] = useState(null)
  const [denied, setDenied] = useState(false)
  const [checks, setChecks] = useState({})

  const load = () => {
    fetch('/api/governance/provenance?limit=12')
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(d => { setReceipts(d.receipts || []); setCurrent(d.current); setDenied(false) })
      .catch(() => setDenied(true))
  }
  useEffect(() => { load() }, [])

  const check = async (id) => {
    setChecks(c => ({ ...c, [id]: { busy: true } }))
    const r = await fetch(`/api/governance/provenance/${id}/reproducible`)
    const out = await r.json()
    setChecks(c => ({ ...c, [id]: out }))
  }

  if (denied) return null
  if (!receipts) return null

  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between',
                    alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <h3>Answer provenance ({receipts.length} recent receipts)</h3>
        <button className="chip" onClick={() => load()}>↻ refresh</button>
      </div>
      {current && (
        <p style={{ color: 'var(--muted)', fontSize: 12, marginTop: 6 }}>
          Current policy version <code>{current.brain_version}</code> · provider{' '}
          <code>{current.provider}</code>
        </p>
      )}
      {receipts.length === 0 && (
        <p style={{ color: 'var(--muted)', marginTop: 6 }}>
          No receipts yet — ask a question and one is recorded automatically.
        </p>
      )}

      {receipts.slice().reverse().map(r => {
        const c = checks[r.receipt_id]
        return (
          <div key={r.receipt_id} className="queue-item">
            <span className={`badge ${r.deterministic ? 'high' : 'med'}`}>
              {r.deterministic ? 'deterministic' : 'model-assisted'}
            </span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <b style={{ fontSize: 12.5 }}>{r.receipt_id}</b>
              <span style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                {' '}· {r.receipt_kind} · {r.user_id || 'system'}
                {r.trust_score != null &&
                  ` · trust ${Math.round(r.trust_score * 100)}%`}
              </span>
              <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2,
                            wordBreak: 'break-all' }}>
                policy {r.brain_version} · model {r.model}
              </div>
              {c && !c.busy && (
                <div style={{ fontSize: 11.5, marginTop: 4,
                              color: c.reproducible ? 'var(--ok, #2E7D32)' : 'var(--warn, #B45309)' }}>
                  {c.reproducible
                    ? '✓ conditions unchanged — reproducible'
                    : `⚠ ${c.explanation}`}
                  {(c.changed_brain_files || []).length > 0 &&
                    ` (changed: ${(c.changed_brain_files || []).join(', ')})`}
                </div>
              )}
            </div>
            <button className="chip" disabled={c?.busy}
                    onClick={() => check(r.receipt_id)}>
              {c?.busy ? '…' : 'check'}
            </button>
          </div>
        )
      })}
    </div>
  )
}
