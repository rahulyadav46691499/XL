import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Phase 2 — mid-market operational pillars dashboard (scoped to the caller's
// LOB). Surfaces regulatory timeliness, PA/UM triage, and FWA alerts, all
// searchable per the OpPal "search in every UI" standard.
export default function PillarsTab() {
  const [data, setData] = useState(null)
  const [q, setQ] = useState('')

  useEffect(() => {
    fetch('/api/pillars').then(r => r.json()).then(setData).catch(() => {})
  }, [])

  if (!data) return <div className="thinking">running pillar checks…</div>
  const term = q.trim().toLowerCase()
  const reg = data.regulatory || {}
  const pa = (data.claims_triage || {}).summary || {}
  const fwa = data.fwa || {}
  const alerts = (fwa.alerts || []).filter(a =>
    !term || a.pattern.toLowerCase().includes(term) ||
    a.provider_id.toLowerCase().includes(term) ||
    (a.detail || '').toLowerCase().includes(term))
  const universes = (reg.universes || []).filter(u =>
    !term || u.universe.toLowerCase().includes(term) ||
    (u.citation || '').toLowerCase().includes(term))

  const Stat = ({ label, value, tone }) => (
    <div className="card" style={{ flex: 1, minWidth: 150 }}>
      <div style={{ fontSize: 24, fontWeight: 700,
        color: tone === 'bad' ? 'var(--bad)' : tone === 'good' ? 'var(--good)' : 'var(--accent)' }}>
        {value}
      </div>
      <div style={{ fontSize: 12, color: 'var(--muted)' }}>{label}</div>
    </div>
  )

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3>🏛️ Operational Pillars<InfoDot id="pillars.regulatory_timeliness_table" /></h3>
          <div style={{ flex: 1 }} />
          <input className="settings-input" style={{ maxWidth: 260 }}
            placeholder="Search alerts / universes / providers…"
            value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          Deterministic, rule-driven checks (from the Context Brain) over your
          line-of-business data. Every query is LOB-scoped through the data layer.
        </p>
      </div>

      {/* Brain-declared rules that carry their own query. A domain whose
          policy_rules.md declares `query:` gets its breaches rendered here
          without a bespoke section per rule — the payer sections below stay
          exactly as they were. */}
      {(reg.breaches || []).length > 0 && (
        <div className="card" style={{ marginBottom: 12 }}>
          <b style={{ fontSize: 13 }}>
            ⚖️ Brain-declared rule breaches
            <span className="chip" style={{ marginLeft: 8, fontSize: 10 }}>
              {reg.breach_count} breach(es) · {(reg.rules_evaluated || []).join(', ')}
            </span>
          </b>
          <table className="data-grid" style={{ marginTop: 8 }}>
            <thead><tr><th>Rule</th><th>Finding</th><th>Action</th></tr></thead>
            <tbody>
              {(reg.breaches || [])
                .filter(b => !term || JSON.stringify(b).toLowerCase()
                  .includes(term))
                .slice(0, 40).map((b, i) => (
                <tr key={i}>
                  <td style={{ whiteSpace: 'nowrap' }}>
                    <b>{b.rule}</b>
                    {b.citation && <div style={{ fontSize: 10.5, color: 'var(--muted)' }}>{b.citation}</div>}
                  </td>
                  <td>{b.headline || b.error}</td>
                  <td><span className="chip chip-nowrap">{b.breach_action || '—'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* A rule declared in the Brain that nothing evaluates must SAY so. It
          used to be sent in the payload and never rendered, so the tab looked
          empty and the operator had no way to know why. */}
      {data.unimplemented_checks && (
        <div className="card" style={{ marginBottom: 12 }}>
          <b style={{ fontSize: 13 }}>⚠️ Declared but not evaluated</b>
          <div style={{ fontSize: 12.5, marginTop: 6 }}>
            {(data.unimplemented_checks.checks || []).map(c => (
              <span key={c} className="chip" style={{ marginRight: 6 }}>{c}</span>
            ))}
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 6 }}>
            {data.unimplemented_checks.detail}
          </div>
        </div>
      )}

      {/* Pillar 5 — regulatory timeliness */}
      {(reg.universes || []).length > 0 && (
      <div className="card" style={{ marginBottom: 12 }}>
        <b style={{ fontSize: 13 }}>⚖️ Regulatory timeliness (42 CFR §423.568 / §422.568)</b>
        <table className="data-grid" style={{ width: '100%', marginTop: 6 }}>
          <thead><tr><th>Universe</th><th>Citation</th><th>Cases</th><th>Breaches</th><th>Compliance</th></tr></thead>
          <tbody>
            {universes.map(u => (
              <tr key={u.universe}>
                <td style={{ fontFamily: 'monospace' }}>{u.universe}</td>
                <td style={{ fontSize: 11.5 }}>{u.citation}</td>
                <td>{u.total}</td>
                <td style={{ color: u.breaches ? 'var(--bad)' : 'var(--good)' }}>{u.breaches}</td>
                <td><span className={`chip ${u.compliance_pct >= 95 ? 'chip-on' : ''}`}>{u.compliance_pct}%</span></td>
              </tr>
            ))}
            {universes.length === 0 && <tr><td colSpan={5} style={{ color: 'var(--muted)' }}>No universes match.</td></tr>}
          </tbody>
        </table>
      </div>
      )}

      {/* Pillar 2 — PA / UM triage. Hidden for a domain that declares no
          triage rule, rather than rendering an empty payer section. */}
      {(pa.total || 0) > 0 && (
      <div className="card" style={{ marginBottom: 12 }}>
        <b style={{ fontSize: 13 }}>🩺 PA / UM triage — 85% trust gate</b>
        <div style={{ display: 'flex', gap: 10, marginTop: 8, flexWrap: 'wrap' }}>
          <Stat label="Total PA cases" value={pa.total ?? 0} />
          <Stat label={`Auto-approve eligible (≥${pa.gate ?? 0.85})`} value={pa.auto_approve_eligible ?? 0} tone="good" />
          <Stat label="Pended for review" value={pa.pended ?? 0} />
          <Stat label="Denied" value={pa.denied ?? 0} tone="bad" />
        </div>
      </div>

      )}

      {/* Pillar 3 — FWA. Hidden when this domain produces no alerts, rather
          than rendering an empty payer section under another vertical. */}
      {(fwa.alerts || []).length > 0 && (
      <div className="card">
        <b style={{ fontSize: 13 }}>🛰️ FWA &amp; overpayment alerts <span className="sidebar-count">{alerts.length}</span></b>
        <table className="data-grid" style={{ width: '100%', marginTop: 6 }}>
          <thead><tr><th>Pattern</th><th>Provider</th><th>z-score</th><th>Est. overpayment</th><th>Detail</th></tr></thead>
          <tbody>
            {alerts.map(a => (
              <tr key={a.fwa_id}>
                <td><span className="chip">{a.pattern}</span></td>
                <td style={{ fontFamily: 'monospace' }}>{a.provider_id}</td>
                <td>{a.z_score ?? '—'}</td>
                <td style={{ color: 'var(--bad)' }}>${(a.estimated_overpayment || 0).toLocaleString()}</td>
                <td style={{ fontSize: 11.5, color: 'var(--muted)' }}>{a.detail}</td>
              </tr>
            ))}
            {alerts.length === 0 && <tr><td colSpan={5} style={{ color: 'var(--muted)' }}>No alerts match “{q}”.</td></tr>}
          </tbody>
        </table>
      </div>
      )}
    </div>
  )
}
