import React from 'react'

// Saved audiences: click to scope every subsequent question to a cohort.
export default function CohortBar({ cohorts, active, onSelect, onDelete }) {
  if (!cohorts.length) return null
  return (
    <div className="cohort-bar">
      <span className="cohort-label">Audiences:</span>
      <button className={`cohort-chip ${!active ? 'on' : ''}`}
        onClick={() => onSelect(null)}>Whole book</button>
      {cohorts.map(c => (
        <span key={c.id} className={`cohort-chip ${active === c.id ? 'on' : ''}`}>
          <button className="cohort-name" onClick={() => onSelect(active === c.id ? null : c.id)}
            title={`${c.prompt}\nWHERE ${c.where}`}>
            {c.name}
            {c.profile && !c.profile.empty &&
              <span className="cohort-n"> · {c.profile.claims.toLocaleString()}</span>}
          </button>
          <button className="cohort-x" onClick={() => onDelete(c.id)}>×</button>
        </span>
      ))}
    </div>
  )
}
