import React, { useEffect, useRef, useState } from 'react'
import InfoDot from './InfoDot.jsx'
import DataGrid from './DataGrid.jsx'

// Current data source + import (csv/xlsx/sqlite, multiple files) +
// top-20 preview of every table.
export default function DataPreview() {
  const [data, setData] = useState(null)
  const [importing, setImporting] = useState(false)
  const [results, setResults] = useState(null)
  const [onboarding, setOnboarding] = useState(null)
  const [progress, setProgress] = useState(0)
  const [activity, setActivity] = useState('')
  const fileRef = useRef(null)

  const downloadTemplate = () => {
    const csv = 'record_id,entity_name,category,region,period,amount\n' +
      'R-0001,Sample Entity,Category A,West,2026Q1,1234.56\n'
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    a.download = 'import_template.csv'
    a.click()
  }

  const load = () =>
    fetch('/api/preview').then(r => r.json()).then(setData).catch(() => {})
  useEffect(() => { load() }, [])

  const ACTIVITIES = ['Creating tables & loading rows…',
    'Profiling columns (types, cardinality, time axis)…',
    'Detecting relationships to existing tables…',
    'Drafting Context Brain knowledge (entities, metrics, vocabulary)…',
    'LLM enrichment from PHI-scrubbed samples (if configured)…',
    'Rebuilding semantic graph & invalidating caches…']

  const doImport = () => {
    const files = fileRef.current?.files
    if (!files?.length) return
    setImporting(true)
    setProgress(0)
    setOnboarding(null)
    setActivity('Uploading files…')
    const fd = new FormData()
    for (const f of files) fd.append('files', f)
    const xhr = new XMLHttpRequest()
    xhr.open('POST', '/api/data/import')
    try {
      const s = JSON.parse(sessionStorage.getItem('oppal-session'))
      if (s?.token) xhr.setRequestHeader('Authorization', `Bearer ${s.token}`)
    } catch { }
    let actTimer = null
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const pct = Math.round(e.loaded / e.total * 60)
        setProgress(pct)
        setActivity(`Uploading files… ${Math.round(e.loaded / e.total * 100)}%`)
        if (e.loaded >= e.total && !actTimer) {
          // server-side pipeline: walk through the real stages
          let i = 0
          setActivity(ACTIVITIES[0])
          setProgress(65)
          actTimer = setInterval(() => {
            i = Math.min(i + 1, ACTIVITIES.length - 1)
            setActivity(ACTIVITIES[i])
            setProgress(p => Math.min(p + 6, 96))
          }, 700)
        }
      }
    }
    xhr.onload = () => {
      if (actTimer) clearInterval(actTimer)
      setActivity('Done')
      setProgress(100)
      try {
        const out = JSON.parse(xhr.responseText)
        setResults(out.results)
        setOnboarding(out.onboarding)
      } catch { setResults([{ file: '—', ok: false, error: 'upload failed' }]) }
      load()
      setImporting(false)
      if (fileRef.current) fileRef.current.value = ''
      setTimeout(() => setProgress(0), 1500)
    }
    xhr.onerror = () => {
      if (actTimer) clearInterval(actTimer)
      setActivity('')
      setResults([{ file: '—', ok: false, error: 'upload failed' }])
      setImporting(false)
    }
    xhr.send(fd)
  }

  if (!data) return <div className="thinking">loading data preview…</div>

  return (
    <div>
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>Data source<InfoDot id="data.per_table_preview_cards" /></h3>
        <div style={{ fontSize: 13, marginTop: 6 }}>
          <span style={{ color: 'var(--muted)' }}>Engine:</span> {data.source.engine}
          <span style={{ color: 'var(--muted)', marginLeft: 14 }}>Configured connection:</span> {data.source.configured}
        </div>
        <div style={{ fontSize: 12, fontFamily: 'monospace', color: 'var(--accent)', marginTop: 2, wordBreak: 'break-all' }}>
          {data.source.path}
        </div>

        <div style={{ borderTop: '1px solid var(--border)', marginTop: 12, paddingTop: 10 }}>
          <b style={{ fontSize: 13 }}>Import data</b>
          <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 8px' }}>
            Select multiple files — each CSV, Excel sheet, or SQLite table becomes a
            table below (like connecting multiple tables from a database). Supported:
            .csv, .xlsx, .db/.sqlite. Warehouse connections (BigQuery, Snowflake, …)
            are configured in Settings → Data connection with a tables list.
          </p>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <input type="file" multiple ref={fileRef}
              accept=".csv,.xlsx,.xlsm,.db,.sqlite,.sqlite3"
              style={{ fontSize: 12.5 }} />
            <button className="primary-btn" onClick={doImport} disabled={importing}>
              {importing ? (progress < 90 ? `Uploading ${progress}%` : 'Onboarding…') : 'Import files'}
            </button>
            <button className="chip" onClick={downloadTemplate}>
              ⬇ CSV/Excel template
            </button>
          </div>
          {(importing || progress > 0) && (
            <>
              <div className="progress-track">
                <div className="progress-fill" style={{ width: `${progress}%` }} />
              </div>
              {activity && activity !== 'Done' && (
                <div className="import-activity">
                  <span className="shimmer" style={{ width: 26, height: 7 }} />
                  {activity}
                </div>
              )}
            </>
          )}
          {results && results.some(r => r.ok) && (
            <div className="import-done fade-in">
              <b style={{ fontSize: 12.5 }}>Tables imported:</b>
              {results.filter(r => r.ok).map((r, i) => (
                <span key={i} className="table-done">
                  ✅ {r.table} <em>({r.rows?.toLocaleString?.() ?? r.rows} rows)</em>
                </span>
              ))}
            </div>
          )}
          {onboarding && !onboarding.error && (
            <div className="brain-status ok" style={{ marginTop: 8 }}>
              🧠 Auto-onboarded into the Context Brain:
              {' '}{(onboarding.metrics_added || []).length} metrics,
              {' '}{(onboarding.terms_added || []).length} vocabulary terms
              — queryable NOW in chat (uncertified until reviewed).
              {onboarding.notes?.length > 0 && <> {onboarding.notes.join(' · ')}</>}
            </div>
          )}
          {results && (
            <div style={{ marginTop: 8, fontSize: 12.5 }}>
              {results.map((r, i) => (
                <div key={i} style={{ color: r.ok ? 'var(--good)' : 'var(--bad)' }}>
                  {r.ok
                    ? `✓ ${r.file} → table "${r.table}" (${r.rows.toLocaleString()} rows)`
                    : `✗ ${r.file}: ${r.error}`}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {Object.entries(data.tables).map(([table, t]) => (
        <div key={table} className="card" style={{ marginBottom: 16 }}>
          <h3 style={{ marginBottom: 4 }}>
            {table}
            <span style={{ fontSize: 11, fontWeight: 400, marginLeft: 10,
              color: t.origin === 'imported' ? 'var(--good)' : 'var(--muted)' }}>
              {t.origin}
            </span>
          </h3>
          <span style={{ fontSize: 12, color: 'var(--muted)' }}>
            {t.total_rows.toLocaleString()} rows total — showing first 20
          </span>
          <DataGrid columns={t.columns} rows={t.rows} collapsed={false} />
        </div>
      ))}
    </div>
  )
}
