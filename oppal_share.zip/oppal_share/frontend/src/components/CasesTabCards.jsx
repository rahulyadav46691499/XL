import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// CARD-BASED PROTOTYPE of the Case queue (Sprint: UI direction).
//
// Same data and same endpoints as CasesTab.jsx — this is purely a visual
// re-language: severity is a coloured top border, trust is a ring gauge, the
// dollar impact is the hero number, and triage/propose live on a card footer.
// The original table view is preserved at CasesTab.jsx for side-by-side
// comparison; swap the import in App.jsx to choose.
// pattern -> dual-control action type. 'timeliness_breach' is the payer
// universe-timeliness pattern; 'thermal_excursion' / 'chargeback_over_claim'
// are the pharma cold-chain/chargeback patterns; the six below them are the
// Medicare Sales patterns. Add a domain's patterns here rather than guessing a
// payer-shaped default for them.
//
// This is load-bearing, not cosmetic. Each domain declares its own
// `dual_control_action_types` in policy_rules.md, and the action engine reads
// the proposed action_type against that list to decide whether two signatures
// are required. A sales pattern falling through to the payer default below
// would name an action type the sales rulebook does not list, and the proposal
// would quietly get SINGLE control.
const PATTERN_ACTION_TYPE = {
  timeliness_breach: 'universe_resubmission',
  thermal_excursion: 'quarantine_hold',
  chargeback_over_claim: 'chargeback_recovery',
  lead_quality_collapse: 'lead_source_suspension',
  funnel_fallout: 'campaign_pause',
  agent_effectuation_outlier: 'agent_remediation',
  retention_leakage: 'enrollment_reconciliation',
  compensation_overpayment: 'commission_recovery',
  certification_lapse: 'agent_suspension',
}

export default function CasesTabCards() {
  const [data, setData] = useState(null)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [msg, setMsg] = useState('')

  const load = () => {
    const p = status ? `?status=${encodeURIComponent(status)}` : ''
    fetch(`/api/cases${p}`).then(r => r.json()).then(setData).catch(() => {})
  }
  useEffect(load, [status])

  const proposeAction = async (cse) => {
    setMsg('')
    const r = await fetch('/api/actions/propose', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        case_id: cse.case_id,
        // Each domain declares its own dual-control action types (see
        // policy_rules.md); this maps the finding pattern that opened the
        // case to the matching one. Falls back to the payer default for any
        // pattern not listed here rather than guessing.
        action_type: PATTERN_ACTION_TYPE[cse.pattern] || 'overpayment_recovery',
        summary: `Remediate ${(cse.pattern || '').replace(/_/g, ' ')} for ${cse.subject}`,
        fields: { case_id: cse.case_id, subject: cse.subject,
          amount: cse.estimated_impact }
      })
    })
    const out = await r.json().catch(() => ({}))
    setMsg(r.ok
      ? `Proposed ${out.action_id} (${out.control_mode} control) — review it in the Actions tab`
      : (out.detail || 'Could not propose action'))
  }

  const setCaseStatus = async (id, newStatus) => {
    setMsg('')
    const r = await fetch(`/api/cases/${id}/status`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    })
    if (r.ok) { setMsg(`${id} → ${newStatus}`); load() }
    else {
      const e = await r.json().catch(() => ({}))
      setMsg(e.detail || 'Not permitted')
    }
  }

  if (!data) return <div className="thinking">loading cases…</div>
  const term = q.trim().toLowerCase()
  const cases = (data.cases || []).filter(c =>
    !term || c.case_id.toLowerCase().includes(term) ||
    (c.subject || '').toLowerCase().includes(term) ||
    (c.pattern || '').toLowerCase().includes(term) ||
    (c.detail || '').toLowerCase().includes(term))
  const s = data.summary || {}

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3>📁 Case Queue<InfoDot id="cases.case_table" /></h3>
          <span className="chip">{s.total || 0} in your scope</span>
          <span className="chip">${(s.estimated_impact || 0).toLocaleString()} est. impact</span>
          <div style={{ flex: 1 }} />
          <select className="settings-input" style={{ maxWidth: 150 }}
            value={status} onChange={e => setStatus(e.target.value)}>
            <option value="">All statuses</option>
            {(data.states || []).map(st => <option key={st} value={st}>{st}</option>)}
          </select>
          <input className="settings-input" style={{ maxWidth: 240 }}
            placeholder="Search cases…" value={q}
            onChange={e => setQ(e.target.value)} />
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          Card view (prototype). Severity is the top stripe, trust is the ring,
          dollar impact is the hero figure. Same governed data as the table view.
        </p>
        {msg && <div className="brain-status ok" style={{ marginTop: 8 }}>{msg}</div>}
      </div>

      {cases.length === 0 && (
        <div className="card"><p style={{ color: 'var(--muted)' }}>
          No cases {q ? `match “${q}”` : 'yet — run the swarm to open cases'}.
        </p></div>
      )}

      <div className="cases-cards">
        {cases.map(c => {
          const sev = (c.severity || 'low').toLowerCase()
          const pct = Math.round((c.trust_score || 0) * 100)
          return (
            <div key={c.case_id} className="case-card">
              <div className={`case-card-top sev-${sev}`} />
              <div className="case-card-body">
                <div className="case-card-head">
                  <span className="case-card-id">{c.case_id}</span>
                  <span className="chip" style={{
                    color: (sev === 'critical' || sev === 'high')
                      ? 'var(--bad)' : sev === 'medium' ? 'var(--warn)' : 'var(--muted)'
                  }}>{c.severity}</span>
                </div>
                <div className="case-card-subject">{c.subject}</div>
                <div className="case-card-meta">
                  <span className="chip">{c.case_type}</span>
                  <span className="chip">{(c.pattern || '').replace(/_/g, ' ')}</span>
                  <span className={`chip ${c.status === 'open' ? 'chip-on' : ''}`}>
                    {c.status}</span>
                </div>
                {c.estimated_impact ? (
                  <div className="case-card-impact">
                    ${Math.round(c.estimated_impact).toLocaleString()}
                    {' '}<small>est. impact</small>
                  </div>
                ) : null}
              </div>
              <div className="case-card-foot">
                <span className="case-trust-ring" data-pct={`${pct}%`}
                  style={{ '--pct': pct }} title={`Trust ${pct}%`} />
                <select className="settings-input" style={{ flex: 1, fontSize: 11 }}
                  value={c.status}
                  onChange={e => setCaseStatus(c.case_id, e.target.value)}>
                  {(data.states || []).map(st => <option key={st} value={st}>{st}</option>)}
                </select>
                <button className="chip" style={{ fontSize: 11 }}
                  onClick={() => proposeAction(c)}>propose ▸</button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
