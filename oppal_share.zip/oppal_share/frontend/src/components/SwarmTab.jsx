import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Phase 3 — departmental agent swarm. Sentry triages the question and only
// the relevant departments activate; findings land on a shared blackboard.
export default function SwarmTab() {
  const [roster, setRoster] = useState(null)
  // Starts empty and is seeded from the Brain below. The literal that used to
  // live here was the payer's question, so a Medicare Sales analyst opened the
  // tab invited to investigate provider upcoding -- a question this domain has
  // no tables for.
  const [q, setQ] = useState('')
  const [touched, setTouched] = useState(false)
  const [run, setRun] = useState(null)
  const [busy, setBusy] = useState(false)
  const [filter, setFilter] = useState('')

  useEffect(() => {
    fetch('/api/swarm/roster').then(r => r.json()).then(d => {
      setRoster(d)
      // Seed only until the analyst types: re-seeding over their own question
      // on a domain switch would be worse than a stale placeholder.
      const ex = d?.settings?.example_question
      if (ex && !touched) setQ(ex)
    }).catch(() => {})
  }, [])

  const investigate = async () => {
    setBusy(true); setRun(null)
    try {
      const r = await fetch('/api/swarm', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q })
      })
      setRun(await r.json())
    } catch { /* degrade silently */ }
    setBusy(false)
  }

  const term = filter.trim().toLowerCase()
  const findings = (run?.findings || []).filter(f =>
    !term || f.agent.toLowerCase().includes(term) ||
    f.headline.toLowerCase().includes(term) ||
    (f.severity || '').toLowerCase().includes(term))
  const active = new Set(run?.activated || [])
  const sevColor = s => s === 'critical' ? 'var(--bad)' : s === 'high'
    ? 'var(--accent)' : 'var(--muted)'
  const sevClass = s => s === 'critical' ? 'bad' : s === 'high' ? 'warn' : ''

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <h3>🛰️ Departmental Swarm<InfoDot id="swarm.agent_roster_chips" /></h3>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 8px' }}>
          The Sentry agent triages your question and activates only the relevant
          departments — typically 2–4 of {roster?.agents?.length || 10} — keeping
          each investigation fast and inexpensive.
        </p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <input className="settings-input" style={{ flex: 1, minWidth: 260 }}
            value={q}
            onChange={e => { setTouched(true); setQ(e.target.value) }}
            onKeyDown={e => e.key === 'Enter' && investigate()}
            placeholder="Ask an operational question…" />
          <button className="primary-btn" onClick={investigate} disabled={busy}>
            {busy ? 'Investigating…' : '🛰️ Run swarm'}
          </button>
        </div>
      </div>

      {roster && (
        <div className="card" style={{ marginBottom: 12 }}>
          <b style={{ fontSize: 13 }}>Roster</b>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
            {roster.agents.map(a => (
              <span key={a.name}
                className={`chip ${active.has(a.name) ? 'chip-on' : ''}`}
                title={`${a.department} — ${a.role}`}>
                {active.has(a.name) ? '● ' : '○ '}{a.name.replace(/_/g, ' ')}
              </span>
            ))}
          </div>
          {run && (
            <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>
              Activated {run.activated?.length || 0} of {roster.agents.length}
              {' '}· trust {(run.trust * 100).toFixed(0)}%
              {' '}· gate {run.gate_passed ? '✅ passed' : '⛔ below'}
              {' '}· {run.ms} ms
            </div>
          )}
        </div>
      )}

      {run && (
        <>
          <div className="card" style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <b style={{ fontSize: 13 }}>Findings <span className="sidebar-count">{findings.length}</span></b>
              <div style={{ flex: 1 }} />
              <input className="settings-input" style={{ maxWidth: 240 }}
                placeholder="Search findings…" value={filter}
                onChange={e => setFilter(e.target.value)} />
            </div>
            <p style={{ fontSize: 12.5, marginTop: 6 }}>{run.summary}</p>
            {/* Findings as cards: each one is a short narrative (headline +
                detail + dollar impact) from a named department, which reads
                far better as a unit than as a four-column row. The severity
                stripe gives triage-at-a-glance without relying on colour
                alone — the severity word is still printed. */}
            <div className="ui-cards" style={{ marginTop: 8 }}>
              {findings.map((f, i) => (
                <div key={i} className="ui-card"
                  style={{ animationDelay: `${0.04 * (i + 1)}s` }}>
                  <div className={`ui-card-bar ${sevClass(f.severity)}`} />
                  <div className="ui-card-head">
                    <span className="ui-card-title">{f.headline}</span>
                    <span className="chip" style={{ color: sevColor(f.severity),
                      fontSize: 10 }}>{f.severity}</span>
                  </div>
                  <div className="ui-card-meta">
                    🛰 {f.agent.replace(/_/g, ' ')}
                  </div>
                  {f.detail && (
                    <div style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 6 }}>
                      {f.detail}
                    </div>
                  )}
                  {f.impact ? (
                    <div className="ui-card-kv">
                      <div><span>est. impact</span>
                        <b>${f.impact.toLocaleString()}</b></div>
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
            {findings.length === 0 && (
              <div className="ui-empty">No findings match.</div>
            )}
            {run.cases_created?.length > 0 && (
              <div className="brain-status ok" style={{ marginTop: 8 }}>
                📁 {run.cases_created.length} case(s) opened/updated: {run.cases_created.join(', ')}
                {' '}— review them in the Cases tab.
              </div>
            )}
          </div>

          <div className="card">
            <b style={{ fontSize: 13 }}>Swarm flow (StateGraph)</b>
            <ol style={{ fontSize: 12, color: 'var(--muted)', marginTop: 6 }}>
              {(run.flow || []).map((s, i) => <li key={i}>{s.replace(/^\d+\.\s*/, '')}</li>)}
            </ol>
          </div>
        </>
      )}
    </div>
  )
}
