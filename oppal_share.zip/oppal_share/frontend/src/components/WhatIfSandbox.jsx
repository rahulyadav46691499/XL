import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Phase 5 — Actuarial "What-If" Simulator (REQ-5.1–5.5). Every simulation
// runs in an isolated Brain fork on the server; nothing here ever touches
// the live Context Brain or the warehouse. Props are optional — the
// component is fully self-sufficient (fetches formulas/scope and calls the
// API itself) when used as a plain tab, but accepts the TDD's contract
// (onRun/onPromote/formulas/scope) so it can be driven/tested externally.
const OPS = ['set', 'delta_abs', 'delta_pct', 'tier_shift']
const OP_LABEL = { set: 'set to', delta_abs: 'add', delta_pct: 'shift by %',
  tier_shift: 'tier shift %' }

function blankOverride() {
  return { brain_path: '', op: 'delta_pct', value: '', reason: '' }
}

export default function WhatIfSandbox({ scope, formulas, onRun, onPromote,
  initialOverrides, busy: busyProp }) {
  const [myScope, setMyScope] = useState(scope || null)
  const [myFormulas, setMyFormulas] = useState(formulas || null)
  const [baselineQuery, setBaselineQuery] = useState(
    'members with raf score above 1.2')
  const [overrides, setOverrides] = useState(
    initialOverrides && initialOverrides.length ? initialOverrides
      : [blankOverride()])
  const [result, setResult] = useState(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [note, setNote] = useState('')
  const [promoted, setPromoted] = useState(null)
  const [showProvenance, setShowProvenance] = useState(false)
  const [pinned, setPinned] = useState(false)

  useEffect(() => {
    if (!scope) fetch('/api/me').then(r => r.json())
      .then(m => setMyScope({ allowed_lobs: m.allowed_lobs || [],
        full_scope: (m.allowed_lobs || []).length > 1 })).catch(() => {})
  }, [scope])
  useEffect(() => {
    if (!formulas) fetch('/api/sim/formulas').then(r => r.json())
      .then(d => setMyFormulas(d.formulas || [])).catch(() => {})
  }, [formulas])

  const effScope = scope || myScope
  const effFormulas = formulas || myFormulas || []

  const defaultRun = async (req) => {
    const r = await fetch('/api/sim/run', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req)
    })
    const out = await r.json().catch(() => ({}))
    if (!r.ok) throw new Error(out.detail?.detail || out.detail ||
      'simulation failed')
    return out
  }
  const defaultPromote = async (runId, noteText) => {
    const r = await fetch(`/api/sim/${runId}/promote`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note: noteText })
    })
    const out = await r.json().catch(() => ({}))
    if (!r.ok) throw new Error(out.detail || 'promotion failed')
    return out
  }

  const pinToWorkspace = async () => {
    if (!result) return
    setBusy(true); setErr('')
    try {
      const list = await fetch('/api/workspace').then(r => r.json())
      let wsId = list.dashboards?.[0]?.id
      if (!wsId) {
        const created = await fetch('/api/workspace', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: 'Simulations' })
        }).then(r => r.json())
        wsId = created.id
      }
      await fetch(`/api/workspace/${wsId}/pin`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'simulation',
          spec: { run_id: result.run_id, mlr_delta_bps: result.mlr_delta_bps,
            net_dollar_impact: result.net_dollar_impact },
          lineage_ref: result.lineage_ref })
      })
      setPinned(true)
    } catch (e) {
      setErr(e.message || 'pin failed')
    }
    setBusy(false)
  }

  const run = async () => {
    setBusy(true); setErr(''); setResult(null); setPromoted(null); setPinned(false)
    try {
      const req = {
        baseline_query: baselineQuery,
        parameter_overrides: overrides
          .filter(o => o.brain_path.trim())
          .map(o => ({ ...o, value: o.value === '' ? '0' : o.value }))
      }
      const out = await (onRun ? onRun(req) : defaultRun(req))
      setResult(out)
    } catch (e) {
      setErr(e.message || 'simulation failed')
    }
    setBusy(false)
  }

  const promote = async () => {
    if (!result) return
    setBusy(true); setErr('')
    try {
      const action = await (onPromote ? onPromote(result.run_id, note)
        : defaultPromote(result.run_id, note))
      setPromoted(action)
    } catch (e) {
      setErr(e.message || 'promotion failed')
    }
    setBusy(false)
  }

  const setOv = (i, patch) => setOverrides(ovs =>
    ovs.map((o, j) => j === i ? { ...o, ...patch } : o))
  const addOv = () => setOverrides(ovs => [...ovs, blankOverride()])
  const rmOv = (i) => setOverrides(ovs => ovs.filter((_, j) => j !== i))

  const money = n => `${(n < 0 ? '-$' : '$')}${Math.abs(Math.round(n || 0))
    .toLocaleString()}`
  const isBusy = busy || busyProp

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3>🧮 What-If Simulator<InfoDot id="simulator.override_row" /></h3>
          {effScope && (
            <span className="chip" title="Every simulation runs strictly within your authorized scope">
              🛡 {effScope.full_scope ? 'full scope' :
                (effScope.allowed_lobs || []).join(', ') || 'no scope'}
            </span>
          )}
          <span className="chip">isolated Brain fork · zero-copy read-only</span>
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          Describe a cohort, add parameter overrides, and run a baseline-vs-
          simulated comparison. Nothing here writes anything — promoting a
          result only queues a dual-control action for human review.
        </p>
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <label style={{ fontSize: 12.5, fontWeight: 600 }}>Baseline cohort (natural language)</label>
        <input className="settings-input" style={{ width: '100%', marginTop: 4 }}
          value={baselineQuery} onChange={e => setBaselineQuery(e.target.value)}
          placeholder="e.g. members with raf score above 1.2" />

        <div style={{ marginTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <label style={{ fontSize: 12.5, fontWeight: 600 }}>Parameter overrides (applied to a forked Brain only)</label>
          <button className="chip" onClick={addOv}>＋ add override</button>
        </div>
        {overrides.map((o, i) => (
          <div key={i} style={{ display: 'flex', gap: 6, marginTop: 6, flexWrap: 'wrap', alignItems: 'center' }}>
            <input className="settings-input" style={{ flex: 2, minWidth: 200 }}
              placeholder="brain_path e.g. metrics.pharmacy_cost.stress_pct"
              value={o.brain_path} onChange={e => setOv(i, { brain_path: e.target.value })} />
            <select className="settings-input" style={{ maxWidth: 150 }}
              value={o.op} onChange={e => setOv(i, { op: e.target.value })}>
              {OPS.map(op => <option key={op} value={op}>{OP_LABEL[op]}</option>)}
            </select>
            <input className="settings-input" style={{ maxWidth: 110 }}
              placeholder="value (e.g. -0.05)" value={o.value}
              onChange={e => setOv(i, { value: e.target.value })} />
            <input className="settings-input" style={{ flex: 1, minWidth: 140 }}
              placeholder="reason (optional)" value={o.reason}
              onChange={e => setOv(i, { reason: e.target.value })} />
            <button className="linkbtn" onClick={() => rmOv(i)}>remove</button>
          </div>
        ))}

        <div style={{ marginTop: 10 }}>
          <button className="primary-btn" disabled={isBusy || !baselineQuery.trim()}
            onClick={run}>{isBusy ? 'Running…' : '▶ Run simulation'}</button>
        </div>
        {err && <div className="brain-status" style={{ marginTop: 8, color: 'var(--bad)' }}>{err}</div>}
      </div>

      {result && (
        <div className="card rise-in">
          <div style={{ display: 'flex', gap: 8, alignItems: 'baseline', flexWrap: 'wrap' }}>
            <b>Run {result.run_id}</b>
            <span className="chip" style={{
              color: result.trust_gate_passed ? 'var(--good)' : 'var(--bad)'
            }}>
              trust {Math.round((result.trust_score || 0) * 100)}%
              {result.trust_gate_passed ? ' ✓ gate cleared' : ' ⛔ below gate'}
            </span>
            {result.truncated && <span className="chip">rows truncated</span>}
            <span className="chip">{result.warehouse_ms?.toFixed?.(0) ?? result.warehouse_ms} ms</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10, marginTop: 10 }}>
            {(result.metrics || []).map(m => (
              <div key={m.metric} className="card" style={{ padding: 10, margin: 0 }}>
                <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>{m.metric.replace(/_/g, ' ')}</div>
                <div style={{ fontSize: 13.5, marginTop: 4 }}>
                  baseline: <b>{m.unit === 'usd' ? money(m.baseline) : String(m.baseline)}</b>
                </div>
                <div style={{ fontSize: 13.5 }}>
                  simulated: <b style={{ color: m.direction === 'favorable' ? 'var(--good)' : m.direction === 'adverse' ? 'var(--bad)' : 'var(--ink)' }}>
                    {m.unit === 'usd' ? money(m.simulated) : String(m.simulated)}
                  </b>
                </div>
                <div style={{ fontSize: 11, color: 'var(--muted)' }}>Δ {String(m.delta)} {m.unit}</div>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 16, marginTop: 10, flexWrap: 'wrap', fontSize: 12.5 }}>
            <span>MLR Δ <b style={{ color: result.mlr_delta_bps <= 0 ? 'var(--good)' : 'var(--bad)' }}>
              {result.mlr_delta_bps} bps</b></span>
            <span>Net $ impact <b>{money(result.net_dollar_impact)}</b></span>
            <span>Admin burden Δ <b>{String(result.admin_burden_delta)} min</b></span>
            <span>Affected members <b>{result.affected_member_count}</b></span>
          </div>

          <button className="linkbtn" style={{ marginTop: 8 }}
            onClick={() => setShowProvenance(v => !v)}>
            {showProvenance ? '▾' : '▸'} formula provenance (NFR-1)
          </button>
          {showProvenance && (
            <div style={{ background: 'var(--panel)', borderRadius: 6, padding: 8, marginTop: 4, fontSize: 11.5 }}>
              Every number above is derived from these Brain formula ids —
              editing simulation.md changes the output with no code change:
              <ul style={{ margin: '4px 0 0 16px' }}>
                {(result.formula_ids_used || []).map(f => <li key={f}><code>{f}</code></li>)}
              </ul>
            </div>
          )}

          <div style={{ display: 'flex', gap: 8, marginTop: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <button className="chip" disabled={isBusy || pinned} onClick={pinToWorkspace}>
              {pinned ? '📌 Pinned' : '📌 Pin to Workspace'}
            </button>
            <input className="settings-input" style={{ flex: 1, minWidth: 220 }}
              placeholder="Promotion note (optional)" value={note}
              onChange={e => setNote(e.target.value)} />
            <button className="primary-btn" disabled={isBusy || !result.trust_gate_passed || !!promoted}
              title={result.trust_gate_passed
                ? 'Queue this simulation as a dual-control action for human review'
                : 'Blocked: trust score is below the execution gate'}
              onClick={promote}>
              {promoted ? '✓ Promoted' : result.trust_gate_passed
                ? '📤 Promote to Action Queue' : '⛔ Below trust gate'}
            </button>
          </div>
          {promoted && (
            <div className="brain-status ok" style={{ marginTop: 8 }}>
              Queued as {promoted.action_id} ({promoted.control_mode} control,
              {' '}{promoted.state}) — review it in the Actions tab.
            </div>
          )}
        </div>
      )}

      {effFormulas.length > 0 && (
        <div className="card" style={{ marginTop: 12 }}>
          <button className="linkbtn" onClick={() => setShowProvenance(v => !v)}>
            📖 Brain-declared simulation formulas ({effFormulas.length})
          </button>
        </div>
      )}
    </div>
  )
}
