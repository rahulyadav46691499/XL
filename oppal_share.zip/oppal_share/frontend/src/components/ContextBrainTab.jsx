import React, { useEffect, useRef, useState } from 'react'
import InfoDot from './InfoDot.jsx'
import BrainEditQueue from './BrainEditQueue.jsx'

const FILE_LABELS = {
  'domain.md': '🪪 Domain', 'entities.md': '🗂 Entities & joins',
  'metrics.md': '📐 Governed metrics', 'vocabulary.md': '🗣 Vocabulary',
  'reference.md': '📚 Reference (drugs, codes, docs)',
  'policy_rules.md': '⚖️ Policy rulebook', 'prompts.md': '💬 Agent prompts',
}

// One label per file, used EVERYWHERE the file is named — tab chips, search
// results, status messages. Search results previously printed the raw
// "metrics.md" while the chip beside them said "Governed metrics", so the
// same thing had two names on one screen. The filename stays in a tooltip
// for anyone who needs it.
const fileLabel = (f) => (FILE_LABELS[f] || f)
// Label without the leading emoji — for running text, where the icon adds noise.
const fileName = (f) => fileLabel(f).replace(/^\S+\s/, '')

// Context Brain: domains as clickable cards, knowledge as editable
// Markdown. Save & Reload re-parses and rebuilds the whole engine —
// zero domain knowledge is hard-coded.
export default function ContextBrainTab() {
  const [domains, setDomains] = useState([])
  const [sel, setSel] = useState(null)          // selected domain id
  const [file, setFile] = useState('metrics.md')
  const [content, setContent] = useState('')
  const [dirty, setDirty] = useState(false)
  const [status, setStatus] = useState(null)
  const [bq, setBq] = useState('')
  const [bres, setBres] = useState(null)
  const [versions, setVersions] = useState([])
  const [showVersions, setShowVersions] = useState(false)
  const [queueKey, setQueueKey] = useState(0)   // remounts the approval queue
  const [highlight, setHighlight] = useState(true)
  const [domainsOpen, setDomainsOpen] = useState(false)   // collapsed by default
  const [canWrite, setCanWrite] = useState(true)          // brain_write held?
  // Jump-to-line. A search hit reports file:line, but clicking it used to only
  // switch files and drop you at the top — fine for a 40-line file, useless
  // for policy_rules.md. `jump` survives until the target file's content has
  // actually loaded, then the effect below scrolls to it.
  const [jump, setJump] = useState(null)        // 1-based line number
  const taRef = useRef(null)                    // <textarea> (edit mode)
  const hlRef = useRef(null)                    // highlight view (read mode)
  const gutRef = useRef(null)                   // line-number gutter

  const lineCount = content ? content.split('\n').length : 1

  // Keep the gutter aligned with whichever pane is scrolling.
  const syncGutter = (e) => {
    if (gutRef.current) gutRef.current.scrollTop = e.currentTarget.scrollTop
  }

  useEffect(() => {
    if (!jump || !content) return
    const line = Math.max(1, Math.min(jump, lineCount))
    const el = highlight ? hlRef.current : taRef.current
    if (!el) return
    if (highlight) {
      const row = el.querySelector(`[data-line="${line}"]`)
      if (row) row.scrollIntoView({ block: 'center', behavior: 'smooth' })
    } else {
      // Put the caret on the line and select it — the browser scrolls to the
      // selection and highlights it natively, which is clearer than a
      // computed scrollTop that drifts when lines wrap.
      const lines = content.split('\n')
      const start = lines.slice(0, line - 1).join('\n').length
                    + (line > 1 ? 1 : 0)
      el.focus()
      el.setSelectionRange(start, start + lines[line - 1].length)
      const approx = (el.scrollHeight / lineCount) * (line - 1)
      el.scrollTop = Math.max(0, approx - el.clientHeight / 2)
    }
    if (gutRef.current && el) gutRef.current.scrollTop = el.scrollTop
    // Clear AFTER the scroll so re-renders don't re-trigger it.
    const t = setTimeout(() => setJump(null), 1200)
    return () => clearTimeout(t)
  }, [jump, content, highlight, lineCount])

  const loadVersions = (d) =>
    fetch(`/api/brain/${d}/versions`).then(r => r.json())
      .then(x => setVersions(x.versions || [])).catch(() => {})

  const revert = async (versionId, label) => {
    if (!window.confirm(`Revert the Brain to "${label}"? A safety snapshot of the current state is taken first.`)) return
    setStatus({ kind: 'busy', msg: 'Rolling back & rebuilding…' })
    const r = await fetch(`/api/brain/${sel}/rollback`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ version: versionId })
    })
    const out = await r.json()
    setStatus(out.ok
      ? { kind: 'ok', msg: `⏪ Reverted to ${label} — ${out.report}` }
      : { kind: 'err', msg: out.error || 'rollback failed' })
    if (out.ok) {
      loadVersions(sel)
      fetch(`/api/brain/${sel}/${file}`).then(r => r.json())
        .then(d => { setContent(d.content || ''); setDirty(false) })
    }
  }

  const brainSearch = async (query) => {
    setBq(query)
    if (!query.trim() || !sel) { setBres(null); return }
    const r = await fetch(`/api/brain/${sel}/search/${encodeURIComponent(query)}`)
    const out = await r.json()
    setBres(out.results || [])
  }

  const load = () =>
    fetch('/api/brain/domains').then(r => r.json())
      .then(d => {
        setDomains(d.domains || [])
        setCanWrite(d.can_write !== false)
        if (!sel) setSel((d.domains || []).find(x => x.active)?.id)
      }).catch(() => {})
  useEffect(() => { load() }, [])

  useEffect(() => {
    if (!sel) return
    fetch(`/api/brain/${sel}/${file}`).then(r => r.json())
      .then(d => { setContent(d.content || ''); setDirty(false) })
      .catch(() => {})
    loadVersions(sel)
  }, [sel, file])

  const save = async () => {
    setStatus({ kind: 'busy', msg: 'Saving & validating…' })
    const r = await fetch(`/api/brain/${sel}/${file}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content })
    })
    // Parse defensively: a 403 carries `detail`, not `errors`, and a server
    // error may not be JSON at all. Both used to end in an empty (or never
    // shown) message, so the user believed an unsaved edit had been saved.
    const out = await r.json().catch(() => ({}))
    // A protected control-key edit does not save — it is parked for
    // maker-checker approval. That is a successful outcome, not an error, and
    // reporting it as a failure would train officers to ignore the message.
    if (out.requires_dual_control) {
      const keys = (out.protected_changes || []).map(c => c.key).join(', ')
      setStatus({ kind: 'warn',
        msg: `Parked for approval as ${out.edit_id} — changes ${keys}. `
           + 'Two distinct compliance officers must approve before this takes '
           + 'effect. See the approval queue above.' })
      setDirty(false)
      setQueueKey(k => k + 1)
      return
    }
    if (!out.saved) {
      setStatus({ kind: 'err', msg: 'Not saved — '
        + ((out.errors || []).join('; ') || out.detail || `HTTP ${r.status}`) })
      return
    }
    setDirty(false)
    setStatus({ kind: 'busy', msg: 'Reloading Brain…' })
    const r2 = await fetch('/api/brain/activate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: sel })
    })
    const rep = await r2.json()
    setStatus({
      kind: rep.errors?.length ? 'warn' : 'ok',
      msg: `Brain live — ${rep.report}`
    })
    load()
  }

  const activate = async (id) => {
    setSel(id)
    setStatus({ kind: 'busy', msg: 'Activating domain…' })
    const r = await fetch('/api/brain/activate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: id })
    })
    const rep = await r.json()
    setStatus({ kind: rep.errors?.length ? 'warn' : 'ok',
                msg: `Active: ${rep.name} — ${rep.report}` })
    load()
    // The RBAC badge row (App.jsx) fetches /api/me once, keyed on [session] --
    // it has no reason to know a domain switch happened here. Without this,
    // "authorized LOBs" kept showing the PREVIOUS domain's values until a
    // full page reload re-ran that fetch. Same event pattern already used
    // for workspace pins (oppal-workspace-changed): fire, don't prop-drill.
    window.dispatchEvent(new Event('oppal-domain-changed'))
  }

  const selected = domains.find(d => d.id === sel)
  // What the collapsed header reports. Prefer the domain the ENGINE says is
  // live over the one merely selected in this tab — if those ever diverge,
  // showing the selection would misreport which knowledge is answering
  // questions, which is the one thing this line exists to tell you.
  const activeDomain = domains.find(d => d.active) || selected

  return (
    <div className="fade-in">
      <BrainEditQueue key={queueKey} onApplied={() => { load(); setQueueKey(k => k + 1) }} />
      {/* Domain picker, COLLAPSED by default. Switching domain is a rare
          act — most sessions use one — while editing the knowledge below is
          the constant. Left expanded, the cards pushed the editor (the actual
          work surface) down the page on every visit. Collapsed, the header
          still answers "which domain am I in?" without being opened. */}
      <div className="card" style={{ marginBottom: 16 }}>
        <button className="brain-domains-toggle"
          aria-expanded={domainsOpen}
          onClick={() => setDomainsOpen(o => !o)}
          title={domainsOpen ? 'Collapse domains' : 'Choose a different domain'}>
          <span className="nav-caret">{domainsOpen ? '▾' : '▸'}</span>
          <h3 style={{ margin: 0 }}>🧠 Context Brain — domains</h3>
          {/* The collapsed summary: which domain is live, right here. */}
          {activeDomain && (
            <span className="brain-domain-pill">
              <span className="brain-icon">{activeDomain.icon}</span>
              <b>{activeDomain.name}</b>
              <span className="brain-live">● ACTIVE</span>
            </span>
          )}
          {!domainsOpen && domains.length > 1 && (
            <span className="brain-domains-more">
              {domains.length - 1} other{domains.length === 2 ? '' : 's'}
            </span>
          )}
          <InfoDot id="context_brain.save_reload_brain_button" />
        </button>

        {domainsOpen && (<div className="fade-in">
          <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '8px 0 12px' }}>
            Everything the engine knows lives here as editable Markdown: entities,
            metric formulas, vocabulary, drug/formulary reference, the CMS rulebook
            and every agent prompt. Click a domain to activate it; edit any file and
            <b> Save &amp; Reload</b> — the knowledge graph and agents rebuild live,
            with zero code changes.
          </p>
          <div className="brain-domains">
            {domains.map(d => (
              <button key={d.id}
                className={`brain-domain ${d.active ? 'active' : ''}`}
                onClick={() => { activate(d.id); setDomainsOpen(false) }}>
                <span className="brain-icon">{d.icon}</span>
                <b>{d.name}</b>
                <span className="brain-desc">{d.description}</span>
                {d.active && <span className="brain-live">● ACTIVE</span>}
              </button>
            ))}
          </div>
        </div>)}
      </div>

      {selected && (
        <div className="card">
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <h3>{selected.icon} {selected.name} — knowledge files</h3>
            <div style={{ flex: 1 }} />
            <button className="chip" onClick={() => setShowVersions(v => !v)}>
              🕘 Versions ({versions.length})
            </button>
            <button className="primary-btn" onClick={() => save()}
              disabled={!dirty || !canWrite}>
              {!canWrite ? '🔒 Read-only' : dirty ? '💾 Save & Reload Brain' : 'Saved'}
            </button>
          </div>
          {!canWrite && (
            <div className="brain-status warn">
              Your role can view the Context Brain but not edit it — ask a
              compliance officer to make changes.
            </div>
          )}
          {showVersions && (
            <div className="panel fade-in" style={{ maxHeight: 220, overflow: 'auto' }}>
              <b>Brain versions — every change is snapshotted first</b>
              {versions.map(v => (
                <div key={v.id} style={{ display: 'flex', gap: 10, alignItems: 'center',
                  padding: '5px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{v.ts}</span>
                  <span style={{ flex: 1 }}>
                    {v.original ? '🏷 ORIGINAL (pristine baseline)' : v.label}
                  </span>
                  <button className="chip"
                    style={v.original ? { borderColor: 'var(--good)', color: 'var(--good)' } : {}}
                    onClick={() => revert(v.id, v.original ? 'original' : v.label)}>
                    ⏪ Revert
                  </button>
                </div>
              ))}
              {versions.length === 0 && <div style={{ color: 'var(--muted)' }}>No versions yet.</div>}
            </div>
          )}
          <input className="settings-input" style={{ width: '100%', margin: '10px 0 4px' }}
            placeholder="🔍 Search this domain's knowledge — e.g. 'medicaid', '0.60', 'reject', 'MLR'…"
            value={bq} onChange={e => brainSearch(e.target.value)} />
          {bres && (
            <div className="panel" style={{ maxHeight: 180, overflow: 'auto' }}>
              {bres.length === 0 && <span style={{ color: 'var(--muted)' }}>No matches.</span>}
              {bres.map((r, i) => (
                <div key={i} className="brain-hit"
                  title={`Open ${r.file} at line ${r.line}`}
                  onClick={() => {
                    // Switch file AND remember where to land. Clearing the
                    // query used to be the whole action, which left the user
                    // at line 1 of a 300-line rulebook.
                    setFile(r.file)
                    setJump(Number(r.line) || 1)
                    setBres(null); setBq('')
                  }}>
                  <b style={{ color: 'var(--accent)' }}>
                    {fileName(r.file)}
                  </b>
                  <span className="brain-hit-line">line {r.line}</span>{' '}
                  <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 11.5 }}>{r.text}</span>
                </div>
              ))}
            </div>
          )}
          <div className="brain-files">
            {(selected.files || []).map(f => (
              <button key={f} className={`chip ${file === f ? 'chip-on' : ''}`}
                onClick={() => setFile(f)}>
                {FILE_LABELS[f] || f}{file === f && dirty ? ' *' : ''}
              </button>
            ))}
          </div>
          <label style={{ fontSize: 12, color: 'var(--muted)', display: 'flex', gap: 6, alignItems: 'center', margin: '4px 0' }}>
            <input type="checkbox" checked={highlight}
              onChange={e => setHighlight(e.target.checked)} />
            Highlight view — <span className="hl-auto-sample">auto-onboarded entries</span> shown in green, <span className="hl-uncert-sample">uncertified flags</span> in amber (read-only; untick to edit)
          </label>
          {/* Gutter + pane share one scroll position. The gutter is its own
              element rather than pseudo-content so it works for BOTH the
              read-only highlight view and the textarea, which cannot render
              children. */}
          <div className="brain-editor-wrap">
            <div className="brain-gutter" ref={gutRef} aria-hidden="true">
              {Array.from({ length: lineCount }, (_, i) => (
                <div key={i}
                  className={jump === i + 1 ? 'gut-jump' : undefined}>{i + 1}</div>
              ))}
            </div>
            {highlight ? (
              <div className="brain-editor brain-highlight" ref={hlRef}
                onScroll={syncGutter}
                onClick={() => setHighlight(false)}
                title="Click to switch to edit mode">
                {content.split('\n').map((line, i) => (
                  <div key={i} data-line={i + 1} className={[
                    /auto-onboard|auto-onboarding/i.test(line) ? 'hl-auto'
                      : /certified:\s*false/i.test(line) ? 'hl-uncert' : '',
                    jump === i + 1 ? 'hl-jump' : '',
                  ].filter(Boolean).join(' ') || undefined}
                  >{line || '\u00A0'}</div>
                ))}
              </div>
            ) : (
              <textarea className="brain-editor" spellCheck={false}
                ref={taRef} onScroll={syncGutter}
                readOnly={!canWrite}
                value={content}
                onChange={e => { setContent(e.target.value); setDirty(true) }} />
            )}
          </div>
          <div className="brain-editor-meta">
            {lineCount} line{lineCount === 1 ? '' : 's'} \u00B7 {fileName(file)}
            <span style={{ color: 'var(--muted)' }}> ({file})</span>
          </div>
          {status && (
            <div className={`brain-status ${status.kind}`}>{status.msg}</div>
          )}
          <p style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 6 }}>
            Format: headings define items (### metric_id), bullets define fields
            (- formula: …). The reload report validates what was parsed before
            the knowledge goes live.
          </p>
        </div>
      )}
    </div>
  )
}
