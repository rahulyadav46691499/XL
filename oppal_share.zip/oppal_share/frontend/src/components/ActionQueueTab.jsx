import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Phase 4 — HITL action queue. Shows the AI's proposed action, its estimated
// financial / regulatory impact, the trust score, and an expandable compliance
// logic tree. Execution is double-gated: the button only activates when the
// action is APPROVED and its trust score clears the gate.
const STATE_TONE = {
  PROPOSED: 'var(--muted)',
  PENDING_FIRST_APPROVAL: 'var(--accent)',
  PENDING_SECOND_APPROVAL: 'var(--accent)',
  APPROVED: 'var(--good)',
  EXECUTED: 'var(--good)',
  REJECTED: 'var(--bad)',
  FAILED: 'var(--bad)',
  PENDING_COMPENSATION: 'var(--accent)',
  COMPENSATED: 'var(--muted)',
}

// Phase 6 — hash-chain status banner. Any authenticated user can check;
// export is compliance_officer-only server-side (this is cosmetic gating).
function LedgerBanner() {
  const [v, setV] = useState(null)
  const [busy, setBusy] = useState(false)
  const check = () => fetch('/api/ledger/verify').then(r => r.json())
    .then(setV).catch(() => {})
  useEffect(check, [])
  const exportLedger = async () => {
    setBusy(true)
    try {
      const today = new Date().toISOString().slice(0, 10)
      const r = await fetch('/api/ledger/export', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date_from: '2020-01-01', date_to: today,
          fmt: 'jsonl' })
      })
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail
        || 'export refused')
      const blob = await r.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url; a.download = 'ledger_export.jsonl'; a.click()
      URL.revokeObjectURL(url)
    } catch (e) { window.alert(e.message || 'export failed') }
    setBusy(false)
  }
  if (!v) return null
  return (
    <div className="card" style={{ marginBottom: 12, display: 'flex',
      gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
      <span className="chip" style={{ color: v.ok ? 'var(--good)' : 'var(--bad)' }}>
        {v.ok ? '🔗 hash chain intact' : `🚨 chain broken at seq ${v.first_broken_seq}`}
      </span>
      <span className="chip">{v.checked} blocks checked · head seq {v.head_seq}</span>
      <div style={{ flex: 1 }} />
      <button className="chip" onClick={check}>↻ re-verify</button>
      <button className="chip" disabled={busy} onClick={exportLedger}>⬇ export (auditor)</button>
    </div>
  )
}

function LogicTree({ node, depth = 0 }) {
  if (node === null || node === undefined) return null
  if (typeof node !== 'object') {
    return <span style={{ color: 'var(--ink)' }}>{String(node)}</span>
  }
  const entries = Array.isArray(node)
    ? node.map((v, i) => [String(i + 1), v])
    : Object.entries(node)
  return (
    <ul style={{ margin: '2px 0 2px 12px', paddingLeft: 10, fontSize: 11.5,
      borderLeft: '1px solid var(--border)' }}>
      {entries.map(([k, v]) => (
        <li key={k} style={{ margin: '2px 0' }}>
          <span style={{ color: 'var(--muted)' }}>{k.replace(/_/g, ' ')}: </span>
          {typeof v === 'object' && v !== null
            ? <LogicTree node={v} depth={depth + 1} />
            : <span>{String(v)}</span>}
        </li>
      ))}
    </ul>
  )
}

export default function ActionQueueTab() {
  const [data, setData] = useState(null)
  const [q, setQ] = useState('')
  const [stateFilter, setStateFilter] = useState('')
  const [open, setOpen] = useState({})
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState('')
  // Which card just succeeded, so the confirmation lands ON the row the user
  // acted on. A single status line at the top of a long queue leaves people
  // unsure whether the right action moved.
  const [flashed, setFlashed] = useState('')

  const load = () => {
    const p = stateFilter ? `?state=${encodeURIComponent(stateFilter)}` : ''
    fetch(`/api/actions${p}`).then(r => r.json()).then(setData).catch(() => {})
  }
  useEffect(load, [stateFilter])

  const call = async (id, verb, payload) => {
    setBusy(id + verb); setMsg('')
    const r = await fetch(`/api/actions/${id}/${verb}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload || {})
    })
    const out = await r.json().catch(() => ({}))
    setMsg(r.ok ? `${id}: ${verb} ok${out.state ? ` → ${out.state}` : ''}`
      : (out.detail || `${verb} refused`))
    setBusy('')
    if (r.ok) {
      setFlashed(id)
      setTimeout(() => setFlashed(''), 800)
    }
    load()
  }

  const reject = (id) => {
    const reason = window.prompt(
      'Rejection reason (required — it is written to the audit ledger):')
    if (reason && reason.trim()) call(id, 'reject', { reason })
    else if (reason !== null) setMsg('A rejection reason is required.')
  }

  const compensate = (id) => {
    const reason = window.prompt(
      'Compensation reason (required, min 8 chars — this queues a NEW '
      + 'dual-control action; the original ledger entry is never edited):')
    if (!reason) return
    if (reason.trim().length < 8) {
      setMsg('A compensation reason of at least 8 characters is required.')
      return
    }
    const mode = window.prompt('Mode: "void" or "credit"?', 'void')
    if (!mode || !['void', 'credit'].includes(mode.trim().toLowerCase())) {
      setMsg('Compensation mode must be "void" or "credit".')
      return
    }
    const body = { reason, mode: mode.trim().toLowerCase() }
    if (body.mode === 'credit') {
      const amt = window.prompt('Credit amount (positive number):')
      if (!amt || Number(amt) <= 0) {
        setMsg('A credit compensation requires a positive credit_amount.')
        return
      }
      body.credit_amount = amt
    }
    call(id, 'compensate', body)
  }

  if (!data) return <div className="thinking">loading action queue…</div>
  const gate = data.summary?.gate ?? 0.85
  const rules = data.rules || {}
  const term = q.trim().toLowerCase()
  const actions = (data.actions || []).filter(a =>
    !term || a.action_id.toLowerCase().includes(term) ||
    (a.action_type || '').toLowerCase().includes(term) ||
    (a.target_object || '').toLowerCase().includes(term) ||
    (a.summary || '').toLowerCase().includes(term) ||
    (a.state || '').toLowerCase().includes(term))
  const s = data.summary || {}
  const money = n => `$${Math.round(n || 0).toLocaleString()}`

  return (
    <div className="fade-in">
      <LedgerBanner />
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3>✅ Action Queue (human-in-the-loop)<InfoDot id="actions.approve_button" /></h3>
          <span className="chip">{s.total || 0} in your scope</span>
          <span className="chip">{money(s.pending_impact)} pending impact</span>
          <span className="chip">gate {Math.round(gate * 100)}%</span>
          <span className="chip">dual control ≥ {money(rules.financial_impact_threshold)}</span>
          <div style={{ flex: 1 }} />
          <select className="settings-input" style={{ maxWidth: 190 }}
            value={stateFilter} onChange={e => setStateFilter(e.target.value)}>
            <option value="">All states</option>
            {Object.keys(STATE_TONE).map(st => <option key={st} value={st}>{st}</option>)}
          </select>
          <input className="settings-input" style={{ maxWidth: 220 }}
            placeholder="Search actions…" value={q}
            onChange={e => setQ(e.target.value)} />
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          Nothing writes back without human approval. Actions above the impact
          threshold or with a triggering regulatory severity require two
          distinct approvers; a proposer can never approve their own action.
          Target: <b>{data.targets?.default_target}</b>
          {data.targets?.default_target === 'dry_run' &&
            ' (simulated — records the exact payload, performs no external write)'}
        </p>
        {msg && <div className="brain-status ok" style={{ marginTop: 8 }}>{msg}</div>}
      </div>

      {actions.map(a => {
        const gateOk = (a.trust_score || 0) >= gate
        const isApproved = a.state === 'APPROVED'
        const canExecute = isApproved && gateOk
        const pending = a.state === 'PENDING_FIRST_APPROVAL' ||
          a.state === 'PENDING_SECOND_APPROVAL'
        // State stripe: green once executed, amber while awaiting a human,
        // red for anything blocked/failed. The state name is always printed
        // next to it — the colour is a shortcut, never the only signal.
        const stateBar = a.state === 'EXECUTED' ? 'good'
          : pending || a.state === 'PENDING_COMPENSATION' ? 'warn'
            : (a.state || '').startsWith('REJECT') || a.state === 'FAILED'
              ? 'bad' : ''
        return (
          <div key={a.action_id}
            className={`ui-card ${flashed === a.action_id ? 'flash-ok' : ''}`}
            style={{ marginBottom: 10 }}>
            <div className={`ui-card-bar ${stateBar}`} />
            <div style={{ display: 'flex', gap: 8, alignItems: 'baseline', flexWrap: 'wrap' }}>
              <b style={{ fontSize: 13 }}>{(a.action_type || '').replace(/_/g, ' ')}</b>
              <span style={{ fontFamily: 'monospace', fontSize: 11.5, color: 'var(--muted)' }}>
                {a.action_id}
              </span>
              <span className="chip" style={{ color: STATE_TONE[a.state] }}>{a.state}</span>
              <span className="chip">{a.control_mode === 'dual' ? '👥 dual control' : '👤 single'}</span>
              <div style={{ flex: 1 }} />
              <span className="chip" style={{ color: 'var(--bad)' }}>
                impact {money(a.estimated_financial_impact)}
              </span>
              <span className="chip">severity {a.regulatory_severity}</span>
              <span className="chip" style={{ color: gateOk ? 'var(--good)' : 'var(--bad)' }}>
                trust {Math.round((a.trust_score || 0) * 100)}%{gateOk ? '' : ' ⛔'}
              </span>
            </div>

            <p style={{ fontSize: 12.5, margin: '6px 0 4px' }}>
              <b>Proposed:</b> {a.summary || '—'} → <span style={{ fontFamily: 'monospace' }}>
                {a.target_object}</span> on <b>{a.target_system}</b>
            </p>
            <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
              proposed by {a.proposed_by}
              {a.proposer_user_id ? ` (for ${a.proposer_user_id})` : ''}
              {a.approver_1_id && ` · approver 1: ${a.approver_1_id}`}
              {a.approver_2_id && ` · approver 2: ${a.approver_2_id}`}
              {a.rejection_reason && <> · <span style={{ color: 'var(--bad)' }}>
                rejected: {a.rejection_reason}</span></>}
            </div>

            <button className="linkbtn" style={{ marginTop: 6 }}
              onClick={() => setOpen(o => ({ ...o, [a.action_id]: !o[a.action_id] }))}>
              {open[a.action_id] ? '▾' : '▸'} compliance logic tree
            </button>
            {open[a.action_id] && (
              <div style={{ background: 'var(--panel)', borderRadius: 6, padding: 8, marginTop: 4 }}>
                <LogicTree node={a.compliance_logic} />
                {a.payload && (
                  <div style={{ marginTop: 6, fontSize: 11.5 }}>
                    <b>Outbound payload (validated):</b>
                    <LogicTree node={a.payload} />
                  </div>
                )}
                {a.signatures?.length > 0 && (
                  <div style={{ marginTop: 6, fontSize: 11.5 }}>
                    <b>Approval signatures:</b>
                    <LogicTree node={a.signatures} />
                  </div>
                )}
              </div>
            )}

            <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
              {pending && (
                <>
                  <button className="primary-btn" disabled={busy === a.action_id + 'approve'}
                    onClick={() => call(a.action_id, 'approve', {})}>
                    ✍️ Approve{a.state === 'PENDING_SECOND_APPROVAL' ? ' (2nd)' : ''}
                  </button>
                  <button className="chip" onClick={() => reject(a.action_id)}>
                    ✖ Reject (reason required)
                  </button>
                </>
              )}
              {isApproved && (
                <button className="primary-btn" disabled={!canExecute || busy === a.action_id + 'execute'}
                  title={canExecute ? 'Execute write-back'
                    : `Blocked: trust ${Math.round((a.trust_score || 0) * 100)}% < gate ${Math.round(gate * 100)}%`}
                  onClick={() => call(a.action_id, 'execute')}>
                  {canExecute ? '🚀 Execute write-back'
                    : `⛔ Below ${Math.round(gate * 100)}% gate`}
                </button>
              )}
              {a.state === 'EXECUTED' && (
                <>
                  <span className="chip chip-on">
                    executed {a.executed_at ? `at ${a.executed_at.slice(0, 19)}` : ''}
                    {a.execution_receipt?.payload_hash &&
                      ` · hash ${String(a.execution_receipt.payload_hash).slice(0, 12)}`}
                  </span>
                  {a.action_type !== 'compensating' && (
                    <button className="chip" disabled={busy === a.action_id + 'compensate'}
                      title="Propose a dual-control credit/void reversal — the original ledger entry is never edited"
                      onClick={() => compensate(a.action_id)}>
                      ↩ Compensate (void/credit)
                    </button>
                  )}
                </>
              )}
              {a.state === 'PENDING_COMPENSATION' && (
                <span className="chip" style={{ color: STATE_TONE.PENDING_COMPENSATION }}>
                  ⏳ reversal proposed — awaiting the compensating action's own approval
                </span>
              )}
              {a.state === 'COMPENSATED' && (
                <span className="chip">↩ compensated — see the linked compensating action</span>
              )}
            </div>
          </div>
        )
      })}

      {actions.length === 0 && (
        <div className="card" style={{ color: 'var(--muted)' }}>
          No actions {q ? `match “${q}”` : 'in the queue — propose one from a case in the Cases tab'}.
        </div>
      )}
    </div>
  )
}
