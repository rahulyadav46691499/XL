import React, { useState } from 'react'
import NavMenu from './NavMenu.jsx'

// Left pane, two stacked concerns separated by a rule:
//
//   NAVIGATION (top)  — five grouped drawers of tabs; see NavMenu.jsx
//   ─────────────────
//   CHAT HISTORY      — collapsed by default so navigation, the thing used
//                       on every screen, is never pushed below the fold by a
//                       long transcript list.
//
// Navigation moved here from two horizontal rows in the sticky header, which
// wrapped badly at 19 tabs and stole height from every page.
export default function Sidebar({ history, onSelect, onClear, onNewChat,
                                  navGroups, tab, onTab, uid }) {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(true)
  const [expanded, setExpanded] = useState(null)
  // History starts CLOSED. It is reference material; the menu is the tool.
  const [histOpen, setHistOpen] = useState(false)

  const filtered = history.filter(h =>
    !q || (h.title || '').toLowerCase().includes(q.toLowerCase())
      || (h.qs || [h.q]).some(x => (x || '').toLowerCase().includes(q.toLowerCase())))

  const byDay = {}
  for (const h of filtered) {
    const day = new Date(h.ts).toLocaleDateString(undefined,
      { month: 'short', day: 'numeric' })
    ;(byDay[day] = byDay[day] || []).push(h)
  }

  if (!open) return (
    <button className="sidebar-toggle" title="Show menu &amp; history"
      onClick={() => setOpen(true)}>☰</button>
  )

  return (
    <aside className="sidebar">
      {navGroups && (
        <>
          <NavMenu groups={navGroups} current={tab} onSelect={onTab}
                   uid={uid} />
          <hr className="sidebar-rule" />
        </>
      )}

      <div className="sidebar-head">
        <button className="hist-toggle" aria-expanded={histOpen}
          onClick={() => setHistOpen(o => !o)}
          title={histOpen ? 'Collapse chat history' : 'Expand chat history'}>
          <span className="nav-caret">{histOpen ? '▾' : '▸'}</span>
          <b>Chat history</b>
          {history.length > 0 &&
            <span className="sidebar-count">{history.length}</span>}
        </button>
        <div>
          <button className="chip" style={{ fontSize: 11, padding: '3px 10px' }}
            onClick={onNewChat}>+ New</button>{' '}
          <button className="linkbtn" onClick={() => setOpen(false)}>hide</button>
        </div>
      </div>

      {histOpen && (<>
      <input className="sidebar-search" placeholder="Search past queries…"
        value={q} onChange={e => setQ(e.target.value)} />
      <div className="sidebar-list">
        {Object.entries(byDay).map(([day, items]) => (
          <div key={day}>
            <div className="sidebar-day">{day}</div>
            {items.map((h, i) => (
              <div key={(h.id || h.ts) + '' + i}>
                <button className="sidebar-item"
                  title={new Date(h.ts).toLocaleString()}
                  onClick={() => setExpanded(
                    expanded === (h.id || h.ts) ? null : (h.id || h.ts))}>
                  {expanded === (h.id || h.ts) ? '▾ ' : '▸ '}
                  {h.title || h.q}
                  <span className="sidebar-count">
                    {(h.qs || [h.q]).length}
                  </span>
                </button>
                {expanded === (h.id || h.ts) && (
                  <div className="sidebar-sub fade-in">
                    {(h.qs || [h.q]).map((question, j) => (
                      <button key={j} className="sidebar-item sidebar-q"
                        title={question} onClick={() => onSelect(question)}>
                        {question}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="sidebar-empty">
            {q ? 'No matches.' : 'Ask something — your questions stack here and survive restarts.'}
          </div>
        )}
      </div>
      {history.length > 0 && (
        <button className="linkbtn" style={{ margin: '8px 12px' }}
          onClick={onClear}>clear history</button>
      )}
      </>)}
    </aside>
  )
}
