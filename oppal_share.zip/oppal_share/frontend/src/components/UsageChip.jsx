import React, { useState } from 'react'

// Per-answer token/cost accounting — one collapsed line, expandable.
export default function UsageChip({ usage }) {
  const [open, setOpen] = useState(false)
  if (!usage) return null
  const total = (usage.tokens_in || 0) + (usage.tokens_out || 0)

  return (
    <div className="usage-chip">
      <button className="usage-summary" onClick={() => setOpen(o => !o)}>
        ⚡ {usage.latency_ms}ms · {total} tokens
        {usage.cache_hit ? ' · semantic cache hit' : ''} ·
        ${(usage.est_cost_usd || 0).toFixed(4)} {open ? '▴' : '▸'}
      </button>
      {open && (
        <div className="usage-detail">
          <span>in <b>{usage.tokens_in || 0}</b></span>
          <span>out <b>{usage.tokens_out || 0}</b></span>
          <span>cached <b>{usage.tokens_cached || 0}</b></span>
          <span>LLM calls <b>{usage.llm_calls || 0}</b></span>
          <span>provider <b>{usage.provider || 'mock'}</b></span>
          <span>rows scanned <b>{(usage.rows_scanned || 0).toLocaleString()}</b></span>
          <span>est. cost <b>${(usage.est_cost_usd || 0).toFixed(6)}</b></span>
          {usage.cache_hit &&
            <span style={{ color: 'var(--good)' }}>
              served from semantic cache — full agent pipeline skipped
            </span>}
          {(usage.provider === 'mock' || !usage.provider) && !usage.cache_hit &&
            <span style={{ color: 'var(--muted)' }}>
              mock mode: deterministic agents, zero LLM spend
            </span>}
        </div>
      )}
    </div>
  )
}
