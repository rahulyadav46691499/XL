import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'
import {
  ResponsiveContainer, ComposedChart, Line, Area, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ReferenceLine
} from 'recharts'

// Analysis workbench. Four questions an actuary or ops lead asks in order:
//
//   1. Where is this heading?          -> forecast, with intervals
//   2. Is the rise real or seasonal?   -> trend/seasonal decomposition
//   3. When did it break?              -> change points
//   4. What moves with it, and first?  -> lead/lag correlation
//
// Everything shown here is computed by deterministic statistics server-side.
// No model produces a number — a projection someone prices a benefit on has
// to be reproducible, and the UI says which method produced it.
//
// Metrics, LOBs and the searchable column all come from the ACTIVE Brain
// (/api/analysis/catalog, /api/me). They were payer literals, so under any
// other domain the tab opened on "'medical_cost' is not a governed metric".

const fmt = (v) => v == null ? '—'
  : Math.abs(v) >= 1e6 ? (v / 1e6).toFixed(2) + 'M'
    : Math.abs(v) >= 1e3 ? (v / 1e3).toFixed(1) + 'k'
      : Math.abs(v) < 1 ? Number(v).toFixed(4) : Number(v).toFixed(1)

export default function AnalysisTab() {
  const [metrics, setMetrics] = useState(null)      // [{id, label}]
  const [lobs, setLobs] = useState([])
  const [searchCols, setSearchCols] = useState({})  // {'table.col': label}
  const [vcol, setVcol] = useState('')
  const [metric, setMetric] = useState('')
  const [lob, setLob] = useState('')
  const [horizon, setHorizon] = useState(4)
  const [busy, setBusy] = useState('')
  const [err, setErr] = useState('')
  const [fc, setFc] = useState(null)
  const [dec, setDec] = useState(null)
  const [cps, setCps] = useState(null)
  const [cor, setCor] = useState(null)
  const [drv, setDrv] = useState(null)
  const [cat, setCat] = useState(null)
  const [vq, setVq] = useState('')
  const [vhits, setVhits] = useState(null)

  useEffect(() => {
    fetch('/api/ai/functions').then(r => r.ok ? r.json() : null)
      .then(setCat).catch(() => {})
    fetch('/api/me').then(r => r.ok ? r.json() : null)
      .then(me => setLobs(me?.allowed_lobs || [])).catch(() => {})
    // Land on something useful: the domain's first analysable metric.
    fetch('/api/analysis/catalog').then(r => r.ok ? r.json() : Promise.reject())
      .then(c => {
        const ms = c.metrics || []
        setMetrics(ms)
        setSearchCols(c.search_columns || {})
        setVcol(Object.keys(c.search_columns || {})[0] || '')
        if (ms.length) { setMetric(ms[0].id); runAll(ms[0].id) }
      }).catch(() => { setMetrics([]); setErr('Could not load this domain\'s metrics.') })
  }, [])

  const post = async (url, body) => {
    const r = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
    const out = await r.json().catch(() => null)
    if (!r.ok) throw new Error(out?.detail || `failed (${r.status})`)
    return out
  }

  const runAll = async (m = metric) => {
    setBusy('all'); setErr('')
    setFc(null); setDec(null); setCps(null); setDrv(null)
    try {
      const base = { metric: m, lob }
      const [f, d, c, dr] = await Promise.all([
        post('/api/analysis/run', { ...base, kind: 'forecast', horizon }),
        post('/api/analysis/run', { ...base, kind: 'decompose' }),
        post('/api/analysis/run', { ...base, kind: 'changepoints' }),
        post('/api/analysis/drivers', base).catch(() => null),
      ])
      setFc(f.result); setDec(d.result); setCps(c.result); setDrv(dr)
    } catch (e) { setErr(String(e.message || e)) }
    setBusy('')
  }

  const runCorrelate = async () => {
    setBusy('cor'); setErr('')
    try {
      const out = await post('/api/analysis/run', {
        kind: 'correlate', lob,
        metrics: (metrics || []).slice(0, 8).map(x => x.id),
      })
      setCor(out.result)
    } catch (e) { setErr(String(e.message || e)) }
    setBusy('')
  }

  const runVector = async () => {
    if (!vq.trim()) return          // Enter on an empty box
    setBusy('vec'); setErr('')
    try {
      const [table, column] = vcol.split('.')
      const out = await post('/api/search/vector', { query: vq, table, column, k: 8 })
      setVhits(out)
    } catch (e) { setErr(String(e.message || e)) }
    setBusy('')
  }

  // History + forecast on one axis, with the interval as a band.
  const fcData = !fc ? [] : [
    ...(fc.history || []).map(h => ({ label: h.label, actual: h.value })),
    ...(fc.points || []).map(p => ({
      label: p.label, forecast: p.forecast,
      band: [p.lower, p.upper],
    })),
  ]
  const decData = !dec?.sufficient ? [] : (dec.labels || []).map((l, i) => ({
    label: l, value: dec.values[i], trend: dec.trend[i],
    seasonal: dec.seasonal[i], residual: dec.residual[i],
  }))

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <h3>📈 Analysis<InfoDot id="analysis.metric_selector" /></h3>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 10px' }}>
          Forecasting, seasonality, structural breaks and lead/lag signals —
          all computed by <b>deterministic statistics</b> over governed
          metrics, inside your authorized lines of business. No language model
          produces a number here; one is only used to describe what was
          computed.
        </p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          <select className="settings-input" value={metric}
            onChange={e => setMetric(e.target.value)}>
            {(metrics || []).map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
          </select>
          <select className="settings-input" value={lob}
            onChange={e => setLob(e.target.value)}>
            {['', ...lobs].map(l => <option key={l} value={l}>{l || 'All authorized LOBs'}</option>)}
          </select>
          <label style={{ fontSize: 12, color: 'var(--muted)' }}>horizon</label>
          <select className="settings-input" style={{ width: 76 }} value={horizon}
            onChange={e => setHorizon(Number(e.target.value))}>
            {[1, 2, 4, 6, 8].map(h => <option key={h} value={h}>{h}Q</option>)}
          </select>
          <button className="primary-btn" disabled={!!busy || !metric}
            onClick={() => runAll()}>
            {busy === 'all' ? 'Analysing…' : 'Analyse'}
          </button>
        </div>
        {metrics && !metrics.length && !err && (
          <div className="ui-empty" style={{ marginTop: 8 }}>
            This domain declares no metric with a time series (a metric
            needs <code>table:</code> and <code>time_column:</code> in
            metrics.md, and its table must be loaded).
          </div>
        )}
        {err && <div className="brain-status err" style={{ marginTop: 8 }}>⛔ {err}</div>}
      </div>

      {/* 1. FORECAST */}
      {fc && (
        <div className="card" style={{ marginBottom: 12 }}>
          <div className="ui-card-head">
            <span className="ui-card-title">Where is this heading?</span>
            <span className="ui-card-meta">
              {fc.method} · {fc.n} periods of history
            </span>
          </div>
          {!fc.sufficient ? (
            <div className="ui-empty">⚠ {fc.note}</div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={260}>
                <ComposedChart data={fcData}>
                  <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                  <XAxis dataKey="label" stroke="var(--muted)" fontSize={11} />
                  <YAxis stroke="var(--muted)" fontSize={11} tickFormatter={fmt} width={64} />
                  <Tooltip formatter={(v) => Array.isArray(v)
                    ? `${fmt(v[0])} … ${fmt(v[1])}` : fmt(v)}
                    contentStyle={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 8 }} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Area dataKey="band" name="prediction interval" stroke="none"
                    fill="var(--accent)" fillOpacity={0.16} />
                  <Line dataKey="actual" name="actual" stroke="var(--accent)"
                    strokeWidth={2} dot={{ r: 3 }} connectNulls={false} />
                  <Line dataKey="forecast" name="forecast" stroke="var(--good)"
                    strokeWidth={2} strokeDasharray="5 4" dot={{ r: 3 }} />
                </ComposedChart>
              </ResponsiveContainer>
              <div className="ui-card-kv">
                <div><span>direction</span><b>{fc.direction}</b></div>
                <div><span>per period</span><b>{fmt(fc.slope_per_period)}</b></div>
                <div><span>trend fit r²</span><b>{fc.trend_r2}</b></div>
                <div><span>residual σ</span><b>{fmt(fc.residual_sigma)}</b></div>
                <div><span>interval</span><b>95%</b></div>
              </div>
              {/* An honest read of the model's own quality. A weak fit with
                  confident-looking lines is how forecasts mislead people. */}
              <p style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 6 }}>
                {fc.trend_r2 >= 0.7
                  ? 'The trend explains most of the variation — the interval is the honest range.'
                  : `A weak trend fit (r² ${fc.trend_r2}); the wide interval is the real message. Treat the central line as indicative, not a plan number.`}
                {fc.seasonal_applied ? ' Seasonal indices applied.' : ' Not enough history for seasonality.'}
              </p>
            </>
          )}
        </div>
      )}

      {/* 2. DECOMPOSITION */}
      {dec && (
        <div className="card" style={{ marginBottom: 12 }}>
          <div className="ui-card-head">
            <span className="ui-card-title">Is the movement real, or just seasonal?</span>
            <span className="ui-card-meta">additive decomposition</span>
          </div>
          {!dec.sufficient ? <div className="ui-empty">⚠ {dec.note}</div> : (
            <>
              <ResponsiveContainer width="100%" height={230}>
                <ComposedChart data={decData}>
                  <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                  <XAxis dataKey="label" stroke="var(--muted)" fontSize={11} />
                  <YAxis stroke="var(--muted)" fontSize={11} tickFormatter={fmt} width={64} />
                  <Tooltip formatter={fmt} contentStyle={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 8 }} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <ReferenceLine y={0} stroke="var(--border)" />
                  <Line dataKey="value" name="actual" stroke="var(--accent)" strokeWidth={2} dot={false} />
                  <Line dataKey="trend" name="trend" stroke="var(--good)" strokeWidth={2} dot={false} />
                  <Bar dataKey="seasonal" name="seasonal" fill="var(--warn, #c58a00)" fillOpacity={0.7} />
                </ComposedChart>
              </ResponsiveContainer>
              <div className="ui-card-kv">
                <div><span>trend strength</span><b>{dec.trend_strength}</b></div>
                <div><span>seasonal strength</span><b>{dec.seasonal_strength}</b></div>
                <div><span>direction</span><b>{dec.direction}</b></div>
              </div>
              <p style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 6 }}>
                {dec.seasonal_strength >= 0.3
                  ? 'A material share of the movement is the seasonal pattern — compare like quarter with like quarter before escalating.'
                  : 'Seasonality is minor here, so quarter-on-quarter moves are mostly genuine signal.'}
                {dec.note ? ` ${dec.note}.` : ''}
              </p>
            </>
          )}
        </div>
      )}

      {/* 3. CHANGE POINTS + 4. DRIVERS */}
      <div className="ui-cards" style={{ marginBottom: 12 }}>
        {cps && (
          <div className="ui-card">
            <div className="ui-card-bar warn" />
            <div className="ui-card-head">
              <span className="ui-card-title">When did it break?</span>
              <span className="ui-card-meta">binary segmentation</span>
            </div>
            {!cps.changepoints?.length ? (
              <div className="ui-empty">{cps.note || 'No structural break detected.'}</div>
            ) : cps.changepoints.map((c, i) => (
              <div key={i} className="ui-card-kv" style={{ borderTop: i ? '1px solid var(--border)' : 'none', paddingTop: i ? 8 : 0 }}>
                <div><span>break at</span><b>{c.label}</b></div>
                <div><span>shift</span>
                  <b style={{ color: c.direction === 'up' ? 'var(--bad)' : 'var(--good)' }}>
                    {c.direction === 'up' ? '▲' : '▼'} {c.shift_pct != null ? c.shift_pct + '%' : fmt(c.shift)}
                  </b></div>
                <div><span>before → after</span><b>{fmt(c.mean_before)} → {fmt(c.mean_after)}</b></div>
                <div><span>confidence</span><b>{c.score}</b></div>
              </div>
            ))}
            <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 8 }}>
              A break is a level shift, not an outlier — line it up against a
              benefit or formulary effective date.
            </p>
          </div>
        )}

        {drv && (
          <div className="ui-card">
            <div className="ui-card-bar" />
            <div className="ui-card-head">
              <span className="ui-card-title">What is driving it?</span>
              <span className="ui-card-meta">contribution attribution</span>
            </div>
            {!drv.anomalies?.length && !drv.drivers?.length ? (
              <div className="ui-empty">No anomaly or driver stood out.</div>
            ) : (
              <>
                {(drv.anomalies || []).slice(0, 2).map((a, i) => (
                  <div key={i} style={{ fontSize: 12, marginBottom: 6 }}>
                    ⚠ <b>{a.period}</b> — {a.direction === 'spike' ? 'jumped' : 'fell'}{' '}
                    {Math.abs(a.pct_change)}% QoQ (z={a.z_score})
                  </div>
                ))}
                {(drv.drivers || []).slice(0, 4).map((d, i) => (
                  <div key={i} style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                    · {String(d.dimension || '').replace(/_/g, ' ')}
                    {d.value ? ` = ${d.value}` : ''}
                    {d.contribution_pct != null ? ` — ${d.contribution_pct}% of the move` : ''}
                  </div>
                ))}
              </>
            )}
          </div>
        )}
      </div>

      {/* 5. CORRELATION / LEADING INDICATORS */}
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3 style={{ margin: 0 }}>What moves together — and what moves first?</h3>
          <div style={{ flex: 1 }} />
          <button className="chip" disabled={!!busy || (metrics || []).length < 2}
            onClick={runCorrelate}>
            {busy === 'cor' ? 'Scanning…' : 'Scan metrics'}
          </button>
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          A metric that reliably leads another by a quarter is an early-warning
          signal: it buys you a quarter to staff, negotiate or intervene.
        </p>
        {cor && (
          <>
            <table className="cohort-table" style={{ marginTop: 8 }}>
              <thead><tr style={{ fontSize: 11, color: 'var(--muted)', textAlign: 'left' }}>
                <th>pair</th><th>r</th><th>lag</th><th>leads</th><th></th>
              </tr></thead>
              <tbody>
                {cor.pairs.slice(0, 8).map((p, i) => (
                  <tr key={i}>
                    <td style={{ fontSize: 12 }}>
                      {p.a.replace(/_/g, ' ')} ↔ {p.b.replace(/_/g, ' ')}
                    </td>
                    <td><b style={{ color: p.direction === 'inverse' ? 'var(--warn, #c58a00)' : 'var(--good)' }}>
                      {p.r}</b></td>
                    <td style={{ fontSize: 12 }}>{p.lag === 0 ? 'same Q' : `${Math.abs(p.lag)}Q`}</td>
                    <td style={{ fontSize: 12 }}>
                      {p.leads ? <b>{p.leads.replace(/_/g, ' ')}</b> : '—'}</td>
                    <td><span className="chip" style={{ fontSize: 10 }}>{p.strength}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 6 }}>
              ⚠ {cor.caveat}
            </p>
          </>
        )}
      </div>

      {/* 6. VECTOR SEARCH */}
      <div className="card" style={{ marginBottom: 12 }}>
        <h3>Vector search<InfoDot id="analysis.vector_search" /></h3>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 8px' }}>
          Finds records that are <i>close</i>, not just equal — misspellings,
          brand vs generic, partial names. Runs locally on character n-grams,
          so nothing leaves the box and the ranking is reproducible. It is
          lexical similarity, <b>not</b> neural embeddings: it will match
          “semaglutid” to “Semaglutide”, but it does not know GLP-1 relates to
          weight loss.
        </p>
        {!vcol ? (
          <div className="ui-empty">
            No searchable text column is declared for this domain — add one
            under <code>## Search Columns</code> in entities.md.
          </div>
        ) : (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {Object.keys(searchCols).length > 1 && (
            <select className="settings-input" value={vcol}
              onChange={e => { setVcol(e.target.value); setVhits(null) }}>
              {Object.entries(searchCols).map(([c, l]) =>
                <option key={c} value={c}>{l}</option>)}
            </select>
          )}
          <input className="settings-input" style={{ flex: 1, minWidth: 200 }}
            value={vq} onChange={e => setVq(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && runVector()}
            placeholder="try a misspelling or a partial name" />
          <button className="chip" disabled={!!busy || !vq.trim()} onClick={runVector}>
            {busy === 'vec' ? 'Searching…' : `🔍 Search ${searchCols[vcol]}`}
          </button>
        </div>
        )}
        {vhits && (
          <div style={{ marginTop: 8 }}>
            {!vhits.hits?.length && <div className="ui-empty">No match above the noise floor.</div>}
            {(vhits.hits || []).map((h, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'center',
                padding: '3px 0', fontSize: 12.5 }}>
                <span style={{ flex: 1 }}>{h.text}</span>
                <span className="chip" style={{ fontSize: 10 }}>{h.score}</span>
              </div>
            ))}
            {!!vhits.candidates && (
              <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 4 }}>
                {vhits.candidates} distinct values indexed · {vhits.method}
              </p>
            )}
          </div>
        )}
      </div>

      {/* 7. ai_* CATALOGUE */}
      {cat && (
        <div className="card">
          <h3>Built-in AI functions</h3>
          <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 8px' }}>
            Callable directly in SQL, e.g.{' '}
            <code>SELECT ai_classify(denial_reason, 'Prior Auth,Eligibility,Coding')
              FROM claims</code>. Model-backed calls are PHI-scrubbed, cached per
            distinct value and capped at {cat.max_llm_calls_per_statement} per
            statement — a per-row model call over a whole warehouse is a
            five-figure mistake, so the ceiling is structural.
            {' '}Model currently {cat.llm_available
              ? 'configured — model-backed functions are live.'
              : 'not configured — deterministic paths only; ai_gen and ai_translate will say so.'}
          </p>
          <table className="cohort-table">
            <thead><tr style={{ fontSize: 11, color: 'var(--muted)', textAlign: 'left' }}>
              <th>function</th><th>returns</th><th>engine</th><th>what it does</th>
            </tr></thead>
            <tbody>
              {cat.functions.map(f => (
                <tr key={f.name + f.args}>
                  <td style={{ fontFamily: 'ui-monospace, Menlo, monospace', fontSize: 11.5 }}>
                    <b>{f.name}</b>{f.args}
                  </td>
                  <td style={{ fontSize: 11.5, color: 'var(--muted)' }}>{f.returns}</td>
                  {/* A rounded pill cannot wrap: the border breaks mid-word
                      and the second line escapes the outline (which is what
                      "deterministic + model on ties" was doing). Keep the
                      pill on one line and let the CELL be the thing that has
                      room, via .fn-engine below. */}
                  <td className="fn-engine">
                    <span className="chip chip-nowrap">{f.engine}</span>
                  </td>
                  <td style={{ fontSize: 11.5 }}>{f.about}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
