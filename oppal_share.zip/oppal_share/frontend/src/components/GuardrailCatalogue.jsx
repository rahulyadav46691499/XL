import React, { useEffect, useState } from 'react'

// Read-only guardrail catalogue.
//
// This view exists to answer one question — "what PHI rules are active right
// now?" — with something exportable. There is deliberately no edit affordance
// anywhere in it: guardrail authorship lives in code so that changing one
// requires a pull request, review and the pipeline. The absence of a Save
// button here is the feature, not an omission, so the panel says so out loud
// rather than leaving a reviewer to wonder.
export default function GuardrailCatalogue() {
  const [cat, setCat] = useState(null)
  const [denied, setDenied] = useState(false)
  const [showPatterns, setShowPatterns] = useState(false)
  const [showIngest, setShowIngest] = useState(false)

  const load = () => {
    fetch('/api/governance/guardrails')
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(d => { setCat(d); setDenied(false) })
      .catch(() => setDenied(true))
  }
  useEffect(() => { load() }, [])

  if (denied || !cat) return null

  const phi = cat.phi_pii_detectors || []
  const ingest = cat.ingest_guardrails || []
  const exclusions = cat.structured_payload_exclusions || []

  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between',
                    alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <h3>
          Active guardrails ({phi.length} PHI/PII detectors ·{' '}
          {ingest.length} ingest rules)
        </h3>
        <div style={{ display: 'flex', gap: 8 }}>
          <a className="chip" href="/api/governance/guardrails?fmt=csv">
            ↓ CSV
          </a>
          <button className="chip" onClick={() => load()}>↻ refresh</button>
        </div>
      </div>

      <p style={{ color: 'var(--muted)', fontSize: 12, marginTop: 6 }}>
        <b>Read-only.</b> {cat.authorship}
      </p>
      <p style={{ color: 'var(--muted)', fontSize: 11.5, marginTop: 4 }}>
        {cat.derivation}
      </p>

      <table className="cohort-table" style={{ marginTop: 10 }}>
        <thead>
          <tr>
            <th>Detector</th><th>Detects</th>
            <th>Free text</th><th>Write-back payloads</th>
          </tr>
        </thead>
        <tbody>
          {phi.map(e => (
            <tr key={e.id}>
              <td>
                <b>{e.id}</b>
                <div style={{ fontSize: 11, color: 'var(--muted)' }}>
                  {e.label}
                </div>
              </td>
              <td style={{ fontSize: 11.5 }}>{e.detects}</td>
              <td>
                <span className="badge high">yes</span>
              </td>
              <td>
                {e.applies_to_structured_payloads
                  ? <span className="badge high">yes</span>
                  : <span className="badge med" title={
                      e.structured_exclusion_reason || ''}>
                      excluded — hover
                    </span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {exclusions.length > 0 && (
        <div style={{ marginTop: 12 }}>
          <b style={{ fontSize: 12.5 }}>
            Deliberate write-back exclusions ({exclusions.length})
          </b>
          {phi.filter(e => e.applies_to_structured_payloads === false)
              .map(e => (
            <p key={e.id} style={{ fontSize: 11.5, color: 'var(--muted)',
                                   margin: '4px 0 0' }}>
              <b>{e.id}</b> — {e.structured_exclusion_reason}
            </p>
          ))}
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <button className="chip" onClick={() => setShowIngest(s => !s)}>
          {showIngest ? '▾' : '▸'} ingest guardrails ({ingest.length})
        </button>
        <button className="chip" onClick={() => setShowPatterns(s => !s)}>
          {showPatterns ? '▾' : '▸'} detection patterns
        </button>
      </div>

      {showIngest && (
        <table className="cohort-table" style={{ marginTop: 8 }}>
          <thead><tr><th>Rule</th><th>Detects</th><th>Action</th></tr></thead>
          <tbody>
            {ingest.map(e => (
              <tr key={e.id}>
                <td><b>{e.id}</b>
                  <div style={{ fontSize: 11, color: 'var(--muted)' }}>
                    {e.fail_direction}
                  </div>
                </td>
                <td style={{ fontSize: 11.5 }}>{e.detects}</td>
                <td style={{ fontSize: 11.5 }}>{e.action}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showPatterns && (
        <div style={{ marginTop: 8 }}>
          <p style={{ fontSize: 11.5, color: 'var(--muted)' }}>
            {cat.scope_note}
          </p>
          <table className="cohort-table" style={{ marginTop: 6 }}>
            <thead><tr><th>Detector</th><th>Pattern</th><th>Example</th></tr></thead>
            <tbody>
              {phi.map(e => (
                <tr key={e.id}>
                  <td><b>{e.id}</b></td>
                  <td style={{ fontFamily: 'monospace', fontSize: 10.5,
                               wordBreak: 'break-all' }}>
                    {e.pattern || '—'}
                  </td>
                  <td style={{ fontSize: 11 }}>
                    {e.synthetic_example || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
