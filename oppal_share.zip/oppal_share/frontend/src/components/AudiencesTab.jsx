import React, { useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Audience workspace: create with an explicit name, browse history
// (persisted across sessions), activate, delete, and compare two.
export default function AudiencesTab({ cohorts, active, onSelect, onDelete,
  onCreate, onCompare }) {
  const [name, setName] = useState('')
  const [prompt, setPrompt] = useState('')
  const [picked, setPicked] = useState([])
  const [busy, setBusy] = useState(false)

  const create = async () => {
    if (!prompt.trim() || busy) return
    setBusy(true)
    await onCreate(prompt, name.trim() || null)
    setPrompt(''); setName(''); setBusy(false)
  }

  const togglePick = (id) => setPicked(p =>
    p.includes(id) ? p.filter(x => x !== id) : [...p.slice(-1), id])

  return (
    <div>
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>Create a new audience<InfoDot id="audiences.name_input_optional_prompt_input" /></h3>
        <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
          <input className="settings-input" style={{ flex: '0 0 200px' }}
            placeholder="Audience name (optional)"
            value={name} onChange={e => setName(e.target.value)} />
          <input className="settings-input" style={{ flex: 1, minWidth: 260 }}
            placeholder='Plain English, e.g. "denied ER claims in the Southeast over $5k"'
            value={prompt} onChange={e => setPrompt(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && create()} />
          <button className="primary-btn" onClick={create} disabled={busy}>
            {busy ? 'Building…' : 'Create + auto-analyze'}
          </button>
        </div>
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3>Audience history ({cohorts.length})</h3>
          <button className="primary-btn" disabled={picked.length !== 2}
            onClick={() => onCompare(picked[0], picked[1])}>
            Compare selected ({picked.length}/2)
          </button>
        </div>
        {cohorts.length === 0 &&
          <p style={{ color: 'var(--muted)', marginTop: 8 }}>
            No audiences yet — create one above or say "create an audience of …" in chat.
          </p>}
        {/* Card grid rather than a table: an audience is a small object with a
            name, an intent, a predicate and a few profile stats — reading it
            row-wise forced the predicate into a cramped cell. Cards also make
            the compare-two selection state visible at a glance. */}
        <div className="ui-cards" style={{ marginTop: 10 }}>
          {cohorts.map((c, i) => {
            const p = c.profile
            const lift = p && !p.empty && p.severity_ratio
            return (
              <div key={c.id}
                className={`ui-card ${active === c.id ? 'ui-card-active' : ''}`}
                style={{ animationDelay: `${0.04 * (i + 1)}s` }}>
                <div className={`ui-card-bar ${active === c.id ? '' : 'warn'}`}
                  style={active === c.id ? undefined : { opacity: .35 }} />
                <div className="ui-card-head">
                  <span className="ui-card-title">
                    <label style={{ display: 'inline-flex', gap: 6, alignItems: 'center', cursor: 'pointer' }}>
                      <input type="checkbox" checked={picked.includes(c.id)}
                        onChange={() => togglePick(c.id)} />
                      {c.name}
                    </label>
                  </span>
                  <span className="ui-card-meta">{c.created_at}</span>
                </div>
                <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>{c.prompt}</div>
                <div style={{ fontSize: 10.5, color: 'var(--accent)',
                  fontFamily: 'ui-monospace, Menlo, Consolas, monospace',
                  marginTop: 5, wordBreak: 'break-word' }}>
                  WHERE {c.where}
                </div>
                {/* Clauses the governance gate refused. Showing these is the
                    whole point: an audience that quietly lost a filter is
                    worse than one that failed loudly, because every later
                    number is scoped to something the analyst never asked
                    for. */}
                {!!(c.rejected_filters || []).length && (
                  <div className="cohort-rejected">
                    <b>⚠ {c.rejected_filters.length} clause(s) not applied</b>
                    {c.rejected_filters.map((r, k) => (
                      <div key={k}>· {r.reason}</div>
                    ))}
                  </div>
                )}
                {p && p.empty && (
                  <div className="cohort-rejected">
                    <b>⚠ This audience matches no claims.</b>
                    <div>· Every metric scoped to it will be empty. Check the
                      predicate above, or rebuild with wider filters.</div>
                  </div>
                )}
                {p && !p.empty ? (
                  <div className="ui-card-kv">
                    <div><span>claims</span><b>{p.claims.toLocaleString()}</b></div>
                    <div><span>severity</span><b>${Number(p.severity).toLocaleString()}</b></div>
                    {lift ? <div><span>vs book</span>
                      <b style={{ color: lift > 1 ? 'var(--bad)' : 'var(--good)' }}>
                        {lift}×</b></div> : null}
                    {p.avg_raf ? <div><span>avg RAF</span><b>{p.avg_raf}</b></div> : null}
                  </div>
                ) : (
                  <div className="ui-empty">No profile — the audience matched no claims.</div>
                )}
                <div className="ui-card-actions">
                  <button className={`chip ${active === c.id ? 'chip-on' : ''}`}
                    onClick={() => onSelect(active === c.id ? null : c.id)}>
                    {active === c.id ? '● active in chat' : 'use in chat'}
                  </button>
                  <button className="linkbtn" onClick={() => onDelete(c.id)}>delete</button>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
