import React from 'react'

// Auto-detected patterns rendered as scannable cards.
export default function InsightCards({ items }) {
  return (
    <div className="insight-cards">
      {items.map((t, i) => (
        <div key={i} className={`insight-card ${t.startsWith('⚠') ? 'warn' : ''}`}>
          {t}
        </div>
      ))}
    </div>
  )
}
