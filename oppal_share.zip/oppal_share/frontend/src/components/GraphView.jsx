import React, { useEffect, useMemo, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// `head` is the band name; `label` is the legend name. They differ because a
// band can hold more than one type, and its header is then built from the
// heads actually present — see `layout` below.
const TYPE_META = {
  term: { color: '#f5a623', label: 'Business terms', head: 'Terms', col: 0 },
  drug: { color: '#e5544b', label: 'Drugs (RxNorm)', head: 'Drugs', col: 0 },
  metric: { color: '#3ecf8e', label: 'Governed metrics', head: 'Metrics', col: 1 },
  tier: { color: '#4dd0e1', label: 'Formulary tiers', head: 'Tiers', col: 1 },
  policy: { color: '#d33a82', label: 'Policy rules', head: 'Policy rules', col: 1 },
  column: { color: '#5b8def', label: 'Columns', head: 'Columns', col: 2 },
  table: { color: '#a76bf2', label: 'Tables', head: 'Tables', col: 3 },
}
const BAND_COUNT = 4
// Source documents are deliberately absent. They are the citation layer, not
// part of the meaning layer this view is for, and they used to share the
// Tables band — which is how the Medicare Sales pack's thirteen regulations
// ("42 CFR §422.2274(d)", "CMS Complaints Tracking Module") came to be read as
// thirteen tables that do not exist. They are still in the Brain, still
// grounded, and still cited on an answer: see the Trust panel's source
// documents, fed by ground().
const HIDDEN_NTYPES = new Set(['document'])
// SOURCED_FROM is omitted with them — every such edge ends at a document.
const REL_COLOR = { SYNONYM_OF: '#f5a623', DERIVED_FROM: '#3ecf8e',
  HAS_COLUMN: '#5b8def', JOINS_ON: '#a76bf2', RESOLVES_TO: '#e5544b', GOVERNS: '#d33a82',
  ADJUDICATED_AS: '#4dd0e1' }

// Layered SVG rendering of the semantic knowledge graph, left to right:
// terms -> metrics -> columns -> tables, edges coloured by relationship.
// Each band is named by what stands in it (see `layout`).
export default function GraphView() {
  const [graph, setGraph] = useState(null)
  const [hover, setHover] = useState(null)
  const [search, setSearch] = useState('')
  const [showAll, setShowAll] = useState(false)
  // FOCUS / DRILL-DOWN. Nodes were already styled with cursor:pointer but did
  // nothing on click — they looked interactive and were not. Clicking now
  // isolates a node's connected sub-graph, which is the natural way to read a
  // graph this dense: "show me what this metric actually touches".
  const [focus, setFocus] = useState(null)
  const [hops, setHops] = useState(1)
  const [trail, setTrail] = useState([])       // breadcrumb of drilled nodes

  useEffect(() => {
    fetch(`/api/graph?full=${showAll ? 1 : 0}`)
      .then(r => r.json())
      // Drop hidden types HERE, once, rather than in the layout — the focus
      // panel, the search and the relationship insights all read `graph`
      // directly, and filtering only at render time would leave them offering
      // neighbours the canvas never drew.
      .then(g => {
        const gone = new Set(g.nodes
          .filter(n => HIDDEN_NTYPES.has(n.ntype)).map(n => n.id))
        setGraph({ ...g,
          nodes: g.nodes.filter(n => !gone.has(n.id)),
          edges: g.edges.filter(e => !gone.has(e.source)
                                     && !gone.has(e.target)) })
      })
      .catch(() => {})
  }, [showAll])

  // Toggling "show ALL columns" can remove the focused node from the graph
  // entirely; leaving a focus pointing at a node that no longer exists would
  // render an empty canvas with no way back.
  useEffect(() => {
    if (focus && graph && !graph.nodes.some(n => n.id === focus)) {
      setFocus(null); setTrail([])
    }
  }, [graph, focus])

  // Breadth-first expansion from the focused node, `hops` levels out, treating
  // edges as undirected — a join or a derivation is worth following in either
  // direction when you are asking "what is this connected to?".
  const nbhd = useMemo(() => {
    if (!graph || !focus) return null
    const adj = new Map()
    for (const e of graph.edges) {
      if (!adj.has(e.source)) adj.set(e.source, [])
      if (!adj.has(e.target)) adj.set(e.target, [])
      adj.get(e.source).push(e.target)
      adj.get(e.target).push(e.source)
    }
    const depth = new Map([[focus, 0]])
    let frontier = [focus]
    for (let d = 1; d <= hops; d++) {
      const next = []
      for (const id of frontier) {
        for (const nb of (adj.get(id) || [])) {
          if (!depth.has(nb)) { depth.set(nb, d); next.push(nb) }
        }
      }
      frontier = next
      if (!frontier.length) break
    }
    return depth                         // id -> hop distance from focus
  }, [graph, focus, hops])

  const layout = useMemo(() => {
    if (!graph) return null
    // Lay out only what is VISIBLE. Positioning the whole graph and hiding
    // most of it would leave the focused sub-graph scattered across a mostly
    // empty 980px canvas with meaningless gaps between its nodes.
    const visible = nbhd
      ? graph.nodes.filter(n => nbhd.has(n.id))
      : graph.nodes
    const cols = Array.from({ length: BAND_COUNT }, () => [])
    for (const n of visible) {
      const meta = TYPE_META[n.ntype]
      if (meta) cols[meta.col].push(n)
    }
    // A band is named by the types actually standing in it, so the header can
    // never again claim something the band does not hold. Bands left empty by
    // the domain or by a drill-down are dropped rather than labelled over
    // nothing.
    const headOf = (nodes) => [...new Set(nodes
      .map(n => (TYPE_META[n.ntype] || {}).head).filter(Boolean))].join(' · ')

    // MEASURED column layout. These x positions used to be the literals
    // [90, 360, 640, 890] inside a fixed 980px canvas, with the right-hand
    // columns' labels anchored 'end' so they grew LEFTWARDS into the previous
    // column. That held while every name looked like "claims.paid_amount"
    // (18 chars). Onboard a table and it stops holding: the graph gains
    // "hedis_measure_results.numerator_compliant" (41 chars, ~250px), whose
    // label reached back over the Metrics column, and the Tables column sat
    // beyond the visible width — lineage appeared to stop at Columns.
    //
    // Every label now anchors 'start' and each column is placed after the
    // widest label in the column before it, so overlap is arithmetically
    // impossible and the canvas is exactly as wide as the content needs.
    // Wider than the viewport is fine — the container scrolls.
    const CHAR_W = 6.15          // ≈ advance width at fontSize 11
    const LABEL_DX = 11          // gap from node dot to its text
    const COL_GAP = 46           // clear space between a label and the next dot
    const widest = (nodes) => nodes.reduce(
      (m, n) => Math.max(m, (String(n.label || '').length
        + (n.certified ? 2 : 0)) * CHAR_W), 0)

    const HEAD_CHAR_W = 6.9      // ≈ advance width at fontSize 12, weight 600

    const pos = {}
    const bands = []
    let x = 92
    let H = 0
    for (const nodes of cols) {
      if (!nodes.length) continue
      const header = headOf(nodes)
      // Regulation ids sort as decimals, not as strings: §422.52 precedes
      // §422.2264. Plain localeCompare put the longer number first.
      nodes.sort((a, b) => a.label.localeCompare(b.label, undefined,
                                                 { numeric: true }))
      const gap = 26
      nodes.forEach((n, i) => { pos[n.id] = { x, y: 46 + i * gap } })
      H = Math.max(H, 46 + nodes.length * gap + 20)
      bands.push({ x, header, count: nodes.length })
      // The header starts at the band's x, the node labels LABEL_DX past it,
      // so the band is as wide as whichever of the two runs longer. The
      // header's trailing count is part of what is drawn, so it is measured.
      x += Math.max(LABEL_DX + widest(nodes),
                    `${header} ${nodes.length}`.length * HEAD_CHAR_W) + COL_GAP
    }
    const W = Math.max(980, x - COL_GAP + 40)
    return { pos, W, H: Math.max(H, 140), cols, bands }
  }, [graph, nbhd])

  if (!graph || !layout) return <div className="thinking">loading semantic graph…</div>

  const drill = (id) => {
    setTrail(t => (focus && focus !== id ? [...t, focus] : t))
    setFocus(id)
    setHover(null)
  }
  const back = () => {
    setTrail(t => {
      const prev = t[t.length - 1]
      setFocus(prev ?? null)
      return t.slice(0, -1)
    })
  }
  const clearFocus = () => { setFocus(null); setTrail([]); setHover(null) }

  const { pos, W, H, bands } = layout
  const q = search.trim().toLowerCase()
  const matches = new Set(
    q ? graph.nodes.filter(n =>
        n.label.toLowerCase().includes(q)
        || (n.description || '').toLowerCase().includes(q)
        || (n.formula || '').toLowerCase().includes(q)
        || (n.threshold || '').toLowerCase().includes(q)
        || (n.citation || '').toLowerCase().includes(q)
      ).map(n => n.id) : [])
  const connected = new Set()
  if (hover) {
    connected.add(hover)
    for (const e of graph.edges) {
      if (e.source === hover) connected.add(e.target)
      if (e.target === hover) connected.add(e.source)
    }
  }

  return (
    <div className="card">
      <h3>Semantic layer — knowledge graph<InfoDot id="semantic_graph.search_box" /></h3>
      <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '6px 0 10px' }}>
        Every question is grounded by traversing this graph before SQL is written.
        Built from the Context Brain
        {graph.meta?.last_rebuild && <>
          {' '}— <b style={{ color: 'var(--good)' }}>rebuilt {graph.meta.last_rebuild}</b> (build #{graph.meta.rebuild_count})
        </>}. Hover to trace relationships, <b>click a node to drill into its
        connected sub-graph</b>.
      </p>

      {focus && (
        <div className="graph-focus-bar fade-in">
          <span className="graph-focus-label">Focused on</span>
          <b className="graph-focus-node">
            {graph.nodes.find(n => n.id === focus)?.label || focus}
          </b>
          <span className="graph-focus-count">
            {nbhd ? nbhd.size - 1 : 0} connected node(s) within {hops} hop{hops > 1 ? 's' : ''}
          </span>
          <span className="graph-hops">
            {[1, 2, 3].map(h => (
              <button key={h}
                className={`chip ${hops === h ? 'chip-on' : ''}`}
                title={`Expand ${h} hop${h > 1 ? 's' : ''} from the focused node`}
                onClick={() => setHops(h)}>{h} hop{h > 1 ? 's' : ''}</button>
            ))}
          </span>
          {trail.length > 0 && (
            <button className="linkbtn" onClick={back}
              title={`Back to ${graph.nodes.find(n => n.id === trail[trail.length - 1])?.label || ''}`}>
              ← back
            </button>
          )}
          <button className="linkbtn" onClick={clearFocus}>show whole graph</button>
        </div>
      )}
      {trail.length > 0 && (
        <div className="graph-trail">
          {trail.map((id, i) => (
            <span key={id + i}>
              <button className="linkbtn" onClick={() => {
                setTrail(trail.slice(0, i)); setFocus(id)
              }}>{graph.nodes.find(n => n.id === id)?.label || id}</button>
              <span className="graph-trail-sep">›</span>
            </span>
          ))}
          <b>{graph.nodes.find(n => n.id === focus)?.label || focus}</b>
        </div>
      )}
      <input className="settings-input" style={{ width: '100%', marginBottom: 10 }}
        placeholder="🔍 Search nodes — try 'medicaid', '0.6', 'ozempic', '438.330', a formula…"
        value={search} onChange={e => setSearch(e.target.value)} />
      {q && <div style={{ fontSize: 12, color: 'var(--accent)', marginBottom: 6 }}>
        {matches.size} node(s) match "{search}"</div>}
      <label style={{ fontSize: 12, color: 'var(--muted)', display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
        <input type="checkbox" checked={showAll}
          onChange={e => setShowAll(e.target.checked)} />
        Show ALL physical columns (dimmed = not curated in the Brain — the
        default view is the governed semantic layer, not a data dictionary)
      </label>
      <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 8 }}>
        {Object.entries(TYPE_META).map(([t, m]) => (
          <span key={t} style={{ fontSize: 11.5, color: m.color }}>● {m.label}</span>
        ))}
        {Object.entries(REL_COLOR).map(([r, c]) => (
          <span key={r} style={{ fontSize: 11.5, color: 'var(--muted)' }}>
            <span style={{ color: c }}>—</span> {r.toLowerCase().replace('_', ' ')}
          </span>
        ))}
      </div>
      <div style={{ overflow: 'auto', border: '1px solid var(--border)', borderRadius: 8 }}>
        <svg width={W} height={H} style={{ display: 'block', background: 'var(--panel-deep)' }}>
          {bands.map((b) => (
            // Left-aligned with the band's labels, not centred on the dot —
            // a centred header over a left-growing label column reads as
            // belonging to the column to its left. The count is what tells you
            // at a glance that a band holds thirteen citations, not thirteen
            // tables.
            <text key={b.header} x={b.x} y={22} fill="var(--muted)"
              fontSize="12" fontWeight="600" textAnchor="start">
              {b.header}
              <tspan fill="var(--muted)" opacity="0.6"> {b.count}</tspan>
            </text>
          ))}
          {/* Faint band rules: with the canvas now wider than the viewport,
              these keep the bands legible while scrolling sideways. */}
          {bands.map((b, i) => (
            <line key={`r${i}`} x1={b.x - 14} y1={30} x2={b.x - 14} y2={H - 6}
              stroke="var(--border)" strokeWidth="1" opacity="0.5" />
          ))}
          {graph.edges.map((e, i) => {
            const a = pos[e.source], b = pos[e.target]
            if (!a || !b) return null
            const searchActive = !q || (matches.has(e.source) || matches.has(e.target))
            const active = (!hover || (connected.has(e.source) && connected.has(e.target))) && searchActive
            return (
              <path key={i}
                d={`M ${a.x} ${a.y} C ${(a.x + b.x) / 2} ${a.y}, ${(a.x + b.x) / 2} ${b.y}, ${b.x} ${b.y}`}
                stroke={REL_COLOR[e.rel] || '#555'} fill="none"
                strokeWidth={active && hover ? 1.8 : 0.8}
                opacity={active ? (hover ? 0.9 : 0.35) : 0.06} />
            )
          })}
          {graph.nodes.filter(n => pos[n.id]).map(n => {
            const p = pos[n.id]
            const meta = TYPE_META[n.ntype]
            const active = (!hover || connected.has(n.id)) && (!q || matches.has(n.id))
            const isFocus = focus === n.id
            const hop = nbhd ? nbhd.get(n.id) : null
            return (
              <g key={n.id} opacity={active ? 1 : 0.15}
                onMouseEnter={() => setHover(n.id)}
                onMouseLeave={() => setHover(null)}
                onClick={() => drill(n.id)}
                style={{ cursor: 'pointer' }}>
                {isFocus && (
                  <circle cx={p.x} cy={p.y} r={12} fill="none"
                    stroke={meta.color} strokeWidth={1.5} opacity={0.55}>
                    <animate attributeName="r" values="10;13;10" dur="2.4s"
                      repeatCount="indefinite" />
                  </circle>
                )}
                <circle cx={p.x} cy={p.y}
                  r={isFocus ? 9 : q && matches.has(n.id) ? 8 : n.ntype === 'metric' ? 7 : 5}
                  fill={meta.color}
                  fillOpacity={n.unmapped ? 0.35 : 1}
                  stroke={isFocus ? 'var(--accent)'
                    : n.certified ? 'var(--text)' : 'none'}
                  strokeWidth={isFocus ? 2 : 1.2} />
                {/* Always anchored 'start'. Right-anchored labels grew back
                    over the previous column as soon as names got long. */}
                <text x={p.x + 11} y={p.y + 4}
                  fill={isFocus ? 'var(--accent)' : 'var(--chart-label)'}
                  fontSize="11" fontWeight={isFocus ? 700 : 400}
                  textAnchor="start">
                  {n.label}{n.certified ? ' ✓' : ''}
                </text>
                <title>
                  {n.id}{n.description ? `\n${n.description}` : ''}
                  {hop != null ? `\n${hop === 0 ? 'focused node'
                    : hop + ' hop' + (hop > 1 ? 's' : '') + ' away'}` : ''}
                  {'\nClick to drill into this node'}
                </title>
              </g>
            )
          })}
        </svg>
      </div>
      <span style={{ fontSize: 11, color: 'var(--muted)' }}>
        ✓ = certified metric definition (owned by a governance team). Hover to
        highlight multi-hop paths; click to drill in.
      </span>

      {focus && <FocusPanel graph={graph} focus={focus} onDrill={drill} />}

      <RelationshipInsights graph={graph} />
    </div>
  )
}

// The focused node in words: what it is, and everything it touches grouped by
// relationship. The SVG shows the SHAPE of a neighbourhood; this reads it out,
// which is what someone answering "what would break if I changed this metric?"
// actually needs. Every neighbour is itself a drill target, so the graph can
// be walked entirely from here without hunting for a 5px circle.
function FocusPanel({ graph, focus, onDrill }) {
  const byId = Object.fromEntries(graph.nodes.map(n => [n.id, n]))
  const node = byId[focus]
  if (!node) return null

  // Group by relationship AND direction — "governs" and "is governed by" are
  // very different facts, and collapsing them would misreport lineage.
  const groups = {}
  for (const e of graph.edges) {
    let other = null, dir = ''
    if (e.source === focus) { other = e.target; dir = '→' }
    else if (e.target === focus) { other = e.source; dir = '←' }
    if (!other || !byId[other]) continue
    const key = `${e.rel} ${dir}`
    ;(groups[key] = groups[key] || []).push({ node: byId[other], on: e.on })
  }
  const entries = Object.entries(groups)

  return (
    <div className="graph-focus-panel fade-in">
      <div className="graph-focus-head">
        <span className="graph-focus-dot"
          style={{ background: (TYPE_META[node.ntype] || {}).color }} />
        <b>{node.label}</b>
        <span className="chip">{node.ntype}</span>
        {node.certified && <span className="chip chip-on">✓ certified</span>}
        {node.owner && <span className="graph-focus-owner">owned by {node.owner}</span>}
      </div>
      {node.description &&
        <p className="graph-focus-desc">{node.description}</p>}
      {node.formula &&
        <div className="graph-focus-formula">{node.formula}</div>}
      {node.citation &&
        <div className="graph-focus-cite">📎 {node.citation}</div>}

      {entries.length === 0 ? (
        <p className="graph-focus-desc">
          Nothing in the Brain connects to this node yet — it is grounded but
          unused, which is usually a modelling gap worth closing.
        </p>
      ) : (
        <div className="graph-focus-rels">
          {entries.map(([key, items]) => {
            const [rel, dir] = key.split(' ')
            return (
              <div key={key} className="graph-rel-group">
                <div className="graph-rel-label"
                  style={{ borderColor: REL_COLOR[rel] || '#555' }}>
                  {dir === '→' ? '' : 'is '}
                  {rel.toLowerCase().replace(/_/g, ' ')}
                  {dir === '→' ? '' : ' by'}
                  <span className="sidebar-count">{items.length}</span>
                </div>
                <div className="graph-rel-items">
                  {items.map(({ node: nb, on }, i) => (
                    <button key={nb.id + i} className="graph-rel-item"
                      title={`Drill into ${nb.label}`}
                      onClick={() => onDrill(nb.id)}>
                      <span className="graph-focus-dot small"
                        style={{ background: (TYPE_META[nb.ntype] || {}).color }} />
                      {nb.label}
                      {on && <span className="graph-rel-on">ON {on}</span>}
                    </button>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// Entity & relationship insights extracted from the knowledge graph.
function RelationshipInsights({ graph }) {
  const byId = Object.fromEntries(graph.nodes.map(n => [n.id, n]))
  const joins = graph.edges.filter(e => e.rel === 'JOINS_ON')
  const metrics = graph.nodes.filter(n => n.ntype === 'metric')
  const derived = graph.edges.filter(e => e.rel === 'DERIVED_FROM')
  const synonyms = graph.edges.filter(e => e.rel === 'SYNONYM_OF')

  const synsFor = (id) => synonyms
    .filter(e => e.target === id)
    .map(e => byId[e.source]?.label).filter(Boolean)

  return (
    <div style={{ marginTop: 16 }}>
      <h3>Entity &amp; relationship insights</h3>

      <div style={{ marginTop: 8 }}>
        <b style={{ fontSize: 13 }}>Entity relationships (joins)</b>
        {joins.map((e, i) => (
          <div key={i} style={{ fontSize: 12.5, margin: '4px 0', paddingLeft: 8, borderLeft: '2px solid #a76bf2' }}>
            <b>{e.source}</b> ↔ <b>{e.target}</b>
            <span style={{ fontFamily: 'monospace', color: 'var(--muted)', marginLeft: 8 }}>
              ON {e.on}
            </span>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 12 }}>
        <b style={{ fontSize: 13 }}>Metric derivations (lineage)</b>
        {metrics.map(m => (
          <div key={m.id} style={{ fontSize: 12.5, margin: '6px 0', paddingLeft: 8, borderLeft: '2px solid #3ecf8e' }}>
            <b>{m.label}</b>{m.certified ? ' ✓' : ''}
            {m.owner && <span style={{ color: 'var(--muted)' }}> — owned by {m.owner}</span>}
            <div style={{ fontFamily: 'monospace', fontSize: 11.5, color: 'var(--accent)' }}>
              {m.formula}
            </div>
            <div style={{ color: 'var(--muted)' }}>
              derives from: {derived.filter(e => e.source === m.id).map(e => byId[e.target]?.label || e.target).join(', ')}
              {synsFor(m.id).length > 0 && <> · answers to: "{synsFor(m.id).join('", "')}"</>}
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 12, fontSize: 12, color: 'var(--muted)' }}>
        {graph.nodes.filter(n => n.ntype === 'term').length} business terms map onto{' '}
        {metrics.length} governed metrics across{' '}
        {graph.nodes.filter(n => n.ntype === 'table').length} entities — every question
        is resolved through these relationships before SQL is generated.
      </div>
    </div>
  )
}
