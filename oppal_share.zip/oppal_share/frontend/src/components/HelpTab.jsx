import React, { useEffect, useMemo, useState } from 'react'
import { HELP_TABS } from '../help/helpData.js'

// About — "which build is this?" answered from the running system.
// Every value is fetched from GET /api/about rather than hardcoded in the
// frontend, so the panel cannot drift from the backend the way a duplicated
// version string does. Renders nothing if the call fails: a Help tab that
// still works is better than one that errors over a version banner.
function AboutPanel() {
  const [about, setAbout] = useState(null)
  useEffect(() => {
    fetch('/api/about').then(r => r.ok ? r.json() : null)
      .then(setAbout).catch(() => {})
  }, [])
  if (!about) return null
  const row = (label, value, title) => (
    <div style={{ display: 'flex', gap: 8, padding: '3px 0' }} title={title || ''}>
      <span style={{ color: 'var(--muted)', minWidth: 132 }}>{label}</span>
      <b style={{ fontFamily: label === 'Brain fingerprint' || label === 'Ledger head'
        ? 'ui-monospace, monospace' : 'inherit' }}>{value}</b>
    </div>
  )
  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <h3>ℹ️ About this build</h3>
      <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
        Quote the version below in any bug report — it identifies exactly
        which code produced the behaviour you are seeing.
      </p>
      <div style={{ fontSize: 12.5 }}>
        {row('Version', about.version_string || `v${about.version}`)}
        {row('Released', about.build_date)}
        {row('LLM provider', about.llm_provider || 'mock')}
        {row('Brain domain',
          `${about.brain_domain}` +
          (about.brain_metrics != null
            ? ` · ${about.brain_metrics} metrics · ${about.brain_policy_rules} policy rules`
            : ''))}
        {about.brain_fingerprint
          ? row('Brain fingerprint', about.brain_fingerprint + '…',
              'SHA of the semantic layer that answers are grounded in')
          : null}
        {about.ledger_verified != null && row('Audit ledger',
          <span style={{ color: about.ledger_verified ? 'var(--good)' : 'var(--bad)' }}>
            {about.ledger_verified ? '✓ verified' : '✗ CHAIN BROKEN'}
            {about.ledger_blocks != null ? ` · ${about.ledger_blocks} blocks` : ''}
          </span>)}
        {about.ledger_head ? row('Ledger head', about.ledger_head + '…') : null}
      </div>
      {about.release_note && (
        <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 10,
          borderTop: '1px solid var(--border)', paddingTop: 8 }}>
          <b>This release: </b>{about.release_note}
        </p>
      )}
    </div>
  )
}

// In-app Help & Playbooks — searchable field reference and operator playbooks
// for every tab. Content is generated from the same source as the Operational
// Guide, so it stays in step with the real UI.
export default function HelpTab() {
  const [q, setQ] = useState('')
  const [openTab, setOpenTab] = useState(HELP_TABS[0] ? HELP_TABS[0].id : null)

  const query = q.trim().toLowerCase()

  // filter fields/tabs by the query; a tab shows if its name, purpose,
  // importance, playbook or any field matches
  const results = useMemo(() => {
    if (!query) return HELP_TABS.map(t => ({ tab: t, fields: t.fields }))
    const hit = (s) => (s || '').toLowerCase().includes(query)
    return HELP_TABS.map(t => {
      const tabHit = hit(t.name) || hit(t.purpose) || hit(t.importance)
        || (t.playbook || []).some(hit)
      const fields = (t.fields || []).filter(f =>
        hit(f.label) || hit(f.what) || hit(f.example) || hit(f.why))
      if (tabHit || fields.length) {
        return { tab: t, fields: fields.length ? fields : t.fields }
      }
      return null
    }).filter(Boolean)
  }, [query])

  const totalFields = HELP_TABS.reduce((a, t) => a + t.fields.length, 0)

  return (
    <div className="fade-in help-tab">
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>📖 Help &amp; Playbooks</h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 12px' }}>
          Every tab, every field, with a small example and why it matters to a
          payer — plus an operator playbook per tab. {HELP_TABS.length} tabs,{' '}
          {totalFields} fields. Search across all of it.
        </p>
        <input
          className="settings-input help-search"
          style={{ width: '100%', maxWidth: 460 }}
          placeholder="Search help — e.g. 'trust score', 'dual control', 'MLR', 'reject'…"
          value={q}
          onChange={e => setQ(e.target.value)}
        />
        {query && (
          <p style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 8 }}>
            {results.length} tab(s) match “{q}”.
          </p>
        )}
      </div>

      {/* Hidden while searching so it never sits between the query and its
          results — it is reference information, not a search hit. */}
      {!query && <AboutPanel />}

      {!query && (
        <div className="card help-jump" style={{ marginBottom: 16 }}>
          <b style={{ fontSize: 12.5 }}>Jump to a tab</b>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
            {HELP_TABS.map(t => (
              <button key={t.id}
                className={`chip ${openTab === t.id ? 'chip-on' : ''}`}
                onClick={() => setOpenTab(t.id)}>
                {t.icon} {t.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {results
        .filter(({ tab }) => query || tab.id === openTab)
        .map(({ tab, fields }) => (
        <div key={tab.id} className="card help-card" style={{ marginBottom: 16 }}>
          <h3 style={{ marginBottom: 2 }}>{tab.icon} {tab.name}
            <span style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 400 }}>
              {'  '}· {tab.group}
            </span>
          </h3>
          <p style={{ fontSize: 12.5, margin: '6px 0' }}>{tab.purpose}</p>

          <div className="help-importance" style={{
            background: 'var(--panel2)', borderRadius: 8, padding: '8px 12px',
            fontSize: 12, margin: '8px 0' }}>
            <b>Business importance —</b> {tab.importance}
          </div>

          {tab.playbook && tab.playbook.length > 0 && (
            <div style={{ margin: '10px 0' }}>
              <b style={{ fontSize: 12.5 }}>Operator playbook</b>
              <ol style={{ margin: '6px 0 0', paddingLeft: 20, fontSize: 12 }}>
                {tab.playbook.map((step, i) => (
                  <li key={i} style={{ marginBottom: 3 }}>{step}</li>
                ))}
              </ol>
            </div>
          )}

          <table className="cohort-table" style={{ marginTop: 10 }}>
            <thead>
              <tr><th>Field</th><th>What it does</th>
                  <th>Example</th><th>Why it matters</th></tr>
            </thead>
            <tbody>
              {fields.map(f => (
                <tr key={f.id}>
                  <td style={{ whiteSpace: 'nowrap' }}><b>{f.label}</b>
                    <div style={{ fontSize: 10.5, color: 'var(--muted)' }}>{f.type}</div>
                  </td>
                  <td style={{ fontSize: 11.5 }}>{f.what}</td>
                  <td style={{ fontSize: 11.5, fontStyle: 'italic',
                               color: 'var(--muted)' }}>
                    {f.example || '—'}
                  </td>
                  <td style={{ fontSize: 11.5 }}>{f.why}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}

      {query && results.length === 0 && (
        <div className="card">
          <p style={{ color: 'var(--muted)' }}>
            No help matches “{q}”. Try a governed term like “MLR”, “dual
            control”, “provenance”, or a tab name.
          </p>
        </div>
      )}
    </div>
  )
}
