import React, { useEffect, useState } from 'react'

// Phase 3 — persistent case queue produced by the swarm. Triage states only;
// approval and write-back to the core-admin system are Phase 4.
// pattern -> dual-control action type. Kept in step with the same map in
// CasesTabCards.jsx, which is the view App.jsx currently renders — see the
// longer note there on why an unmapped sales pattern would silently receive
// single control instead of dual.
const PATTERN_ACTION_TYPE = {
  timeliness_breach: 'universe_resubmission',
  thermal_excursion: 'quarantine_hold',
  chargeback_over_claim: 'chargeback_recovery',
  lead_quality_collapse: 'lead_source_suspension',
  funnel_fallout: 'campaign_pause',
  agent_effectuation_outlier: 'agent_remediation',
  retention_leakage: 'enrollment_reconciliation',
  compensation_overpayment: 'commission_recovery',
  certification_lapse: 'agent_suspension',
}

export default function CasesTab() {
  const [data, setData] = useState(null)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [msg, setMsg] = useState('')

  const load = () => {
    const p = status ? `?status=${encodeURIComponent(status)}` : ''
    fetch(`/api/cases${p}`).then(r => r.json()).then(setData).catch(() => {})
  }
  useEffect(load, [status])

  const proposeAction = async (cse) => {
    setMsg('')
    const r = await fetch('/api/actions/propose', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        case_id: cse.case_id,
        // Each domain declares its own dual-control action types (see
        // policy_rules.md); this maps the finding pattern that opened the
        // case to the matching one. Falls back to the payer default for any
        // pattern not listed here rather than guessing.
        action_type: PATTERN_ACTION_TYPE[cse.pattern] || 'overpayment_recovery',
        summary: `Remediate ${(cse.pattern || '').replace(/_/g, ' ')} for ${cse.subject}`,
        fields: { case_id: cse.case_id, subject: cse.subject,
          amount: cse.estimated_impact }
      })
    })
    const out = await r.json().catch(() => ({}))
    setMsg(r.ok
      ? `Proposed ${out.action_id} (${out.control_mode} control) — review it in the Actions tab`
      : (out.detail || 'Could not propose action'))
  }

  const setCaseStatus = async (id, newStatus) => {
    setMsg('')
    const r = await fetch(`/api/cases/${id}/status`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    })
    if (r.ok) { setMsg(`${id} → ${newStatus}`); load() }
    else {
      const e = await r.json().catch(() => ({}))
      setMsg(e.detail || 'Not permitted')
    }
  }

  if (!data) return <div className="thinking">loading cases…</div>
  const term = q.trim().toLowerCase()
  const cases = (data.cases || []).filter(c =>
    !term || c.case_id.toLowerCase().includes(term) ||
    (c.subject || '').toLowerCase().includes(term) ||
    (c.pattern || '').toLowerCase().includes(term) ||
    (c.detail || '').toLowerCase().includes(term))
  const s = data.summary || {}

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3>📁 Case Queue</h3>
          <span className="chip">{s.total || 0} in your scope</span>
          <span className="chip">${(s.estimated_impact || 0).toLocaleString()} est. impact</span>
          <div style={{ flex: 1 }} />
          <select className="settings-input" style={{ maxWidth: 150 }}
            value={status} onChange={e => setStatus(e.target.value)}>
            <option value="">All statuses</option>
            {(data.states || []).map(st => <option key={st} value={st}>{st}</option>)}
          </select>
          <input className="settings-input" style={{ maxWidth: 240 }}
            placeholder="Search cases…" value={q}
            onChange={e => setQ(e.target.value)} />
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          Cases are created and de-duplicated by the swarm, scoped to your line
          of business. Approval and write-back to the core-admin system are
          human-in-the-loop (Phase 4).
        </p>
        {msg && <div className="brain-status ok" style={{ marginTop: 8 }}>{msg}</div>}
      </div>

      <div className="card">
        <table className="data-grid" style={{ width: '100%' }}>
          <thead>
            <tr><th>Case</th><th>Type</th><th>Subject</th><th>Pattern</th>
              <th>Sev</th><th>Trust</th><th>Impact</th><th>Status</th><th>Triage</th>
              <th>Action</th></tr>
          </thead>
          <tbody>
            {cases.map(c => (
              <tr key={c.case_id}>
                <td style={{ fontFamily: 'monospace', fontSize: 11.5 }}>{c.case_id}</td>
                <td style={{ fontSize: 11.5 }}>{c.case_type}</td>
                <td style={{ fontFamily: 'monospace', fontSize: 11.5 }}>{c.subject}</td>
                <td style={{ fontSize: 11.5 }}>{(c.pattern || '').replace(/_/g, ' ')}</td>
                <td><span className="chip" style={{
                  color: c.severity === 'critical' ? 'var(--bad)' : 'var(--muted)'
                }}>{c.severity}</span></td>
                <td style={{ fontSize: 11.5 }}>{Math.round((c.trust_score || 0) * 100)}%</td>
                <td style={{ fontSize: 11.5, color: 'var(--bad)' }}>
                  {c.estimated_impact ? `$${Math.round(c.estimated_impact).toLocaleString()}` : '—'}</td>
                <td><span className={`chip ${c.status === 'open' ? 'chip-on' : ''}`}>{c.status}</span></td>
                <td>
                  <select className="settings-input" style={{ maxWidth: 130, fontSize: 11 }}
                    value={c.status}
                    onChange={e => setCaseStatus(c.case_id, e.target.value)}>
                    {(data.states || []).map(st => <option key={st} value={st}>{st}</option>)}
                  </select>
                </td>
                <td>
                  <button className="chip" style={{ fontSize: 11 }}
                    onClick={() => proposeAction(c)}>propose ▸</button>
                </td>
              </tr>
            ))}
            {cases.length === 0 && (
              <tr><td colSpan={10} style={{ color: 'var(--muted)' }}>
                No cases {q ? `match “${q}”` : 'yet — run the swarm to open cases'}.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
