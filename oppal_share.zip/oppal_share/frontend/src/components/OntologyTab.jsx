import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

// Phase 2 — Open Graph RAG ontology + CAPS integration surface.
// Searchable object types / edges and per-vendor CAPS staging coverage.
export default function OntologyTab() {
  const [ont, setOnt] = useState(null)
  const [caps, setCaps] = useState(null)
  const [q, setQ] = useState('')
  const [vendor, setVendor] = useState('')

  useEffect(() => {
    fetch('/api/ontology').then(r => r.json()).then(setOnt).catch(() => {})
    fetch('/api/caps').then(r => r.json()).then(d => {
      setCaps(d); setVendor(d.active_vendor)
    }).catch(() => {})
  }, [])

  if (!ont) return <div className="thinking">loading ontology…</div>
  const term = q.trim().toLowerCase()
  const nodes = (ont.nodes || []).filter(n =>
    !term || n.id.toLowerCase().includes(term) ||
    (n.source_of_truth || '').toLowerCase().includes(term) ||
    (n.pillar_attributes || []).some(a => a.toLowerCase().includes(term)))
  const edges = (ont.edges || []).filter(e =>
    !term || e.from.toLowerCase().includes(term) ||
    e.to.toLowerCase().includes(term) || (e.type || '').toLowerCase().includes(term))
  const cov = caps?.coverage?.[vendor] || {}

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3>🧬 Object Ontology<InfoDot id="ontology.caps_staging_binding_table" /></h3>
          <span className="chip">v{ont.version}</span>
          <span className={`chip ${ont.validation?.ok ? 'chip-on' : ''}`}>
            {ont.validation?.ok ? 'validated' : `${ont.validation?.warnings?.length || 0} warnings`}
          </span>
          <div style={{ flex: 1 }} />
          <input className="settings-input" style={{ maxWidth: 260 }}
            placeholder="Search object types / edges / pillar attrs…"
            value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          The formal object model the Graph RAG reasons over. Pillar-tagged
          attributes power the mid-market operational modules.
        </p>
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <b style={{ fontSize: 13 }}>Object types <span className="sidebar-count">{nodes.length}</span></b>
        <table className="data-grid" style={{ width: '100%', marginTop: 6 }}>
          <thead><tr><th>Type</th><th>Source</th><th>Phase</th><th>Attrs</th><th>Pillar attributes</th></tr></thead>
          <tbody>
            {nodes.map(n => (
              <tr key={n.id}>
                <td style={{ fontFamily: 'monospace' }}>{n.id}</td>
                <td style={{ fontSize: 12 }}>{n.source_of_truth || '—'}</td>
                <td>{n.planned_phase > 1
                  ? <span className="chip">phase {n.planned_phase}</span>
                  : <span className="chip chip-on">live</span>}</td>
                <td>{n.attribute_count}</td>
                <td style={{ fontSize: 11.5, color: 'var(--accent)' }}>
                  {(n.pillar_attributes || []).join(', ') || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <b style={{ fontSize: 13 }}>Edges <span className="sidebar-count">{edges.length}</span></b>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
          {edges.map((e, i) => (
            <span key={i} className="chip" style={{ fontSize: 11.5 }}>
              {e.from} —{e.type}→ {e.to}
            </span>
          ))}
        </div>
      </div>

      {caps && (
        <div className="card">
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <b style={{ fontSize: 13 }}>🔌 CAPS staging bindings</b>
            <select className="settings-input" style={{ maxWidth: 180 }}
              value={vendor} onChange={e => setVendor(e.target.value)}>
              {(caps.vendors || []).map(v => (
                <option key={v} value={v}>{v}{v === caps.active_vendor ? ' (active)' : ''}</option>
              ))}
            </select>
          </div>
          <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 8px' }}>
            Pre-mapped bindings to standard mid-market core-admin systems. Bind a
            client's read-only staging views — no custom ETL.
          </p>
          <table className="data-grid" style={{ width: '100%' }}>
            <thead><tr><th>Object</th><th>Staging view</th><th>Mapped</th><th>Coverage</th></tr></thead>
            <tbody>
              {Object.entries(cov).map(([obj, c]) => (
                <tr key={obj}>
                  <td style={{ fontFamily: 'monospace' }}>{obj}</td>
                  <td style={{ fontSize: 12 }}>{c.view}</td>
                  <td style={{ fontSize: 11.5 }}>{(c.mapped || []).length} cols</td>
                  <td><span className={`chip ${c.coverage_pct >= 50 ? 'chip-on' : ''}`}>{c.coverage_pct}%</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
