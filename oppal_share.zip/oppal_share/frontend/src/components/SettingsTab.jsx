import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'

const LLM_FIELDS = {
  mock: [],
  anthropic: [['api_key', 'API key'], ['model', 'Model (default claude-sonnet-5)']],
  openai: [['api_key', 'API key'], ['model', 'Model (default gpt-4o)'],
    ['endpoint', 'Base URL (optional)']],
  gemini: [['api_key', 'API key'], ['model', 'Model (default gemini-3.6-flash)']],
  azure: [['api_key', 'API key'], ['endpoint', 'Endpoint URL'],
    ['deployment', 'Deployment name']],
}

const PHI_SAMPLE = 'Member M-004217 (SSN 123-45-6789, jane.doe@mail.com, ' +
  '555-867-5309) saw Dr. Maya B. — claim C-0012345 at PR-017.'

// Configuration: LLM provider + keys, warehouse connection, privacy, theme.
export default function SettingsTab({ theme, setTheme, me }) {
  const [s, setS] = useState(null)
  const [status, setStatus] = useState({})
  const [phiDemo, setPhiDemo] = useState(null)
  // settings_write is compliance_officer-only server-side (auth.py); a
  // non-officer's save always 403s. Gate the UI so that shows up as a clear
  // banner instead of a save that silently fails and prints "undefined".
  const canWrite = !me || me.role === 'compliance_officer'
  // Switching the model the chat agents call is self-serve for every signed-in
  // user — the server accepts the `llm` section from anyone and ignores the
  // rest (see _SELF_SERVE_SETTINGS in main.py). Only the other panels, which
  // can weaken a real safeguard, stay officer-only.

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(setS).catch(() => {})
  }, [])
  if (!s) return <div className="thinking">loading settings…</div>

  const setLLM = (k, v) => setS({ ...s, llm: { ...s.llm, [k]: v } })
  const setData = (k, v) => setS({ ...s, data: { ...s.data, [k]: v } })
  const setParam = (k, v) => setS({
    ...s, data: { ...s.data, params: { ...s.data.params, [k]: v } }
  })
  const setCache = (k, v) => setS({ ...s, cache: { ...s.cache, [k]: v } })

  const save = async (then) => {
    // No client-side role guard. The LLM panel is reachable by everyone and
    // the other panels' buttons are already disabled, so the only caller a
    // non-officer can reach is the provider switch — which the server allows
    // and whose sections the server filters. Authorization stays server-side.
    let r, out
    try {
      r = await fetch('/api/settings', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ llm: s.llm, data: s.data,
          privacy: s.privacy, network: s.network, cache: s.cache,
          ui: { theme } })
      })
      out = await r.json()
    } catch (e) {
      setStatus(st => ({ ...st, save: `✗ Save failed — ${e.message || e}` }))
      return
    }
    if (!r.ok) {
      // A 403 (wrong role) or any other error returns {"detail": "..."},
      // which has no llm_provider key — showing that as "active provider:
      // undefined" instead of the real reason is what was reported.
      setStatus(st => ({ ...st, save:
        `✗ Save failed (${r.status}) — ${out?.detail || 'permission denied'}` }))
      return
    }
    // "gemini+phi-guard" is the internal wrapped-provider name (PHI
    // pseudonymization is on by default); show the clean provider id here.
    const provider = (out.llm_provider || '').replace(/\+phi-guard$/, '')
    setStatus(st => ({ ...st, save: `✓ Saved — active provider: ${provider}` }))
    if (then) then()
  }

  const testPHI = async () => {
    const r = await fetch('/api/privacy/preview', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: PHI_SAMPLE })
    })
    setPhiDemo(await r.json())
  }

  const testLLM = () => save(async () => {
    const r = await fetch('/api/settings/test-llm', { method: 'POST' })
    const out = await r.json()
    setStatus(st => ({ ...st, llm: `${out.ok ? '✓' : '✗'} ${out.message}` }))
  })

  const testData = () => save(async () => {
    const r = await fetch('/api/settings/test-data', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: s.data.type })
    })
    const out = await r.json()
    setStatus(st => ({ ...st, data: `${out.ok ? '✓' : '✗'} ${out.message}` }))
  })

  const connectors = s.connectors || {}
  const params = connectors[s.data.type]?.params || []

  return (
    <div>
      {!canWrite && (
        <div className="card" style={{ marginBottom: 16, borderColor: 'var(--warn, #c58a00)' }}>
          <b>🔒 Mostly read-only for your role.</b> You can switch the{' '}
          <b>LLM provider</b> below — that only changes which model answers,
          and every trust gate, policy rule and scoping rule applies either
          way. The data connection, cache, and PHI/TLS protections can only
          be changed by a Compliance Officer, so those Save buttons are
          disabled for {me.role}.
        </div>
      )}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>LLM provider<InfoDot id="settings.llm_provider_dropdown_fields" /></h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
          Agents call the selected provider and fall back to governed rule-based
          templates on failure — validation gates apply either way. Keys are stored
          locally in settings.json and never leave the backend.
        </p>
        <div className="settings-row">
          <label>Provider</label>
          <select className="settings-input" value={s.llm.provider}
            onChange={e => setLLM('provider', e.target.value)}>
            <option value="mock">Mock (offline, no key required)</option>
            <option value="anthropic">Anthropic Claude</option>
            <option value="openai">OpenAI</option>
            <option value="gemini">Google Gemini</option>
            <option value="azure">Azure OpenAI</option>
          </select>
        </div>
        {(LLM_FIELDS[s.llm.provider] || []).map(([k, label]) => (
          <div className="settings-row" key={k}>
            <label>{label}</label>
            <input className="settings-input" type={k === 'api_key' ? 'password' : 'text'}
              value={s.llm[k] || ''} placeholder={label}
              onChange={e => setLLM(k, e.target.value)} />
          </div>
        ))}
        <div style={{ borderTop: '1px solid var(--border)', marginTop: 14, paddingTop: 10 }}>
          <b style={{ fontSize: 13 }}>Network / corporate proxy</b>
          <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 6px' }}>
            On corporate networks (Zscaler/Netskope) TLS is re-signed and you'll see
            "certificate verify failed: self-signed certificate". Fix: point to your
            corporate root-CA .pem below (ask IT, or export it from your browser).
            Disabling verification is acceptable for POC testing only.
          </p>
          <div className="settings-row">
            <label>Corporate CA bundle (.pem)</label>
            <input className="settings-input"
              value={s.network?.ca_bundle || ''}
              placeholder="e.g. C:\\certs\\zscaler-root.pem or /etc/ssl/corp-ca.pem"
              onChange={e => setS({ ...s, network: { ...s.network, ca_bundle: e.target.value } })} />
          </div>
          <div className="settings-row">
            <label>SSL verification</label>
            <label style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
              <input type="checkbox" checked={s.network?.ssl_verify ?? true}
                onChange={e => setS({ ...s, network: { ...s.network, ssl_verify: e.target.checked } })} />
              Verify TLS certificates (untick only for POC on inspected networks)
            </label>
          </div>
        </div>
        <div style={{ marginTop: 10 }}>
          {/* Not gated on canWrite: picking the model is self-serve. */}
          <button className="primary-btn" onClick={() => save()}>Save</button>{' '}
          <button className="chip" onClick={testLLM}>Test LLM connection</button>
          {status.llm && <div className="status-line">{status.llm}</div>}
        </div>
      </div>

      <div className="card">
        <h3>Data connection</h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
          The demo runs on the bundled SQLite healthcare claims database. Point the
          executor at your warehouse for production — the semantic layer, agents and
          validation gates are engine-agnostic.
        </p>
        <div className="settings-row">
          <label>Source</label>
          <select className="settings-input" value={s.data.type}
            onChange={e => setData('type', e.target.value)}>
            {Object.entries(connectors).map(([k, v]) => (
              <option key={k} value={k}>{v.label}</option>
            ))}
          </select>
        </div>
        {params.map(p => (
          <div className="settings-row" key={p}>
            <label>{p.replace(/_/g, ' ')}</label>
            <input className="settings-input"
              type={/password|token|json/.test(p) ? 'password' : 'text'}
              value={s.data.params?.[p] || ''} placeholder={p}
              onChange={e => setParam(p, e.target.value)} />
          </div>
        ))}
        <div style={{ marginTop: 10 }}>
          <button className="primary-btn" onClick={() => save()} disabled={!canWrite}>Save</button>{' '}
          <button className="chip" onClick={testData} disabled={!canWrite}>Test connection</button>
          {status.data && <div className="status-line">{status.data}</div>}
        </div>
      </div>
      <div className="card" style={{ marginTop: 16 }}>
        <h3>Performance — semantic cache (Redis)</h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
          Frequent pulls (daily MLR, standard reject trends) are served from a
          semantic cache keyed on grounded meaning, skipping the agent pipeline
          and LLM entirely. Leave the URL empty for the in-process store; point
          at Redis for shared enterprise caching.
        </p>
        <div className="settings-row">
          <label>Redis URL</label>
          <input className="settings-input"
            placeholder="redis://localhost:6379/0 (empty = in-process cache)"
            value={s.cache?.redis_url || ''}
            onChange={e => setCache('redis_url', e.target.value)} />
        </div>
        <div className="settings-row">
          <label>Cache TTL (seconds)</label>
          <input className="settings-input" type="number"
            value={s.cache?.ttl_seconds ?? 900}
            onChange={e => setCache('ttl_seconds', Number(e.target.value) || 900)} />
        </div>
        <div style={{ marginTop: 10 }}>
          <button className="primary-btn" onClick={() => save()} disabled={!canWrite}>Save</button>
        </div>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h3>Privacy — PHI / PII protection</h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
          When enabled, member/claim/provider IDs, names, SSNs, phones, emails,
          DOBs and addresses are pseudonymized with deterministic tokens
          <b> before any prompt leaves the backend</b>. LLM responses are
          re-identified locally from an in-memory vault (never persisted).
          Mock mode sends nothing externally at all.
        </p>
        <div className="settings-row">
          <label>PHI protection</label>
          <label style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
            <input type="checkbox" checked={s.privacy?.phi_protection ?? true}
              onChange={e => setS({ ...s, privacy: { ...s.privacy, phi_protection: e.target.checked } })} />
            Scrub PHI/PII before every LLM call
          </label>
        </div>
        <div className="settings-row">
          <label>Data to LLM</label>
          <label style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
            <input type="checkbox" checked={s.privacy?.send_row_samples ?? true}
              onChange={e => setS({ ...s, privacy: { ...s.privacy, send_row_samples: e.target.checked } })} />
            Send scrubbed row samples for narration (uncheck = METADATA ONLY —
            the LLM sees schema/counts, never data values; visuals are always
            built locally in the browser)
          </label>
        </div>
        <div style={{ marginTop: 10 }}>
          <button className="primary-btn" onClick={() => save()} disabled={!canWrite}>Save</button>{' '}
          <button className="chip" onClick={testPHI}>Preview scrubbing</button>
        </div>
        {phiDemo && (
          <div className="panel" style={{ fontFamily: 'monospace', fontSize: 11.5 }}>
            <div><b>Original:</b> {PHI_SAMPLE}</div>
            <div style={{ marginTop: 6, color: 'var(--good)' }}>
              <b>Sent to LLM:</b> {phiDemo.scrubbed}</div>
            <div style={{ marginTop: 6 }}>
              <b>Detected:</b> {Object.entries(phiDemo.detected)
                .map(([k, v]) => `${k}×${v}`).join(', ')}</div>
            <div style={{ marginTop: 6, color: 'var(--muted)' }}>
              <b>Restored locally:</b> {phiDemo.restored}</div>
          </div>
        )}
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h3>Appearance</h3>
        <div className="settings-row">
          <label>Theme</label>
          <select className="settings-input" value={theme}
            onChange={e => setTheme(e.target.value)}>
            <option value="light">Light (default)</option>
            <option value="dark">Dark</option>
          </select>
        </div>
      </div>

      {status.save && <div className="status-line">{status.save}</div>}
    </div>
  )
}
