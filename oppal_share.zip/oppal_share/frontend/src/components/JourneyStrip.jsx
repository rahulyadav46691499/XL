import React, { useEffect, useState } from 'react'

// Animated query journey: which stops used internal algorithms vs the
// LLM vs cache vs the data engine. Replays the recorded trace with the
// real step order, then stays as an expandable strip.
const ENGINE_META = {
  internal: { color: 'var(--accent)', icon: '🧮', label: 'internal algorithm' },
  llm: { color: '#a76bf2', icon: '✨', label: 'LLM call' },
  cache: { color: 'var(--good)', icon: '⚡', label: 'semantic cache' },
  data: { color: 'var(--warn)', icon: '🗄', label: 'data engine' },
}
const STEP_LABELS = {
  access_control: 'RBAC', semantic_cache: 'Cache',
  semantic_grounding: 'Brain', intent_routing: 'Intent',
  cohort_scope: 'Cohort', sql_generation: 'SQL',
  validation_and_execute: 'Gates+Run', root_cause_analysis: 'Root-cause',
  visualization: 'Viz', insight_narration: 'Insight',
  trust_scoring: 'Trust', graceful_degradation: 'Gate ⛔',
  universe_pull: 'Universes', policy_validation: 'CMS Policy',
  cohort_parsing: 'Parse', auto_insights: 'Patterns',
}

export default function JourneyStrip({ audit }) {
  const [lit, setLit] = useState(0)
  const [hover, setHover] = useState(null)
  const steps = (audit || []).filter(s => STEP_LABELS[s.step])

  useEffect(() => {
    setLit(0)
    if (!steps.length) return
    let i = 0
    const timer = setInterval(() => {
      i += 1
      setLit(i)
      if (i >= steps.length) clearInterval(timer)
    }, 160)
    return () => clearInterval(timer)
  }, [audit])

  if (!steps.length) return null

  return (
    <div className="journey">
      <div className="journey-track">
        {steps.map((s, i) => {
          const meta = ENGINE_META[s.engine] || ENGINE_META.internal
          const on = i < lit
          return (
            <React.Fragment key={i}>
              {i > 0 && <span className={`journey-link ${on ? 'on' : ''}`} />}
              <button className={`journey-node ${on ? 'on' : ''}`}
                style={{ '--node-color': meta.color }}
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(null)}>
                <span className="journey-icon">{meta.icon}</span>
                <span className="journey-label">{STEP_LABELS[s.step]}</span>
                {s.engine === 'llm' && s.tokens > 0 &&
                  <span className="journey-tok">{s.tokens}t</span>}
                {hover === i && (
                  <span className="journey-tip">
                    <b>{s.agent}</b><br />
                    {meta.label}{s.tokens ? ` · ${s.tokens} tokens` : ''} · {s.ms}ms
                  </span>
                )}
              </button>
            </React.Fragment>
          )
        })}
      </div>
      <div className="journey-legend">
        {Object.entries(ENGINE_META).map(([k, m]) => (
          <span key={k} style={{ color: m.color }}>{m.icon} {m.label}</span>
        ))}
      </div>
    </div>
  )
}
