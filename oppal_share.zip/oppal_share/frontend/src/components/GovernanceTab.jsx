import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'
import AgentAclPanel from './AgentAclPanel.jsx'
import ProvenancePanel from './ProvenancePanel.jsx'
import GuardrailCatalogue from './GuardrailCatalogue.jsx'

// Audit ledger (hash-chained) + human review queue, both searchable, plus the
// two governance-of-AI views: who may invoke which agent, and how each answer
// was produced.
export default function GovernanceTab() {
  const [entries, setEntries] = useState(null)
  const [queue, setQueue] = useState([])
  const [q, setQ] = useState('')
  const [error, setError] = useState('')

  const load = () => {
    fetch('/api/audit-log', {})
      .then(r => r.json())
      .then(d => { setEntries(d.entries || []); setError(d.error || '') })
      .catch(() => {})
    fetch('/api/review-queue').then(r => r.json())
      .then(d => setQueue(d.items || [])).catch(() => {})
  }
  useEffect(() => { load() }, [])

  const resolve = async (id) => {
    await fetch(`/api/review-queue/${id}/resolve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resolution: 'reviewed by analyst' })
    })
    load()
  }

  const match = (e) => !q ||
    JSON.stringify(e).toLowerCase().includes(q.toLowerCase())

  return (
    <div className="fade-in">
      <AgentAclPanel />
      <GuardrailCatalogue />
      <ProvenancePanel />
      <div className="card" style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
          <h3>Human review queue ({queue.filter(i => i.status === 'open').length} open)<InfoDot id="governance.audit_ledger_list" /></h3>
          <button className="chip" onClick={() => load()}>↻ refresh</button>
        </div>
        {queue.length === 0 && <p style={{ color: 'var(--muted)', marginTop: 6 }}>
          Empty — degraded/refused queries land here for triage.</p>}
        {queue.map(i => (
          <div key={i.id} className="queue-item">
            <span className={`badge ${i.status === 'open' ? 'med' : 'high'}`}>
              #{i.id} {i.status}
            </span>
            <div style={{ flex: 1 }}>
              <b>{i.question}</b>
              <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                {i.ts} · {i.user_id} · {i.reason}
              </div>
            </div>
            {i.status === 'open' &&
              <button className="chip" onClick={() => resolve(i.id)}>✓ resolve</button>}
          </div>
        ))}
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
          <h3>Audit ledger (hash-chained, HIPAA §164.312(b))</h3>
          <input className="settings-input" style={{ maxWidth: 260 }}
            placeholder="Search ledger…" value={q}
            onChange={e => setQ(e.target.value)} />
        </div>
        {error && <p style={{ color: 'var(--warn)', marginTop: 6 }}>🔒 {error}</p>}
        {!error && entries && (
          <div className="ledger">
            {entries.filter(match).slice().reverse().map((e, i) => (
              <div key={i} className={`ledger-row ${e.kind}`}>
                <span className="ledger-ts">{(e.ts || '').slice(11, 19)}</span>
                <span className={`ledger-kind k-${e.kind}`}>{e.kind}</span>
                <span className="ledger-body">
                  {e.kind === 'http' && <>{e.method} {e.path} → {e.status_code} · {e.latency_ms}ms · <b>{e.user_id}</b></>}
                  {e.kind === 'agent_trace' && <>"{e.prompt_scrubbed}" · trust {e.trust_score} · {e.steps?.length} steps · <b>{e.user_id}</b>{e.generated_sql && <span className="ledger-sql"> · {e.generated_sql.slice(0, 90)}…</span>}</>}
                  {e.kind === 'usage' && <>{e.tokens_in}/{e.tokens_out} tok · ${e.est_cost_usd} · {e.rows_scanned} rows · {e.latency_ms}ms{e.cache_hit ? ' · ⚡cache' : ''} · <b>{e.user_id}</b></>}
                  {e.kind === 'brain' && <>🧠 Brain rebuilt — domain <b>{e.domain}</b> · {e.report}{e.errors?.length ? ` · ⚠ ${e.errors.length} errors` : ''} · by <b>{e.user_id}</b></>}
                  {e.kind === 'quality' && <>🩺 Imputation — <b>{e.table}.{e.column}</b> ← {e.fill_value} ({e.method}) · {e.rows_filled} rows · by <b>{e.user_id}</b></>}
                </span>
                <span className="ledger-hash" title={`prev: ${e.prev_hash}`}>#{e.record_hash}</span>
              </div>
            ))}
            {entries.length === 0 && <p style={{ color: 'var(--muted)' }}>Ledger empty.</p>}
          </div>
        )}
      </div>
    </div>
  )
}
