import React, { useEffect, useState } from 'react'

// Agents and MCP tools as securable objects (Upgrade 2).
//
// "You grant access to an agent the way you grant access to a table" is only a
// real claim if an auditor can SEE the grants — this panel is that view.
// Lives inside the Governance tab rather than as an 18th tab: governing the AI
// belongs next to the audit ledger, not in its own silo.
export default function AgentAclPanel() {
  const [acl, setAcl] = useState(null)
  const [denied, setDenied] = useState(false)
  const [showTools, setShowTools] = useState(false)

  const load = () => {
    fetch('/api/governance/agent-acl')
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(d => { setAcl(d); setDenied(false) })
      .catch(() => setDenied(true))
  }
  useEffect(() => { load() }, [])

  if (denied) return (
    <div className="card" style={{ marginBottom: 16 }}>
      <h3>Agent &amp; tool grants</h3>
      <p style={{ color: 'var(--muted)', marginTop: 6 }}>
        Requires the audit_read permission — sign in as a compliance officer to
        review the grant matrix.
      </p>
    </div>
  )
  if (!acl) return null

  const agents = Object.entries(acl.agents || {})
  const tools = Object.entries(acl.tools || {})
  // Never dereference a field that arrived over the wire without a fallback:
  // one absent granted_to_roles would throw inside render and white-screen the
  // whole tree, not just this panel.
  const rolesOf = (v) => (v && Array.isArray(v.granted_to_roles))
    ? v.granted_to_roles : []
  const officerOnly = (roles) =>
    (roles || []).length === 1 && roles[0] === 'compliance_officer'

  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between',
                    alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <h3>Agent &amp; tool grants ({agents.length} agents · {tools.length} tools)</h3>
        <button className="chip" onClick={() => load()}>↻ refresh</button>
      </div>
      <p style={{ color: 'var(--muted)', fontSize: 12, marginTop: 6 }}>
        {acl.policy}. The mapping is pinned in code — a grant declared in
        agents.md is honoured only if it is no wider than the code floor.
      </p>

      <table className="cohort-table" style={{ marginTop: 10 }}>
        <thead>
          <tr>
            <th>Agent</th><th>Required permission</th>
            <th>Granted to</th><th>Source</th>
          </tr>
        </thead>
        <tbody>
          {agents.map(([name, v]) => {
            const roles = rolesOf(v)
            return (
              <tr key={name}>
                <td><b>{name}</b></td>
                <td style={{ fontSize: 12 }}>{v?.required_permission || '—'}</td>
                <td>
                  <span className={`badge ${officerOnly(roles) ? 'high' : 'med'}`}>
                    {officerOnly(roles)
                      ? 'compliance officer only'
                      : `${roles.length} roles`}
                  </span>
                </td>
                <td style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                  {v?.overlay_applied ? 'agents.md (tightened)' : 'code floor'}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>

      <button className="chip" style={{ marginTop: 10 }}
              onClick={() => setShowTools(s => !s)}>
        {showTools ? '▾' : '▸'} MCP tool grants
      </button>
      {showTools && (
        <table className="cohort-table" style={{ marginTop: 8 }}>
          <thead><tr><th>Tool</th><th>Required permission</th><th>Granted to</th></tr></thead>
          <tbody>
            {tools.map(([name, v]) => {
              const roles = rolesOf(v)
              return (
                <tr key={name}>
                  <td>{name}</td>
                  <td style={{ fontSize: 12 }}>{v?.required_permission || '—'}</td>
                  <td>
                    <span className={`badge ${officerOnly(roles) ? 'high' : 'med'}`}>
                      {officerOnly(roles)
                        ? 'compliance officer only'
                        : `${roles.length} roles`}
                    </span>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      )}
    </div>
  )
}
