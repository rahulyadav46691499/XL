import React from 'react'
import { fieldHelp } from '../help/helpData.js'

// InfoDot — a small "?" that reveals a governed hover tooltip.
//
// One component, two ways to feed it:
//   <InfoDot id="chat.trust_panel" />        // pulls label/what/example/why
//   <InfoDot text="free text" example="..."/> // ad-hoc
//
// Pure CSS hover (see .info-dot in styles.css) — no positioning JS, so it
// cannot throw at render and can be dropped next to any label safely. The
// content is sourced from the SAME registry the Help tab renders, so a field's
// tooltip and its Help entry can never disagree.
export default function InfoDot({ id, text, example, label }) {
  const h = id ? fieldHelp(id) : null
  const title = label || (h && h.label) || ''
  const what = text || (h && h.what) || ''
  const ex = example || (h && h.example) || ''
  const why = (h && h.why) || ''
  if (!what && !why) return null
  return (
    <span className="info-dot" tabIndex={0} aria-label={`Help: ${title || what}`}>
      <span className="info-dot-mark" aria-hidden="true">?</span>
      <span className="info-tip" role="tooltip">
        {title && <b className="info-tip-title">{title}</b>}
        {what && <span className="info-tip-what">{what}</span>}
        {ex && <span className="info-tip-ex">e.g. {ex}</span>}
        {why && <span className="info-tip-why">Why it matters: {why}</span>}
      </span>
    </span>
  )
}
