import React, { useEffect, useState } from 'react'
import InfoDot from './InfoDot.jsx'
import DataGrid from './DataGrid.jsx'

const METHOD_LABELS = {
  mean: 'Mean (numeric average)',
  median: 'Median (robust to outliers)',
  mode: 'Mode (most frequent value)',
  cohort: 'Similar-cohort fill (group mean/mode by region/plan/type)',
}

// Data Quality: missing-data view with imputation + anomaly-data view.
export default function DataQualityTab({ onAsk }) {
  const [missing, setMissing] = useState(null)
  const [anoms, setAnoms] = useState(null)
  const [methods, setMethods] = useState({})
  const [status, setStatus] = useState({})
  const [history, setHistory] = useState([])

  const load = () => {
    fetch('/api/quality/missing').then(r => r.json())
      .then(d => setMissing(d.report)).catch(() => {})
    fetch('/api/quality/anomalies').then(r => r.json())
      .then(setAnoms).catch(() => {})
    fetch('/api/quality/history').then(r => r.json())
      .then(d => setHistory(d.items || [])).catch(() => {})
  }

  const preview = async (row) => {
    const key = `${row.table}.${row.column}`
    const method = methods[key] || row.techniques[0]
    const r = await fetch('/api/quality/impute', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ table: row.table, column: row.column,
        method, dry_run: true })
    })
    const out = await r.json()
    setStatus(st => ({ ...st,
      [key]: out.ok ? `👁 ${out.message}` : `✗ ${out.error}` }))
  }
  useEffect(() => { load() }, [])

  const applyImpute = async (row) => {
    const key = `${row.table}.${row.column}`
    const method = methods[key] || row.techniques[0]
    setStatus(st => ({ ...st, [key]: 'applying…' }))
    const r = await fetch('/api/quality/impute', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ table: row.table, column: row.column, method })
    })
    const out = await r.json()
    setStatus(st => ({
      ...st,
      [key]: out.ok
        ? `✓ filled ${out.filled.toLocaleString()} values (${out.method}: ${out.fill_value})`
        : `✗ ${out.error}`
    }))
    if (out.ok) load()
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>Missing data<InfoDot id="data_quality.missing_value_table" /></h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
          Every table and column is scanned for NULL/blank values. Pick a fill
          technique per column — numeric columns support mean/median, categorical
          columns support mode, and <b>similar-cohort fill</b> imputes from rows
          sharing the same region/plan/claim-type group (usually the most faithful).
        </p>
        {!missing && <div className="thinking">scanning…</div>}
        {missing?.length === 0 &&
          <div style={{ color: 'var(--good)', fontSize: 13 }}>
            ✓ No missing values detected in any table.
          </div>}
        {missing?.length > 0 && (
          <div className="ui-cards" style={{ marginTop: 10 }}>
              {missing.map((row, i) => {
                const key = `${row.table}.${row.column}`
                // Severity stripe by how much is missing: >10% is a data
                // problem you should not silently impute over, so it reads red.
                const bar = row.pct > 10 ? 'bad' : row.pct > 2 ? 'warn' : ''
                return (
                  <div key={key} className="ui-card"
                    style={{ animationDelay: `${0.04 * (i + 1)}s` }}>
                    <div className={`ui-card-bar ${bar}`} />
                    <div className="ui-card-head">
                      <span className="ui-card-title">
                        {row.table}.{row.column}
                      </span>
                      <span className="ui-card-meta"
                        style={{ color: row.pct > 10 ? 'var(--bad)' : 'var(--warn)' }}>
                        {row.pct}%
                      </span>
                    </div>
                    <div className="ui-card-meta">
                      {row.type}{row.note && <> — {row.note}</>}
                    </div>
                    <div className="ui-card-kv">
                      <div><span>missing</span><b>{row.missing.toLocaleString()}</b></div>
                      <div><span>of total</span><b>{row.total.toLocaleString()}</b></div>
                    </div>
                    {/* Fill bar: proportion missing, shown as a shape so the
                        magnitude is legible without reading the number. */}
                    <div style={{ height: 4, borderRadius: 2, marginTop: 8,
                      background: 'var(--border)', overflow: 'hidden' }}>
                      <div style={{ width: `${Math.min(100, row.pct)}%`,
                        height: '100%',
                        background: row.pct > 10 ? 'var(--bad)' : 'var(--warn)' }} />
                    </div>
                    <div style={{ marginTop: 9 }}>
                      <label style={{ fontSize: 10, letterSpacing: '.05em',
                        textTransform: 'uppercase', color: 'var(--muted)' }}>
                        Fill technique
                      </label>
                      <select className="settings-input"
                        style={{ fontSize: 12, width: '100%', marginTop: 3 }}
                        value={methods[key] || row.techniques[0]}
                        onChange={e => setMethods({ ...methods, [key]: e.target.value })}>
                        {row.techniques.map(t => (
                          <option key={t} value={t}>{METHOD_LABELS[t] || t}</option>
                        ))}
                      </select>
                    </div>
                    {status[key] && (
                      <div style={{ fontSize: 11.5, marginTop: 5,
                        color: status[key].startsWith('✓') ? 'var(--good)' : 'var(--warn)' }}>
                        {status[key]}
                      </div>
                    )}
                    <div className="ui-card-actions">
                      <button className="chip" style={{ fontSize: 12 }}
                        onClick={() => preview(row)}>👁 Preview</button>
                      <button className="primary-btn" style={{ fontSize: 12, padding: '6px 12px' }}
                        onClick={() => applyImpute(row)}>Apply fill</button>
                    </div>
                  </div>
                )
              })}
          </div>
        )}
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <h3>Imputation history (what changed)</h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 8px' }}>
          Every applied fill, permanently recorded in the governance ledger and
          the SQL Log — technique, exact fill value, rows changed, who and when.
        </p>
        {history.length === 0 &&
          <div style={{ color: 'var(--muted)', fontSize: 13 }}>No imputations applied yet.</div>}
        {history.map((h, i) => (
          <div key={i} style={{ fontSize: 12.5, padding: '7px 0',
            borderBottom: '1px solid var(--border)' }}>
            <b>{h.table}.{h.column}</b> ← <b style={{ color: 'var(--accent)' }}>{h.fill_value}</b>
            <span style={{ color: 'var(--muted)' }}>
              {' '}({h.method}) · {h.rows_filled?.toLocaleString?.() ?? h.rows_filled} rows ·
              {' '}{(h.ts || '').slice(0, 19).replace('T', ' ')} · by {h.user_id}
            </span>
          </div>
        ))}
      </div>

      <div className="card">
        <h3>Anomaly data</h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', margin: '4px 0 10px' }}>
          Quarter-level anomalies across every governed metric (z-score on QoQ change),
          plus record-level outlier claims. Click an anomaly to investigate it in chat.
        </p>
        {!anoms && <div className="thinking">detecting…</div>}
        {anoms && <>
          <div className="insight-cards">
            {anoms.metric_anomalies.map((a, i) => (
              <button key={i} className="insight-card warn"
                style={{ cursor: 'pointer', textAlign: 'left' }}
                onClick={() => onAsk && onAsk(`Why did ${a.metric.replace(/_/g, ' ')} change in ${a.period}?`)}>
                ⚠ <b>{a.metric.replace(/_/g, ' ')}</b> {a.direction} in {a.period}:{' '}
                {a.pct_change > 0 ? '+' : ''}{a.pct_change}% QoQ (z={a.z_score})
                <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 3 }}>
                  click to root-cause in chat →
                </div>
              </button>
            ))}
            {anoms.metric_anomalies.length === 0 &&
              <div style={{ color: 'var(--good)' }}>No metric-level anomalies.</div>}
          </div>

          <div style={{ marginTop: 14 }}>
            <b style={{ fontSize: 13 }}>Outlier claims</b>
            {anoms.outliers.note ? (
              <span style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 8 }}>
                — {anoms.outliers.note}
              </span>
            ) : (
              <span style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 8 }}>
                {anoms.outliers.rule} (&gt; ${Math.round(anoms.outliers.threshold).toLocaleString()})
                — {anoms.outliers.rows.length} records
              </span>
            )}
            {!anoms.outliers.note &&
              <DataGrid columns={anoms.outliers.columns}
                rows={anoms.outliers.rows} collapsed={false} />}
          </div>
        </>}
      </div>
    </div>
  )
}
