import React, { useEffect, useRef, useState } from 'react'

// Click-to-edit heading, used for chart titles.
//
// Titles are generated from the metric and intent, which is right often
// enough to be useful and wrong often enough to be annoying — "Pbm Reject
// Rate by reject code" is not what anyone would call that chart in a board
// pack. Renaming has to be one click, and the rename has to travel with the
// artifact when it is pinned or exported.
//
// Enter commits, Escape reverts, blur commits. Empty falls back to the
// generated title rather than leaving a headless chart.
export default function EditableTitle({ value, onChange, placeholder = 'Untitled chart',
                                        as = 'h4', className = '' }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(value || '')
  const ref = useRef(null)

  useEffect(() => { if (!editing) setDraft(value || '') }, [value, editing])
  useEffect(() => {
    if (editing && ref.current) { ref.current.focus(); ref.current.select() }
  }, [editing])

  const commit = () => {
    const next = (draft || '').trim()
    setEditing(false)
    if (next !== (value || '')) onChange && onChange(next || value || '')
  }
  const cancel = () => { setDraft(value || ''); setEditing(false) }

  if (editing) {
    return (
      <input ref={ref} className={`editable-title-input ${className}`}
        value={draft} placeholder={placeholder}
        onChange={e => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={e => {
          if (e.key === 'Enter') { e.preventDefault(); commit() }
          if (e.key === 'Escape') { e.preventDefault(); cancel() }
        }} />
    )
  }

  const Tag = as
  return (
    <Tag className={`editable-title ${className}`}
      title="click to rename"
      tabIndex={0}
      onClick={() => setEditing(true)}
      onKeyDown={e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setEditing(true) }
      }}>
      {value || <span className="editable-title-empty">{placeholder}</span>}
      <span className="editable-title-pencil" aria-hidden="true">✎</span>
    </Tag>
  )
}
