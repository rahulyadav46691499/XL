import React, { useState } from 'react'

// Trust badge + expandable audit panel (validation gate for humans).
export default function TrustPanel({ trust, audit, sql, grounding, question }) {
  const [open, setOpen] = useState(false)
  const [verdict, setVerdict] = useState(null)
  const pct = Math.round(trust.score * 100)
  const cls = trust.score >= 0.8 ? 'high' : trust.score >= 0.6 ? 'med' : 'low'

  const vote = async (v) => {
    setVerdict(v)
    await fetch('/api/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, verdict: v, reviewer: 'analyst' })
    })
  }

  return (
    <div>
      <div className="trust-row">
        <button className={`badge trust-seal ${cls}`} style={{ '--pct': pct }}
          onClick={() => setOpen(o => !o)}>
          Trust {pct}% {open ? '▾' : '▸'}
        </button>
        <button className="linkbtn" onClick={() => setOpen(o => !o)}>
          inspect logic, sources &amp; steps
        </button>
      </div>

      {trust.needs_review && (
        <div className="gate">
          ⚠ Below the {Math.round(trust.threshold * 100)}% trust threshold —
          human validation required before this insight can be shared.
          {verdict
            ? <div>Recorded: <b>{verdict}</b></div>
            : <div>
                <button onClick={() => vote('approved')}>✓ Approve</button>
                <button onClick={() => vote('rejected')}>✗ Reject</button>
              </div>}
        </div>
      )}

      {open && (
        <div className="panel">
          <b>Trust formula</b>: {trust.formula}
          <table>
            <tbody>
              {Object.entries(trust.components).map(([k, v]) => (
                <tr key={k}>
                  <td>{k.replace(/_/g, ' ')}</td>
                  <td>weight {trust.weights[k]}</td>
                  <td>{Math.round(v * 100)}%</td>
                </tr>
              ))}
            </tbody>
          </table>

          {trust.recommendations?.length > 0 && (
            <div style={{ marginTop: 10 }}>
              <b>How to improve this score</b>
              {trust.recommendations.map((r, i) => (
                <div key={i} style={{ margin: '5px 0', paddingLeft: 8, borderLeft: '2px solid var(--warn)' }}>
                  <span style={{ color: 'var(--warn)', fontWeight: 600 }}>
                    {r.component.replace(/_/g, ' ')}{r.impact ? ` (${r.impact})` : ''}
                  </span>
                  <div style={{ color: 'var(--text)' }}>{r.tip}</div>
                </div>
              ))}
            </div>
          )}

          <div style={{ marginTop: 10 }}><b>Semantic grounding (Graph RAG)</b></div>
          <div>matched terms: {grounding.matched_terms.join(', ') || '—'}</div>
          {Object.entries(grounding.metrics).map(([k, v]) => (
            <div key={k}>• <b>{k}</b>: {v}</div>
          ))}

          {trust.logic_tree && (trust.logic_tree.entity_extraction?.length > 0
            || trust.logic_tree.policy_rules?.length > 0) && (
            <div style={{ marginTop: 10 }}>
              <b>Logic tree (compliance view)</b>
              {trust.logic_tree.entity_extraction?.length > 0 && <>
                <div style={{ marginTop: 4, color: 'var(--muted)' }}>
                  Entity extraction — exact regex per entity:</div>
                {trust.logic_tree.entity_extraction.slice(0, 8).map((e, i) => (
                  <div key={i} style={{ fontFamily: 'monospace', fontSize: 11 }}>
                    "{e.matched_text}" → {e.entity}
                    <span style={{ color: 'var(--muted)' }}> via {e.regex}</span>
                  </div>
                ))}
              </>}
              {trust.logic_tree.source_documents?.length > 0 && <>
                <div style={{ marginTop: 6, color: 'var(--muted)' }}>Source documentation:</div>
                {trust.logic_tree.source_documents.map((d, i) => (
                  <div key={i} style={{ fontSize: 11.5 }}>📄 {d}</div>
                ))}
              </>}
              {trust.logic_tree.policy_rules?.length > 0 && <>
                <div style={{ marginTop: 6, color: 'var(--muted)' }}>CMS rules evaluated:</div>
                {trust.logic_tree.policy_rules.map((r, i) => (
                  <div key={i} style={{ fontSize: 11.5,
                    color: r.status === 'fail' ? 'var(--bad)'
                      : r.status === 'warning' ? 'var(--warn)' : 'var(--good)' }}>
                    [{r.rule_id}] {r.citation} — {r.observed} (threshold: {r.threshold}) → {r.status.toUpperCase()}
                  </div>
                ))}
              </>}
              {trust.logic_tree.graph_paths?.length > 0 && <>
                <div style={{ marginTop: 6, color: 'var(--muted)' }}>Graph hops traversed:</div>
                {trust.logic_tree.graph_paths.slice(0, 6).map((g, i) => (
                  <div key={i} style={{ fontFamily: 'monospace', fontSize: 10.5, color: 'var(--muted)' }}>{g}</div>
                ))}
              </>}
            </div>
          )}

          <div style={{ marginTop: 10 }}><b>Generated SQL</b></div>
          <pre style={{ whiteSpace: 'pre-wrap', color: 'var(--muted)' }}>{sql}</pre>

          <div style={{ marginTop: 10 }}><b>Agent trace</b></div>
          {audit.map((s, i) => (
            <div key={i} className="audit-step">
              <span className="agent">{s.agent}</span> — {s.step} ({s.ms}ms)
              <pre>{JSON.stringify(s.detail, null, 1).slice(0, 600)}</pre>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
