import React, { useEffect, useState } from 'react'

// Maker-checker queue for protected Context Brain edits.
//
// An edit that changes a control-of-controls key (the thresholds deciding
// whether an action needs two signatures) does not save on write — it parks
// here until two DISTINCT compliance officers approve it. This view is the
// difference between that control existing and it being usable: before this,
// the dual-control flow was reachable only by calling the API directly.
export default function BrainEditQueue({ onApplied }) {
  const [pending, setPending] = useState([])
  const [protectedKeys, setProtectedKeys] = useState([])
  const [msg, setMsg] = useState(null)
  const [busy, setBusy] = useState(null)

  const load = () => {
    fetch('/api/brain/edits')
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(d => {
        setPending(d.pending || [])
        setProtectedKeys(d.protected_keys || [])
      })
      .catch(() => setPending([]))
  }
  useEffect(() => { load() }, [])

  const act = async (id, verb) => {
    setBusy(id); setMsg(null)
    const r = await fetch(`/api/brain/edits/${id}/${verb}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason: verb === 'reject' ? 'rejected in review' : '' })
    })
    const out = await r.json()
    setBusy(null)
    if (out.error) {
      // separation-of-duties refusals surface verbatim — the officer needs to
      // know WHY they cannot sign, not just that the button did nothing
      setMsg({ kind: 'err', text: out.error })
    } else if (out.applied) {
      setMsg({ kind: 'ok', text: `Applied — two signatures recorded. ${out.report || ''}` })
      onApplied && onApplied()
    } else if (out.state === 'REJECTED') {
      setMsg({ kind: 'ok', text: 'Edit rejected; the Brain is unchanged.' })
    } else {
      setMsg({ kind: 'warn',
               text: `Signature ${out.signatures?.length || 1} of 2 recorded — `
                   + 'a second, distinct officer must approve.' })
    }
    load()
  }

  if (pending.length === 0) return null

  return (
    <div className="card" style={{ marginBottom: 16,
                                   borderLeft: '3px solid var(--warn, #B45309)',
                                   borderRadius: 0 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between',
                    alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <h3>Policy edits awaiting approval ({pending.length})</h3>
        <button className="chip" onClick={() => load()}>↻ refresh</button>
      </div>
      <p style={{ color: 'var(--muted)', fontSize: 12, marginTop: 6 }}>
        These edits change control-of-controls keys, so they require two
        distinct compliance officers. The proposer may not approve their own
        edit. Nothing below is live yet.
      </p>

      {msg && (
        <div className="status-line" style={{ marginTop: 8, fontSize: 12.5,
          color: msg.kind === 'err' ? 'var(--danger, #9B1C1C)'
               : msg.kind === 'warn' ? 'var(--warn, #B45309)'
               : 'var(--ok, #2E7D32)' }}>
          {msg.text}
        </div>
      )}

      {pending.map(edit => (
        <div key={edit.edit_id} style={{ borderTop: '1px solid var(--border, #ddd)',
                                      paddingTop: 10, marginTop: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center',
                        flexWrap: 'wrap', gap: 8 }}>
            <span className="badge high">{edit.edit_id}</span>
            <b style={{ fontSize: 12.5 }}>{edit.fname}</b>
            <span style={{ fontSize: 11.5, color: 'var(--muted)' }}>
              proposed by {edit.proposer_user_id || 'the review itself'} ·{' '}
              {(edit.signatures || []).length} of 2 signatures
            </span>
          </div>

          <table className="cohort-table" style={{ marginTop: 8 }}>
            <thead><tr><th>Control key</th><th>Current</th><th>Proposed</th></tr></thead>
            <tbody>
              {(edit.changes || []).map(c => (
                <tr key={c.key}>
                  <td><b>{c.key}</b></td>
                  <td style={{ fontSize: 12 }}>{String(c.old)}</td>
                  <td style={{ fontSize: 12 }}>{String(c.new)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {(edit.signatures || []).length > 0 && (
            <div style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 6 }}>
              signed by {(edit.signatures || []).map(s => s.user_id).join(', ')}
            </div>
          )}

          <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
            <button className="chip" disabled={busy === edit.edit_id}
                    onClick={() => act(edit.edit_id, 'approve')}>
              ✓ approve
            </button>
            <button className="chip" disabled={busy === edit.edit_id}
                    onClick={() => act(edit.edit_id, 'reject')}>
              ✕ reject
            </button>
          </div>
        </div>
      ))}

      {protectedKeys.length > 0 && (
        <p style={{ color: 'var(--muted)', fontSize: 11, marginTop: 12 }}>
          Protected keys: {protectedKeys.join(', ')}
        </p>
      )}
    </div>
  )
}
