import React, { useEffect, useState } from 'react'
import { login } from '../auth.js'

export default function Login({ onLogin }) {
  const [users, setUsers] = useState([])
  const [userId, setUserId] = useState('')
  const [pw, setPw] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    fetch('/api/auth/users').then(r => r.json())
      .then(d => setUsers(d.users || [])).catch(() => {})
  }, [])

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true); setErr('')
    try { onLogin(await login(userId, pw)) }
    catch (ex) { setErr(ex.message) }
    setBusy(false)
  }

  return (
    <div className="login-wrap">
      <form className="card login-card rise-in" onSubmit={submit}>
        <div className="exl-logo" style={{ marginBottom: 6 }}>
          <span className="mark">OpPal</span>
          <span className="tag">Agentic Payer Engine</span>
        </div>
        <p>
          Sign in with your plan credentials. Every question, query and
          approval is written to the tamper-evident governance ledger.
        </p>
        <select className="settings-input" value={userId} required
          onChange={e => setUserId(e.target.value)}>
          <option value="">Select user…</option>
          {users.map(u => (
            <option key={u.user_id} value={u.user_id}>{u.display_name}</option>
          ))}
        </select>
        <input className="settings-input" type="password" required
          placeholder="Password" value={pw}
          onChange={e => setPw(e.target.value)} />
        {err && <div className="brain-status err">{err}</div>}
        <button className="primary-btn" disabled={busy}>
          {busy ? 'Signing in…' : '🔐 Sign in'}
        </button>
        <span className="login-hint">demo password: OpPal!demo2026</span>
      </form>
    </div>
  )
}
