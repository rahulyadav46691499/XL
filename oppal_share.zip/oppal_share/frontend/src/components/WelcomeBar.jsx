import React, { useEffect, useState } from 'react'
import { userKey } from '../auth.js'

// Chat header: who you are, when it is, optionally the weather where you are,
// and a single-line ticker of industry headlines.
//
// Everything past the greeting is OPTIONAL BY DESIGN. On a network that blocks
// egress or re-signs TLS, an unconfigured or unreachable widget renders as
// nothing at all — never a spinner, an error, or a dash where a temperature
// should be. A greeting must not be able to fail.
export default function WelcomeBar({ session, me, onAsk, starters = [] }) {
  const [b, setB] = useState(null)
  const [loc, setLoc] = useState('')
  const [editingLoc, setEditingLoc] = useState(false)
  const [idx, setIdx] = useState(0)

  // Location is a PERSONAL preference, so it lives in this user's own local
  // storage and is passed per request. Writing it into server Settings would
  // require settings_write (compliance-officer only), which would mean an
  // analyst could not set their own city — and would make one person's
  // location everyone's.
  const LOC_KEY = 'oppal-briefing-loc'
  const savedLoc = () => {
    try { return localStorage.getItem(userKey(LOC_KEY)) || '' } catch { return '' }
  }
  const load = (locOverride) => {
    const l = locOverride !== undefined ? locOverride : savedLoc()
    const q = l ? `?location=${encodeURIComponent(l)}` : ''
    return fetch(`/api/briefing${q}`)
      .then(r => (r.ok ? r.json() : null))
      .then(d => { if (d) { setB(d); setLoc(d.location || l || '') } })
      .catch(() => {})
  }
  useEffect(() => { setLoc(savedLoc()); load() }, [session])

  // Rotate headlines on one line rather than stacking four. A ticker that
  // advances every 6s is readable; anything faster reads as noise.
  useEffect(() => {
    const n = b?.news?.length || 0
    if (n < 2) return
    const t = setInterval(() => setIdx(i => (i + 1) % n), 6000)
    return () => clearInterval(t)
  }, [b?.news?.length])

  const saveLoc = () => {
    setEditingLoc(false)
    try { localStorage.setItem(userKey(LOC_KEY), loc) } catch { /* ignore */ }
    load(loc)
  }

  const name = b?.first_name || session?.user?.display_name || ''
  const greeting = b?.greeting || 'Welcome'
  const news = b?.news || []
  const current = news[idx % (news.length || 1)]

  return (
    <div className="welcome-bar rise-in">
      <div className="welcome-row">
        <div className="welcome-hello">
          <h2>
            {greeting}{name ? <>, <span className="welcome-name">{name}</span></> : ''}
          </h2>
          <div className="welcome-sub">
            {b?.date || ''}
            {b?.time && <> · <span className="welcome-clock">{b.time}</span></>}
            {me?.role && <> · <span className="welcome-role">{me.role}</span></>}
          </div>
        </div>

        <div className="welcome-side">
          {/* Weather appears only when an endpoint is configured AND returned
              something parseable. */}
          {b?.weather && (
            <span className="welcome-weather" title={b.weather.label || 'current conditions'}>
              <b>{b.weather.temp_c}°C</b>
              {b.weather.label ? <span> {b.weather.label}</span> : null}
              {b.location ? <span className="welcome-loc"> {b.location}</span> : null}
            </span>
          )}
          {b?.weather_configured && !b?.weather && (
            <span className="welcome-weather muted" title="weather source unreachable">
              weather unavailable
            </span>
          )}
          {b?.weather_configured && (
            editingLoc ? (
              <span className="welcome-locedit">
                <input className="settings-input" value={loc} autoFocus
                  placeholder="city or lat,lon"
                  onChange={e => setLoc(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && saveLoc()} />
                <button className="chip" onClick={saveLoc}>set</button>
              </span>
            ) : (
              <button className="linkbtn welcome-locbtn"
                title="change location" onClick={() => setEditingLoc(true)}>
                📍 {b.location || 'set location'}
              </button>
            )
          )}
        </div>
      </div>

      {news.length > 0 && (
        <div className="welcome-ticker" aria-live="polite">
          <span className="welcome-ticker-tag">AI &amp; DATA</span>
          <a key={idx} className="welcome-ticker-item fade-in"
            href={current?.url || undefined}
            target={current?.url ? '_blank' : undefined}
            rel="noreferrer noopener">
            {current?.title}
          </a>
          <span className="welcome-ticker-dots">
            {news.map((_, i) => (
              <i key={i} className={i === idx ? 'on' : ''}
                onClick={() => setIdx(i)} />
            ))}
          </span>
        </div>
      )}

      {!!starters.length && (
        <div className="welcome-starters">
          <span className="welcome-starters-label">Try</span>
          {starters.slice(0, 4).map((s, i) => (
            <button key={i} className="chip welcome-starter"
              style={{ animationDelay: `${0.05 * (i + 1)}s` }}
              onClick={() => onAsk && onAsk(s)}>{s}</button>
          ))}
        </div>
      )}
    </div>
  )
}
