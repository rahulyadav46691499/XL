import React, { useEffect, useState } from 'react'

// Phase 6 — FinOps / LLM telemetry widget (REQ-6.4–6.6). Floating/dockable;
// polls GET /api/finops on its own unless `telemetry` is supplied. Every
// cost figure is a Decimal STRING on the wire — rendered as-is, never
// re-derived client-side, so the widget can't drift from the server's math.
export default function FinOpsWidget({ telemetry, pollIntervalMs, collapsed,
  onToggle }) {
  const [myTelemetry, setMyTelemetry] = useState(telemetry || null)
  const [myCollapsed, setMyCollapsed] = useState(
    collapsed !== undefined ? collapsed : true)

  useEffect(() => {
    if (telemetry) return
    const poll = () => fetch('/api/finops').then(r => r.json())
      .then(setMyTelemetry).catch(() => {})
    poll()
    const id = setInterval(poll, pollIntervalMs || 5000)
    return () => clearInterval(id)
  }, [telemetry, pollIntervalMs])

  const t = telemetry || myTelemetry
  const isCollapsed = collapsed !== undefined ? collapsed : myCollapsed
  const toggle = () => onToggle ? onToggle() : setMyCollapsed(v => !v)

  if (!t) return null
  const usd = (v) => `$${Number(v || 0).toFixed(4)}`

  return (
    <div style={{
      position: 'fixed', right: 16, bottom: 16, zIndex: 50,
      background: 'var(--card)', border: '1px solid var(--border)',
      borderRadius: 10, boxShadow: '0 4px 16px rgba(0,0,0,.15)',
      minWidth: isCollapsed ? 160 : 260, fontSize: 11.5,
    }}>
      <button className="chip" style={{ width: '100%', textAlign: 'left',
        borderRadius: '10px 10px 0 0' }} onClick={toggle}>
        💰 FinOps {isCollapsed ? '▸' : '▾'}
        {isCollapsed && <span style={{ marginLeft: 6 }}>{usd(t.session_cost_usd)}</span>}
      </button>
      {!isCollapsed && (
        <div style={{ padding: 10 }}>
          <div>p95 latency: <b>{Math.round(t.p95_latency_ms || 0)} ms</b></div>
          <div>session tokens: <b>{(t.session_tokens_in || 0) + (t.session_tokens_out || 0)}</b>
            {' '}/ global <b>{(t.global_tokens_in || 0) + (t.global_tokens_out || 0)}</b></div>
          <div>session cost: <b>{usd(t.session_cost_usd)}</b>
            {' '}/ global <b>{usd(t.global_cost_usd)}</b></div>
          <div>cache hit rate: <b>{Math.round((t.cache_hit_rate || 0) * 100)}%</b></div>
          <div>cache savings: <b style={{ color: 'var(--good)' }}>{usd(t.cache_savings_usd)}</b></div>
          <div style={{ color: 'var(--muted)', marginTop: 4 }}>
            provider {t.provider} · ${t.price_in_per_m}/M in · ${t.price_out_per_m}/M out
          </div>
        </div>
      )}
    </div>
  )
}
