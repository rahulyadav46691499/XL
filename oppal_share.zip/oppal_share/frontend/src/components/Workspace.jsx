import React, { useEffect, useRef, useState } from 'react'
import InfoDot from './InfoDot.jsx'
import ChartArtifact from './ChartArtifact.jsx'
import EditableTitle from './EditableTitle.jsx'
import { exportPng, exportDashboardHtml } from '../exportUtils.js'

// Server-persisted Workspace (REQ-5.6–5.8): pinned simulation/chart/grid
// artifacts on named dashboards, each traceable back to its journey/trust/
// logic-tree lineage. Props are optional — self-sufficient standalone.
//
// Dashboards are PRIVATE to their owner and reachable by others only through
// an explicit share grant ("view" or "edit"); the server is authoritative and
// re-checks every read and write. The `access` field on each summary tells
// this component which controls the caller is actually allowed to use.
export default function Workspace({ dashboards, activeId, onSelect, onCreate,
  onLayoutChange, onOpenLineage, readOnly }) {
  const [myDashboards, setMyDashboards] = useState(dashboards || null)
  const [myActive, setMyActive] = useState(activeId || null)
  const [detail, setDetail] = useState(null)
  const [lineage, setLineage] = useState(null)
  const [lineageOpen, setLineageOpen] = useState(null)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState('')

  const [err, setErr] = useState('')

  const load = () => {
    if (dashboards) return
    fetch('/api/workspace').then(r => r.json())
      .then(d => {
        setMyDashboards(d.dashboards || [])
        setMyActive(prev => {
          const ids = (d.dashboards || []).map(x => x.id)
          if (prev && ids.includes(prev)) return prev
          return ids[0] || null
        })
      }).catch(() => {})
  }
  useEffect(load, [])

  const list = dashboards || myDashboards || []
  const active = activeId || myActive
  const activeSummary = list.find(d => d.id === active)
  const canEdit = !readOnly && (!activeSummary
    || activeSummary.access === 'owner' || activeSummary.access === 'edit')
  const isOwner = !activeSummary || activeSummary.access === 'owner'

  const loadDetail = (id) => {
    if (!id) { setDetail(null); return }
    // MUST check r.ok. GET /api/workspace/{id} did not exist, so this fetch
    // returned 405 and .json() yielded {detail:"Method Not Allowed"} — a
    // truthy object with no .artifacts, which rendered as a permanently
    // "empty" dashboard even though artifacts were stored correctly.
    fetch(`/api/workspace/${id}`)
      .then(async r => {
        const body = await r.json().catch(() => null)
        if (!r.ok) {
          setDetail(null)
          setErr(`Could not load this dashboard (${r.status})`
                 + (body?.detail ? ` — ${body.detail}` : ''))
          return
        }
        setErr('')
        setDetail(body)
      })
      .catch(e => { setDetail(null); setErr(String(e.message || e)) })
  }
  useEffect(() => { loadDetail(active) }, [active])

  // Refresh when a chart is pinned from the Chat tab, so the board is already
  // populated when the user switches over to look at it.
  useEffect(() => {
    const onChanged = () => { load(); loadDetail(active) }
    window.addEventListener('oppal-workspace-changed', onChanged)
    return () =>
      window.removeEventListener('oppal-workspace-changed', onChanged)
  }, [active])

  const select = (id) => {
    if (onSelect) onSelect(id)
    else setMyActive(id)
  }

  const create = async () => {
    const name = window.prompt('New dashboard name:')
    if (!name || !name.trim()) return
    setBusy(true)
    try {
      const ws = onCreate ? await onCreate(name)
        : await fetch('/api/workspace', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name })
        }).then(r => r.json())
      setMsg(`Created ${ws.name}`)
      load(); select(ws.id)
    } catch (e) { setMsg(e.message || 'create failed') }
    setBusy(false)
  }

  const GRID_COLS = 8
  // An artifact with no stored grid entry gets one on the fly, so a board
  // pinned by an older build (which saved no layout at all) still lays out
  // instead of stacking every card on 0,0.
  const layoutFor = (aid, i) => {
    const g = (detail?.layout || []).find(x => x.artifact_id === aid)
    if (g) return g
    const w = 4, per = Math.max(1, Math.floor(GRID_COLS / w))
    return { artifact_id: aid, w, h: 2,
             x: (i % per) * w, y: Math.floor(i / per) * 2 }
  }

  // Ensure every artifact has a real entry before persisting a change, or
  // editing one card's size would wipe the implied positions of the rest.
  const fullLayout = () => (detail?.artifacts || [])
    .map((a, i) => layoutFor(a.id, i))

  const resize = (item, dw, dh) => {
    if (!detail || !canEdit) return
    persistLayout(fullLayout().map(g => g.artifact_id === item.artifact_id
      ? { ...g, w: Math.min(GRID_COLS, Math.max(1, g.w + dw)),
          h: Math.max(1, g.h + dh) } : g))
  }
  const move = (item, dx, dy) => {
    if (!detail || !canEdit) return
    persistLayout(fullLayout().map(g => g.artifact_id === item.artifact_id
      ? { ...g, x: Math.min(GRID_COLS - g.w, Math.max(0, g.x + dx)),
          y: Math.max(0, g.y + dy) } : g))
  }
  // ---- drag-to-resize from a card's edge/corner -------------------------
  // Pointer events (not mouse) so a trackpad, a pen and a touchscreen all
  // work, and setPointerCapture keeps the drag alive when the cursor leaves
  // the small handle. Movement is quantised to grid cells and only persisted
  // on release — persisting every pointermove would be one PUT per pixel.
  const gridRef = useRef(null)
  const [drag, setDrag] = useState(null)      // {id, edge, w, h, cellW, cellH}

  const startResize = (e, g, edge) => {
    if (!canEdit) return
    e.preventDefault(); e.stopPropagation()
    const box = gridRef.current?.getBoundingClientRect()
    const cellW = box ? box.width / GRID_COLS : 120
    const cellH = 150            // gridAutoRows 140 + 10 gap
    try { e.currentTarget.setPointerCapture(e.pointerId) } catch { /* ignore */ }
    setDrag({ id: g.artifact_id, edge, startX: e.clientX, startY: e.clientY,
              w0: g.w, h0: g.h, w: g.w, h: g.h, cellW, cellH })
  }

  const onResizeMove = (e) => {
    if (!drag) return
    const dx = e.clientX - drag.startX, dy = e.clientY - drag.startY
    const dw = drag.edge.includes('e') ? Math.round(dx / drag.cellW) : 0
    const dh = drag.edge.includes('s') ? Math.round(dy / drag.cellH) : 0
    const w = Math.max(1, Math.min(GRID_COLS, drag.w0 + dw))
    const h = Math.max(1, drag.h0 + dh)
    if (w !== drag.w || h !== drag.h) setDrag({ ...drag, w, h })
  }

  const endResize = () => {
    if (!drag) return
    const { id, w, h, w0, h0 } = drag
    setDrag(null)
    if (w === w0 && h === h0) return          // a click, not a resize
    persistLayout(fullLayout().map(g => g.artifact_id === id
      ? { ...g, w, h } : g))
  }

  const autoArrange = async () => {
    if (!canEdit || !active) return
    setBusy(true)
    try {
      const r = await fetch(`/api/workspace/${active}/autoarrange`,
                            { method: 'POST' })
      if (r.ok) { setDetail(await r.json()); setMsg('Auto-arranged') }
      else setMsg('Could not auto-arrange')
    } catch (e) { setMsg(String(e.message || e)) }
    setBusy(false)
  }
  const persistLayout = async (layout) => {
    setDetail(d => ({ ...d, layout }))
    if (onLayoutChange) { onLayoutChange(active, layout); return }
    await fetch(`/api/workspace/${active}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ layout })
    })
  }

  // Rename persists server-side so the new title follows the artifact into
  // exports, PNGs and other viewers' sessions. Optimistic locally, reconciled
  // from the response.
  const renameArtifact = async (a, title) => {
    if (!canEdit || !active) return
    const clean = String(title || '').trim()
    if (!clean || clean === (a.spec?.title || '')) return
    setDetail(d => !d ? d : { ...d, artifacts: d.artifacts.map(x =>
      x.id === a.id ? { ...x, spec: { ...(x.spec || {}), title: clean } } : x) })
    try {
      const r = await fetch(`/api/workspace/${active}/artifact/${a.id}/title`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: clean })
      })
      if (!r.ok) { setMsg('Could not rename this artifact'); loadDetail(active) }
    } catch { loadDetail(active) }
  }

  const removeArtifact = async (aid) => {
    if (!canEdit) return
    await fetch(`/api/workspace/${active}/artifact/${aid}`, { method: 'DELETE' })
    loadDetail(active)
  }

  // ---- sharing (owner only; server re-checks) --------------------------
  const [shareOpen, setShareOpen] = useState(false)
  const [shareUser, setShareUser] = useState('')
  const [shareLevel, setShareLevel] = useState('view')

  const applyShare = async (revoke, targetUser) => {
    const who = (targetUser !== undefined ? targetUser : shareUser).trim()
    if (!who) return
    setBusy(true)
    try {
      const r = await fetch(`/api/workspace/${active}/share`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: who, level: shareLevel,
                               revoke: !!revoke })
      })
      const body = await r.json().catch(() => null)
      if (!r.ok) {
        setMsg(`✗ ${body?.detail || `share failed (${r.status})`}`)
      } else {
        setMsg(revoke ? `Revoked access for ${who}`
                      : `Shared with ${who} (${shareLevel})`)
        setShareUser('')
        load(); loadDetail(active)
      }
    } catch (e) { setMsg(String(e.message || e)) }
    setBusy(false)
  }

  // ---- export (dependency-free; see src/exportUtils.js) ----------------
  // Refs to each artifact's rendered container, so export reads the SVG the
  // user is actually looking at rather than re-deriving a chart.
  const artRefs = useRef({})
  const setArtRef = (id) => (el) => { artRefs.current[id] = el }

  const doExportPng = async (a) => {
    try {
      await exportPng(artRefs.current[a.id],
                      a.spec?.title || a.spec?.question || a.id)
      setMsg('Saved PNG')
    } catch (e) { setMsg(`✗ PNG export failed — ${e.message || e}`) }
  }

  const doExportHtml = () => {
    if (!detail) return
    try {
      exportDashboardHtml({
        name: activeSummary?.name || detail.name || 'dashboard',
        owner: detail.owner,
        artifacts: detail.artifacts || [],
        containers: artRefs.current,
      })
      setMsg('Exported a self-contained HTML file — open it and use '
             + 'Print → Save as PDF for a PDF copy.')
    } catch (e) { setMsg(`✗ HTML export failed — ${e.message || e}`) }
  }

  const openLineage = async (aid) => {
    setLineageOpen(aid)
    if (onOpenLineage) { onOpenLineage(aid); return }
    const lin = await fetch(`/api/artifact/${aid}/lineage`).then(r => r.json())
      .catch(() => null)
    setLineage(lin)
  }

  const gridPos = (g) => ({
    gridColumn: `${g.x + 1} / span ${g.w}`,
    gridRow: `${g.y + 1} / span ${g.h}`,
  })

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <h3>🗂️ Workspace<InfoDot id="workspace.view_lineage_button" /></h3>
          {list.map(d => (
            <button key={d.id} className={`chip ${d.id === active ? 'chip-on' : ''}`}
              onClick={() => select(d.id)}
              title={d.access === 'owner' ? 'your dashboard'
                : `shared with you by ${d.owner} (${d.access})`}>
              {d.access !== 'owner' && '👥 '}{d.name}{' '}
              <span className="sidebar-count">{d.artifact_count}</span>
            </button>
          ))}
          <button className="chip" disabled={busy} onClick={create}>＋ new dashboard</button>
          {isOwner && active && (
            <button className="chip" onClick={() => setShareOpen(o => !o)}>
              👤 share
            </button>
          )}
          {!!detail?.artifacts?.length && canEdit && (
            <button className="chip" disabled={busy} onClick={autoArrange}
              title="repack every card into a gap-free grid">
              ⊞ auto-arrange
            </button>
          )}
          {!!detail?.artifacts?.length && (
            <>
              <button className="chip" onClick={doExportHtml}
                title="one self-contained .html file — charts and data embedded">
                ⬇ export HTML
              </button>
              <button className="chip" onClick={() => window.print()}
                title="print this dashboard, or choose Save as PDF">
                🖨 print / PDF
              </button>
            </>
          )}
        </div>
        <p style={{ fontSize: 12, color: 'var(--muted)', margin: '6px 0 0' }}>
          Your pinned charts and simulation results, persisted server-side and
          private to you unless you share them. Every artifact carries a
          lineage trail back to the journey/trust/logic-tree snapshot that
          produced it.
        </p>
        {activeSummary && activeSummary.access !== 'owner' && (
          <div className="brain-status warn" style={{ marginTop: 8 }}>
            👥 Shared with you by <b>{activeSummary.owner}</b> —{' '}
            {activeSummary.access === 'edit'
              ? 'you can add and remove artifacts.'
              : 'view only.'}
          </div>
        )}
        {shareOpen && isOwner && active && (
          <div className="panel" style={{ marginTop: 8 }}>
            <b style={{ fontSize: 13 }}>Share this dashboard</b>
            <p style={{ fontSize: 11.5, color: 'var(--muted)', margin: '4px 0 8px' }}>
              Dashboards are private by default. Grant access to a specific
              user id — they still need their own data authorization, so
              sharing a board never widens what they may query.
            </p>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
              <input className="settings-input" style={{ flex: '1 1 180px' }}
                placeholder="user id — e.g. u-ma" value={shareUser}
                onChange={e => setShareUser(e.target.value)} />
              <select className="settings-input" value={shareLevel}
                onChange={e => setShareLevel(e.target.value)}>
                <option value="view">can view</option>
                <option value="edit">can edit</option>
              </select>
              <button className="primary-btn" disabled={busy || !shareUser.trim()}
                onClick={() => applyShare(false)}>Share</button>
            </div>
            {!!(activeSummary?.shared_with || []).length && (
              <div style={{ marginTop: 8 }}>
                {activeSummary.shared_with.map(g => (
                  <div key={g.user_id} style={{ display: 'flex', gap: 8,
                    alignItems: 'center', padding: '3px 0', fontSize: 12 }}>
                    <span style={{ fontFamily: 'monospace' }}>{g.user_id}</span>
                    <span className="chip" style={{ fontSize: 10.5 }}>{g.level}</span>
                    <div style={{ flex: 1 }} />
                    <button className="linkbtn" disabled={busy}
                      onClick={() => applyShare(true, g.user_id)}>revoke</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {msg && <div className="brain-status ok" style={{ marginTop: 8 }}>{msg}</div>}
        {err && <div className="brain-status err" style={{ marginTop: 8 }}>{err}</div>}
      </div>

      {!list.length && (
        <div className="card" style={{ color: 'var(--muted)' }}>
          No dashboards yet — pin a chart from a chat answer or a result from
          the What-If Simulator, or create one above.
        </div>
      )}

      {detail && (
        <div className="card">
          {(!detail.artifacts || detail.artifacts.length === 0) ? (
            <div style={{ color: 'var(--muted)' }}>
              This dashboard is empty — pin an artifact to see it here.
            </div>
          ) : (
            <div ref={gridRef} style={{ display: 'grid', gridAutoRows: '140px',
              gridTemplateColumns: 'repeat(8, 1fr)', gap: 10 }}
              onPointerMove={onResizeMove}
              onPointerUp={endResize}
              onPointerCancel={endResize}>
              {detail.artifacts.map((a, ai) => {
                const base = layoutFor(a.id, ai)
                // While dragging, show the provisional size immediately so the
                // card follows the pointer instead of jumping on release.
                const g = (drag && drag.id === a.id)
                  ? { ...base, w: drag.w, h: drag.h } : base
                return (
                  <div key={a.id} className="card ws-art" style={{
                    margin: 0, padding: 8, ...gridPos(g), overflow: 'auto',
                    position: 'relative',
                    outline: (drag && drag.id === a.id)
                      ? '2px dashed var(--accent)' : undefined,
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                      <EditableTitle as="span" className="ws-art-title"
                        value={a.spec?.title || a.type}
                        placeholder={a.type}
                        onChange={t => renameArtifact(a, t)} />
                      <span className="ws-art-tools">
                        <button className="linkbtn" onClick={() => doExportPng(a)}
                          title="download this chart as a PNG">🖼</button>
                        {canEdit && (
                          <>
                            {/* Move controls: previously only resize was
                                wired, so a card could never be relocated out
                                of an overlap. */}
                            <button className="linkbtn" onClick={() => move(g, -1, 0)} title="move left">◀</button>
                            <button className="linkbtn" onClick={() => move(g, 1, 0)} title="move right">▶</button>
                            <button className="linkbtn" onClick={() => move(g, 0, -1)} title="move up">▲</button>
                            <button className="linkbtn" onClick={() => move(g, 0, 1)} title="move down">▼</button>
                            <button className="linkbtn" onClick={() => resize(g, 1, 0)} title="wider">↔</button>
                            <button className="linkbtn" onClick={() => resize(g, -1, 0)} title="narrower">↤</button>
                            <button className="linkbtn" onClick={() => resize(g, 0, 1)} title="taller">↕</button>
                            <button className="linkbtn" onClick={() => resize(g, 0, -1)} title="shorter">↥</button>
                            <button className="linkbtn" onClick={() => removeArtifact(a.id)} title="remove">✕</button>
                          </>
                        )}
                      </span>
                    </div>
                    {/* Render the pinned artifact as the ACTUAL chart. The
                        pinned spec is the same object ChartArtifact renders in
                        chat, so a dashboard shows charts rather than a JSON
                        dump — and export can read the real rendered SVG. */}
                    <div ref={setArtRef(a.id)} className="ws-art-body">
                      {a.type === 'chart' && a.spec?.columns && a.spec?.rows
                        ? <ChartArtifact spec={a.spec} />
                        : (
                          <pre style={{ fontSize: 10.5, whiteSpace: 'pre-wrap',
                            margin: '6px 0' }}>
                            {JSON.stringify(a.spec, null, 1).slice(0, 300)}
                          </pre>
                        )}
                    </div>
                    <button className="linkbtn" onClick={() => openLineage(a.id)}>
                      🔗 view lineage
                    </button>
                    {canEdit && (
                      <>
                        {/* Edge and corner grips. Thin, only visible on hover,
                            and they never overlay the chart's own click
                            targets (drill-down still works). */}
                        <span className="ws-grip ws-grip-e"
                          title="drag to widen"
                          onPointerDown={e => startResize(e, g, 'e')} />
                        <span className="ws-grip ws-grip-s"
                          title="drag to make taller"
                          onPointerDown={e => startResize(e, g, 's')} />
                        <span className="ws-grip ws-grip-se"
                          title="drag to resize"
                          onPointerDown={e => startResize(e, g, 'se')} />
                      </>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {lineageOpen && (
        <div className="card rise-in" style={{ marginTop: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <b>Lineage — {lineageOpen}</b>
            <button className="linkbtn" onClick={() => { setLineageOpen(null); setLineage(null) }}>close</button>
          </div>
          {!lineage ? <div className="thinking">loading lineage…</div> : (
            <div style={{ fontSize: 11.5 }}>
              {lineage.trust && (
                <div style={{ marginBottom: 6 }}>
                  trust score: <b>{Math.round((lineage.trust.score || 0) * 100)}%</b>
                  {' '}(gate {Math.round((lineage.trust.hard_gate || 0.85) * 100)}%)
                </div>
              )}
              <details open>
                <summary>logic tree</summary>
                <pre style={{ whiteSpace: 'pre-wrap' }}>
                  {JSON.stringify(lineage.logic_tree, null, 1)}
                </pre>
              </details>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
