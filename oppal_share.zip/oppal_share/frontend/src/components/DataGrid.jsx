import React, { useMemo, useState } from 'react'

// Explorable grid: client-side sort + per-column filter, no re-prompting.
export default function DataGrid({ columns, rows, collapsed }) {
  const [open, setOpen] = useState(!collapsed)
  const [sort, setSort] = useState(null) // {col, dir}
  const [filters, setFilters] = useState({})

  const view = useMemo(() => {
    let out = rows
    for (const [i, f] of Object.entries(filters)) {
      if (f) out = out.filter(r => String(r[i] ?? '').toLowerCase().includes(f.toLowerCase()))
    }
    if (sort) {
      const i = sort.col
      out = [...out].sort((a, b) => {
        const x = a[i], y = b[i]
        const cmp = typeof x === 'number' && typeof y === 'number'
          ? x - y : String(x).localeCompare(String(y))
        return sort.dir === 'asc' ? cmp : -cmp
      })
    }
    return out
  }, [rows, sort, filters])

  if (!open) return (
    <button className="linkbtn" onClick={() => setOpen(true)}>
      ▸ Explore underlying data ({rows.length} rows)
    </button>
  )

  return (
    <div>
      <button className="linkbtn" onClick={() => setOpen(false)}>▾ Hide data</button>
      <div className="grid-wrap">
        <table className="grid">
          <thead>
            <tr>{columns.map((c, i) => (
              <th key={c} onClick={() => setSort(s =>
                s?.col === i && s.dir === 'desc' ? { col: i, dir: 'asc' } : { col: i, dir: 'desc' })}>
                {c}{sort?.col === i ? (sort.dir === 'desc' ? ' ↓' : ' ↑') : ''}
              </th>))}
            </tr>
            <tr>{columns.map((c, i) => (
              <th key={c + '_f'}>
                <input placeholder="filter…" value={filters[i] || ''}
                  onChange={e => setFilters({ ...filters, [i]: e.target.value })} />
              </th>))}
            </tr>
          </thead>
          <tbody>
            {view.slice(0, 200).map((r, ri) => (
              <tr key={ri}>{r.map((v, ci) => (
                <td key={ci}>{typeof v === 'number' && !Number.isInteger(v) ? v.toLocaleString() : String(v ?? '')}</td>
              ))}</tr>
            ))}
          </tbody>
        </table>
      </div>
      <span style={{ fontSize: 11, color: 'var(--muted)' }}>
        {view.length} of {rows.length} rows
      </span>
    </div>
  )
}
