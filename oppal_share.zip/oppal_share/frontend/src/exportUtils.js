// Dashboard export — deliberately DEPENDENCY-FREE.
//
// No html2canvas / jsPDF / xlsx libraries: this build must work on an air-
// gapped or proxy-restricted network where `npm install` of anything new is
// not an option, and a governed analytics tool should not need to ship a
// third-party rasteriser to hand someone a picture of their own chart.
//
// Everything here uses only browser primitives:
//   * PNG  — clone the live <svg>, inline the styles the browser computed,
//            paint it into a <canvas>, read it back as a PNG blob.
//   * HTML — embed those same serialised SVGs (plus the underlying data as a
//            real table) into one self-contained file with a print stylesheet,
//            so "Save as PDF" from the browser print dialog produces a clean
//            document with no extra tooling.

const XMLNS = 'http://www.w3.org/2000/svg'

// Attributes recharts leaves to CSS. If we serialise the SVG without copying
// these, exported text renders black-on-black in dark theme or vanishes.
const TEXT_PROPS = ['fill', 'font-size', 'font-family', 'font-weight',
                    'text-anchor', 'opacity']
const SHAPE_PROPS = ['fill', 'stroke', 'stroke-width', 'stroke-dasharray',
                     'opacity', 'fill-opacity', 'stroke-opacity']

function inlineStyles(srcEl, dstEl) {
  const src = srcEl.querySelectorAll('*')
  const dst = dstEl.querySelectorAll('*')
  for (let i = 0; i < src.length && i < dst.length; i++) {
    const cs = window.getComputedStyle(src[i])
    const tag = src[i].tagName.toLowerCase()
    const props = (tag === 'text' || tag === 'tspan') ? TEXT_PROPS : SHAPE_PROPS
    let style = ''
    for (const p of props) {
      const v = cs.getPropertyValue(p)
      if (v && v !== 'none' && v !== 'normal') style += `${p}:${v};`
    }
    if (style) dst[i].setAttribute('style', style)
  }
}

// Returns a standalone SVG string for a rendered chart, or null.
export function serializeChartSvg(container, { background } = {}) {
  const svg = container?.querySelector('svg')
  if (!svg) return null
  const box = svg.getBoundingClientRect()
  const w = Math.max(1, Math.round(Number(svg.getAttribute('width')) || box.width))
  const h = Math.max(1, Math.round(Number(svg.getAttribute('height')) || box.height))

  const clone = svg.cloneNode(true)
  clone.setAttribute('xmlns', XMLNS)
  clone.setAttribute('width', w)
  clone.setAttribute('height', h)
  clone.setAttribute('viewBox', svg.getAttribute('viewBox') || `0 0 ${w} ${h}`)
  inlineStyles(svg, clone)

  // Charts are drawn for a themed page; on white paper they need their own
  // opaque backdrop or a dark theme exports as an unreadable dark block.
  if (background) {
    const rect = document.createElementNS(XMLNS, 'rect')
    rect.setAttribute('x', 0); rect.setAttribute('y', 0)
    rect.setAttribute('width', w); rect.setAttribute('height', h)
    rect.setAttribute('fill', background)
    clone.insertBefore(rect, clone.firstChild)
  }
  return { svg: new XMLSerializer().serializeToString(clone), width: w, height: h }
}

function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  // Revoke on the next turn: revoking synchronously can cancel the download
  // in some browsers before it has started reading the blob.
  setTimeout(() => URL.revokeObjectURL(url), 10000)
}

export function safeFilename(s, fallback = 'dashboard') {
  const cleaned = String(s || '').replace(/[^\w\d\-. ]+/g, '').trim()
    .replace(/\s+/g, '-').slice(0, 60)
  return cleaned || fallback
}

// PNG of one chart. Rasterised at 2x for a legible image in a deck.
export function exportPng(container, filename, { scale = 2 } = {}) {
  return new Promise((resolve, reject) => {
    const ser = serializeChartSvg(container, { background: '#ffffff' })
    if (!ser) { reject(new Error('no chart found to export')); return }
    const img = new Image()
    // Data URL (not a blob URL) keeps the canvas untainted, so toBlob works.
    const encoded = window.btoa(unescape(encodeURIComponent(ser.svg)))
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas')
        canvas.width = ser.width * scale
        canvas.height = ser.height * scale
        const ctx = canvas.getContext('2d')
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(0, 0, canvas.width, canvas.height)
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        canvas.toBlob(b => {
          if (!b) { reject(new Error('canvas encoding failed')); return }
          triggerDownload(b, `${safeFilename(filename, 'chart')}.png`)
          resolve(true)
        }, 'image/png')
      } catch (e) { reject(e) }
    }
    img.onerror = () => reject(new Error('could not rasterise the chart'))
    img.src = `data:image/svg+xml;base64,${encoded}`
  })
}

const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')

function dataTable(spec) {
  const cols = spec?.columns, rows = spec?.rows
  if (!Array.isArray(cols) || !Array.isArray(rows) || !cols.length) return ''
  const head = cols.map(c => `<th>${esc(c)}</th>`).join('')
  // Cap the embedded table: an export is a document, not a data dump, and a
  // 50k-row table would make the file unopenable in a browser.
  const capped = rows.slice(0, 500)
  const body = capped.map(r =>
    `<tr>${(Array.isArray(r) ? r : [r]).map(v => `<td>${esc(v)}</td>`).join('')}</tr>`
  ).join('')
  const note = rows.length > capped.length
    ? `<p class="note">Showing first ${capped.length} of ${rows.length} rows.</p>`
    : ''
  return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>${note}`
}

const PRINT_CSS = `
  :root { color-scheme: light; }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 28px; background: #fff; color: #1b2733;
         font: 14px/1.5 -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
  h1 { font-size: 21px; margin: 0 0 2px; color: #1F3864; }
  .meta { color: #5b6b79; font-size: 12px; margin-bottom: 18px; }
  .art { border: 1px solid #d8e0e8; border-radius: 8px; padding: 14px;
         margin: 0 0 16px; page-break-inside: avoid; break-inside: avoid; }
  .art h2 { font-size: 15px; margin: 0 0 8px; color: #2E74B5; }
  .badge { display: inline-block; font-size: 10.5px; letter-spacing: .04em;
           text-transform: uppercase; color: #5b6b79; border: 1px solid #d8e0e8;
           border-radius: 999px; padding: 1px 8px; margin-left: 6px; }
  .chart { overflow: hidden; margin: 6px 0 10px; }
  .chart svg { max-width: 100%; height: auto; }
  table { border-collapse: collapse; width: 100%; font-size: 11.5px; }
  th, td { border: 1px solid #dfe6ec; padding: 4px 7px; text-align: left; }
  th { background: #f4f7fa; }
  .note { color: #5b6b79; font-size: 11px; margin: 4px 0 0; }
  .lineage { color: #5b6b79; font-size: 11px; margin-top: 6px;
             font-family: ui-monospace, Menlo, Consolas, monospace; }
  footer { margin-top: 22px; border-top: 1px solid #d8e0e8; padding-top: 10px;
           color: #5b6b79; font-size: 11px; }
  .hint { background: #eef4fb; border: 1px solid #cfe0f3; border-radius: 6px;
          padding: 8px 10px; font-size: 12px; margin-bottom: 16px; }
  @media print { .hint { display: none; } body { padding: 0; } }
  @page { margin: 14mm; }
`

/**
 * One self-contained .html file: charts as inline SVG, data as real tables,
 * print stylesheet included. Opens anywhere, needs no server, and the
 * browser's own "Save as PDF" turns it into a clean PDF — which is why no
 * PDF library is bundled.
 */
export function exportDashboardHtml({ name, owner, artifacts, containers }) {
  const when = new Date().toLocaleString()
  const blocks = (artifacts || []).map((a, i) => {
    const el = containers?.[a.id]
    const ser = el ? serializeChartSvg(el, { background: '#ffffff' }) : null
    const title = a.spec?.title || a.spec?.question || `${a.type} ${i + 1}`
    return `
    <section class="art">
      <h2>${esc(title)}<span class="badge">${esc(a.type)}</span></h2>
      ${ser ? `<div class="chart">${ser.svg}</div>` : ''}
      ${dataTable(a.spec)}
      ${a.lineage_ref ? `<div class="lineage">lineage: ${esc(a.lineage_ref)}</div>` : ''}
    </section>`
  }).join('\n')

  const html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${esc(name)} — OpPal dashboard</title>
<style>${PRINT_CSS}</style></head>
<body>
  <h1>${esc(name)}</h1>
  <div class="meta">OpPal dashboard export${owner ? ` · owner ${esc(owner)}` : ''}
    · ${esc(when)} · ${(artifacts || []).length} artifact(s)</div>
  <div class="hint">Self-contained file — charts and data are embedded. Use your
    browser's Print → “Save as PDF” for a PDF copy. (This note is hidden when printed.)</div>
  ${blocks || '<p class="note">This dashboard has no artifacts.</p>'}
  <footer>Figures carry lineage back to the governed query that produced them.
    Exported copies are point-in-time and are not refreshed.</footer>
</body></html>`

  triggerDownload(new Blob([html], { type: 'text/html;charset=utf-8' }),
                  `${safeFilename(name)}.html`)
  return true
}

export default { exportPng, exportDashboardHtml, serializeChartSvg,
                 safeFilename }
